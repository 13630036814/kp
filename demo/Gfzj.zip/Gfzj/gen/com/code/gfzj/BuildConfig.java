/** Automatically generated file. DO NOT MODIFY */
package com.code.gfzj;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}