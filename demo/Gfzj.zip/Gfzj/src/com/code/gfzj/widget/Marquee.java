/**
 * 
 */
package com.code.gfzj.widget;

import android.view.View;

/**
 * @author mrcola
 *
 */
public interface Marquee {
	public void clean();
	public void update(MarqueeInfo info,View v);
}
