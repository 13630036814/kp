/**
 * 
 */
package com.code.gfzj.widget;

/**
 * 走马灯效果的参数
 * @author mrcola
 *
 */
public class MarqueeInfo {
	public String name;
	/**
	 * 日涨跌幅超过
	 */
	public String ppGe;
	public String code;
	/**
	 * 换手率
	 */
	public String exGe;
	/**
	 * 两个信息间的间隔
	 */
	public int interval = 0;
	public int color = 0;
}
