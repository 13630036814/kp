/**
 * 
 */
package com.code.gfzj.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * @author mrcola
 * 
 */
public class MarqueeTextView extends LinearLayout implements Marquee{
	protected Context context;
	protected TextView tv, tv2;

	// private Animation myAnimation_Translate;

	public MarqueeTextView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	public MarqueeTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	private void init() {
		LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
		this.setLayoutParams(params);
		this.setOrientation(1);
		// addView();
	}

	public View addView(MarqueeInfo info) {

		tv = new TextView(context);
		tv.setText(info.name + "  " + info.code);
		tv.setTextSize(15);
		// tv.setTextColor(info.color);
		tv2 = new TextView(context);
		tv2.setText(info.exGe + "  (" + info.ppGe + ")");
		tv2.setTextColor(info.color);
		tv2.setTextSize(15);
		this.addView(tv);
		this.addView(tv2);
		Animation myAnimation_Translate = new TranslateAnimation(info.interval,
				500, 0, 0);
		myAnimation_Translate.setDuration(10000);
		myAnimation_Translate.setRepeatCount(-1);// 设置重复次数
		// myAnimation_Translate.setStartOffset(1000);
		myAnimation_Translate.setInterpolator(new LinearInterpolator());
		this.startAnimation(myAnimation_Translate);
		return this;
	}

	public void clean() {
		this.clearAnimation();
	}

	@Override
	public void update(MarqueeInfo info, View v) {
		// TODO Auto-generated method stub
		
	}

}
