/**
 * 
 */
package com.code.gfzj.data.bean;

/**
 * @author cola
 * 
 */
public class VolumeItem {
	public String price = "";
	public String time = "";
	public String volume = "";
	public String level = "";
}
