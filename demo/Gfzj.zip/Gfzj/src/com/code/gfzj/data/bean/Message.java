package com.code.gfzj.data.bean;

/**
 * 欢迎加入QQ开发群讨论：88130145
 * 
 * @Description:
 * @author: zhuanggy
 * @see:   
 * @since:      
 * @copyright © 35.com
 * @Date:2013-10-14
 */
public class Message {

	private String groupName;
	private int groupId;
	private String info = "";
	/**
	 * 涨跌幅
	 */
	public String stockRang = "";
	/**
	 * 在本组中的位置
	 */
	public int order = 0;
	public String mTitle = "";
	
	/**
	 * 在
	 * @return
	 */
	public String mField1="",mField2="",mField3="",mField4="";

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
