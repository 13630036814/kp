/**
 * 
 */
package com.code.gfzj.base;

import com.code.gfzj.desktop.Desktop.onChangeViewListener;
import com.code.gfzj.widget.FlipperLayout.OnOpenListener;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;

/**
 * 各主界面功能的父类
 * @author mrcola
 *
 */
public abstract class FlipChildView {
	protected OnOpenListener mOnOpenListener;
	protected Activity mActivity;
	protected LayoutInflater mLayoutInflater;
	
	
	public FlipChildView(Activity mActivity){
		this.mActivity = mActivity;
		mLayoutInflater = LayoutInflater.from(mActivity);

	}
	abstract public View getView();
	abstract public void findViewById() ;
	abstract public void init();
	abstract public void setListener();
	public void setOnOpenListener(OnOpenListener onOpenListener) {
		mOnOpenListener = onOpenListener;
	}
	
}
