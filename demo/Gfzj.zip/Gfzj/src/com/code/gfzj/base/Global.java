package com.code.gfzj.base;



import java.util.Vector;

import android.app.Activity;
import android.content.Context;

import com.code.gfzj.ui.widget.Events;
import com.code.gfzj.util.Functions;
import com.code.gfzj.util.Rectangle;
//import com.gf.model.quotations.ZXInfo;

public class Global {
    public static Vector<Activity> WinContainer = new Vector<Activity>();
    public static Context basewindow;
   
//	public static ZXInfo[] mystocks;//自选股列表
	
    //-----------屏幕尺寸(自适应)
	public static int HARD_WIDTH_PIXELS;
	public static int HARD_HEIGHT_PIXELS;
	public static float density = 1;//标准值
    public static int arg0;//w
    public static int arg1;//h
    public static int arg2;//font
    public static int arg3;//w
    public static float scale_h;
    public static float scale_w;
    public static float scale_h2;//
    public static float scale_icon;//九宫格
    public static int fullScreenWidth = 0;
    public static int fullScreenHeight = 0;
    public static int fullScreenWidthPhysical = 0;
    public static int fullScreenHeightPhysical = 0;
    public static int fullScreenWidthDeviceNoRotate = 0;
    public static int fullScreenHeightDeviceNoRotate = 0;
    
	public static boolean isLandscape(){
		return fullScreenWidth>fullScreenHeight;
	}

    public static int beginY = 0;
    
    public static int gameFontHeight = 20;    
    public static int gameFontHeight16 = 0;   
    public static int subMenuFontWidth = 0;    
    public static int titleFontWidth = 0;    
    public static int bottomFont = 0; 
    public static int stockPondFontBig = 0;    
    public static int stockPondFontSmall = 0;    
    public static int stockPondFontNormal = 0;    
    public static int stockPondFontMini = 0;    
    public static int gameFontHuge = 0;          
    public static int MK_Height;//分时K线 title 的高度    
    //public static Bitmap zjlx_Bg = null;
    //public static Bitmap zjlxBg_Down = null;
    //public static Bitmap zjlx_Bg2 = null;
    //public static Bitmap zjlxBg2_Down = null;    
    //public static Rectangle rec_tab = null;
    public static int Advt_H = 0; //主菜单广告栏高度
    public static int Notice_H = 0; //主菜单公告栏高度
    public static int BottomButton_H = 0;
    public static int BottomMenu_H = 0; // 处理魅族手机
    public static int Title_H = 0; //标题栏高度
    public static int mTaskHeight = 0;//?
    public static int titlebarH = 0;    

    public static int TableHead_H = 0;    
    public static int TableCell_H = 0;
    
    public static Rectangle recTable = null;//ax 列表内容区域
    public static Rectangle rec_btn2 = new Rectangle(0, 0, 110, 30);//自选
    public static Rectangle rec_FlipperCtrl = null;    
    
    public static boolean debug = true;    
    

	//公告url
	public static String noticeUrl = "http://211.154.151.96:8080/";
	//广告资源定义
	public static String advtUrl = "http://sjzq.gf.com.cn:8080/StockNews/adv/advt.json";
	public static String ad1_img = "";
	public static String ad2_img = "";
	public static String ad3_img = "";
	public static String ad1_title = "";	
	public static String ad2_title = "";
	public static String ad3_title = "";	
	public static String ad1_url = "";
	public static String ad2_url = "";
	public static String ad3_url = "";	
	  
    public static void setGprsChoice(int value){
    	//GlobeAdapter.GprsChoice = value;
    }
    public static int getGprsChoice(){
    	//return GlobeAdapter.GprsChoice;
    	return 0;
    }    
    //BIZ
    public static final String URL_F10_TAIL = "/TS/infoedit.do?op=F10&gpdm=";
    
    //MESSAGE
	public static final int MSG = Events.EVENT_MAX + 10;	
	public static final int MSG_ACTION                         = MSG  - 1;
	//public static final int MSG_NETWORK_START           = MSG + 0;
	public static final int MSG_NETWORK                     = MSG + 1;
	public static final int MSG_REQUEST                       = MSG + 2;
	public static final int MSG_LOADING                       = MSG + 3;
	public static final int MSG_LOADING_OK                    = MSG + 4;
	public static final int MSG_LOGIN_OK                      = MSG + 5;		
	//public static final int MSG_PROGRESS_LOADING              = MSG + 6;
	public static final int MSG_SEARCH_UPDATE                 = MSG + 7;	
	public static final int MSG_MYSTOCK_EDIT                  = MSG + 8;
	public static final int MSG_MYSTOCK_UPDATE                = MSG + 9;
	public static final int MSG_MESSAGE                       = MSG + 10;	
	public static final int MSG_DIALOG_ONDISMISS              = MSG + 11;	
	public static final int MSG_PROGRESS_FINISH               = MSG + 12;	
	public static final int MSG_CLIENT_SEND_QUIZ              = MSG + 13;	
	public static final int MSG_LOADING_AD_OK                 = MSG + 14;	
	//public static final int MSG_FEEDBBACK_ITEM_OK             = MSG + 15;	
	public static final int MSG_PING_SITE_OK                  = MSG + 16;
	public static final int MSG_BACKUP                        = MSG + 17;
	public static final int MSG_SaveLogin                     = MSG + 18;
	public static final int MSG_MAX = MSG_CLIENT_SEND_QUIZ;  
	public static final int MSG_TimeOutToast                 = MSG + 19;
	//public static final int MSG_loadStockCode                 = MSG + 20;
	//---------------------行情分时K线配色-------------begin
	//public static int frameLineColor = 0xFFAA0000;
	public static int frameLineColor = 0xFF2C2C2C;
	//---------------------行情分时K线配色-------------end

	//---------------------K线分时数据&控制-----------begin
	public static int hqCurrentPage = 0;//行情界面当前页
	public static int stocklistFuncid = -1;//行情列表当前功能
	public static int klineFuncid = -1;    //k线当前功能
    public static String stockCode = "";
    public static String stockName = "";
    public static int    mStockMarket;
    public static int    mStockIndex;    
//  public static String[] stockCodeArray = null;
//  public static int stockCodeArrayIndex = 0;   	
	//处理横竖屏切换时,为兼容4.0
	public static void resetQuotationState(){
		hqCurrentPage = 0;
		Functions.removeCashe(SystemConst.WIN_QUOTATION);	
		Functions.removeCashe(SystemConst.WIN_QUOTATION+1);
	}	
	//其他
	public static void resetBizWindowState(int bizId){
		stocklistFuncid = -1;
		Functions.removeCashe(bizId);	
	}		
	//---------------------K线分时数据&控制-----------end
	
	//跑马灯数据
    public static String[][] mIndexs_value = null;
    public static int[][] mIndexs_color = null;	
	
	//刷新时间
    public static int REFRESH_TIME_TIMESHARE = 15; //分时(K线)刷新时间
    //public static int REFRESH_TIME_KLINE = 15;    //K线刷新时间
    public static int REFRESH_TIME_LIST = 15;     //行情列表刷新时间	
    public static int REFRESH_TIME_FLASH = 15;    //跑马灯刷新时间
    
    //tips信息控制
    private static boolean bShowListTips = true;//显示列表tips 
    private static boolean bShowHqTips = true;//显示行情tips

    //是否交易已经登录
    public static boolean bTradeLoginOk=false;
    
    private static String[] mFeedbackItems=null;
    //是否需要同步上传自选股
  /*  private static boolean bNeedUploadMyStocks=false;
    private static long uploadTime=0;
    */
    
    //GPS定位数据
    private static double longitude=0.0;//经度
    private static double latitude=0.0;//纬度
    private static String address="";//地址
    
    //MA周期
    private static int macycle1=5;
    private static int macycle2=10;
    private static int macycle3=30;
    
    //服务器日期
    private static int serverDate;

	public static String[] getmFeedbackItems() {
		return mFeedbackItems;
	}
	public static void setmFeedbackItems(String[] mFeedbackItems) {
		Global.mFeedbackItems = mFeedbackItems;
	}
	public static boolean isbShowListTips() {
		return bShowListTips;
	}
	public static void setbShowListTips(boolean bShowListTips) {
		Global.bShowListTips = bShowListTips;
	}
	public static boolean isbShowHqTips() {
		return bShowHqTips;
	}
	public static void setbShowHqTips(boolean bShowHqTips) {
		Global.bShowHqTips = bShowHqTips;
	}
	//--同步--begin---
	/*public static boolean isbNeedUploadMyStocks() {
		if(bNeedUploadMyStocks && uploadTime > 0)
			return true;
		else
			return false;
	}
	public static void setbNeedUploadMyStocks() {
		Global.bNeedUploadMyStocks = true;
		Global.uploadTime = System.currentTimeMillis()-5*1000;//立刻发送上传请求
	}
	public static void resetbNeedUploadMyStocks() {
		Global.bNeedUploadMyStocks = false;
		Global.uploadTime = 0;
	}	
	public static void resetUploadTime(){
		uploadTime=System.currentTimeMillis();
	}
	public static long getUploadTime() {
		return uploadTime;
	}	*/
	//--同步--end---
	public static double getLongitude() {
		return longitude;
	}
	public static void setLongitude(double longitude) {
		Global.longitude = longitude;
	}
	public static double getLatitude() {
		return latitude;
	}
	public static void setLatitude(double latitude) {
		Global.latitude = latitude;
	}
	public static String getAddress() {
		return address;
	}
	public static void setAddress(String address) {
		Global.address = address;
	}
	public static int getServerDate() {
		return serverDate;
	}
	public static void setServerDate(int serverDate) {
		Global.serverDate = serverDate;
	}
	public static int getMacycle1() {
		return macycle1;
	}
	public static void setMacycle1(int macycle1) {
		Global.macycle1 = macycle1;
	}
	public static int getMacycle2() {
		return macycle2;
	}
	public static void setMacycle2(int macycle2) {
		Global.macycle2 = macycle2;
	}
	public static int getMacycle3() {
		return macycle3;
	}
	public static void setMacycle3(int macycle3) {
		Global.macycle3 = macycle3;
	}
	/**系统默认字体大小*/
	public final static int textSize = 20;
}
