package com.code.gfzj.base;
/**
 * 跟业务界面相关的定义
 *
 */

public interface SystemConst {
	//业务bizID----------------begin
	int WIN_INIT = 1000; // 启动界面	
	int WIN_LOGIN = 1100; // 短信发送和手机登录界面	
	int WIN_PUBNOTICE = 1200; // 公告界面
	int WIN_MAINMENU = 2100; // 主菜单
	int WIN_MYSTOCK = 2200; // 自选股票
	int WIN_STOCKLIST = 2300; // 行情
	int WIN_STOCKLIST_CW = 2301; // 行情(场外基金)
	int WIN_QUOTATION = 2600; // 行情详细 2600-2601
	                          //2600 分时  2601 K线 
	int WIN_SEARCHSTOCK = 2700; // 查股票
	int WIN_EDITSTOCK = 2800; // 编辑自选股票	
	
	int WIN_TRADE_LOGIN = 3000; //交易登录
	int WIN_TRADE_MAIN = 3001; //交易主菜单界面
	//业务bizID----------------end
	
	int MAIN_PAGE = 1;//首页 0宫格主菜单 1自选股 
	
	//行情列表子界面（functionbar子按钮）
	int FUNC_INDEXS = 1;          //行情走势
//	int FUNC_ALLSTOCK = 2;        //综合排名
	int FUNC_GLOBALLIST = 2;      //全球指数
	int FUNC_ALIST = 3;           //沪深A股
	int FUNC_BLIST = 4;           //沪深B股
	int FUNC_FUNDLIST = 5;        //基金
	int FUNC_GROWTHLIST = 6;      //创业板
	int FUNC_SMALLLIST = 7;       //中小板
	int FUNC_INDEXLIST = 8;       //指数
	int FUNC_BONDLIST = 9;        //债券
	int FUNC_WARRANTLIST = 10;    //权证
	
	int FUNC_CWFUNDLIST = 11;    //场外基金（非functionbar子按钮）
	
	//K线子界面（functionbar子按钮）
	int FUNC_DAY = 1;             //日K
	int FUNC_WEEK = 2;            //周K
	int FUNC_MONTH = 3;           //月K
	int FUNC_5MINUTES = 4;        //5分钟
	int FUNC_15MINUTES = 5;       //15分钟
	int FUNC_30MINUTES = 6;       //30分钟
	int FUNC_60MINUTES = 7;       //60分钟	
 
 
    
    //持久化数据key
    //advt
    String AD1_IMG = "ad1_img";
    String AD2_IMG = "ad2_img";
    String AD3_IMG = "ad3_img";
    String AD1_TITLE = "ad1_title";
    String AD2_TITLE = "ad2_title";
    String AD3_TITLE = "ad3_title";    
    String AD1_URL = "ad1_url";   
    String AD2_URL = "ad2_url"; 
    String AD3_URL = "ad3_url";
    //新功能指引
    String NEW_FUNCTION = "new_function";
    //操作指引
    String OPERATION_HQ_TIPS = "operation_hq_tips";
    String OPERATION_LIST_TIPS = "operation_list_tips";
    //系统
	String SYS_KEY_PHONE = "sys_key_phone_num";
	String SYS_KEY_LOGINED_PHONE = "sys_key_logined_phone";
	String SYS_KEY_PASS = "sys_key_phone_password"; 
	String SYS_RZ_URL = "sys_rz_url"; 
	String SYS_HQ_URL = "sys_hq_url"; 
	String SYS_PUB_NOTICE = "sys_pub_notice";
	String SYS_SYNC_GETMYSTOCKS = "sys_sync_getmystocks";
	//反馈
	String SYS_FEEDBACK_HIS = "sys_feedback_his";
	//ma参数值
	String SYS_MA_PARAM1 = "sys_ma_param1"; 
	String SYS_MA_PARAM2 = "sys_ma_param2"; 
	String SYS_MA_PARAM3 = "sys_ma_param3"; 
}
