package com.code.gfzj;

import com.code.gfzj.base.Global;
import com.code.gfzj.desktop.Desktop;
import com.code.gfzj.desktop.Desktop.onChangeViewListener;
import com.code.gfzj.ui.InformationMenu;
import com.code.gfzj.ui.Sudoku;
import com.code.gfzj.util.View_Util;
import com.code.gfzj.widget.FlipperLayout;
import com.code.gfzj.widget.FlipperLayout.OnOpenListener;
import com.code.gfzj.widget.MarqueeInfo;
import com.code.gfzj.widget.MarqueeTextView;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

public class MainActivity extends Activity implements OnOpenListener,onChangeViewListener{
	private FlipperLayout mRoot;
	private BaseApplication mApplication;
	private Desktop mDesktop;
	private Sudoku sdk;
	private InformationMenu mInformationMenu;
	private LinearLayout newStock;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
//		setContentView(R.layout.activity_main);
		init();
		setListener();
	}

	public void init(){
		mApplication = (BaseApplication) getApplication();
		mRoot = new FlipperLayout(this);
		LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT);
		mRoot.setLayoutParams(params);
		mDesktop = new Desktop(mApplication, this);	
		sdk = new Sudoku(this);
		sdk.setOnChangeViewListener(this);
		sdk.setOnOpenListener(this);
		
		mInformationMenu = new InformationMenu(
				MainActivity.this);
		mInformationMenu.setOnOpenListener(MainActivity.this);
		mInformationMenu.setOnChangeViewListener(this);
		
		mRoot.addView(mDesktop.getView(), params);
		mRoot.addView(sdk.getView(), params);
		setContentView(mRoot);
		findView();
		windowInit();
	}
	
	private void findView(){
//		newStock = (LinearLayout) findViewById(R.id.desktop_top_newstock);
//		LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT,
//				LayoutParams.WRAP_CONTENT);
//		MarqueeTextView mtv = new MarqueeTextView(this);
//		mtv.setLayoutParams(params);
//		MarqueeInfo info = new MarqueeInfo();
//		info.code = "12345";
//		info.name = "上证股";
//		info.exGe = "68%";
//		info.ppGe = "344";
//		info.interval = -200;
//		info.color = Color.BLUE;
//		mtv.addView(info);
//		newStock.addView(mtv);
//		
//		MarqueeTextView mtv2 = new MarqueeTextView(this);
//		mtv2.setLayoutParams(params);
////		MarqueeInfo info = new MarqueeInfo();
//		info.code = "123453333";
//		info.name = "上证股大";
//		info.exGe = "68%";
//		info.ppGe = "34422";
//		info.interval = -180;
//		info.color = Color.RED;
//		mtv2.addView(info);
//		newStock.addView(mtv2);
		
//		new Handler().postAtTime(r, uptimeMillis);
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void open() {
		// TODO Auto-generated method stub
		if (mRoot.getScreenState() == FlipperLayout.SCREEN_STATE_CLOSE) {
			mRoot.open();
		}
	}

	private void setListener() {
		mDesktop.setOnChangeViewListener(new onChangeViewListener() {

			@Override
			public void onChangeView(int arg0) {
				// TODO Auto-generated method stub
				switch (arg0) {
				case View_Util.Information:
					if (mInformationMenu == null) {
						mInformationMenu = new InformationMenu(
								MainActivity.this);
						mInformationMenu.setOnOpenListener(MainActivity.this);
					}
					mRoot.close(mInformationMenu.getView());
					break;

				case View_Util.main:
					mRoot.close(sdk.getView());
					break;
				case View_Util.mystock:
					mRoot.close(sdk.getView());
					break;
				}
			}

		});
	}
	
	public int orientation;
	public void windowInit() {
        //Global.density = getDensity();
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		//使用标准值
		//Global.density = dm.density;		
		Global.scale_w = 1;
		Global.scale_h = 1;
		Global.fullScreenWidth = dm.widthPixels;
		Global.fullScreenHeight = dm.heightPixels - Global.beginY;
		Global.HARD_WIDTH_PIXELS = 320;//dm.widthPixels;
		Global.HARD_HEIGHT_PIXELS = 480;//dm.heightPixels;		
		
		if (Global.fullScreenHeight >= Global.fullScreenWidth)
			{orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;}
		else
			{
			if(orientation!=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
//				StatService.onEvent(this, "8", "横屏");
			}
			orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;}
		if (orientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
			Global.arg0 = Global.fullScreenWidth * 100 / Global.HARD_WIDTH_PIXELS;
			Global.arg1 = (Global.fullScreenHeight + Global.beginY) * 100 / Global.HARD_HEIGHT_PIXELS;
			Global.arg2 = Global.arg1;
			Global.scale_w = (float) Global.fullScreenWidth / Global.HARD_WIDTH_PIXELS;
			Global.scale_h = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_HEIGHT_PIXELS;
			Global.scale_h2 = Global.scale_h;
			Global.scale_icon = (float) Global.fullScreenWidth / Global.HARD_HEIGHT_PIXELS;
			// Globe.arg00 = Globe.fullScreenWidth*1000/480;
		} else {
			Global.arg0 = Global.fullScreenWidth * 100 / Global.HARD_WIDTH_PIXELS;
			Global.arg1 = (Global.fullScreenHeight + Global.beginY) * 100 / Global.HARD_HEIGHT_PIXELS;
			Global.arg2 = (Global.fullScreenHeight + Global.beginY) * 100 / Global.HARD_WIDTH_PIXELS;
			Global.arg3 = Global.fullScreenWidth * 100 / Global.HARD_HEIGHT_PIXELS;
			Global.scale_w = (float) Global.fullScreenWidth / Global.HARD_WIDTH_PIXELS;
			Global.scale_h = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_HEIGHT_PIXELS;
			Global.scale_h2 = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_WIDTH_PIXELS;
			Global.scale_icon = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_HEIGHT_PIXELS;
		
		}
		Global.MK_Height = 48 * Global.arg2 / 100;
	}

	@Override
	public void onChangeView(int arg0) {
		// TODO Auto-generated method stub
		switch (arg0) {
		case View_Util.Information:
			
			mRoot.close(mInformationMenu.getView());
			mInformationMenu.setAlpha(255);
			break;
		case View_Util.mystock:
			mRoot.close(sdk.getView());
			break;
		}
	}
	
	
}
