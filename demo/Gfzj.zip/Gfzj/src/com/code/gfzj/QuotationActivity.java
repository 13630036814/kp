/**
 * 
 */
package com.code.gfzj;

import java.util.ArrayList;
import java.util.List;

import com.code.gfzj.base.Global;
import com.code.gfzj.data.bean.Message;
import com.code.gfzj.data.bean.VolumeItem;
import com.code.gfzj.ui.adapter.FiveRangeAdapter;
import com.code.gfzj.ui.adapter.MailAdapter;
import com.code.gfzj.ui.adapter.StockDetailInfoAdapter;
import com.code.gfzj.ui.adapter.VolumeAdapter;
import com.code.gfzj.ui.coustomviews.stockViews.MailListView;
import com.code.gfzj.ui.menu.BottomToolBar;
import com.code.gfzj.ui.widget.TabIndicator;
import com.code.gfzj.ui.widget.WorkSpace;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * @author cola
 * 
 */
public class QuotationActivity extends Activity implements OnClickListener{
	private TabIndicator tabIndicator;
	private WorkSpace main_workspace;
	private BottomToolBar menu;
	private RelativeLayout mPopMenu;
	/**
	 * 五档里的变量
	 */
	private ListView listViewBuy;
	private ListView listViewSell;
	private List<VolumeItem> buyList;
	private FiveRangeAdapter buyAdapter;
	private List<VolumeItem> sellList;
	private FiveRangeAdapter sellAdapter;
	/**
	 * 成交量的两个变量
	 */
	private ListView listViewVolume;
	private List<VolumeItem> volumList;
	private VolumeAdapter volumeAdapter;
	/**
	 * 五档和成交量的容器
	 */
	private RelativeLayout container;
	public int orientation = 0;
	/**
	 * 成交量顶部的按钮
	 */
	private TextView fiverange;
	private TextView vVolume;
	
	/**
	 * 第三页的变量
	 */
	private MailListView mListView;
	private StockDetailInfoAdapter mAdapter;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.quotation_layout);
		init();
		setListener();
	}

	public void init() {
		menu = (BottomToolBar) findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) findViewById(R.id.home_ugc);
		menu.setPopMenur(mPopMenu);
		((TextView) findViewById(R.id.title)).setText("股票详情");
		Global.hqCurrentPage = 0;
		fiverange = (TextView) findViewById(R.id.fiverange);
		vVolume = (TextView) findViewById(R.id.vvolume);
		container = (RelativeLayout) findViewById(R.id.volumeContainer);	
		listViewBuy = (ListView) container.findViewById(R.id.listview_buy);
		listViewSell = (ListView) container.findViewById(R.id.listview_sell);
		listViewVolume = (ListView) findViewById(R.id.listview_volume);	

		mListView = (MailListView) findViewById(R.id.stock_listview);
		
		FrameLayout pFrameLayout = (FrameLayout) findViewById(R.id.mainmenu_progress);		
		tabIndicator= new TabIndicator(this, 3, 15, 8);		
		pFrameLayout.addView(tabIndicator);	
		positionInit();
		main_workspace = (WorkSpace) findViewById(R.id.mainmenu_container);
		main_workspace.setWindow(this);
		//处理横竖屏切换时,为兼容4.0
		main_workspace.setToScreen(Global.hqCurrentPage);
		
		volumList = new ArrayList<VolumeItem>();
		sellList = new ArrayList<VolumeItem>();
		buyList = new ArrayList<VolumeItem>();
		
		for(int i = 0; i < 8; i++){
			VolumeItem vi = new VolumeItem();
			vi.level = "S";
			vi.price = i + "101";
			vi.time = "10:15";
			vi.volume = "2222";
			volumList.add(vi);
			vi.time = "@卖";
			sellList.add(vi);
			vi.time = "@买";
			buyList.add(vi);
		}
		volumeAdapter = new VolumeAdapter(this,volumList);
		sellAdapter = new FiveRangeAdapter(this,sellList);
		buyAdapter = new FiveRangeAdapter(this,buyList);
		listViewVolume.setAdapter(volumeAdapter);
		listViewBuy.setAdapter(buyAdapter);
		listViewSell.setAdapter(sellAdapter);
		fiverange.setTextColor(getResources().getColor(R.color.blue));
		container.getChildAt(2).setVisibility(View.INVISIBLE);
		
		List<Message> messages = new ArrayList<Message>();
//		for (int i = 0; i < 10; i++) {
			Message msg = new Message();
			msg.setGroupName("新闻");
			msg.mField1 = "新闻";
			msg.mField2 = "公司简介";
			msg.mField3 = "分红配送";
			msg.mField4 = "财务数据";
			msg.mTitle = "汽车之家 新闻";
			msg.setInfo(" [汽车之家 新闻]  近日在一次广汽乘用车的产品沟通会上我们了解到，2014年传祺品牌会陆续推出包括GA6、GA4、GS6三款全新车。此外中大型车和小型车的新平台也在研发当中。");
			messages.add(msg);
			
			Message msg2 = new Message();
			msg2.setGroupName("新闻");
			msg2.mTitle = "获取更多..";
			msg2.setInfo("请教网易新闻内容详情页图文混排及左右对齐是怎么做到的？");
			messages.add(msg2);
			
			Message msg3 = new Message();
			msg3.setGroupName("主营业务");
			msg3.mField1 = "股本结构";
			msg3.mField2 = "公司简介";
			msg3.mField3 = "十大股东";
			msg3.mField4 = "股东户数";
			msg3.mTitle = "汽车之家 新闻";
			msg3.setInfo(" [汽车之家 新闻]  近日在一次广汽乘用车的产品沟通会上我们了解到，2014年传祺品牌会陆续推出包括GA6、GA4、GS6三款全新车。此外中大型车和小型车的新平台也在研发当中。");
			messages.add(msg3);
			
			Message msg4 = new Message();
			msg4.setGroupName("主营业务");
			msg4.mTitle = "获取更多..";
			msg4.setInfo("请教网易新闻内容详情页图文混排及左右对齐是怎么做到的？");
			messages.add(msg4);
//		}

		mAdapter = new StockDetailInfoAdapter(this, messages, true);//第三个参数是：第一次填充listview时，分组是否展开

		mListView.setAdapter(mAdapter);
		mListView.setDivider(null);//getResources().getDrawable(R.drawable.line)
	}

	public void setListener() {
		vVolume.setOnClickListener(this);
		fiverange.setOnClickListener(this);
		
		((Button) findViewById(R.id.top_back)).setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
			
		});
	}
	
	private void positionInit() {

		int iBottomButton_H = 0;
		int iTaskHeight = 0;
		// 横竖屏计算
		if (orientation == 0)// 竖
		{
			if (Global.BottomMenu_H > 35) {
				iBottomButton_H = Global.BottomButton_H + Global.BottomMenu_H - 27;
			} else {
				iBottomButton_H = Global.BottomButton_H;
			}
			iTaskHeight = Global.mTaskHeight;
		} else {
			iBottomButton_H = 0;
			iTaskHeight = 0;
		}

//		tabIndicator.setPosition(Global.fullScreenHeight - iTaskHeight - iBottomButton_H - 12);
		tabIndicator.setPosition(Global.fullScreenHeight - 96);
	}	
	
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
    	int key = keyCode;
    	switch(key){
    	case KeyEvent.KEYCODE_BACK:
//            if(main_workspace.getCurScreen() == 2 && mWebView.canGoBack())
//            {
//            	mWebView.goBack();    
//        		return true;
//            }
//            this.setResult(onResult);
            break;
        case KeyEvent.KEYCODE_SEARCH:
            break;
       	case KeyEvent.KEYCODE_MENU:
   			break;
    	}
		return super.onKeyDown(keyCode, event);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if(fiverange.equals(v)){
			fiverange.setTextColor(getResources().getColor(R.color.blue));
			vVolume.setTextColor(getResources().getColor(R.color.white));
			int sum = container.getChildCount();
			if(sum == 3){
			container.getChildAt(1).setVisibility(View.VISIBLE);
			container.getChildAt(2).setVisibility(View.GONE);
			}
		}else if(vVolume.equals(v)){
//			int sum = container.getChildCount();
//			if(sum < 3){
//				View convertView = LayoutInflater.from(this).inflate(R.layout.fiverange, null);
				
//				container.getChildAt(1).setVisibility(View.GONE);
//				container.removeViewAt(1);
//				container.addView(convertView);
				
//				container.getChildAt(2).setVisibility(View.VISIBLE);
//			}else if(sum == 3){
				container.getChildAt(1).setVisibility(View.GONE);
				container.getChildAt(2).setVisibility(View.VISIBLE);
//				container.invalidate();
//			}
			fiverange.setTextColor(getResources().getColor(R.color.white));
			vVolume.setTextColor(getResources().getColor(R.color.blue));
		}
	}
	
	public void snapToScreen(){
		if (tabIndicator != null)
		{
			tabIndicator.postInvalidate();		
		    tabIndicator.setKind(main_workspace.getCurScreen());
		    Global.hqCurrentPage = main_workspace.getCurScreen();
		}
	}
}
