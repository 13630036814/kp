/**
 * 
 */
package com.code.gfzj.util;

import java.text.ParseException;

/**
 * @author duminghui
 * 
 */
public class StringUtils {
	/**
	 * <p>
	 * Checks if a String is empty ("") or null.
	 * </p>
	 * 
	 * <pre>
	 * StringUtils.isEmpty(null)      = true
	 * StringUtils.isEmpty("")        = true
	 * StringUtils.isEmpty(" ")       = false
	 * StringUtils.isEmpty("bob")     = false
	 * StringUtils.isEmpty("  bob  ") = false
	 * </pre>
	 * 
	 * <p>
	 * NOTE: This method changed in Lang version 2.0. It no longer trims the
	 * String. That functionality is available in isBlank().
	 * </p>
	 * 
	 * @param str
	 *            the String to check, may be null
	 * @return <code>true</code> if the String is empty or null
	 */
	public static boolean isEmpty(String str) {
		return str == null || str.length() == 0;
	}

	// Equals
	// -----------------------------------------------------------------------
	/**
	 * <p>
	 * Compares two Strings, returning <code>true</code> if they are equal.
	 * </p>
	 * 
	 * <p>
	 * <code>null</code>s are handled without exceptions. Two <code>null</code>
	 * references are considered to be equal. The comparison is case sensitive.
	 * </p>
	 * 
	 * <pre>
	 * StringUtils.equals(null, null)   = true
	 * StringUtils.equals(null, "abc")  = false
	 * StringUtils.equals("abc", null)  = false
	 * StringUtils.equals("abc", "abc") = true
	 * StringUtils.equals("abc", "ABC") = false
	 * </pre>
	 * 
	 * @see java.lang.String#equals(Object)
	 * @param str1
	 *            the first String, may be null
	 * @param str2
	 *            the second String, may be null
	 * @return <code>true</code> if the Strings are equal, case sensitive, or
	 *         both <code>null</code>
	 */
	public static boolean equals(String str1, String str2) {
		return str1 == null ? str2 == null : str1.equals(str2);
	}

	/**
	 * <p>
	 * Convert a <code>String</code> to a <code>long</code>, returning
	 * <code>zero</code> if the conversion fails.
	 * </p>
	 * 
	 * <p>
	 * If the string is <code>null</code>, <code>zero</code> is returned.
	 * </p>
	 * 
	 * <pre>
	 *   NumberUtils.toLong(null) = 0L
	 *   NumberUtils.toLong("")   = 0L
	 *   NumberUtils.toLong("1")  = 1L
	 * </pre>
	 * 
	 * @param str
	 *            the string to convert, may be null
	 * @return the long represented by the string, or <code>0</code> if
	 *         conversion fails
	 * @since 2.1
	 */
	public static long stringToLong(String str) {
		return stringToLong(str, 0L);
	}

	/**
	 * <p>
	 * Convert a <code>String</code> to a <code>long</code>, returning a default
	 * value if the conversion fails.
	 * </p>
	 * 
	 * <p>
	 * If the string is <code>null</code>, the default value is returned.
	 * </p>
	 * 
	 * <pre>
	 *   NumberUtils.toLong(null, 1L) = 1L
	 *   NumberUtils.toLong("", 1L)   = 1L
	 *   NumberUtils.toLong("1", 0L)  = 1L
	 * </pre>
	 * 
	 * @param str
	 *            the string to convert, may be null
	 * @param defaultValue
	 *            the default value
	 * @return the long represented by the string, or the default if conversion
	 *         fails
	 * @since 2.1
	 */
	public static long stringToLong(String str, long defaultValue) {
		if (str == null) {
			return defaultValue;
		}
		try {
			return Long.parseLong(str);
		} catch (NumberFormatException nfe) {
			return defaultValue;
		}
	}

	/**
	 * <p>
	 * Convert a <code>String</code> to an <code>int</code>, returning
	 * <code>zero</code> if the conversion fails.
	 * </p>
	 * 
	 * @param str
	 *            the string to convert
	 * @return the int represented by the string, or <code>zero</code> if
	 *         conversion fails
	 */
	public static int stringToInt(String str) {
		return stringToInt(str, 0);
	}

	/**
	 * <p>
	 * Convert a <code>String</code> to an <code>int</code>, returning a default
	 * value if the conversion fails.
	 * </p>
	 * 
	 * @param str
	 *            the string to convert
	 * @param defaultValue
	 *            the default value
	 * @return the int represented by the string, or the default if conversion
	 *         fails
	 */
	public static int stringToInt(String str, int defaultValue) {
		
			try {
				return java.text.NumberFormat.getInstance().parse(str).intValue();
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();	
				return defaultValue;
			}
	
	}

}
