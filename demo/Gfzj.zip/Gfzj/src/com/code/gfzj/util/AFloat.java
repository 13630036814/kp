package com.code.gfzj.util;

public class AFloat implements Cloneable{
	public final static int NUMBER = 0; // 单位(个)
	public final static int TEN_THOUSAND = 1; // 单位(万)
	public final static int HUNDRED_MILLION = 2; // 单位(亿)
	public int nValue; // 实际数值
	public int nDigit; // 小数点位数
	public int nUnit; // 单位
	private int format;//
	public long longVlaue;// 存储大数

	public AFloat() {
		this.nValue = 0;
		this.nDigit = 2;
		this.nUnit = NUMBER;
	}

	public AFloat(int nFloat) {
		this.nUnit = (nFloat & 0x00000003);
		this.nDigit = ((nFloat & 0x0000000C) >> 2);
		this.nValue = (nFloat >> 4);
	}

	public AFloat init(int nFloat) {
		this.nUnit = (nFloat & 0x00000003);
		this.nDigit = ((nFloat & 0x0000000C) >> 2);
		this.nValue = (nFloat >> 4);
		return this;
	}

	public void init(int nValue, int nDigit, int nUnit) {
		this.nValue = nValue;
		this.nDigit = nDigit;
		this.nUnit = nUnit;
	}
	
	public AFloat init(AFloat v){
		this.nValue = v.nValue;
		this.nDigit = v.nDigit;
		this.nUnit = v.nUnit;
		return this;
	}

	public int float2int() {
		int v = (this.nValue << 4) & 0xFFFFFFF0;
		v = v | (this.nDigit << 2) | this.nUnit;
		return v;
	}

	/**
	 * 
	 * @param nValue
	 * @param nDigit
	 *            小数点位数
	 * @param nUnit
	 *            单位
	 */

	public AFloat(double fValue, int nDigit, int nUnit) {
		initF(fValue,nDigit,nUnit);
	}
	
	public void initF(double fValue, int nDigit, int nUnit){
		switch (nUnit) {
		case TEN_THOUSAND: // 单位(万)
			fValue /= 10000;
			break;
		case HUNDRED_MILLION: // 单位(亿)
			fValue /= 100000000;
			break;
		default:
			break;
		}

		switch (nDigit) {
		case 1: // 单位
			fValue *= 10;
			break;
		case 2: // 单位
			fValue *= 100;
			break;
		case 3:
			fValue *= 1000;
		default:
			break;
		}

		if (fValue >= 0) {
			this.nValue = (int) (fValue + 0.5);
		} else {
			this.nValue = (int) (fValue - 0.5);
		}
		this.nDigit = nDigit;
		this.nUnit = nUnit;
	}

	public AFloat(int nValue, int nDigit, int nUnit) {
		this.nValue = nValue;
		this.nDigit = nDigit;
		this.nUnit = nUnit;
	}

	public AFloat(AFloat AFloat) {
		this.nValue = AFloat.nValue;
		this.nDigit = AFloat.nDigit;
		this.nUnit = AFloat.nUnit;
	}

	public int getDigitBase() {
		int nBase = 1;
		for (int i = 0; i < this.nDigit; i++) {
			nBase *= 10;
		}
		return nBase;
	}
	
	public final AFloat abs(){
		nValue=Math.abs(nValue);
		return this;
	}
	

	public final AFloat singleSub(AFloat val1, AFloat val2) {
		/*
		prepare(val1, val2, true);
		this.nValue = val1.nValue - val2.nValue;
		this.nDigit = val1.nDigit;
		this.nUnit = val1.nUnit;
		*/
		float value = val1.toFloat() - val2.toFloat();
		initF(value, nDigit, get_units(value));
		return this;
	}

	public AFloat sub(AFloat f) {
		/*
		prepare(this, f, true);
		this.nValue = this.nValue - f.nValue;
		*/
		float value = toFloat() - f.toFloat();
		initF(value, nDigit, get_units(value));
		return this;
	}
	/*
	public static final AFloat toAFloat(float value){
		String fStr = Float.toString(value);
		int index = fStr.indexOf(".");
		int digit = 0;
		if(index>=0){
			digit = fStr.length() - index-1;
		}
		AFloat af = new AFloat(value,digit,0);
		return af;
	}
	*/

	/**
	 * 两个浮点数比较
	 */
	public static final int compare(AFloat val1, AFloat val2) {
		int nRtn = 0;
		if (val1.toFloat() > val2.toFloat())
			nRtn = 1;
		else if (val1.toFloat() < val2.toFloat())
			nRtn = -1;
		return nRtn;
	}

	/**
	 * 加运算
	 */
	public static final AFloat add(AFloat val1, AFloat val2) {
		float value = val1.toFloat() + val2.toFloat();
		return new AFloat(value, val1.nDigit, get_units(value));
	}
	/**
	 * 最大值
	 */
	public void max(AFloat val1){
		if (compare(val1, this) > 0){
			init(val1.float2int());
		}
	}

	public void add(AFloat val2) {
		/*
		prepare(this, val2, true);
		this.nValue += val2.nValue;
		*/
		float value = toFloat() + val2.toFloat();
		initF(value, nDigit, get_units(value));
	}
	
	public void add(float val2) {
		/*
		prepare(this, val2, true);
		this.nValue += val2.nValue;
		*/
		float value = toFloat() + val2;
		initF(value, nDigit, get_units(value));
	}

	/**
	 * 减运算
	 */
	public static final AFloat sub(AFloat val1, AFloat val2) {
		float value = val1.toFloat() - val2.toFloat();
		return new AFloat(value, val1.nDigit, get_units(value));
	}
	
	public static final float floatSub(AFloat val1, AFloat val2) {
		return val1.toFloat() - val2.toFloat();
	}

	/**
	 * 乘运算
	 */
	public static final AFloat mul(AFloat val1, int val2) {
		float value = val1.toFloat() * val2;
		return new AFloat(value, val1.nDigit, get_units(value));
	}
	
	public static final float mul(AFloat val1, float val2) {
		return val1.toFloat() * val2;
	}

	/**
	 * 除运算
	 */
	public static final AFloat div(AFloat val1, int val2) {
		float value = val1.toFloat() / val2;
		return new AFloat(value, val1.nDigit, get_units(value));
	}
	
	public static final float div(AFloat val1, float val2) {
		float value = val1.toFloat() / val2;
		return value;
	}
	
	public static final float div(float val1, AFloat val2) {
		float value = val1 / val2.toFloat();
		return value;
	}
	
	public static final AFloat div(AFloat val1, AFloat val2) {
		float value = val1.toFloat() / val2.toFloat();
		return new AFloat(value, val1.nDigit, get_units(value));
	}

	public AFloat div(AFloat val2) {
		/*
		if (val2.nValue == 0)
			return;
		prepare(this, val2, false);
		int i = this.nValue / val2.nValue;
		int iMod = this.nValue % val2.nValue;
		for (int t = 0; t < this.nDigit; t++) {
			i = i * 10 + (iMod * 10 / val2.nValue);
			iMod = iMod * 10 % val2.nValue;
		}
		this.nValue = i;
		*/
		float value = toFloat() / val2.toFloat();
		initF(value, nDigit, get_units(value));
		return this;
	}
	public AFloat div(float val2) {
		float value = toFloat() / val2;
		initF(value, nDigit, get_units(value));
		return this;
	}

	public AFloat mul(int val2) {
		//this.longVlaue *= val2;
		//this.nValue *= val2;
		float value = toFloat() * val2;
		initF(value, nDigit, get_units(value));
		return this;
	}
	
	public AFloat mul(AFloat val2) {
		float value = toFloat() * val2.toFloat();
		initF(value, nDigit, get_units(value));
		return this;
	}

	public void div(int val2) {
		//this.longVlaue /= val2;
		//this.nValue /= val2;
		float value = toFloat() / val2;
		initF(value, nDigit, get_units(value));
	}

	/**
	 * 绝对值
	 */
	public static final AFloat abs(AFloat ftValue) {
		if (ftValue.nValue < 0)
			return new AFloat((0 - ftValue.nValue), ftValue.nDigit,
					ftValue.nUnit);
		else
			return new AFloat(ftValue.nValue, ftValue.nDigit, ftValue.nUnit);
	}

	/**
	 * 最大值
	 */
	public static final AFloat max(AFloat val1, AFloat val2) {
		if (compare(val1, val2) > 0)
			return new AFloat(val1.nValue, val1.nDigit, val1.nUnit);
		else
			return new AFloat(val2.nValue, val2.nDigit, val2.nUnit);
	}

	/**
	 * 最小值
	 */
	public static final AFloat min(AFloat val1, AFloat val2) {
		if (compare(val1, val2) > 0)
			return new AFloat(val1.nValue, val1.nDigit, val1.nUnit);
		else
			return new AFloat(val2.nValue, val2.nDigit, val2.nUnit);
	}

	/**
	 * 四舍五入
	 * 
	 * @param val
	 *            原始值
	 * @param nDigit
	 *            小数点后需保留的位数
	 * @return
	 */
	public static final AFloat round(AFloat val, int nDigit) {
		if ((val.nDigit <= nDigit) || (nDigit < 0)) {
			return val;
		}
		int nHalfBase = 5;
		int nDigitBase = 10;
		for (int i = 1; i < (val.nDigit - nDigit); i++) {
			nHalfBase *= 10;
			nDigitBase *= 10;
		}

		return new AFloat((val.nValue + nHalfBase) / nDigitBase, nDigit,
				val.nUnit);

	}

	public String toString(String ch) {
		format = ch != null ? 1 : 0;
		String s = toString() + ch;
		format = 0;
		return s;
	}

	public float toFloat() {
		float f = nValue;

		if (format == 0 && nValue == 0)
			return 0;

		switch (this.nDigit) {
		case 1:
			f /= 10;
			break;
		case 2:
			f /= 100;
			break;
		case 3:
			f /= 1000;
		default:
			break;
		}

		switch (this.nUnit) {
		case TEN_THOUSAND: // 单位(万)
			f *= 10000;
			break;
		case HUNDRED_MILLION: // 单位(亿)
			f *= 100000000;
			break;
		default:
			break;
		}
		return f;
	}
	

	public static float toFloat(int floatValue) {
		final int fUnit = (floatValue & 0x00000003);
		final int fDigit = ((floatValue & 0x0000000C) >> 2);
		final int fValue = (floatValue >> 4);
		float f = fValue;

		if (fValue == 0)
			return 0;

		switch (fDigit) {
		case 1:
			f /= 10;
			break;
		case 2:
			f /= 100;
			break;
		case 3:
			f /= 1000;
		default:
			break;
		}

		switch (fUnit) {
		case TEN_THOUSAND: // 单位(万)
			f *= 10000;
			break;
		case HUNDRED_MILLION: // 单位(亿)
			f *= 100000000;
			break;
		default:
			break;
		}
		return f;
	}
	
	
	public AFloat clone(){
		return new AFloat(nValue,nDigit,nUnit);
	}

	public String toString() {
		if (format == 0 && nValue == 0)
			return "---";
		StringBuffer strRtn = new StringBuffer(12);
		strRtn.append(this.nValue);
		int nLen = strRtn.length();
		int nPos = 0;
		if (this.nValue < 0) {
			nPos = 1;
		}
		if (this.nDigit > 0) {
			if ((nLen - nPos) > this.nDigit)
				strRtn.insert(nLen - this.nDigit, '.');
			else {
				strRtn.insert(nPos, "0.");
				while ((nLen - nPos) < this.nDigit) {
					strRtn.insert(nPos + 2, '0');
					nLen++;
				}
			}
		}
		switch (this.nUnit) {
		case TEN_THOUSAND: // 单位(万)
			strRtn.append("万");
			break;
		case HUNDRED_MILLION: // 单位(亿)
			strRtn.append("亿");
			break;
		default:
			break;
		}
		return strRtn.toString();
	}

	/**
	 * 自动适配单位
	 * 
	 * @param value
	 * @return
	 */
	public static final int get_units(float value) {
		if (value > 100000000 * 10)
			return HUNDRED_MILLION;
		else if (value > 10000 * 10)
			return TEN_THOUSAND;
		else
			return NUMBER;
	}
/*
	public static void prepare(AFloat val1, AFloat val2, boolean enlarge) {
		while (val1.nDigit != val2.nDigit) {
			if (enlarge) {
				if (val1.nDigit < val2.nDigit) {
					val1.nValue = val1.nValue * 10;
					val1.nDigit++;
				} else if (val1.nDigit > val2.nDigit) {
					val2.nValue = val2.nValue * 10;
					val2.nDigit++;
				}
			} else {
				if (val1.nDigit > val2.nDigit) {
					val1.nValue = val1.nValue / 10;
					val1.nDigit--;
				} else if (val1.nDigit < val2.nDigit) {
					val2.nValue = val2.nValue / 10;
					val2.nDigit--;
				}
			}

		}
	}
	*/
	/**
	 * 最大值
	 */
	public static AFloat getMax(int pos, AFloat[] data) {		
		AFloat tmp =data==null?new AFloat(): data[pos];
		for (int i = pos; data!=null && i < data.length; i++) {
			if (AFloat.compare(tmp, data[i]) == -1)
				tmp = data[i];
		}
		return tmp;
	}
	/**
	 * 最小值
	 */
	public static AFloat getMin(int pos, AFloat[] data) {
		if(data==null){
			return new AFloat();
		}
		AFloat tmp = data[pos];
		for (int i = pos; i < data.length; i++) {
			if (AFloat.compare(tmp, data[i]) == 1)
				tmp = data[i];
		}
		return tmp;
	}
}
