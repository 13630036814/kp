package com.code.gfzj.util;

/**
 * 
 * 定义主界面的功能页
 * @author cola
 * 
 */
public class View_Util {
	public static final int Information = 0;
	public static final int main = 1;
	public static final int Message = 2;
	public static final int Chat = 3;
	public static final int Friends = 4;
	public static final int Page = 5;
	public static final int Location = 6;
	public static final int update = 7;
	public static final int mystock = 8;
}
