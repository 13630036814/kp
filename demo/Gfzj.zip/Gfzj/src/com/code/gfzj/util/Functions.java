package com.code.gfzj.util;


import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.code.gfzj.base.Global;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Paint.Align;
import android.graphics.Paint.FontMetrics;
import android.graphics.Paint.Style;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;

public class Functions {
	public static Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
	public static Paint mPaint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
	public static Paint mPaint3 = new Paint(Paint.ANTI_ALIAS_FLAG);	
	public static Paint mPaint4 = new Paint();	
	public static Paint mPaint5 = new Paint(Paint.ANTI_ALIAS_FLAG);

	public static final int BASELINE = 64; 
	public static final int BOTTOM = 32; 
	public static final int DOTTED = 1; 
	public static final int HCENTER = 1; 
	public static final int LEFT = 4;
	public static final int RIGHT = 8;
	public static final int SOLID = 0; 
	public static final int TOP = 16; 
	public static final int VCENTER = 2; 
	
	public static int TextOffY;	
	public static FontMetrics fontMetrics = null;	
	
	protected static Hashtable<Integer, Object> urDataCache = new Hashtable<Integer, Object>();
	/** 获取缓存*/
	public static final Object getCashe(int uiid){
		return urDataCache.get(uiid);
	}
	
	/** 存入缓存*/
	public static final void putCashe(int uiid,Object value){
		urDataCache.put(uiid, value);
	}
	
	/** 移除缓存*/
	public static final void removeCashe(int uiid){
	//debug	urDataCache.remove(uiid);
	}
	/** 移除全部*/
	public static final void removeAllCashe(){
		urDataCache.clear();
	}	

	public static String[] getAdsPort(String host) {
		String[] tmp = new String[2];
		int len = 0;
		for (int i = 0; i < host.length(); i++) {
			char c = host.charAt(i);
			if (c == ':') {
				len = i + 1;
				break;
			}
		}
		tmp[0] = host.substring(0, len - 1);
		tmp[1] = host.substring(len, host.length());
		return tmp;
	}

	public static byte[] wordToByteArray(int wordData) {
		byte[] result = new byte[2];
		result[1] = (byte) ((wordData & 0xFF00) >> 8);
		result[0] = (byte) (wordData & 0xFF);
		return result;
	}

	/**
	 * Converts an "int" to a byte array of size 4.
	 */
	public static byte[] intToByteArray(int intData) {
		byte[] result = new byte[4];
		result[0] = (byte) ((intData & 0xFF));
		result[1] = (byte) ((intData & 0xFF00) >> 8);
		result[2] = (byte) ((intData & 0xFF0000) >> 16);
		result[3] = (byte) ((intData & 0xFF000000) >> 24);
		return result;
	}

	/**
	 * Converts 4 continuous bytes in a byte array to "int".
	 * 
	 * @param offset
	 *            From here are the 4 bytes of the int data.
	 */
	public static int byteArrayToInt(byte[] byteArrayData, int offset) {
		return (byteArrayData[offset + 3] & 0xff) << 24
				| (byteArrayData[offset + 2] & 0xff) << 16
				| (byteArrayData[offset + 1] & 0xff) << 8
				| (byteArrayData[offset] & 0xff);
	}

	public static byte[] StringToKey(String key) {
		byte[] bs = new byte[8];
		for (int i = 0; i < bs.length; i++) {
			bs[i] = (byte) Integer
					.parseInt(key.substring(i * 2, i * 2 + 2), 16);
		}
		return bs;
	}

	public static String format(byte[] key) {
		StringBuffer b = new StringBuffer();
		for (int i = 0; i < key.length; i++) {
			String s = Integer.toString(key[i] & 0xFF, 16);
			b.append(s.length() == 2 ? s : "0" + s);
		}
		return b.toString().toUpperCase();
	}

	/**
	 * Converts 2 continuous bytes in a byte array to "int".
	 * 
	 * @param offset
	 *            From here are the 4 bytes of the int data.
	 */
	public static int byteArrayToShort(byte[] byteArrayData, int offset) {
		int a = (0 & 0xff) << 24 | (0 & 0xff) << 16
				| (byteArrayData[offset + 1] & 0xff) << 8
				| (byteArrayData[offset] & 0xff);
		return a > 32767 ? a - 65536 : a;
	}

	public static int byteArrayToWord(byte[] byteArrayData, int offset) {
		int ret = byteArrayToShort(byteArrayData, offset);
		return ret & 0xFFFF;
	}

	public static int byteToUnsigned(byte b) {
		return b & 0xFF;
	}

	public static String bytesToString(byte[] byteArrayData, int offset, int len) {
		if (len == 0) {
			return "";
		}
		if (byteArrayData[offset + len - 1] == 0) {
			len--;
		}

		return new String(byteArrayData, offset, len);
	}

	public static String bytesToUTFString(byte[] byteArrayData, int offset,
			int len) {
		if (byteArrayData[offset + len - 1] == 0) {
			len--;
		}

		try {

			return new String(byteArrayData, offset, len, "UTF-8");
		} catch (Exception e) {
			return null;
		}
	}

	public static String bytesToUNIString(byte[] byteArrayData, int offset,
			int len) {
		if (byteArrayData[offset + len - 1] == 0) {
			len--;
		}

		try {
			return new String(byteArrayData, offset, len, "UNICODE");
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 切割字符串通用方法 
	 * str 要分割的字符串 
	 * font 字体 
	 * rowMaxW 分割后每行宽度 支持标示符： \n 换行 \t 插入两个汉字长度的空格
	 */
	public static final Vector splitStr(String str, int rowMaxW) {
		if (str == null) {
			return null;
		}
		int fontWidth = (int) mPaint.getTextSize();
		// System.out.println("fontwidth="+fontWidth);
		if (rowMaxW < fontWidth) {
			rowMaxW = fontWidth;
		}

		int strID = 0;
		int rowW = 0;
		Vector strManager = new Vector(89, 89);
		char ch = ' ';
		while (str.length() > strID) {
			ch = str.charAt(strID);
			// Log.w("splitStr","ch="+ch);
			switch (ch) {
			case '\n':
				strManager.addElement(str.substring(0, strID));
				str = str.substring(strID + 1);
				rowW = 0;
				strID = 0;
				break;
			case '\t':
				StringBuffer sb = new StringBuffer(str);
				sb.deleteCharAt(strID);
				sb.insert(strID, "");
				str = sb.toString();
				break;
			case '\r':
				StringBuffer sb2 = new StringBuffer(str);
				sb2.deleteCharAt(strID);
				sb2.insert(strID, "");
				str = sb2.toString();
				break;
			case '\u0000':
				StringBuffer sb3 = new StringBuffer(str);
				sb3.deleteCharAt(strID);
				sb3.insert(strID, "");
				str = sb3.toString();
				break;
			default:
				if (rowW + fontWidth > rowMaxW) {
					strManager.addElement(str.substring(0, strID - 1));
					str = str.substring(strID - 1);
					rowW = 0;
					strID = 0;
				} else {
					if (ch == ' ') {
						rowW += fontWidth >> 2;
					} else
						rowW += fontWidth;
					strID++;
				}
			}
		}
		strManager.addElement(str);
		// String[] o_Str = new String[strManager.size()];
		// strManager.copyInto(o_Str);
		return strManager;
	}

	/**
	 * 同步自选列表
	 * 
	 * @param _stockCode
	 *            String
	 */
/*	public static void UpdateStock(String[] codestr) {
		if (codestr.length == 0) {
			return;
		}
		for (int j = 0; j < codestr.length; j++) {
			boolean bool = true;
			String code;
			String code2;
			Z: for (int i = 0; i < Globe.vecFreeStock.size(); i++) {
				code = (String) Globe.vecFreeStock.elementAt(i);
				code2 = codestr[j];
				if (code.equals(code2)) {
					bool = false;
					break Z;
				}
			}
			if (bool) {
				Globe.vecFreeStock.addElement(codestr[j]);
			}
		}
	}
*/
	/**
	 * 加入自选列表
	 * 
	 * @param _stockCode
	 *            String
	 */
/*	public static boolean addFreeStock(String _stockCode) {
		if (Globe.vecFreeStock.size() >= GameConst.MAX_MINE_STOCK_NUM)
			return false;

		String code;
		for (int i = 0; i < Globe.vecFreeStock.size(); i++) {
			code = (String) Globe.vecFreeStock.elementAt(i);
			if (code.equals(_stockCode)) {
				return false;
			}
		}

		Globe.vecFreeStock.add(0, _stockCode);
		// System.out.println("size = " + Globe.vecFreeStock.size());
		return true;
	}
*/
	/**
	 * 检测给定股票代码是否存在自选列表中
	 * 
	 * @param _stockCode
	 *            String
	 * @return boolean
	 */
/*	public static boolean existFreeStock(String _stockCode) {
		String code;
		for (int i = 0; i < Globe.vecFreeStock.size(); i++) {
			code = (String) Globe.vecFreeStock.elementAt(i);
			if (code.equals(_stockCode)) {
				return true;
			}
		}
		return false;
	}
*/
	/**
	 * 从自选列表中删除给定股票
	 * 
	 * @param _stockCode
	 *            String
	 */
/*	public static void delFreeStock(String _stockCode) {
		Globe.vecFreeStock.removeElement(_stockCode);

		saveFreeStock();
	}
*/
	/**
	 * 删除自选列表中全部股票
	 * 
	 * @param _stockCode
	 *            String
	 */
/*	public static void delAllFreeStock() {
		Globe.vecFreeStock.removeAllElements();

		saveFreeStock();
	}

	public static void saveFreeStock() {
		RmsAdapter rms = InitScreen.rms;
		StructRequest in = new StructRequest();
		in.writeVector(Globe.vecFreeStock);
		rms.put(GameConst.STOCK_FREE, in.getBytes());

		Globe.MineStockSum = Globe.vecFreeStock.size();
		rms.put(GameConst.MINESTOCK_SUM, Globe.MineStockSum);
		rms.close();
	}

	public static void saveLaterStock() {
		RmsAdapter rms = InitScreen.rms;
		StructRequest in = new StructRequest();
		in.writeVector(Globe.vecLaterStock);
		rms.put(GameConst.STOCK_LATER, in.getBytes());

		rms.close();
	}
*/
	public static String getDay(int intData) {
		int[] result = new int[5];
		result[0] = (int) ((intData & 0x3F)); // min
		result[1] = (int) (((intData >>> 6) & 0x1F)); // hour
		result[2] = (int) (((intData >>> 11) & 0x1F)); // day
		result[3] = (int) (((intData >>> 16) & 0xF)); // month
		result[4] = (int) (((intData >>> 20) & 0xFFF)); // year
		StringBuffer sb = new StringBuffer();
		sb.append(formatNumber(result[3])).append(formatNumber(result[2]))
				.append(" ").append(formatNumber(result[1])).append(":")
				.append(formatNumber(result[0]));
		return sb.toString();
	}

	public static String getDay_OnlyHM(int intData) {
		int[] result = new int[5];
		result[0] = (int) ((intData & 0x3F)); // min
		result[1] = (int) (((intData >>> 6) & 0x1F)); // hour
		result[2] = (int) (((intData >>> 11) & 0x1F)); // day
		result[3] = (int) (((intData >>> 16) & 0xF)); // month
		result[4] = (int) (((intData >>> 20) & 0xFFF)); // year
		StringBuffer sb = new StringBuffer();
		sb.append(formatNumber(result[1])).append(":")
				.append(formatNumber(result[0]));
		return sb.toString();

	}

	public static String getDay_OnlyMD(int intData) {
		int[] result = new int[5];
		result[0] = (int) ((intData & 0x3F)); // min
		result[1] = (int) (((intData >>> 6) & 0x1F)); // hour
		result[2] = (int) (((intData >>> 11) & 0x1F)); // day
		result[3] = (int) (((intData >>> 16) & 0xF)); // month
		result[4] = (int) (((intData >>> 20) & 0xFFF)); // year
		StringBuffer sb = new StringBuffer();
		sb.append(formatNumber(result[3])).append("/")
				.append(formatNumber(result[2]));
		return sb.toString();

	}

	private static String formatNumber(int data) {
		if (data < 10) {
			StringBuffer sb = new StringBuffer("0").append(data);
			return sb.toString();
		}
		return Integer.toString(data);
	}

	public static String formatNumString2(long data) {
		if (data == 0) {
			return "-";
		}
		return formatNumString2(String.valueOf(data));
	}

	public static String formatNumString2(String data) {
		data = data.trim();
		int length = data.length();
		if (length <= 5) {
			return data + "万";
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append(data.substring(0, length - 4)).append(".")
					.append(data.substring(length - 4, length));
			data = sb.toString();
			sb = new StringBuffer();
			sb.append(data.substring(0, 5));
			data = sb.toString();
			if (data.charAt(4) == '.') {
				sb = new StringBuffer();
				sb.append(data.substring(0, 4)).append("亿");
			}
			// else if (data.charAt(4) == '0') {
			// sb = new StringBuffer();
			// sb.append(data.substring(0, 4)).append("1").append("亿");
			// }
			else {
				sb.append("亿");
			}
			return sb.toString();
		}
	}

	public static String formatNumString(long data) {
		if (data == 0) {
			return "-";
		}
		return formatNumString(String.valueOf(data));
	}

	public static String formatNumString(String data) {
		data = data.trim();
		int length = data.length();
		if (length <= 7) {
			return data;
		} else if (length < 10) {
			StringBuffer sb = new StringBuffer();
			sb.append(data.substring(0, length - 4)).append(".")
					.append(data.substring(length - 4, length));
			data = sb.toString();
			sb = new StringBuffer();
			sb.append(data.substring(0, 5));
			data = sb.toString();
			if (data.charAt(4) == '.') {
				sb = new StringBuffer();
				sb.append(data.substring(0, 4)).append("万");
			}
			// else if (data.charAt(4) == '0') {
			// sb = new StringBuffer();
			// sb.append(data.substring(0, 4)).append("1").append("万");
			// }
			else {
				sb.append("万");
			}
			return sb.toString();
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append(data.substring(0, length - 8)).append(".")
					.append(data.substring(length - 8, length));
			data = sb.toString();
			sb = new StringBuffer();
			sb.append(data.substring(0, 5));
			data = sb.toString();
			if (data.charAt(4) == '.') {
				sb = new StringBuffer();
				sb.append(data.substring(0, 4)).append("亿");
			}
			// else if (data.charAt(4) == '0') {
			// sb = new StringBuffer();
			// sb.append(data.substring(0, 4)).append("1").append("亿");
			// }
			else {
				sb.append("亿");
			}
			return sb.toString();
		}
	}


/*
	public static String getTextView(int id) {
		if (id < 0 || Globe.TEXTVIEW_DATA == null
				|| id >= Globe.TEXTVIEW_DATA.length) {
			return "";
		}
		if (Globe.TEXTVIEW_DATA[id] == null)
			return "";

		return Globe.TEXTVIEW_DATA[id];
	}
*/
	public static String formatSpecString(String str) {
		StringBuffer tmp = new StringBuffer();

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c != '\r') {
				tmp.append(c);
			}
		}

		return tmp.toString();
	}

	public static String formatString(String str, int width, int TextSize,
			int row) {
		StringBuffer sb = new StringBuffer();

		if (stringWidthWithSize(str, TextSize) < width * 3) {
			sb.append(str);
		} else {
			int offset = 0;
			int l = str.length();

			for (int r = 0; r < row || offset >= str.length(); r++) {
				String tmp = null;

				for (int i = offset; i <= l; i++) {
					tmp = str.substring(offset, i);
					if (stringWidthWithSize(tmp, TextSize)
							+ stringWidthWithSize("国", TextSize) >= width) {
						sb.append(tmp);
						offset = i;
						break;
					}
				}
			}
			sb.append("...");
		}
		return sb.toString();
	}


	private static String urlBase;

	public static String getPhoneNumber(String str) {
		String pn = "";
		int i = 0;
		for (i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c == '&')
				break;
		}
		pn = str.substring(0, i);
		return pn;
	}

	private static String zhPattern = "[\u4e00-\u9fa5]+";

	/**
	 * 替换字符串卷
	 * 
	 * @param str
	 *            被替换的字符串
	 * @param charset
	 *            字符集
	 * @return 替换好的
	 * @throws UnsupportedEncodingException
	 *             不支持的字符集
	 */
	public static String encode(String str, String charset)
			throws UnsupportedEncodingException {
		Pattern p = Pattern.compile(zhPattern);
		Matcher m = p.matcher(str);
		StringBuffer b = new StringBuffer();
		while (m.find()) {
			m.appendReplacement(b, URLEncoder.encode(m.group(0), charset));
		}
		m.appendTail(b);
		return b.toString();
	}

	/**
	 * 替换字符串卷
	 * 
	 * @param str
	 *            被替换的字符串
	 * @param charset
	 *            字符集
	 * @return 替换好的
	 * @throws UnsupportedEncodingException
	 *             不支持的字符集
	 */
	public static String decode(String str, String charset)
			throws UnsupportedEncodingException {
//		Pattern p = Pattern.compile(zhPattern);
//		Matcher m = p.matcher(str);
//		StringBuffer b = new StringBuffer();
//		while (m.find()) {
//			m.appendReplacement(b, URLDecoder.decode(m.group(0), charset));
//		}
//		m.appendTail(b);
		str = URLDecoder.decode(str, charset);
//		str = new String(str.getBytes("ISO-8859-1"));
		return str;
	}
	
	public static int findTag(String str,char tag){
		if(str == null)
			return -1;

		for(int i = 0; i < str.length();i ++){
			char tmp = str.charAt(i);
			if(tmp == tag){
				return i;
			}
		}
		return -1;
	}
	
	public static int findPattern(String str,String pattern){
		if(str == null)
			return -1;

		int count = 0;
		while(count < str.length()){
			String tmp = str.substring(count);
			if(tmp.startsWith(pattern))
				return count;
			count ++;
		}
		return -1;
	}

	public static String getRealCode(String code) {
		String cc = code;
		if (code.length() > 2) {
			String s = code.substring(0, 2);
			if (s.equals("SZ") || s.equals("SH") || s.equals("BI")
					|| s.equals("SC") || s.equals("DC") || s.equals("ZC")
					|| s.equals("SF") || s.equals("SG") || s.equals("FE")
					|| s.equals("HK") || s.equals("IX")) {
				cc = code.substring(2, code.length());
			}
		}

		return cc;
	}

	/**
	 * 根据指定的子串分割字符串
	 * 
	 * @param str
	 *            源字符串
	 * @param split
	 *            子串
	 * @return 切割后生成的字符串数组
	 */
	public static ArrayList<String> splitTrimString(final String str,
			final String split) {
		if (str == null)
			throw new NullPointerException();
		if (split == null || split.length() < 1)
			throw new IllegalArgumentException();
		ArrayList<String> list = new ArrayList<String>();
		int index = 0;
		int index2;
		final int len = str.length();
		final int splitLen = split.length();
		while (true) {
			index2 = str.indexOf(split, index);
			if (index2 < 0)
				index2 = len;
			list.add((str.substring(index, index2)).trim());
			if (index2 == len)
				break;
			index = index2 + splitLen;
			if (index == len) {
				list.add("");
				break;
			}
		}
		return list;
	}

	//window manage------------------------------------begin---------------
	public static void removeAllWindow() {
		int size = Global.WinContainer.size();
		for (int i = 0; i < size; i++) {
//			BaseWindow wm = Global.WinContainer.elementAt(i);
//			if (!wm.isFinishing()) {
//				wm.finish();
//			}
		}

	}
	
	public static void removeOtherWindow(int id) {
		int size = Global.WinContainer.size();
		if (size == 1)
			return;
		for (int i = 0; i < size; i++) {
//			BaseWindow wm = Global.WinContainer.elementAt(i);
//			if (!wm.isFinishing()) {
//				if (wm.bizId == id)
//					continue;
//				wm.finish();
//			}
		}
	}

	public static void removeWindow(int id) {
		int size = Global.WinContainer.size();
		for (int i = 0; i < size; i++) {
			Activity wm = Global.WinContainer.elementAt(i);
			if (!wm.isFinishing()) {
//				if (wm.bizId == id) {
//					// System.out.println(wm.toString()+"isfinish");
//					wm.finish();
//					break;
//				}
			}
		}
	}	
	//window manage------------------------------------end---------------


	public static void killProcess() {
		int id = android.os.Process.myPid();
		android.os.Process.killProcess(id);
	}
	
	public static boolean C_R2R(int tlX1, int tlY1, int w1, int h1, int tlX2, int tlY2, int w2, int h2)
	  {
	    if(!(((tlX1 + w1) < tlX2) || ((tlX2 + w2) < tlX1) || ((tlY1 + h1) < tlY2) || ((tlY2 + h2) < tlY1)))
	    {
	      return true;
	    }
	    return false;
	}
	 
	public static void drawString(String str,int x,int y,int color,Align align,Canvas g){
		mPaint.setColor(color);
		mPaint.setTextAlign(align);
//		int offy = (int) (mPaint.getTextSize()-TextOffY);
//		g.drawText(str, x, y+offy, mPaint);
		fontMetrics = mPaint.getFontMetrics();
		g.drawText(str, x, y - fontMetrics.ascent, mPaint); 
	}
	
	
	public static void drawString(String str,int x,int y,Align align,Canvas g){
		mPaint.setTextAlign(align);
//		int offy = (int) (mPaint.getTextSize()-TextOffY);
//		g.drawText(str, x, y+offy, mPaint);//20
		fontMetrics = mPaint.getFontMetrics();
		g.drawText(str, x, y - fontMetrics.ascent, mPaint); 
	}
	
	public static void drawString2(String str,int x,int y,Align align,Canvas g){
		mPaint2.setTextAlign(align);
//		int offy = (int) (mPaint2.getTextSize()-TextOffY);
//		g.drawText(str, x, y+offy, mPaint2);
		fontMetrics = mPaint2.getFontMetrics();
		g.drawText(str, x, y - fontMetrics.ascent, mPaint2); 
	}
	
	public static void drawString3(String str,int x,int y,Align align,Canvas g){
        mPaint5.setTextSize(16);
//		int offy = (int) (mPaint5.getTextSize()-TextOffY);
		mPaint5.setTextAlign(align);
//		g.drawText(str, x, y+offy, mPaint5);
		fontMetrics = mPaint5.getFontMetrics();
		g.drawText(str, x, y - fontMetrics.ascent, mPaint5); 
	}
	
	public static void drawStringWithP(String str,int x,int y,Align align,Canvas g,Paint p){
		p.setTextAlign(align);
		if(str==null)
			str="--";
	    if(str.equals("null"))
	    	str="";
//		int offy = (int) (p.getTextSize() - ty);
//		g.drawText(str, x, y+offy, p);//20
	    fontMetrics = p.getFontMetrics();
	    g.drawText(str, x, y - fontMetrics.ascent, p); 
	}
	
	public static void drawVerticalString(String str,int x,int y, Canvas g,Paint p){
		p.setTextAlign(Align.LEFT);
//		int offy = (int) (p.getTextSize()-TextOffY);
//		y += offy;
		fontMetrics = p.getFontMetrics();
		for(int i = 0; i < str.length();i ++){
			String c = str.substring(i,i + 1);
			g.drawText(c, x, y - fontMetrics.ascent, p);//20
			y += p.getTextSize();
		}
	}
	
	public static void drawRect(int x,int y,int w,int h,int color,Canvas g){
		mPaint.setColor(color);
		mPaint.setStyle(Style.STROKE);
		g.drawRect(x, y, x+w, y+h, mPaint);
	}
	
	public static void drawRect(int x,int y,int w,int h,Canvas g){
		mPaint.setStyle(Style.STROKE);
		g.drawRect(x, y, x+w, y+h, mPaint);
	}
	
	public static void fillRect(int x,int y,int w,int h,int color,Canvas g){
		mPaint.setColor(color);
		mPaint.setStyle(Style.FILL);
		g.drawRect(x,y,x+w,y+h, mPaint);
	}
	
	public static void fillRoundRect(int x,int y,int w,int h,int rx,int ry,int color,Canvas g){
		mPaint.setColor(color);
		mPaint.setStyle(Style.FILL);
		
		g.drawRoundRect(new RectF(x, y, x + w, y + h), rx, ry, mPaint);
	}

	
	public static void fillRect(int x,int y,int w,int h,Canvas g){
//		mPaint.setColor(color);
		mPaint.setStyle(Style.FILL);
		g.drawRect(x,y,x+w,y+h, mPaint);
	}
	
	public static void drawLine(int x1,int y1,int x2,int y2,int color,Canvas g){
		mPaint4.setColor(color);		
		if(x1==x2)
			g.drawLine(x1, y1, x2, y2+1, mPaint4);
		else if(y1==y2)
			g.drawLine(x1, y1, x2+1, y2, mPaint4);
		else if(y2>y1){
			if(x2>x1)
				g.drawLine(x1, y1, x2+1, y2+1, mPaint4);
			else
				g.drawLine(x1, y1, x2-1, y2+1, mPaint4);
		}
		else{
			if(x2>x1)
				g.drawLine(x1, y1, x2+1, y2-1, mPaint4);
			else
				g.drawLine(x1, y1, x2-1, y2-1, mPaint4);
		}
	}
	
	public static void drawLine2(int x1,int y1,int x2,int y2,int color,Canvas g){
		mPaint5.setColor(color);		
		if(x1==x2)
			g.drawLine(x1, y1, x2, y2+1, mPaint5);
		else if(y1==y2)
			g.drawLine(x1, y1, x2+1, y2, mPaint5);
		else if(y2>y1){
			if(x2>x1)
				g.drawLine(x1, y1, x2+1, y2+1, mPaint5);
			else
				g.drawLine(x1, y1, x2-1, y2+1, mPaint5);
		}
		else{
			if(x2>x1)
				g.drawLine(x1, y1, x2+1, y2-1, mPaint5);
			else
				g.drawLine(x1, y1, x2-1, y2-1, mPaint5);
		}
	}
	
	public static void drawLine(int x1,int y1,int x2,int y2,Canvas g){
//		mPaint.setColor(color);
		if(x1==x2)
			g.drawLine(x1, y1, x2, y2+1, mPaint4);
		else if(y1==y2)
			g.drawLine(x1, y1, x2+1, y2, mPaint4);
		else if(y2>y1){
			if(x2>x1)
				g.drawLine(x1, y1, x2+1, y2+1, mPaint4);
			else
				g.drawLine(x1, y1, x2-1, y2+1, mPaint4);
		}
		else{
			if(x2>x1)
				g.drawLine(x1, y1, x2+1, y2-1, mPaint4);
			else
				g.drawLine(x1, y1, x2-1, y2-1, mPaint4);
		}
	}
	
	public static void drawArc(int x,int y,int w,int h,int beginDegree,int endDegree,Canvas g){
		mPaint.setStyle(Style.STROKE);
		RectF oval = new RectF(x,y,x+w,y+h);
		g.drawArc(oval, beginDegree, endDegree, true, mPaint);
	}
	
	public static void fillArc(int x,int y,int w,int h,int beginDegree,int endDegree,Canvas g){
		mPaint.setStyle(Style.FILL);
		RectF oval = new RectF(x,y,x+w,y+h);
		g.drawArc(oval, beginDegree, endDegree, true, mPaint);
	}
	
	public static void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3,Canvas g) {
      Path path = new Path();
      mPaint.setStyle(Style.FILL);
      path.moveTo(x1, y1);
      path.lineTo(x2, y2);
      path.lineTo(x3, y3);
      path.lineTo(x1, y1);
      g.drawPath(path, mPaint);
  }
	
	public static void drawTriangle(int x1, int y1, int x2, int y2, int x3, int y3,Canvas g) {
      Path path = new Path();
      mPaint.setStyle(Style.STROKE);
      path.moveTo(x1, y1);
      path.lineTo(x2, y2);
      path.lineTo(x3, y3);
      path.lineTo(x1, y1);
      
      g.drawPath(path, mPaint);
  }
	
	
	public static void drawBitmap(Bitmap bm,int x,int y,Canvas g){
		g.drawBitmap(bm, x, y,mPaint);
	}
	
	public static void drawBitmap(Bitmap bm,int srcx,int srcy,int w,int h,int destx1,int desty1,Canvas g){
		Rect src = new Rect(srcx,srcy,srcx+w,srcy+h);
		RectF dst = new RectF(destx1,desty1,destx1+w,desty1+h);
		g.drawBitmap(bm, src, dst, mPaint);
	}
	
	public static void drawBitmap(Bitmap bm,int x,int y,int anchor,Canvas g){
		if((anchor & BOTTOM) == 0x20){
			y-=bm.getHeight();
		}
		if((anchor & RIGHT) == 0x8){
			x+=bm.getWidth();
		}
		if((anchor & VCENTER)==0x2){
			y-=bm.getHeight()/2;
		}
		if(((anchor & HCENTER) == 0x1)){
			x-=bm.getWidth()/2;
		}
		g.drawBitmap(bm, x, y,mPaint);
	}
	
	public static void drawBitmap(Bitmap bm,int srcx,int srcy,int w,int h,int destx1,int desty1,int anchor,Canvas g){
		if((anchor & BOTTOM) == 0x20){
			desty1-=h;
		}
		if((anchor & RIGHT) == 0x8){
			destx1+=w;
		}
		if((anchor & VCENTER)==0x2){
			desty1-=h/2;
		}
		if(((anchor & HCENTER) == 0x1)){
			destx1-=w/2;
		}
		Rect src = new Rect(srcx,srcy,srcx+w,srcy+h);
		RectF dst = new RectF(destx1,desty1,destx1+w,desty1+h);
		g.drawBitmap(bm, src, dst, mPaint);
	}
	
	public static void setClip(int x,int y,int w,int h,Canvas g){
		g.clipRect(x, y, x + w, y + h);
	}
	
//	public static void resetClip(Canvas g){
//  	g.restore();
//  	g.save();
//	}
	public static int stringWidth0(String str){
		String head = "";
		String body = str;
		int width = 0;
		if(str.length()==0)
			return 0;
		if(str.length() > 2){
			head = str.substring(0,2);
		}
		if(head.equals("　　")){
			width = 2 * Global.gameFontHeight;
			body = str.substring(2);
			mPaint.setTextSize(Global.gameFontHeight);
			Rect rect = new Rect();
			mPaint.getTextBounds(body, 0, body.length(), rect);
			width += rect.width();
		}
		else{
			mPaint.setTextSize(Global.gameFontHeight);
			Rect rect = new Rect();
			mPaint.getTextBounds(str, 0, str.length(), rect);
			width = rect.width();
		}
		return width;
	}
	
	public static int stringWidth(String str){
		if(str.length()==0)
			return 0;
		mPaint.setTextSize(Global.gameFontHeight);
		Rect rect = new Rect();
		mPaint.getTextBounds(str, 0, str.length(), rect);
		return rect.width();
	}
	
	public static int stringWidth2(String str){
		if(str.length()==0)
			return 0;
		mPaint.setTextSize(DrawTool.NUMBER_WIDTH);
		Rect rect = new Rect();
		mPaint.getTextBounds(str, 0, str.length(), rect);
		return rect.width();
	}
	
	public static int stringWidth3(String str){
		if(str.length()==0)
			return 0;
		mPaint5.setTextSize(16);
		Rect rect = new Rect();
		mPaint5.getTextBounds(str, 0, str.length(), rect);
		return rect.width();
	}
	
	public static int stringWidthWithSize(String str,int textSize){
		if(str.length()==0)
			return 0;
		Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
		p.setTextSize(textSize);
		Rect rect = new Rect();
		p.getTextBounds(str, 0, str.length(), rect);
		return rect.width();
	}
	
	public static int stringWidthWithPaint(String str,Paint p){
		if(str==null)
			return 0;
		if(str.length()==0)
			return 0;	
		Rect rect = new Rect();
		p.getTextBounds(str, 0, str.length(), rect);
		return rect.width();
	}
	
	public static void activeIntent(Activity c1,Class<?> c2){
		 Intent result = new Intent();
	     result.setClass(c1, c2);
	     c1.startActivity(result);
	}
	
	public static void activeBundle(Activity c1,Class<?> c2,Bundle bd){
		 Intent result = new Intent();
		 result.putExtras(bd);
	     result.setClass(c1, c2);
	     c1.startActivity(result);
	}

	public static Bitmap createBitmap_normal(Resources m_Resources,int id){
		return BitmapFactory.decodeResource(m_Resources, id);
	}
	
	public static Bitmap createBitmap_Trancelate(Resources m_Resources,int id,int trancelate){
		Bitmap bmp = BitmapFactory.decodeResource(m_Resources, id);
		Matrix matrix = new Matrix(); 
	    matrix.postRotate(trancelate);
	    int width = bmp.getWidth();
	    int height = bmp.getHeight();
	    bmp = Bitmap.createBitmap(bmp, 0, 0, width, height, matrix, true);

		return bmp;
	}
	
	public static Bitmap Bitmap_Trancelate(Bitmap bmp,int trancelate){
		
		Matrix matrix = new Matrix(); 
	    matrix.postRotate(trancelate);
	    int width = bmp.getWidth();
	    int height = bmp.getHeight();
	    bmp = Bitmap.createBitmap(bmp, 0, 0, width, height, matrix, true);

		return bmp;
	}

	public static Bitmap createBitmap(Resources m_Resources,int id,float scale_w,float scale_h){
		Bitmap bmp = BitmapFactory.decodeResource(m_Resources, id);
		int bmpWidth = bmp.getWidth();
		int bmpHeight = bmp.getHeight();
		float scaleWidth = (float)(1*scale_w);
		float scaleHeight = (float)(1*scale_h);
		Matrix matrix = new Matrix();
		matrix.postScale(scaleWidth,scaleHeight);
		
		return Bitmap.createBitmap(bmp,0,0,bmpWidth,bmpHeight,matrix,true);
	}
	
	public static Bitmap setBitmapScale(Bitmap bmp,float scale_w,float scale_h){
		int bmpWidth = bmp.getWidth();
		int bmpHeight = bmp.getHeight();
		float scaleWidth = (float)(1*scale_w);
		float scaleHeight = (float)(1*scale_h);
		Matrix matrix = new Matrix();
		matrix.postScale(scaleWidth,scaleHeight);
		
		return Bitmap.createBitmap(bmp,0,0,bmpWidth,bmpHeight,matrix,true);
	}

	public static Drawable createDrawable(Resources m_Resources,int id){
		Drawable draw = null;
		draw = m_Resources.getDrawable(id);
		return draw;
	}
	
	public static int getTransStrToInt(String str){
		try{
			return StringUtils.stringToInt(str);
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}
	public static double getTransStrToDouble(String str){
		try{
			return Double.parseDouble(str);
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}
  public static String getFormatString(double aim,String format) {
		DecimalFormat myformat1 = new DecimalFormat(format);
		return myformat1.format(aim);
	}
  public static String getFormatString(String aim,String format) {
		DecimalFormat myformat1 = new DecimalFormat(format);
		return myformat1.format(getTransStrToDouble(aim));
	}
	/**
	 * 按照通用的换行符切分字符串
	 * @param src
	 * @return
	 */
	public static ArrayList<String> splitStringByLine(final String src) {
		if (src == null)
			throw new NullPointerException();
		ArrayList<String> list = new ArrayList<String>();
		int index = 0;
		int index1, index2;
		final int len = src.length();
		while (true) {
			index1 = src.indexOf('\n', index);
			index2 = src.indexOf('\r', index);
			if (index1 < 0)
				index1 = len;
			if (index2 < 0)
				index2 = len;
			if (index1 > index2)
				index1 = index2;
			list.add(src.substring(index, index1));
			if ((index = index1) == len)
				break;
			// skip
			if (src.charAt(index++) == '\r' && index < len && src.charAt(index) == '\n')
				index++;
			if (index == len) {
				list.add("");
				break;
			}
		}
		return list;
	}
	
	public static ArrayList<String> splitString(String string, final int lineWidth, final int firstLineWidth) {
		if (string == null)
			throw new NullPointerException();
		string = string.replaceAll("\t", " ");
		ArrayList<String> tmpList = splitStringByLine(string);
		ArrayList<String> list = new ArrayList<String>();
		final int expectChars = Math.max(lineWidth / stringWidth("国"), 1);
		int width = firstLineWidth;
		for (String str : tmpList) {
			if (str.length() < 1) {
				list.add(str);
				width = lineWidth;
				continue;
			}
			int len;
			int index;
			while (true) {
				index = expectChars;
				len = str.length();
				if (index > len)
					index = len;
				int w = stringWidth(str.substring(0, index));
				if (w > width && index > 1) {
					--index;
					for (; index > 1; --index)
						if (stringWidth(str.substring(0, index)) <= width)
							break;
				} else if (w < width && index < len) {
					for (; index < len; ++index)
						if (stringWidth(str.substring(0, index+1)) > width)
							break;
				}
				if (index < len) {
					list.add(str.substring(0, index));
					str = str.substring(index);
					width = lineWidth;
				} else {
					list.add(str);
					width = lineWidth;
					break;
				}
			}
		}
		return list;
	}	
}
