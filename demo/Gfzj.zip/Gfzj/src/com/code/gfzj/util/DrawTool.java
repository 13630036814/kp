package com.code.gfzj.util;



import java.util.Vector;

import com.code.gfzj.ui.coustomviews.stockViews.Theme;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.FontMetricsInt;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.util.Log;

public class DrawTool 
{
	public static final void drawText(Canvas c, float x, float y, int w, int h,
			Paint p, String text)
	{
		final FontMetricsInt fmi = p.getFontMetricsInt();
		final int fontHeight = fmi.bottom - fmi.top;
		final float drawY = y + (h - fontHeight) / 2 - fmi.top;
		c.drawText(text, x, drawY, p);
	}

	public static final void drawText(Canvas c, float x, float y, int w, int h,
			Paint p, String text, int start, int end) 
	{
		final FontMetricsInt fmi = p.getFontMetricsInt();
		final int fontHeight = fmi.bottom - fmi.top;
		final float drawY = y + (h - fontHeight) / 2 - fmi.top;
		c.drawText(text, start, end, x, drawY, p);
		//p.setTextAlign(Align.)
	}
	
	//画文字居中 for tmp
	public static final void drawTextMid(Canvas c, float x, float y, int w, int h,
			Paint p, String text)
	{
		final FontMetricsInt fmi = p.getFontMetricsInt();
		final int fontHeight = fmi.bottom - fmi.top;
		final float textWidth = p.measureText(text);
		final float drawX = x + (w - textWidth) / 2;
		final float drawY = y + (h - fontHeight) / 2 - fmi.top;
		c.drawText(text, drawX, drawY, p);
	}	

	/**
	 * 箭头
	 * 
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @return
	 */
/*	
	public static Path buildArrowPath(int x, int y, int w, int h, Paint paint,
			boolean isUp) {
		Path arrowPath = new Path();
		float textSize = paint.getTextSize();
		final float drawY = y + h / 2;
		float top = drawY - textSize / 2;

		if (isUp) {
			arrowPath.moveTo(x, top);
			arrowPath.lineTo(x - w / 2, top + 10);
			arrowPath.lineTo(x - 2, top + 10);
			arrowPath.lineTo(x - 2, top + textSize);
			arrowPath.lineTo(x + 2, top + textSize);
			arrowPath.lineTo(x + 2, top + 10);
			arrowPath.lineTo(x + w / 2, top + 10);
			arrowPath.close();
		} else {
			arrowPath.moveTo(x, top + textSize);
			arrowPath.lineTo(x - w / 2, top + textSize - 10);
			arrowPath.lineTo(x - 2, top + textSize - 10);
			arrowPath.lineTo(x - 2, top + 2);
			arrowPath.lineTo(x + 2, top + 2);
			arrowPath.lineTo(x + 2, top + textSize - 10);
			arrowPath.lineTo(x + w / 2, top + textSize - 10);
			arrowPath.close();
		}
		return arrowPath;
	}
*/	
	public static Path buildArrowPath(int x, int y, int w, int h, Paint paint,
			boolean isUp) {
		Path arrowPath = new Path();
		float textSize = paint.getTextSize();
		final float drawY = y + h / 2;
		float top = drawY - textSize / 2;

		if (isUp) {
			arrowPath.moveTo(x, top);
			arrowPath.lineTo(x - w / 2, top + 8);
			arrowPath.lineTo(x - 2, top + 8);
			arrowPath.lineTo(x - 2, top + textSize);
			arrowPath.lineTo(x + 2, top + textSize);
			arrowPath.lineTo(x + 2, top + 8);
			arrowPath.lineTo(x + w / 2, top + 8);
			arrowPath.close();
		} else {
			arrowPath.moveTo(x, top + textSize);
			arrowPath.lineTo(x - w / 2, top + textSize - 8);
			arrowPath.lineTo(x - 2, top + textSize - 8);
			arrowPath.lineTo(x - 2, top + 2);
			arrowPath.lineTo(x + 2, top + 2);
			arrowPath.lineTo(x + 2, top + textSize - 8);
			arrowPath.lineTo(x + w / 2, top + textSize - 8);
			arrowPath.close();
		}
		return arrowPath;
	}	

	/**
	 * 画文字价格
	 * @param c
	 * @param x 箭头坐标
	 * @param y 箭头坐标
	 * @param rectW 区域宽
	 * @param rectH 区域高
	 * @param text 文本
	 */
	public static final void drawArrowPrice(Canvas c, float x, float y, int rectW, int rectH, String text) 
	{
		boolean bArrowLeft=true;
		int wArrow=30;
		int hArrow=10;
		float xoffset = 6;

		Paint pricePaint = Theme.factroyPricePaint();
		pricePaint.setColor(0XFFFFFF0B);
		int iTextW = (int)pricePaint.measureText(text);
		if(x+wArrow+iTextW <= rectW)
		{
			bArrowLeft = true;			
		}
		else
		{
			bArrowLeft = false;
		}
		
		Paint paint = Theme.factroyPaint();
		paint.setStyle(Paint.Style.STROKE);
		// paint.setStrokeWidth(1.5f);
		//paint.setAlpha(255);
		paint.setColor(0XFFFFFF0B);		
		if(bArrowLeft)
		{
			//left arrow
			c.drawLine(x, y, x+xoffset, y-hArrow/2, paint);
			c.drawLine(x, y, x+xoffset, y+hArrow/2, paint);
			c.drawLine(x, y, x+wArrow, y, paint);
			DrawTool.drawText(c, x+wArrow, y, 0, 0, pricePaint, text);			
		}
		else
		{
			DrawTool.drawText(c, x-wArrow-iTextW, y, 0, 0, pricePaint, text);
			//right arrow
			c.drawLine(x, y, x-xoffset, y-hArrow/2, paint);
			c.drawLine(x, y, x-xoffset, y+hArrow/2, paint);
			c.drawLine(x, y, x-wArrow, y, paint);		
		}
	}	
	
	/**
	 * 获取虚线
	 * 
	 * @param x
	 * @param y
	 * @param r
	 * @param isHorizontal
	 *            横线或纵线
	 * @return
	 */
	public static float[] getDottedLine(Rect r, boolean isHorizontal) {
		if (r == null)
			return null;
		final float section = 6.0f;// 段长
		final int gap = 2;// 间隔
		final int end = isHorizontal ? r.right : r.bottom;
		final int len = isHorizontal ? r.width() : r.height();
		final int fix = 1;
		float xSection = 0;
		int xGap = 0;
		float ySection = 0;
		int yGap = 0;
		float countf = len / section;

		float finalSection = len / countf;

		float x = r.left;
		float y = r.top;
		if (isHorizontal) {
			xSection = finalSection;
			xGap = gap;
		} else {
			ySection = finalSection;
			yGap = gap;
		}
		final int count = (int) countf;
		//这里count+fix为负时下面的语句会导致运行异常
		float[] line = new float[(count + fix) * 4];
		for (int i = 0; i < count; i++) {
			line[i * 4] = x;
			line[i * 4 + 1] = y;
			line[i * 4 + 2] = x + xSection - xGap;
			line[i * 4 + 3] = y + ySection - yGap;
			x += xSection;
			y += ySection;
		}
		if (isHorizontal) {
			line[count * 4] = x;
			line[count * 4 + 1] = y;
			line[count * 4 + 2] = end;
			line[count * 4 + 3] = y;
		} else {
			line[count * 4] = x;
			line[count * 4 + 1] = y;
			line[count * 4 + 2] = x;
			line[count * 4 + 3] = end;
		}

		return line;
	}

	/**
	 * 生成均线
	 * 
	 * @param data
	 * @param maxValueOfTop
	 * @param minValueOfBottom
	 * @param maxColumnCount
	 * @return
	 */
	public static Path buildAVLine(int[] data, AFloat maxValueOfTop,
			AFloat minValueOfBottom, int maxColumnCount, Rect rect,
			int[] dataEx, int dfix, float[] valueY) {
		Path p = new Path();
		AFloat startAFloat = new AFloat();
		// AFloat temAFloat = new AFloat();
		int drawcount = data.length;
		int exCount = getDataCount(dataEx) - dfix;
		if (exCount < 0) {
			exCount = 0;
		}
		float maxZf = maxValueOfTop.toFloat() - minValueOfBottom.toFloat();// temAFloat.singleSub(maxValueOfTop,
																			// minValueOfBottom).nValue;
		if (maxZf == 0) {
			return p;
		}
		float perX = 100 * rect.width() / maxColumnCount; // 水平的间隔点
		float newx = 0;
		float newy = 0;
		float xfix = perX / 100;
		perX = 100 * (rect.width() - xfix) / maxColumnCount;

		float zf = startAFloat.init(data[0]).toFloat()
				- minValueOfBottom.toFloat();// temAFloat.singleSub(startAFloat.init(data[0]),minValueOfBottom).nValue;
		float sy = rect.bottom - zf * rect.height() / maxZf;

		p.moveTo(0, sy);

		for (int i = 0; i < drawcount + exCount; i++) {
			int iTem = 0;
			if (i >= drawcount) {
				iTem = dataEx[dfix + i - drawcount];
			} else {
				iTem = data[i];
			}
			newx = rect.left + perX * i / 100 + xfix;
			zf = startAFloat.init(iTem).toFloat() - minValueOfBottom.toFloat();
			// zf = temAFloat.singleSub(startAFloat.init(iTem),
			// minValueOfBottom).nValue;
			newy = rect.bottom - zf * rect.height() / maxZf;
			// Log.i("buildAVLine", "newx:"+newx+"  newy"+newy);
			//chenx add it 20121206 for 涨停线不越界，能完整显示
			int itmp = (int)newy;
			if(itmp<=rect.top){
				newy=rect.top+1;
			}			
			if (i == 0) {
				p.moveTo(newx, newy);
			} else {
				p.lineTo(newx, newy);
			}
			if(valueY != null && data != null && valueY.length == data.length)
			{
				valueY[i] = newy;
			}
		}

		return p;
	}

	public static Path getVolPath(int[] data, AFloat maxValueOfTop,
			int maxColumnCount, Rect rect, int[] dataEx, int dfix) {
		Path path = new Path();
		AFloat startAFloat = new AFloat();
		int drawcount = data.length;
		int exCount = getDataCount(dataEx) - dfix;
		if (exCount < 0) {
			exCount = 0;
		}
		int maxZf = maxValueOfTop.nValue;
		float newx = 0;
		float newy = 0;
		float perX = 100 * rect.width() / maxColumnCount; // 水平的间隔点
		float xFix = perX / 100;
		int zf = startAFloat.init(data[0]).nValue;
		perX = 100 * (rect.width() - xFix) / maxColumnCount;

		if (maxZf == 0) {
			return path;
		}
		for (int i = 0; i < drawcount + exCount; i++) {
			int iTem = 0;
			if (i >= drawcount) {
				iTem = dataEx[dfix + i - drawcount];
			} else {
				iTem = data[i];
			}
			newx = rect.left + perX * i / 100 + xFix;
			zf = startAFloat.init(iTem).nValue;
			newy = rect.bottom - zf * rect.height() / maxZf;
			if (i == 0) {
				path.moveTo(newx, newy);
			} else {
				path.lineTo(newx, newy);
			}

		}
		path.lineTo(newx, rect.bottom);
		path.lineTo(rect.left + xFix, rect.bottom);
		path.close();
		return path;
	}

	/**
	 * 成交量
	 * 
	 * @param data
	 * @param maxValueOfTop
	 * @param maxColumnCount
	 * @return
	 */
	public static float[] getVolumeLines(int[] data, AFloat maxValueOfTop,
			int maxColumnCount, Rect rect, int[] dataEx, int dfix) {
		AFloat startAFloat = new AFloat();
		int drawcount = data.length;
		int exCount = getDataCount(dataEx) - dfix;
		if (exCount < 0) {
			exCount = 0;
		}
		int maxZf = maxValueOfTop.nValue;
		float newx = 0;
		float newy = 0;
		float perX = 100 * rect.width() / maxColumnCount; // 水平的间隔点
		float xFix = perX / 100;
		int zf = startAFloat.init(data[0]).nValue;
		perX = 100 * (rect.width() - xFix) / maxColumnCount;

		float[] lines = new float[4 * (drawcount + exCount)];
		if (maxZf == 0) {
			return new float[0];
		}
		for (int i = 0; i < drawcount + exCount; i++) {
			int iTem = 0;
			if (i >= drawcount) {
				iTem = dataEx[dfix + i - drawcount];
			} else {
				iTem = data[i];
			}
			newx = rect.left + perX * i / 100 + xFix;
			zf = startAFloat.init(iTem).nValue;
			newy = rect.bottom - zf * rect.height() / maxZf;
			lines[i * 4] = newx;
			lines[i * 4 + 1] = rect.bottom;
			lines[i * 4 + 2] = newx;
			lines[i * 4 + 3] = newy;
		}
		return lines;
	}

	private static int getDataCount(int[] dataEx) {
		int exCount = 0;
		if (dataEx != null) {
			exCount = dataEx.length;
		}
		return exCount;
	}

	public static String[] splitStrings(String s, Paint paint, int w) {
		staticV.removeAllElements();

		int base = (int) (w / paint.measureText("汉"));
		int count = 0;
		int sLen = s.length();
		int faceLabelcrl = -1;// [f:
		char c;
		for (int i = 0; i < sLen; i++) {
			c = s.charAt(i);
			if (faceLabelcrl != -1) {
				switch (faceLabelcrl) {
				case 0:
					if (c == 'f') {
						faceLabelcrl++;
					} else {
						faceLabelcrl = -1;
					}
					break;
				case 1:
					if (c == ':') {
						faceLabelcrl++;
					} else {
						faceLabelcrl = -1;
					}
					break;
				case 2:
					if (!Character.isDigit(c)) {
						faceLabelcrl = -1;
					} else {
						faceLabelcrl++;
					}
					break;
				case 100:
					break;
				default:
					if (c == ']') {
						staticV.addElement(s.substring(count, i + 1));
						count = i + 1;
						faceLabelcrl = 100;
						continue;
					}
					break;
				}
			} else if (c == '[') {
				faceLabelcrl = 0;
			}
			if (c == '\n') {
				staticV.addElement(s.substring(count, i - 1));
				count = i + 1;
				continue;
			}
			if ((i - count) >= base
					&& paint.measureText(s.substring(count, i)) > w) {
				staticV.addElement(s.substring(count, i - 1));
				count = i - 1;
			}
		}
		staticV.addElement(s.substring(count, sLen));
		if (staticV.size() == 0) {
			return null;
		} else {
			String[] items = new String[staticV.size()];
			staticV.copyInto(items);
			return items;
		}
	}
	
	//放大缩小图片   
    public static Bitmap zoomBitmap(Bitmap bitmap,int w,int h)
    {   
        int width = bitmap.getWidth();   
        int height = bitmap.getHeight();   
        Matrix matrix = new Matrix();   
        float scaleWidht = ((float)w / width);   
        float scaleHeight = ((float)h / height);   
        matrix.postScale(scaleWidht, scaleHeight);   
        Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);   
        return newbmp;   
    }   
    
    //将Drawable转化为Bitmap   
     public static Bitmap drawableToBitmap(Drawable drawable)
     {   
            int width = drawable.getIntrinsicWidth();   
            int height = drawable.getIntrinsicHeight();   
            Bitmap bitmap = Bitmap.createBitmap(width, height,   
                    drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888   
                            : Bitmap.Config.RGB_565);   
            Canvas canvas = new Canvas(bitmap);   
            drawable.setBounds(0,0,width,height);   
            drawable.draw(canvas);   
            return bitmap;   
               
    }   
        
     //获得圆角图片的方法   
    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap,float roundPx)
    {          
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap   
                .getHeight(), Config.ARGB_8888);   
        Canvas canvas = new Canvas(output);   
    
        final int color = 0xff424242;   
        final Paint paint = new Paint();   
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());   
        final RectF rectF = new RectF(rect);   
    
        paint.setAntiAlias(true);   
        canvas.drawARGB(0, 0, 0, 0);   
        paint.setColor(color);   
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);   
    
        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));   
        canvas.drawBitmap(bitmap, rect, rect, paint);   
    
        return output;   
    }   
    
    //获得带倒影的图片方法   
    public static Bitmap createReflectionImageWithOrigin(Bitmap bitmap){   
        final int reflectionGap = 4;   
        int width = bitmap.getWidth();   
        int height = bitmap.getHeight();   
           
        Matrix matrix = new Matrix();   
        matrix.preScale(1, -1);   
           
        Bitmap reflectionImage = Bitmap.createBitmap(bitmap,    
                0, height/2, width, height/2, matrix, false);   
           
        Bitmap bitmapWithReflection = Bitmap.createBitmap(width, (height + height/2), Config.ARGB_8888);   
           
        Canvas canvas = new Canvas(bitmapWithReflection);   
        canvas.drawBitmap(bitmap, 0, 0, null);   
        Paint deafalutPaint = new Paint();   
        canvas.drawRect(0, height,width,height + reflectionGap,   
                deafalutPaint);   
           
        canvas.drawBitmap(reflectionImage, 0, height + reflectionGap, null);   
           
        Paint paint = new Paint();   
        LinearGradient shader = new LinearGradient(0,   
                bitmap.getHeight(), 0, bitmapWithReflection.getHeight()   
                + reflectionGap, 0x70ffffff, 0x00ffffff, TileMode.CLAMP);   
        paint.setShader(shader);   
        // Set the Transfer mode to be porter duff and destination in   
        paint.setXfermode(new PorterDuffXfermode(Mode.DST_IN));   
        // Draw a rectangle using the paint with our linear gradient   
        canvas.drawRect(0, height, width, bitmapWithReflection.getHeight()   
                + reflectionGap, paint);   
    
        return bitmapWithReflection;   
    }   

	/**
	 * 绘制渐变圆角按钮（仿OPEAR MINI）
	 * g 工具
	 * bitmap 图
	 * @param x
	 * @param y
	 * @param w
	 * @param h
	 * @param caption
	 *            文字标题（文字标题和图像不能共用）
	 *            
	 * paint 字体设置
	 */
	public static void drawButton(Canvas g, Bitmap bitmap, int x, int y, int w, int h,
			String caption, Paint paint)
	{
		Bitmap zoomBitmap = zoomBitmap(bitmap, w, h);  
		g.drawBitmap(zoomBitmap, x, y, paint); 
		
		final FontMetricsInt fmi = paint.getFontMetricsInt();
		final int fontHeight = fmi.bottom - fmi.top;
		final int fontWidth = (int)paint.measureText(caption);
		drawText(g, x+2+(w-2*2-fontWidth)/2, y+2+(h-2*2)/fontHeight , w-2*2, h-2*2, paint, caption);
	}
	
    
	static Vector<String> staticV = new Vector<String>();
	
	/*
	 * 填充三角形
	 */
	public static void fillTriangle(int x1, int y1, int x2, int y2, int x3, int y3,Canvas g, Paint paint) {
        Path path = new Path();
        paint.setStyle(Style.FILL);
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.lineTo(x1, y1);
        g.drawPath(path, paint);
    }	
	
	/*
	 * 	其他----------begin-------------------------------------------------------------------------------
	 */
	
//  public static int NUMBER_TYPE;
  public static int NUMBER_WIDTH;
  public static int NUMBER_HEIGHT;
/*  
//
  public static void init() {
//  	if(Globe.fullScreenWidth > Globe.fullScreenHeight)//横屏
//  		NUMBER_WIDTH = NUMBER_HEIGHT = 14*Globe.arg2/100;
//  	else//竖屏
  		NUMBER_WIDTH = NUMBER_HEIGHT = 14*Global.arg2/100;
  }
//
  public static void drawNumber(Canvas g, String n, int x, int y, int anchor) {
  	Align a = Align.LEFT;
      if ((anchor & Functions.RIGHT) != 0) {
          a = Align.RIGHT;
      } else if ((anchor & Functions.HCENTER) != 0) {
          a = Align.CENTER;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      Functions.mPaint2.setTextSize(NUMBER_WIDTH);
      
      if(n==null)
      	n="--";
      if(n.equals("null"))
      	n="";
      
      Functions.drawString2(n, x, y, a, g);

  }
  
  public static void paintWords(Canvas g, String n, int x, int y, int anchor) {
  	Functions.mPaint2.setColor(Color.WHITE);
      int w = NUMBER_WIDTH * n.length();

      if ((anchor & Functions.RIGHT) != 0) {
          x -= w;
      } else if ((anchor & Functions.HCENTER) != 0) {
          x -= w / 2;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      if(n==null)
      	n="--";
      
      Functions.mPaint2.setTextSize(NUMBER_WIDTH);
      Functions.drawString2(n, x, y, Align.LEFT, g);

  }
  
  public static void paintWords(Canvas g, String n, int x, int y,int Color, int anchor) {
  	Functions.mPaint2.setColor(Color);
      int w = Functions.stringWidth2(n);

      if ((anchor & Functions.RIGHT) != 0) {
          x -= w;
      } else if ((anchor & Functions.HCENTER) != 0) {
          x -= w / 2;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      if(n==null)
      	n="--";
      
      Functions.mPaint2.setTextSize(NUMBER_WIDTH);
      Functions.drawString2(n, x, y, Align.LEFT, g);

  }
  
  public static void paintWords2(Canvas g, String n, int x, int y, int anchor) {
  	
      int w = Functions.stringWidthWithPaint(n, Functions.mPaint2);

      if ((anchor & Functions.RIGHT) != 0) {
          x -= w;
      } else if ((anchor & Functions.HCENTER) != 0) {
          x -= w / 2;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      if(n==null)
      	n="--";
      
      Functions.mPaint2.setTextSize(NUMBER_WIDTH);
      Functions.drawString2(n, x, y, Align.LEFT, g);

  }
  
  public static void paintWords3(Canvas g, String n, int x, int y, int anchor) {
  	
      int w = NUMBER_WIDTH * n.length()/2;

      if ((anchor & Functions.RIGHT) != 0) {
          x -= w;
      } else if ((anchor & Functions.HCENTER) != 0) {
          x -= w / 2;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      if(n==null)
      	n="--";
      
      Functions.mPaint2.setTextSize(NUMBER_WIDTH);
      Functions.drawString2(n, x, y, Align.LEFT, g);

  }
  
  public static void paintWords4(Canvas g, String n, int x, int y, int anchor) {
  	
      int w = NUMBER_WIDTH * n.length()/2;

      if ((anchor & Functions.RIGHT) != 0) {
          x -= w;
      } else if ((anchor & Functions.HCENTER) != 0) {
          x -= w / 2;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      if(n==null)
      	n="--";

      Functions.mPaint5.setColor(Color.WHITE);
      Functions.drawString3(n, x, y, Align.LEFT, g);

  }
  
  public static void paintWords4(Canvas g, String n, int x, int y, int Color, int anchor) {
  	
      int w = NUMBER_WIDTH * n.length()/2;

      if ((anchor & Functions.RIGHT) != 0) {
          x -= w;
      } else if ((anchor & Functions.HCENTER) != 0) {
          x -= w / 2;
      }

      if ((anchor & Functions.BOTTOM) != 0) {
          y -= NUMBER_HEIGHT;
      } else if ((anchor & Functions.VCENTER) != 0) {
          y -= NUMBER_HEIGHT / 2;
      }
      
      if(n==null)
      	n="--";

      Functions.mPaint5.setColor(Color);
      Functions.drawString3(n, x, y, Align.LEFT, g);

  }

  public static String format(int v, int d) {
      String s = String.valueOf(Math.abs(v));
      while (s.length() <= d) {
          s = "0" + s;
      }
      if (v < 0) {
          s = "-" + s;
      }       
      if (d == 0) {
          return s;
      } else {
          return s.substring(0, s.length() - d) + "." + s.substring(s.length() - d);
      }
  }
  
  public static String format3(int v, int d) {
      String s = String.valueOf(Math.abs(v));
      while (s.length() <= d) {
          s = "0" + s;
      }
      if (v < 0) {
          s = "-" + s;
      }
      else if(v > 0)
      	s = "+" + s;
      
      if (d == 0) {
          return s;
      } else {
          return s.substring(0, s.length() - d) + "." + s.substring(s.length() - d);
      }
  }
  
  public static String format2(int v, int d) {
      String s = String.valueOf(Math.abs(v));
      while (s.length() <= d) {
          s = "0" + s;
      }
      if (v < 0) {
          s = "-" + s;
      }       
      if (d == 0) {
          return s;
      } else {
          return s.substring(0, s.length() - d);
      }
  }

  public static int getColor(int v) {
      return v == 0 ? 0xFFFFFFFF : (v > 0 ? 0xFFFF0000 : 0xFF00FF00);
  }
  
  public static int getColor(long v) {
      return v == 0 ? 0xFFFFFFFF : (v > 0 ? 0xFFFF0000 : 0xFF00FF00);
  }
  
  public static int getColor3(int v) {
      return v == 0 ? 0xFF000000 : (v > 0 ? 0xFFFF0000 : 0xFF00FF00);
  }
  
  public static int getColor_(int v) {
      return v == 0 ? 0xFF989898 : (v > 0 ? 0xFFDD0000 : 0xFF0DB800);
  }

  public static int getColor(int r, int c) {
      return getColor((r == 0 || c == 0) ? 0 : r - c);
  }
  
  
  public static int getColor2(int v) {
      return v == 0 ? 0xFF00FF00 : 0xFFFF0000;
  }
  
  public static int getColor3(int r, int c) {
      return getColor_((r == 0 || c == 0) ? 0 : r - c);
  }
  
  public static int getColor4(int r, int c) {
      return getColor3((r == 0 || c == 0) ? 0 : r - c);
  }
  
  public static String getSign_(int v) {
      return v == 0 ? "" : (v > 0 ? "+" : "-");
  }
  
  public static String getSign(int r, int c) {
      return getSign_((r == 0 || c == 0) ? 0 : r - c);
  }
  
  public static int getRate(int r, int c) {
      if (r == 0 || c == 0) {
          return 0;
      }
      long v = (long) (r - c) * 1000000 / c;
      return (int) ((v + (v >= 0 ? 50 : -50)) / 100);
  }
  
  public static int getRate(long r, long c) {
      if (r == 0 || c == 0) {
          return 0;
      }
      long v = (long) (r - c) * 1000000 / c;
      return (int) ((v + (v >= 0 ? 50 : -50)) / 100);
  }

  public static String formatPrice(int v, int d) {
      return v == 0 ? "-" : format(v, d);
  }
  
  public static String formatLeve2Price(int v, int d) {
      if (d == 1) {
          return v == 0 ? "0.0" : format(v, d);
      } else if (d == 2) {
          return v == 0 ? "0.00" : format(v, d);
      } else {
          return v == 0 ? "0.000" : format(v, d);
      }
  }
  
  public static String format56(int v, int d) {
  	
      int t = (int) (v % (Math.pow(10, d)));
      if(d>1){
      	t = (int) (t % (Math.pow(10, d-1)));
	        if(t>=5)
	        	v += Math.pow(10, d-1);
	        else if(t<=-5)
	        	v -= Math.pow(10, d-1);
	        
	        v /= Math.pow(10, d-1);
	        return formatLeve2Price(v,d-1);
      }
      
      return formatLeve2Price(v,d);
  }
  
  public static String formatNumberWithDecimal(float value,int length){
  	String str = "";
  	String dec = "###0.00";
  	if(length == 3)
  		dec = "###0.000";
  	else if(length == 1)
  		dec = "###0.0";
  	DecimalFormat df = new DecimalFormat(dec);
  	str = String.valueOf(df.format(value));
  	return str;
  }
  
  public static int format56(int v){
  	int a = v % 10;
  	int b = v / 10;
  	
  	if(a > 5){
  		b += 1;
  	}
  	
  	return b;
  }
  

  public static String formatVolumn(int v) {
      return v == 0 ? "-" : String.valueOf(v);
  }
  
  
  public static String formatVolumn2(int v) {
      return v == 0 ? "1" : String.valueOf(v);
  }
  
  public static String formatVolumn(long v) {
      return v == 0 ? "-" : String.valueOf(v);
  }

  public static String formatDelta(int r, int c, int d) {
      return (r == 0 || c == 0) ? "-" : "" + format(r - c, d);
  }
  
  public static String formatDelta2(int r, int c, int d) {
      return (r == 0 || c == 0 || r - c == 0) ? "-" : "" + format(r - c, d);
  }
  
  public static String formatDelta3(int r, int c, int d) {
      return (r == 0 || c == 0) ? "-" : "" + format3(r - c, d);
  }

  public static String formatRate(int r, int c) {
      return (r == 0 || c == 0) ? "-" : "" + format(getRate(r, c), 2) + "%";
  }
  
  public static String formatRate2(int r, int c) {
      return (r == 0 || c == 0) ? "-" : "" + format3(getRate(r, c), 2) + "%";
  }

  public static String formatRateHuge1000(int r) {
      return (r == 0 ) ? "--" : "" + format(getRate(r + 10000, 10000), 2) + "%";
  }
  
  public static String formatRateHuge1000_2(int r) {
      return (r == 0 ) ? "--" : "" + format(getRate(r + 10000, 10000), 2);
  }
  
  public static String formatRateHuge1000_3(int r) {
      return (r == 0 ) ? "--" : "" + format2(getRate(r + 10000, 10000), 2);
  }

  public static String formatRate2(int r,int c,int dclen){
  	return (r == 0 || c == 0) ? "0" : format(getRate(r, c)/10, dclen);
  }
  
  public static String formatRate3(float r,float c,int dclen){
  	return (r == 0 || c == 0) ? "0" : format(divide(r, c), dclen);
  }
  
  public static String formatRate4(int r, int c) {
      return (r == 0 || c == 0) ? "-" : "" + format(getRate(r, c), 2);
  }
  
  public static String formatZJL(long v){
  	if(v > 0){
  		return "资金流入" + Functions.formatNumString2(v);
  	}
  	else if(v < 0){
  		return "资金流出" + Functions.formatNumString2(v);
  	}
  	return "-";
  }
  
  public static int divide(float r,float c){
  	float v = r / c ;
  	v = v*10000;
  	return (int) v;
  }

  public static String formatTime(int t) {
      try {
          String tStr = String.valueOf(t);
          if (tStr.length() < 4) {
              tStr = "0" + tStr;
          }
          return tStr.substring(0, 2) + ":" + tStr.substring(2, 4);
      } catch (Exception e) {
          return "-";
      }
  }
  
  public static String formatTime2(int t) {
      try {
          String tStr = String.valueOf(t);
          if(tStr.length() <= 4){
          	 if (tStr.length() < 4) {
                   tStr = "0" + tStr;
               }
               return tStr.substring(0, 2) + ":" + tStr.substring(2, 4);
          }
          
	        if (tStr.length() < 6) {
	                tStr = "0" + tStr;
	        }
	        return tStr.substring(0, 2) + ":" + tStr.substring(2, 4) + ":" + tStr.substring(4, 6);
          
      } catch (Exception e) {
          return "-";
      }
  }
  
  public static String formatTime3(int t) {
      try {
          String tStr = String.valueOf(t);
          
	        return tStr.substring(4,6)+"/"+tStr.substring(6);
          
      } catch (Exception e) {
          return "-";
      }
  }
  
  public static String formatVolumnHand(int v,int m) {
  	if(m == 0)
  		m = 100;
      if (v == 0) {
          return "-";
      } else if (v < m) {
          return "0." + v;
      } else {
          return "" + v / m;
      }
  }

  public static long parseLong(int v) {
      int v1 = (v >>> 30) & 0x03;
      if (v1 == 0) {
          return v;
      } else {
          long v2 = v & 0x3FFFFFFF;
          v2 = v2 << (v1 * 4);
          return v2;
      }
  }
  
  public static long parseLongWithSign(int v) {
      int v1 = (v >>> 30) & 0x03;
      if (v1 == 0) {
      	int v3 = (v >>> 29) & 0x1;
      	if(v3 == 0)
      		return v;
      	else
      	{	
      		int v4 = (v >>> 30) | 0xc;
      		v = (v4 << 28) | v;
      		return ((~v + 1) & 0xffffffff) * ( -1);
      	}
      } else {
          long v2 = v & 0x3FFFFFFF;

          int v3 = (v >>> 29) & 0x1;
      	if(v3 == 0){}
      	else
      	{
      		int v4 = (v >>> 30) | 0xc;
      		v2 = (v4 << 28) | v2;
      		v2 = ((~v2 + 1) & 0xffffffff) * ( -1);
      	}
      	v2 = v2 << (v1 * 4);
      	
      	return v2;
      }
  }
  
  public static long parseLongWithSignNoMinus(int v) {
      int v1 = (v >>> 30) & 0x03;
      if (v1 == 0) {
      	int v3 = (v >>> 29) & 0x1;
      	if(v3 == 0)
      		return v;
      	else
      	{	
      		int v4 = (v >>> 30) | 0xc;
      		v = (v4 << 28) | v;
      		return ((~v + 1) & 0xffffffff);
      	}
      } else {
          long v2 = v & 0x3FFFFFFF;

          int v3 = (v >>> 29) & 0x1;
      	if(v3 == 0){}
      	else
      	{
      		int v4 = (v >>> 30) | 0xc;
      		v2 = (v4 << 28) | v2;
      		v2 = ((~v2 + 1) & 0xffffffff);
      	}
      	v2 = v2 << (v1 * 4);
      	
      	return v2;
      }
  }
  
  public static String formatPercent (int v, int t)
  {
      return t == 0 ? "-" : format (getRate (v + t, t), 2) + "%";
  }
  
  public static String formatPercent (long v, long t)
  {
      return t == 0 ? "-" : format (getRate (v + t, t), 2) + "%";
  }
  
  public static String formatPercent2(int v, int t)
  {
      return (t == 0 || v == 0) ? "--" : format (getRate (v + t, t), 2);
  }
  
  public static String formatPercent2(long v, long t)
  {
      return (t == 0 || v == 0) ? "--" : format (getRate (v + t, t), 2);
  }
  
  //.........................委托........................
  
	public static boolean checkDigits(String s, int digits) {
		int p = s.indexOf(".");
		if (p == -1)
			return true;
		if (s.indexOf(".", p + 1) > 0)
			return false;
		return p + 1 + digits >= s.length();
	}

	public static int getColor(String r, String c) {
		if (r == null || c == null)
			return getColor(0);
		int p1 = r.indexOf(".");
		int p2 = c.indexOf(".");
		if (p1 == -1)
			p1 = r.length();
		if (p2 == -1)
			p2 = c.length();
		int max = Math.max(p1, p2);
		for (int i = p1; i < max; i++)
			r = "0" + r;
		for (int i = p2; i < max; i++)
			c = "0" + c;
		return getColor(r.compareTo(c));
	}
*/	
	/*
	 * 	其他-----------end-----------------------------------------------------------------------------
	 */
}
