/**
 * 
 */
package com.code.gfzj;

import java.util.ArrayList;
import java.util.List;

import com.code.gfzj.data.bean.Message;
import com.code.gfzj.ui.adapter.MailAdapter;
import com.code.gfzj.ui.adapter.PlateAdapter;
import com.code.gfzj.ui.menu.BottomToolBar;
import com.code.gfzj.widget.Navigation;
import com.code.gfzj.widget.NavigationFragment;
import com.code.gfzj.widget.NavigationFragment.onSelectorNavigationListener;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * @author cola
 * 
 */
public class MarketQuotes extends FragmentActivity implements
		onSelectorNavigationListener {
	private List<Navigation> navs = buildNavigation();
	private NavigationFragment mNavigationFragment;
	private ListView mListView;
	private PlateAdapter mPlateAdapter;
	private BottomToolBar menu;
	private RelativeLayout mPopMenu;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.marketquotes);
		init();
		setListener();
	}

	public void init() {
		menu = (BottomToolBar) findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) findViewById(R.id.home_ugc);
		menu.setPopMenur(mPopMenu);
		((TextView) findViewById(R.id.title)).setText("大盘行情");
		mListView = (ListView) findViewById(R.id.rise_listview);
		mNavigationFragment = (NavigationFragment) getSupportFragmentManager()
				.findFragmentById(R.id.fragment_navigation);
		mNavigationFragment.setNavs(navs);
		mNavigationFragment.setOnSelectorNavigationListener(this);
		fillContent(navs.get(0));
		buildNavigation();
		
		List<Message> messages = new ArrayList<Message>();
		for (int i = 0; i < 10; i++) {
			Message msg = new Message();
			msg.setGroupName("广发证券" + i);
//			for (int j = 0; j < 1; j++) {
//				msg.setInfo("600685");
				messages.add(msg);
//			}
		}

		mPlateAdapter = new PlateAdapter(this, messages);//第三个参数是：第一次填充listview时，分组是否展开

		mListView.setAdapter(mPlateAdapter);
		
		menu = (BottomToolBar) findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) findViewById(R.id.home_ugc);
		menu.setPopMenur(mPopMenu);
	}

	private void fillContent(Navigation navigation) {
		Fragment fragment = null;
	}
	
	private void setListener() {
		((Button) findViewById(R.id.top_back)).setBackgroundResource(R.drawable.back);
		((Button) findViewById(R.id.top_back)).setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
			
		});
	}

	private List<Navigation> buildNavigation() {
		List<Navigation> navigations = new ArrayList<Navigation>();
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "大盘"));
		navigations.add(new Navigation(Navigation.TYPE_1, "url", "个股"));
		navigations.add(new Navigation(Navigation.TYPE_2, "url", "全球"));
		navigations.add(new Navigation(Navigation.TYPE_3, "url", "期货"));
		navigations.add(new Navigation(Navigation.TYPE_4, "url", "白银"));
		navigations.add(new Navigation(Navigation.TYPE_5, "url", "很长的标题"));
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "我还是首页"));
		navigations.add(new Navigation(Navigation.TYPE_3, "url", "另一个用户"));
		return navigations;
	}

	@Override
	public void selector(Navigation navigation, int position) {
		// TODO Auto-generated method stub

	}
}
