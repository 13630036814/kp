/**
 * 
 */
package com.code.gfzj;

import android.app.Application;

/**
 * @author mrcola
 *
 */
public class BaseApplication extends Application{
	public void onCreate() {
		super.onCreate();
	}
}
