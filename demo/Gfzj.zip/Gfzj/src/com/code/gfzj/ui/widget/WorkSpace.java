package com.code.gfzj.ui.widget;

//此类

import com.code.gfzj.QuotationActivity;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.Scroller;

public class WorkSpace extends ViewGroup {
	private Activity window=null;
	private static boolean bProcessBySubView = false;//交给子view处理
	
	private static final String TAG = "WorkSpace";
	
	private Scroller mScroller;
	private VelocityTracker mVelocityTracker;

	private int mCurScreen;
	private int mDefaultScreen = 0;

	private static final int TOUCH_STATE_REST = 0;
	private static final int TOUCH_STATE_SCROLLING = 1;

	private static final int SNAP_VELOCITY = 300;

	private int mTouchState = TOUCH_STATE_REST;
	private int mTouchSlop;
	private float mLastMotionX;
	
	private float mLastMotionY;

	public WorkSpace(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}
	
	public WorkSpace(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		mScroller = new Scroller(context);
	
		mCurScreen = mDefaultScreen;
		
		//ax 获取触发移动事件的最短距离，如果小于这个距离就不触发移动控件
		mTouchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
	
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		// TODO Auto-generated method stub
		if (changed) {
			int childLeft = 0;
			final int childCount = getChildCount();
			
			for (int i=0; i<childCount; i++) {
				final View childView = getChildAt(i);
				if (childView.getVisibility() != View.GONE) {
					final int childWidth = childView.getMeasuredWidth();
					childView.layout(childLeft, 0,  
					childLeft+childWidth, childView.getMeasuredHeight());
					childLeft += childWidth;

				}
			}
		}
	}

	@Override
  	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		  super.onMeasure(widthMeasureSpec, heightMeasureSpec);   
	
		  final int width = MeasureSpec.getSize(widthMeasureSpec);   
		  final int widthMode = MeasureSpec.getMode(widthMeasureSpec);   
		
		  if (widthMode == MeasureSpec.UNSPECIFIED) {
			  throw new IllegalStateException("ScrollLayout can't run at UNSPECIFIED mode!");  
		  }

		  final int height = MeasureSpec.getSize(heightMeasureSpec);   
		  final int heightMode = MeasureSpec.getMode(heightMeasureSpec);   

		  if (heightMode == MeasureSpec.UNSPECIFIED) {
		
			  throw new IllegalStateException("ScrollLayout can't run at UNSPECIFIED mode!");

		  }

		  final int count = getChildCount();   

		  for (int i = 0; i < count; i++) {
			  final View childView = getChildAt(i);
//			  Log.e(TAG, "childView = " + childView.toString());
			  childView.measure(widthMeasureSpec, heightMeasureSpec);
		  }
		  
		  scrollTo(mCurScreen * width, 0);   
	}   

	@Override
	protected void dispatchDraw(Canvas canvas) {
		super.dispatchDraw(canvas);
	}
	
	public void setWindow(Activity win)
	{
		this.window = win;		
	}
	
	//ax 根据当前坐标计算滑到目标屏
	public void snapToDestination() {
		final int screenWidth = getWidth();
		final int destScreen = (getScrollX()+ screenWidth/2)/screenWidth;
		snapToScreen(destScreen);
	}

	/**
	 * 滑动到指定页面
	 * @param whichScreen
	 */
	public void snapToScreen(int whichScreen) {

	  whichScreen = Math.max(0, Math.min(whichScreen, getChildCount()-1));
	  if (getScrollX() != (whichScreen*getWidth())) {
    		
		  final int delta = whichScreen*getWidth()-getScrollX();
		  mScroller.startScroll(getScrollX(), 0,  
		  delta, 0, Math.abs(delta)*2);
		  mCurScreen = whichScreen;
//		  if(this.window != null && this.window instanceof QuotationWindow)
//		  {
			  ((QuotationActivity)this.window).snapToScreen();
//		  }
    		invalidate();		// Redraw the layout
	  }
	}

	/**
	 * 直接跳转到指定页面
	 * @param whichScreen
	 */
	public void setToScreen(int whichScreen) {
	  whichScreen = Math.max(0, Math.min(whichScreen, getChildCount()-1));
	  mCurScreen = whichScreen;
	  scrollTo(whichScreen*getWidth(), 0);
	}

	public int getCurScreen() {
	  return mCurScreen;
	}

	@Override
	public void computeScroll() {
		// TODO Auto-generated method stub
		// 如果返回true，表示动画还没有结束
		if (mScroller.computeScrollOffset()) {
		    //产生了动画效果，根据当前值 每次滚动一点 
			scrollTo(mScroller.getCurrX(), mScroller.getCurrY());
			//刷新view
			postInvalidate();
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		if (mVelocityTracker == null) {
			mVelocityTracker = VelocityTracker.obtain();
		}
		mVelocityTracker.addMovement(event);
	
		final int action = event.getAction();
		final float x = event.getX();
		final float y = event.getY();

		switch (action) {
		case MotionEvent.ACTION_DOWN:
			if (!mScroller.isFinished()){
				mScroller.abortAnimation();
			}
			mLastMotionY = y;
			mLastMotionX = x;
			break;
	
		case MotionEvent.ACTION_MOVE:
			int deltaX = (int)(mLastMotionX - x);
			int deltaY = (int)(mLastMotionY - y);
			mLastMotionX = x;
			mLastMotionY = y;
			if(Math.abs(deltaX) > Math.abs(deltaY))
				scrollBy(deltaX, 0);
			break;

		case MotionEvent.ACTION_UP:
			final VelocityTracker velocityTracker = mVelocityTracker;
			velocityTracker.computeCurrentVelocity(500);
			int velocityX = (int) velocityTracker.getXVelocity();

			if (velocityX > SNAP_VELOCITY && mCurScreen > 0) {
				snapToScreen(mCurScreen - 1);
			} else if (velocityX < -SNAP_VELOCITY
					&& mCurScreen < getChildCount() - 1) {
				snapToScreen(mCurScreen + 1);
			} else {
				snapToDestination();
			}

			if (mVelocityTracker != null) {
				mVelocityTracker.recycle();
				mVelocityTracker = null;
			}

			mTouchState = TOUCH_STATE_REST;
			break;
		case MotionEvent.ACTION_CANCEL:
			mTouchState = TOUCH_STATE_REST;
			break;
		}
		
		return true;
	}

	@Override

	public boolean onInterceptTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		final int action = ev.getAction();		
		
		if(bProcessBySubView)
		{
			return false;
		}
		
		if ((action == MotionEvent.ACTION_MOVE) &&  (mTouchState != TOUCH_STATE_REST)) {
			return true;
		}
		
		final float x = ev.getX();
		final float y = ev.getY();
		switch (action) {
		case MotionEvent.ACTION_MOVE:
			final int xDiff = (int)Math.abs(mLastMotionX - x);
//			Log.e(TAG, "xDiff = " + xDiff + ";mLastMotionX = " + mLastMotionX + ";x = " + x);
			if (xDiff > mTouchSlop) {
				mTouchState = TOUCH_STATE_SCROLLING;
			}
			else{
				mLastMotionX = x;
				mLastMotionY = y;
			}
			break;
		case MotionEvent.ACTION_DOWN:
			mLastMotionX = x;
			
			mLastMotionY = y;
			
			mTouchState = mScroller.isFinished()? TOUCH_STATE_REST : TOUCH_STATE_SCROLLING;
			break;
		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			mTouchState = TOUCH_STATE_REST;
			break;
		}
		boolean b = mTouchState != TOUCH_STATE_REST;//对移动事件拦截
		//Log.e("return value"+action, "onInterceptTouchEvent "+b);
		return b;
	}
	
	public int getTouchState(){
		return mTouchState;
	}

	public static boolean isbProcessBySubView() {
		return bProcessBySubView;
	}

	public static void setbProcessBySubView(boolean bProcessBySubView) {
		WorkSpace.bProcessBySubView = bProcessBySubView;
	}
}


