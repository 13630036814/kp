package com.code.gfzj.ui.coustomviews.stockViews;


import com.code.gfzj.base.Global;
import com.code.gfzj.util.AFloat;
import com.code.gfzj.util.TimeTool;

import android.graphics.Paint;

public class Theme {
	private static final int[] UIColors = {0xFF00ff00, 0xFFffffff, 0xFFff0000};	
//	private static final int[] BLACKCOLORS = {0xFF00ff00, 0xFF000000, 0xFFff0000};
	private static final int[] BLACKCOLORS = {0xFF00ff00, 0xFFffffff, 0xFFff0000};
	
//white	
//	private static final int[] UIColors = {0xFF009900, 0xFFffffff, 0xFFff0000};	
//	private static final int[] BLACKCOLORS = {0xFF009900, 0xFF000000, 0xFFff0000};
	
	public static int fonttype = 2; //字体大小 1小 2中 3大
	
	/**
	 * 设置的价格文字大小
	 * @return
	 */
	public static int factroyFontSizeSet(){
		int fontsize=14;
		switch(fonttype)
		{
		case 3:
			fontsize = 20;
			break;
		case 2:
			fontsize = 16;
			break;
		case 1:
		default:
			fontsize = 14;	
			break;		
		}
		return fontsize;
	}
	
	/**
	 * 设置的列表文字大小
	 * @return
	 */
	public static int factroyListFontSizeSet(){
		int fontsize=16;
		switch(fonttype)
		{
		case 3:
			fontsize = 16;
			break;
		case 2:
			fontsize = 15;
			break;
		case 1:
		default:
			fontsize = 14;	
			break;		
		}
		return fontsize;
	}	
	
	/**
	 * 设置的功能菜单条文字大小
	 * @return
	 */
	public static int factroyFuncFontSizeSet(){
		int fontsize=12;
		switch(fonttype)
		{
		case 3:
			fontsize = 14;
			break;
		case 2:
			fontsize = 13;
			break;
		case 1:
		default:
			fontsize = 12;	
			break;		
		}
		return fontsize;
	}	
	
	/**
	 * 设置的盘口文字大小
	 * @param island 是否横屏
	 * @return
	 */
	public static int factroyPkFontSizeSet(boolean island){
		int fontsize=14;
		switch(fonttype)
		{
		case 3:
			if(island)
                fontsize = 19;
			else
				fontsize = 18;
			break;
		case 2:
			if(island)
                fontsize = 17;
			else
				fontsize = 16;
			break;
		case 1:
		default:
			if(island)
                fontsize = 16;
			else
				fontsize = 15;
			break;		
		}
		return fontsize;
	}	
	
	
	public static Paint factroyPaint(){
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		return paint;
	}
	public static Paint factroyListPaint(){
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(16*Global.density);
		return paint;
	}
	
	/**
	 * 设置的列表内容画笔
	 * @return
	 */
	public static Paint factroyListPaintSet(){
		int fontsize=16;
		switch(fonttype)
		{
		case 3:
			fontsize = 20;
			break;
		case 2:
			fontsize = 18;
			break;
		case 1:
		default:
			fontsize = 16;	
			break;		
		}		
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(fontsize*Global.density);
		return paint;
	}
	
	public static Paint factroyTextPaint(){
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(16);
		return paint;
	}
	
	/**
	 * 设置的文字画笔
	 * @return
	 */
	public static Paint factroyTextPaintSet(){
		int fontsize=16;
		switch(fonttype)
		{
		case 3:
			fontsize = 18;
			break;
		case 2:
			fontsize = 16;
			break;
		case 1:
		default:
			fontsize = 14;	
			break;		
		}		
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(fontsize);
		return paint;
	}	
	
	public static Paint factroyPricePaint(){
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(14);
		return paint;
	}	
	
	/**
	 * 设置的价格画笔
	 * @return
	 */
	public static Paint factroyPricePaintSet(){
		int fontsize=14;
		switch(fonttype)
		{
		case 3:
			fontsize = 18;
			break;
		case 2:
			fontsize = 16;
			break;
		case 1:
		default:
			fontsize = 14;	
			break;		
		}
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(fontsize);
		return paint;
	}
	
	public static Paint factroySmallTextPaint(){
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(14*Global.density);
		return paint;
	}
	
	/**
	 * 设置的列表内容画笔2
	 * @return
	 */
	public static Paint factroySmallTextPaintSet(){
		int fontsize=14;
		switch(fonttype)
		{
		case 3:
			fontsize = 18;
			break;
		case 2:
			fontsize = 16;
			break;
		case 1:
		default:
			fontsize = 14;	
			break;		
		}		
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(fontsize*Global.density);
		return paint;
	}	
	
	public static Paint factroyTitlePaint(){
		Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
		paint.setTextSize(18*Global.density);
		return paint;
	}
	
	public static int factoryColor(AFloat nowValue,AFloat basicValue){		
		if(nowValue==null ||basicValue ==null )return UIColors[0];
		final int i = AFloat.compare(nowValue,basicValue)+1;
		return UIColors[i];
	}
	
	public static int factoryColor(AFloat nowValue){	
		int i = 1;
		if(nowValue.toFloat()>0){
			i = 2;
		}else if(nowValue.toFloat()<0){
			i = 0;
		}
		return UIColors[i];
	}
	
	public static int factoryColor(boolean up){	
		int i = 1;
		if(up){
			i = 2;
		}else{
			i = 0;
		}
		return UIColors[i];
	}
	
	public static int defaultColor(){
		return UIColors[1];
	}
	/**
	 * 涨
	 * @return
	 */
	public static int riseColor(){
		return UIColors[2];
	}
	/**
	 * 跌
	 * @return
	 */
	public static int fallColor(){
		return UIColors[0];
	}
	
	// ------------------------------------------------------------------------------
	

	public static int factoryBColor(AFloat nowValue,AFloat basicValue){		
		if(nowValue==null ||basicValue ==null )return BLACKCOLORS[0];
		final int i = AFloat.compare(nowValue,basicValue)+1;
		return BLACKCOLORS[i];
	}
	
	public static int factoryBColor(AFloat nowValue){	
		int i = 1;
		if(nowValue.toFloat()>0){
			i = 2;
		}else if(nowValue.toFloat()<0){
			i = 0;
		}
		return BLACKCOLORS[i];
	}
	
	public static int factoryBColor(boolean up){	
		int i = 1;
		if(up){
			i = 2;
		}else{
			i = 0;
		}
		return BLACKCOLORS[i];
	}
	
	public static int defaultBColor(){
		return BLACKCOLORS[1];
	}
	/**
	 * 涨
	 * @return
	 */
	public static int riseBColor(){
		return BLACKCOLORS[2];
	}
	/**
	 * 跌
	 * @return
	 */
	public static int fallBColor(){
		return BLACKCOLORS[0];
	}
	
	// ------------------------------------------------------------------------------
	
	public static String formatDate(int time){
		int y = time/10000;
		int m = time%10000/100;
		int d = time%10000%100;
		String year = String.valueOf(y);
		String month = m>9?String.valueOf(m):String.format("0%s", m);
		String date = d>9?String.valueOf(d):String.format("0%s", d);
		return String.format("%s/%s/%s/%s", year,month,date,TimeTool.getWeek(time));
	}
	
	public static String formatDateMMDDHHMM(int time){
		
		int m = time/1000000;
		int d =  time%1000000/10000;
		int h =  time%1000000%10000/100;
		int mm = time%1000000%10000%100;		
		String month = m>9?String.valueOf(m):String.format("0%s", m);
		String date = d>9?String.valueOf(d):String.format("0%s", d);
		String hour = h>9?String.valueOf(h):String.format("0%s", h);
		String minute = mm>9?String.valueOf(mm):String.format("0%s", mm);
		return String.format("%s/%s/%s:%s", month,date,hour,minute);
	}
	
}
