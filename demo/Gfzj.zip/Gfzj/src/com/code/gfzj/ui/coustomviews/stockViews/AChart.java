package com.code.gfzj.ui.coustomviews.stockViews;



import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
/**
 * 图标
 *
 */
public class AChart {
	protected Paint paint = Theme.factroyPaint();
	public Rect frame;
	public AChart(Rect r){
		frame = r;
	}
	public AChart(int left,int top,int right,int bottom){
		frame = new Rect(left, top, right, bottom);
	}
	public void setFrame(Rect r){
		frame = r;
	}
	public void setFrame(int left,int top,int right,int bottom){
		frame.set(left, top, right, bottom);
	}
	public Paint getPaint(){
		return paint;
	}
	public void draw(Canvas canvas){
		final Rect f = frame;
		paint.setStyle(Style.STROKE);
		canvas.drawRect(f, paint);
	}
}
