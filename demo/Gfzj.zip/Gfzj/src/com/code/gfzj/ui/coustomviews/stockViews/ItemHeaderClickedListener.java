package com.code.gfzj.ui.coustomviews.stockViews;

import android.view.View;
/**
 * 欢迎加入QQ开发群讨论：88130145
 * 
 * @Description:
 * @author: zhuanggy
 * @see:   
 * @since:      
 * @copyright © 35.com
 * @Date:2013-10-14
 */
public interface ItemHeaderClickedListener {

	public void onItemHeaderClick(View header, int itemPosition, long headerId);
}
