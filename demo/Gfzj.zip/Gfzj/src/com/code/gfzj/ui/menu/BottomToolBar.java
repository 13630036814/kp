/**
 * 
 */
package com.code.gfzj.ui.menu;

import com.code.gfzj.MarketQuotes;
import com.code.gfzj.R;
import com.code.gfzj.anim.UgcAnimations;
import com.code.gfzj.base.FlipChildView;
import com.code.gfzj.desktop.Desktop.onChangeViewListener;
import com.code.gfzj.util.View_Util;
import com.code.gfzj.widget.FlipperLayout.OnOpenListener;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * 底部工具栏
 * 
 * @author cola
 * 
 */
public class BottomToolBar extends LinearLayout implements OnClickListener {
	private FlipChildView mFlipChildView;
	private boolean isShow = false;
	private ImageView menu, mInformationMenu, mMystockMenu,mMarketQuotes;
	private LinearLayout menu_lineOne;
	private View mPopMenu;
	private onChangeViewListener mOnChangeViewListener;

	public BottomToolBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		LayoutInflater.from(context).inflate(R.layout.bottom_menu, this);
	}

	private Context context;

	public BottomToolBar(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
		LayoutInflater.from(context).inflate(R.layout.bottom_menu, this);

	}

	private void init() {

		menu = (ImageView) findViewById(R.id.bottom_menu);
		mInformationMenu = (ImageView) mPopMenu
				.findViewById(R.id.information_pop);
		mMystockMenu = (ImageView) mPopMenu.findViewById(R.id.mystock_pop);
		mMarketQuotes = (ImageView) mPopMenu.findViewById(R.id.marketQuotes_pop);
	}

	public void setListener() {
		// TODO Auto-generated method stub
		mInformationMenu.setOnClickListener(this);
		mMystockMenu.setOnClickListener(this);
		mMarketQuotes.setOnClickListener(this);
		menu.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				if (menu_lineOne == null)
					return;
				if (!isShow) {
					isShow = true;
					UgcAnimations.startOpenAnimation(menu_lineOne, null, menu,
							500);
				} else {
					isShow = false;
					UgcAnimations.startCloseAnimation(menu_lineOne, null, menu,
							800);
				}
			}

		});
	}

	public void setPopMenur(View mPopMenu) {
		this.mPopMenu = mPopMenu;
		menu_lineOne = (LinearLayout) mPopMenu.findViewById(R.id.ugc_layout);
		init();
		setListener();
	}

	/**
	 * 关闭Path菜单
	 */
	public void closeUgc() {
		if (menu_lineOne == null)
			return;
		isShow = false;
		Log.e("closeUgc", "close");
		UgcAnimations.startCloseAnimation(menu_lineOne, null, menu, 500);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		if (v.equals(mInformationMenu) && mOnChangeViewListener != null) {
//			Animation anim = UgcAnimations.clickAnimation(500);
//			anim.setAnimationListener(new AnimationListener() {
//
//				public void onAnimationStart(Animation animation) {
//
//				}
//
//				public void onAnimationRepeat(Animation animation) {
//
//				}
//
//				public void onAnimationEnd(Animation animation) {
//					closeUgc();
//					new Handler().postAtTime(new Runnable(){
//
//						@Override
//						public void run() {
//							// TODO Auto-generated method stub
							mOnChangeViewListener.onChangeView(View_Util.Information);
//							mInformationMenu.clearAnimation();
//						}
//						
//					}, 1000);
//				}
//			});
//			mInformationMenu.startAnimation(anim);
			
		} else if (v.equals(mMystockMenu) && mOnChangeViewListener != null) {
//			Animation anim = UgcAnimations.clickAnimation(500);
//			anim.setAnimationListener(new AnimationListener() {
//
//				public void onAnimationStart(Animation animation) {
//
//				}
//
//				public void onAnimationRepeat(Animation animation) {
//
//				}
//
//				public void onAnimationEnd(Animation animation) {
//					
//					closeUgc();
//					new Handler().postAtTime(new Runnable(){
//
//						@Override
//						public void run() {
//							// TODO Auto-generated method stub
							mOnChangeViewListener.onChangeView(View_Util.mystock);
//							mMystockMenu.clearAnimation();
//						}
//						
//					}, 1000);
//					
//				}
//			});
//			mMystockMenu.startAnimation(anim);
			
		}else if(mMarketQuotes.equals(v)){
			context.startActivity(new Intent(context,MarketQuotes.class));
		}
		closeUgc();
	}

	/**
	 * 界面修改方法
	 * 
	 * @param onChangeViewListener
	 */
	public void setOnChangeViewListener(
			onChangeViewListener onChangeViewListener) {
		this.mOnChangeViewListener = onChangeViewListener;
	}
}
