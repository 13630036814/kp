/**
 * 
 */
package com.code.gfzj.ui.menu;

import com.code.gfzj.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

/**
 * 顶部工具栏
 * @author cola
 *
 */
public class TopToolsBar extends LinearLayout{
	public TopToolsBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	private Context context;
	public TopToolsBar(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	private void init(){
		LayoutInflater.from(context).inflate(R.layout.topmenu, this);
//		this.addView(convertView);
	}
}
