/**
 * 
 */
package com.code.gfzj.ui.coustomviews.stockViews;

import com.code.gfzj.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

/**
 * @author cola
 *
 */
public class StockitemDetail extends LinearLayout{

	public StockitemDetail(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;
	public StockitemDetail(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}
	
	public void init(){
		LayoutInflater.from(context).inflate(R.layout.stockitem_detail, this);
	}

}
