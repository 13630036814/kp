package com.code.gfzj.ui.widget;

import com.code.gfzj.R;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;

public class Progress{
	private static final float MAX_LEVEL = 360;
    private static final int ANIMATION_RESOLUTION = 200;
    
	private Interpolator mInterpolator;
	private Transformation mTransformation;
	private AlphaAnimation mAnimation;
	
	private Drawable mProgress;
	private float degrees;
	private float degressOffset;
	
	private boolean isProgress;
	
	private long mLastDrawTime;
	
	private Matrix matrix = new Matrix(); 
	private int x;
	private int y;
	
	private int w;
	private int h;
	
	private int mBehavior;
    private int mDuration;
	
	private View mTarget;	
	public Progress(View target,int sx,int sy){
		mDuration = 8*360;
        mBehavior = AlphaAnimation.INFINITE;
		mTarget = target;
		x = sx;
		y = sy;
		Resources r = mTarget.getResources();
		mProgress = r.getDrawable(R.drawable.progress);
	}
	
	public void setPosition(int px,int py,int width,int height){
		w = width;
		h = height;
		x = px-w/2;
		y = py-h/2;
	}
	
	public int getX(){
		return x;		
	}
	
	public int getY(){
		return y;
	}
	
	public int getW(){
		return w;		
	}
	
	public int getH(){
		return h;
	}
	
	public void start(){
		if(!isProgress){
			isProgress = true;
			startAnimation();
		}
		degrees = 0;		
	}
	public void stop(){
		isProgress = false;
		stopAnimation();
	}
	
	public boolean isProgress(){
		return isProgress;
	}
	
	public void draw(Canvas canvas) {
		if(!isProgress)return;		
		canvas.save();
		//Matrix matrix = new Matrix(); 
		matrix.reset();
		matrix.postRotate((degrees+degressOffset)%360,x+w/2,y+h/2);
		canvas.setMatrix(matrix);
		mProgress.setBounds(x, y, x+w, y+h);		
		mProgress.draw(canvas);
		canvas.restore();
		
				
		long time = mTarget.getDrawingTime();
        if (mAnimation != null) {
            mAnimation.getTransformation(time, mTransformation);
            float scale = mTransformation.getAlpha();
            degrees = scale * MAX_LEVEL;    
            if(degrees%360==0){
            	degressOffset +=200*MAX_LEVEL/mDuration;
            	if(degressOffset>=360){
            		degressOffset =200*MAX_LEVEL/mDuration;
            	}
            }
            //Log.i("draw progress", String.format("%s,%s", degrees,degressOffset));
            if (SystemClock.uptimeMillis() - mLastDrawTime >= ANIMATION_RESOLUTION) {
                mLastDrawTime = SystemClock.uptimeMillis();
                mTarget.postInvalidateDelayed(ANIMATION_RESOLUTION);
            }
        }
	}


	
	void startAnimation() {
		if (mInterpolator == null) {
            mInterpolator = new LinearInterpolator();
        }

        mTransformation = new Transformation();
        mAnimation = new AlphaAnimation(0.0f, 1.0f);
        mAnimation.setRepeatMode(mBehavior);
        mAnimation.setRepeatCount(Animation.INFINITE);
        mAnimation.setDuration(mDuration);
        mAnimation.setInterpolator(mInterpolator);
        mAnimation.setStartTime(Animation.START_ON_FIRST_FRAME);
    }
	
	void stopAnimation() {
        mAnimation = null;
        mTransformation = null;
        mInterpolator = null;
    }

}
