package com.code.gfzj.ui.widget;

public class Events {

	//----------------------------------------------------
	// 事件定义
	//----------------------------------------------------
	public static final int EVENT_ERROR_REV = -0x0010;
	public static final int EVENT_ERROR_CON = -0x0011;
	public static final int EVENT_ERROR_REQ = -0x0012;
	public static final int EVENT_SYS_EXIT = 0x0001;
	/**
	 * 返回
	 */	
	public static final int EVENT_KEY_BACK = 0x0010;
	/**
	 * 返回 up
	 */	
	public static final int EVENT_KEYUP_BACK = 0x0011;
	
	/**
	 * key menu
	 */
	public static final int EVENT_KEY_MENU = 0x0012;
	
	/**
	 * key menu up
	 */
	public static final int EVENT_KEYUP_MENU = 0x0013;
	
	/**
	 * 键盘精灵return事件
	 */
	public static final int EVENT_WIZARD_RETURN = 0x0020;
	/**
	 * 传参事件
	 */
	public static final int EVENT_ACCESS_PARA = 0x0030;
	/**
	 * 传参事件(dialog)
	 */
	public static final int EVENT_ACCESS_PARA_DIALOG = 0x0031;
	/**
	 * 数据加载事件
	 */
	public static final int EVENT_ON_LOAD     = 0x0040;
	/**
	 * 数据加载完成
	 */
	public static final int EVENT_LOAD_OK     = 0x0050;
	/**
	 * 数据加载进度
	 */
	//public static final int EVENT_LOAD_PROGRESS    = 0x0070;
	/**
	 * activity 转入后台
	 */
	public static final int EVENT_ON_PAUSE    = 0x0071;	
	/**
	 * 窗体失去焦点
	 */
	public static final int EVENT_ON_WINDOWS_LOSEFOCUS = 0x0072;
	public static final int EVENT_ON_WINDOWS_DELAYCLOSE = 0x0073;
	/**
	 * 关闭当前界面
	 */
	public static final int EVENT_ON_UI_FINISH     = 0x0080;
	
	/**
	 * 销毁当前activity
	 */
	public static final int EVENT_ON_UI_DESTROY     = 0x0081;
	
	/** 
	 * 重启UI
	 */
	public static final int EVENT_ON_UI_RESTART     = 0x0082;
	
	public static final int EVENT_UI_NO_DISPATCH   = 0x0083;
	
	public static final int EVENT_UI_REDIRECTION   = 0x0084;
	
	/**
	 * 刷新时序
	 */
	public static final int EVENT_ON_MSG_TIMING    = 0x0090;
	/**
	 * 互动数据访问
	 */
	public static final int EVENT_ACCESS_DATA_INTER    = 0x0091;
	//----------------------------------------------------
	// UI事件定义
	//----------------------------------------------------
	/**
	 * 点击列事件
	 */
	public static final int EVENT_CLICK_COL = 0x0100;
	/**
	 * 点击行事件
	 */
	public static final int EVENT_CLICK_ROW = 0x0101;
	/**
	 * 系统菜单
	 */
	public static final int EVENT_MENU_ACTION = 0x200;
	/**
	 * 超屏事件
	 */
	public static final int EVENT_DRAG_OVERTOP     = 0x0300;
	public static final int EVENT_DRAG_OVERBOTTOM = 0x0400;
	public static final int EVENT_DRAG_OVERLEFT    = 0x0500;
	public static final int EVENT_DRAG_OVERRIGHT   = 0x0600;
	
	/**
	 * 移动事件
	 */
	public static final int EVENT_DRAG_MOVE = 0x0700;
	
	/**
	 * 自选股票 编辑更新
	 */
	public static final int EVENT_STOCK_UPDATE = 0x0800;
	
	//----------------------------------------------------
	// 模块事件定义
	//----------------------------------------------------
	public static final int EVENT_HQ_NEXT = 0x1001;
	public static final int EVENT_HQ_PREV = 0x1002;
	public static final int EVENT_HQ_FS = 0x1000;
	public static final int EVENT_HQ_KX = 0x2000;
	public static final int EVENT_HQ_KX_CYCLE = 0x2001;
	public static final int EVENT_HQ_KX_CYCLE_F = 0x2011;
	public static final int EVENT_HQ_ZX = 0x3000;
	public static final int EVENT_HQ_ZX_ADD = 0x3001;
	public static final int EVENT_HQ_ZX_ADD_EXIST = 0x3002;
	public static final int EVENT_HQ_ZX_ADD_SUCCESSFUL = 0x3003;
	public static final int EVENT_HQ_PX = 0x4000;
	/*
	 "沪深A股",
	 "沪深B股",
	 "基  金 ",
	 "权  证 ",
	 "指  数 ",
	 "债  券 ",
	 "创业板 ",
	 "中小版 "
	 */
	public static final int EVENT_HQ_PX_HSA = 0x4001;
	public static final int EVENT_HQ_PX_HSB = 0x4002;
	public static final int EVENT_HQ_PX_JJ  = 0x4003;
	public static final int EVENT_HQ_PX_QZ  = 0x4004;
	public static final int EVENT_HQ_PX_ZS  = 0x4005;
	public static final int EVENT_HQ_PX_ZQ  = 0x4006;
	public static final int EVENT_HQ_PX_CYB = 0x4007;
	public static final int EVENT_HQ_PX_ZXB = 0x4008;
	/*
	 * 大盘
	 */
	public static final int EVENT_HQ_DP = 0x4009;
	/**
	 * 全球
	 */
	public static final int EVENT_HQ_QQ = 0x4010;
	
	/**
	 * 服务中心
	 */
	public static final int EVENT_INFO_HELP = 0x5001;
	
	/**
	 * 服务设置
	 */
	public static final int EVENT_INFO_SETTING = 0x5002;
	
	/**
	 * 退出系统
	 */
	public static final int EVENT_INFO_EXIT = 0x5003;
	
	// UI 事件
	
	/**
	 * 事件最大值
	 */
	public static final int EVENT_MAX = 0x30000;
}
