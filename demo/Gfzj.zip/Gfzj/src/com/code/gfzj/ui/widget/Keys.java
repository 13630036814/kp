package com.code.gfzj.ui.widget;

public class Keys {
	public static final String key_col = "col";
	public static final String key_row = "row";
	
	public static final String key_edit = "edit";
	
	public static final String key_progress_total = "progress_total";
	public static final String key_progress       = "progress";
	
	public static final String key_market = "market_id";
	public static final String key_code   = "stock_code";
	public static final String key_add = "key_add";
	public static final String key_from = "key_from";
	
	public static final String key_hudong = "key_hudong";
	//public static final String key_update = "key_update";
	
	public static final String key_phone = "key_phone";
	public static final String key_serviceid = "key_service";
	public static final String key_cpid = "key_cpdi";
	public static final String key_ztjid = "key_ztjid";
	
	public static final String key_tag = "key_tag";
	
	public static final String key_forcerefresh = "key_forcerefresh";
	
	/**
	 * 自选tab页
	 */
	public static final String key_tab_num = "key_tab_num";
	
	/**
	 * 加载
	 */
	public static final String action_loading = "action_loading";
	/**
	 * 网络启动 
	 */
	public static final String action_netstart = "action_netstart";
	/**
	 * 代码链
	 */
	public static final String action_stockcode = "action_stockcode";
	/**
	 * 自选
	 */
	public static final String action_mycodes = "action_mycodes";
}
