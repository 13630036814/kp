package com.code.gfzj.ui.adapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.code.gfzj.QuotationActivity;
import com.code.gfzj.R;
import com.code.gfzj.data.bean.Group;
import com.code.gfzj.data.bean.Message;
import com.code.gfzj.ui.coustomviews.stockViews.ItemClickedListener;
import com.code.gfzj.ui.coustomviews.stockViews.ItemHeaderClickedListener;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 我的自选股列表
 * @author cola
 *
 */
public class MailAdapter extends CommonAdapter  {

	private List<Message> mMessageList;
	private List<Group> mMessageListGroup;
	
//	private ItemClickedListener mItemClickedListener;
//	private ItemHeaderClickedListener mItemHeaderClickedListener;

	private Context context;
	
	private boolean mIsOpen;//初始化View时分组是否展开

	public MailAdapter(Context context, List<Message> message_list, boolean isOpen) {
		this.context = context;
		this.mMessageList = message_list;
		this.mIsOpen = isOpen;
		initMessageList(message_list);
	}

	private void initMessageList(List<Message> message_list) {
		this.mMessageList = message_list;
		if (message_list != null && message_list.size() > 0) {
			getSectionIndicesAndGroupNames();
		}
	}

	@Override
	public int getCount() {
		return mMessageList == null ? 0 : mMessageList.size();
	}

	public int getRealCount() {
		return mMessageList == null ? 0 : mMessageList.size();
	}

	@Override
	public Object getItem(int position) {
		return mMessageList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ItemViewHolder holder;

		if (convertView == null) {
			holder = new ItemViewHolder();
			convertView = LayoutInflater.from(context).inflate(R.layout.view_item, null);
			holder.vv = (LinearLayout) convertView.findViewById(R.id.vv);
			holder.v2 = (LinearLayout) convertView.findViewById(R.id.v2);
			holder.line = (View) convertView.findViewById(R.id.line);
			((TextView) convertView.findViewById(R.id.trend)).setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					context.startActivity(new Intent(context,QuotationActivity.class));
				}
				
			});
			convertView.setTag(holder);
		} else {
			holder = (ItemViewHolder) convertView.getTag();
		}
//		convertView.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);
//		holder.textViewInfo.setText(mMessageList.get(position).getInfo());
	
		holder.v2.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);
		holder.line.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);
		holder.vv.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);
		//若合起分组，则里面的view不显示
//		holder.textViewInfo.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);

		convertView.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(mItemClickedListener != null) {
					mItemClickedListener.onItemClick(v, position);
				}
				
			}
		});
		
		return convertView;
	}

	/**
	 * 分组
	 */
	private void getSectionIndicesAndGroupNames() {
		mMessageListGroup = new ArrayList<Group>();
		Group gp;
		int countGp = 0;
		String groupName = "";
		for (int i = 0; i < mMessageList.size(); i++) {
			String groupName2 = mMessageList.get(i).getGroupName();
			if (!groupName2.equals(groupName)) {
				
				if(mMessageListGroup.size()>0) {
					mMessageListGroup.get(mMessageListGroup.size()-1).setCount(countGp);
				}
				groupName = groupName2;
				countGp = 1;
				mMessageList.get(i).setGroupId(mMessageListGroup.size());
				gp = new Group();
				gp.setName(groupName);
				gp.setFirstPositionInList(i);
				gp.setShown(mIsOpen);
				mMessageListGroup.add(gp);
			} else {
				countGp ++;
				mMessageList.get(i).setGroupId(mMessageListGroup.size() - 1);
			}

		}

	}

	@Override
	public View getHeaderView(final int position, View convertView, ViewGroup parent) {

		ItemHeaderViewHolder holder = null;
		if (convertView == null) {
			holder = new ItemHeaderViewHolder();
			convertView = LayoutInflater.from(context).inflate(R.layout.stockitem, parent, false);
			holder.stcokName = (TextView) convertView.findViewById(R.id.stockName);
			holder.stockCode = (TextView) convertView.findViewById(R.id.stockCode);
			
//			holder.imgArrow = (ImageView) convertView.findViewById(R.id.img_item_header);
			convertView.setTag(holder);
		} else {
			holder = (ItemHeaderViewHolder) convertView.getTag();
		}

		
		Group gp = mMessageListGroup.get(mMessageList.get(position).getGroupId());
		holder.stcokName.setText(gp.getName());
		
		holder.stockCode.setText("( " + gp.getCount() +" )");
		
//		 if(gp.isShown()) {
////			 holder.imgArrow.setImageResource(R.drawable.ic_group_arrow_open);
//			 holder.line.setVisibility(View.VISIBLE);
//		 } else {
////			 holder.imgArrow.setImageResource(R.drawable.ic_group_arrow_close);
//			 holder.line.setVisibility(View.GONE);
//		 }
		
		return convertView;
	}

	@Override
	public long getHeaderId(int position) {
		return mMessageList.get(position).getGroupId();
	}

	/**
	 * 当点击header时，即GroupName，可以展开合起
	 */
	public void onListHeaderClicked(int position) {
		Group gp = mMessageListGroup.get(mMessageList.get(position).getGroupId());
		gp.setShown(!gp.isShown());

		MailAdapter.this.notifyDataSetChanged();
	}
	
	/////////////////////////////////////////
//	public void setOnItemClickedListener(ItemClickedListener listener) {
//		this.mItemClickedListener = listener;
//	}
//	
//	public void setOnItemHeaderClickedListener(ItemHeaderClickedListener listener) {
//		this.mItemHeaderClickedListener = listener;
//	}
//	
//	public ItemHeaderClickedListener getmItemHeaderClickedListener() {
//		return mItemHeaderClickedListener;
//	}


	// /////////////////////////////////////
	public class ItemHeaderViewHolder {

		TextView stcokName;
		ImageView imgArrow;
		TextView stockCode;
		TextView stockRise;
		TextView stockRange;
		
	}

	public class ItemViewHolder {
		LinearLayout vv;
		LinearLayout v2;
		TextView textViewInfo;
		View line;
	}

	protected void sort(int sort){
		Collections.sort(mMessageList, new Comparator<Message>() {

			@Override
			public int compare(Message lhs, Message rhs) {
				// TODO Auto-generated method stub
				if (Integer.parseInt(lhs.stockRang) > Integer
						.parseInt(rhs.stockRang))
					return 1;
				else if (Integer.parseInt(lhs.stockRang) == Integer
						.parseInt(rhs.stockRang))
					return 0;
				else if (Integer.parseInt(lhs.stockRang) < Integer
						.parseInt(rhs.stockRang))
					return -1;
				
				return 0;
			}


			
		});
	}
}
