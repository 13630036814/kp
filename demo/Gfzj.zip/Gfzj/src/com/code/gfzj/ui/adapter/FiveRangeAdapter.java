/**
 * 
 */
package com.code.gfzj.ui.adapter;

import java.util.List;

import com.code.gfzj.R;
import com.code.gfzj.data.bean.VolumeItem;
import com.code.gfzj.ui.adapter.VolumeAdapter.ItemViewHolder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * 五档适配器
 * 
 * @author cola
 * 
 */
public class FiveRangeAdapter extends BaseAdapter {
	private List<VolumeItem> volumList;
	private Context ct;

	public FiveRangeAdapter(final Context ct, List<VolumeItem> volumList) {
		this.ct = ct;
		this.volumList = volumList;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return volumList.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return volumList.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int arg0, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ItemViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(ct).inflate(
					R.layout.fiverangeitem, null);
			holder = new ItemViewHolder();

			holder.price = (TextView) convertView.findViewById(R.id.price);
			holder.time = (TextView) convertView.findViewById(R.id.time);
			holder.volume = (TextView) convertView.findViewById(R.id.tvolume);
			convertView.setTag(holder);
		} else {
			holder = (ItemViewHolder) convertView.getTag();
		}

		holder.price.setText(volumList.get(arg0).price);
		holder.time.setText(volumList.get(arg0).time);
		holder.volume.setText(volumList.get(arg0).volume);
		return convertView;
	}

	public class ItemViewHolder {
		public TextView price;
		public TextView time;
		public TextView volume;

	}
}
