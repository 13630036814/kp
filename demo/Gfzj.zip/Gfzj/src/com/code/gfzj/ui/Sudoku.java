/**
 * 
 */
package com.code.gfzj.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.code.gfzj.R;
import com.code.gfzj.anim.UgcAnimations;
import com.code.gfzj.base.FlipChildView;
import com.code.gfzj.data.bean.Message;
import com.code.gfzj.desktop.Desktop.onChangeViewListener;
import com.code.gfzj.ui.adapter.MailAdapter;
import com.code.gfzj.ui.coustomviews.stockViews.ItemClickedListener;
import com.code.gfzj.ui.coustomviews.stockViews.ItemHeaderClickedListener;
import com.code.gfzj.ui.coustomviews.stockViews.MailListView;
import com.code.gfzj.ui.menu.BottomToolBar;

/**
 * @author mrcola
 *
 */
public class Sudoku extends FlipChildView{
	private BottomToolBar menu;
	private RelativeLayout mPopMenu;
	private LinearLayout menu_lineOne;
	private View parent;
	private boolean isShow = false;
	private ImageView mUgc;
	private ImageView mUgcBg;
	private ImageView mUgcVoice;
	private ImageView mUgcPhoto;
	private ImageView mUgcRecord;
	private ImageView mUgcLbs;
	private MailListView mListView;
	private MailAdapter mAdapter;
	protected onChangeViewListener mOnChangeViewListener;
	
	public Sudoku(Activity mActivity) {
		super(mActivity);
		// TODO Auto-generated constructor stub
		parent = LayoutInflater.from(mActivity).inflate(R.layout.sudoku, null);
		findViewById();
		init();
		setListener();
		
	}

	@Override
	public View getView() {
		// TODO Auto-generated method stub
		return parent;//mLayoutInflater.inflate(R.layout.sudoku, null);
	}

	@Override
	public void findViewById() {
		// TODO Auto-generated method stub
		mListView = (MailListView) parent.findViewById(R.id.stock_listview);
		
		menu = (BottomToolBar) parent.findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) parent.findViewById(R.id.home_ugc);
		menu.setPopMenur(mPopMenu);
		
//		menu_lineOne = (LinearLayout) parent.findViewById(R.id.ugc_layout);
//		mUgcLbs = (ImageView) parent.findViewById(R.id.ugc_lbs);
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		List<Message> messages = new ArrayList<Message>();
		for (int i = 0; i < 10; i++) {
			Message msg = new Message();
			msg.setGroupName("广发证券" + i);
			for (int j = 0; j < 1; j++) {
				msg.setInfo("600685");
				messages.add(msg);
			}
		}

		mAdapter = new MailAdapter(mActivity, messages, false);//第三个参数是：第一次填充listview时，分组是否展开

		mListView.setAdapter(mAdapter);
		mListView.setDivider(mActivity.getResources().getDrawable(R.drawable.line));
	}

	@Override
	public void setListener() {
		// TODO Auto-generated method stub
//		menu.setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				if (!isShow) {
//					isShow = true;
//					UgcAnimations.startOpenAnimation(menu_lineOne, null, menu,
//							500);
//				} else {
//					isShow = false;
//					UgcAnimations.startCloseAnimation(menu_lineOne, null, menu,
//							800);
//				}
//			}
//			
//		});
//		
//		mUgcLbs.setOnClickListener(new OnClickListener() {
//
//			public void onClick(View v) {
//				Animation anim = UgcAnimations.clickAnimation(500);
//				anim.setAnimationListener(new AnimationListener() {
//
//					public void onAnimationStart(Animation animation) {
//
//					}
//
//					public void onAnimationRepeat(Animation animation) {
//
//					}
//
//					public void onAnimationEnd(Animation animation) {
//						 closeUgc();
//					}
//				});
//				mUgcLbs.startAnimation(anim);
//			}
//		});

		mListView.setOnItemHeaderClickedListener(new ItemHeaderClickedListener() {

			@Override
			public void onItemHeaderClick(View header, int itemPosition, long headerId) {
				// 展开或收起分组
				if (mAdapter != null) {
					mAdapter.onListHeaderClicked(itemPosition);
				}
			}
		});

		mListView.setOnItemClickedListener(new ItemClickedListener() {

			@Override
			public void onItemClick(View item, int itemPosition) {
				// TODO Auto-generated method stub

			}
		});
		
		((Button) parent.findViewById(R.id.top_back)).setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(mOnOpenListener != null)
					mOnOpenListener.open();
			}
			
		});
	}

	/**
	 * 界面修改方法
	 * 
	 * @param onChangeViewListener
	 */
	public void setOnChangeViewListener(
			onChangeViewListener onChangeViewListener) {
		this.mOnChangeViewListener = onChangeViewListener;
		menu.setOnChangeViewListener(mOnChangeViewListener);
	}
}
