/**
 * 
 */
package com.code.gfzj.ui;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.code.gfzj.R;
import com.code.gfzj.base.FlipChildView;
import com.code.gfzj.data.bean.Message;
import com.code.gfzj.desktop.Desktop.onChangeViewListener;
import com.code.gfzj.ui.adapter.InformationAdapter;
import com.code.gfzj.ui.adapter.MailAdapter;
import com.code.gfzj.ui.coustomviews.stockViews.ItemClickedListener;
import com.code.gfzj.ui.coustomviews.stockViews.ItemHeaderClickedListener;
import com.code.gfzj.ui.coustomviews.stockViews.MailListView;
import com.code.gfzj.ui.menu.BottomToolBar;

/**
 * 资讯信息菜单
 * @author cola
 *
 */
public class InformationMenu extends FlipChildView{
	private View parent;
	protected onChangeViewListener mOnChangeViewListener;
	private MailListView mListView;
	private InformationAdapter mAdapter;
	private TextView mMystock,mBuy,mSell,mAlarm;
	private RelativeLayout mBottom_menu,mPopMenu;
	private BottomToolBar mBottomToolBar;
	private LinearLayout stock_menu;
	private TextView mTitle;
	
	public InformationMenu(Activity mActivity) {
		super(mActivity);
		// TODO Auto-generated constructor stub
		parent = LayoutInflater.from(mActivity).inflate(R.layout.information_menu, null);
		findViewById();
		init();
		setListener();
	}

	@Override
	public View getView() {
		// TODO Auto-generated method stub
		return parent;
	}

	@Override
	public void findViewById() {
		// TODO Auto-generated method stub
		mBottom_menu = (RelativeLayout) parent.findViewById(R.id.bottom_menu_layout);
		mMystock = (TextView) parent.findViewById(R.id.bottom_mystock);
		mBuy = (TextView) parent.findViewById(R.id.bottom_buy);
		mSell = (TextView) parent.findViewById(R.id.bottom_sell);
		mAlarm = (TextView) parent.findViewById(R.id.bottom_alarm);
		mBottomToolBar = (BottomToolBar) parent.findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) parent.findViewById(R.id.home_ugc);
		stock_menu = (LinearLayout) parent.findViewById(R.id.stock_menu);
		mTitle = (TextView) parent.findViewById(R.id.title);
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		mTitle.setText("资讯中心");
		mListView = (MailListView) parent.findViewById(R.id.stock_listview);
		List<Message> messages = new ArrayList<Message>();
		for (int i = 0; i < 10; i++) {
			Message msg = new Message();
			String group = "财经要闻" + i;
			
			msg.setGroupName(group);
			msg.mTitle = "获取更多";
			for (int j = 0; j < 2; j++) {
				Message msg2 = new Message();
				msg2.setGroupName(group);
				msg2.mTitle = group;
				msg2.setInfo("[汽车之家 新闻]  近日，国内媒体曝光了新款传祺GA5的谍照，这款车将可能会在11月开幕的广州车展上正式上市。");
				messages.add(msg2);
			}
			messages.add(msg);
		}

		mAdapter = new InformationAdapter(mActivity, messages, false);//第三个参数是：第一次填充listview时，分组是否展开
		mListView.setDivider(null);
		mListView.setAdapter(mAdapter);
		mListView.setOnItemHeaderClickedListener(new ItemHeaderClickedListener() {

			@Override
			public void onItemHeaderClick(View header, int itemPosition, long headerId) {
				// 展开或收起分组
				if (mAdapter != null) {
					mAdapter.onListHeaderClicked(itemPosition);
				}
			}
		});

		mListView.setOnItemClickedListener(new ItemClickedListener() {

			@Override
			public void onItemClick(View item, int itemPosition) {
				// TODO Auto-generated method stub

			}
		});
		
		mMystock.setVisibility(View.INVISIBLE);
		mBuy.setVisibility(View.INVISIBLE);
		mSell.setVisibility(View.INVISIBLE);
		mAlarm.setVisibility(View.INVISIBLE);
//		mBottom_menu.setBackgroundColor(20);

		
//		stock_menu.setBackgroundResource(mActivity.getResources().getColor(
//				R.color.transparent));
		
//		stock_menu.getBackground().setAlpha(200);
		mBottomToolBar.setPopMenur(mPopMenu);
	}

	public void setAlpha(int value){
//		mBottom_menu.getBackground().setAlpha(value);
//		mBottom_menu.setBackgroundResource(mActivity.getResources().getColor(
//		R.color.transparent));
	}
	
	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		((Button) parent.findViewById(R.id.top_back)).setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(mOnOpenListener != null)
					mOnOpenListener.open();
			}
			
		});
	}
	/**
	 * 界面修改方法
	 * 
	 * @param onChangeViewListener
	 */
	public void setOnChangeViewListener(
			onChangeViewListener onChangeViewListener) {
		this.mOnChangeViewListener = onChangeViewListener;
		mBottomToolBar.setOnChangeViewListener(mOnChangeViewListener);
	}

}
