/**
 * 
 */
package com.gf.view;

/**
 * 窗口小控件接口
 * @author Cola
 *
 */
public interface MiniView {
	public void init();
	public void setData(Object object);
	public void draw() ;
}
