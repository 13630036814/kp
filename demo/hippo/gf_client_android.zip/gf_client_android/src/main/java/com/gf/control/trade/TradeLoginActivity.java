package com.gf.control.trade;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.gf.client.R;
import com.gf.control.BaseApplication;
import com.gf.dataProcess.trade.TradeProcessor;
import com.gf.model.user.TradeInfo;
import com.gf.trade.TradeManager;
import com.gf.trade.model.user.Trader;
import com.gf.trade.network.NetworkEvent;
import com.gf.trade.network.NetworkEventHandler;
import com.gf.trade.network.TradeResponse;
import com.gf.view.widget.SlipButton;
import com.gf.view.widget.SlipButton.OnChangedListener;
import com.gf.view.widget.TopToolsBar;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;

public class TradeLoginActivity extends Activity implements OnChangedListener {
	private SlipButton button;
	private TopToolsBar titleBar;
	
	private EditText txtAccount;
	private EditText txtPassword;
	
	private QuoteManagerFactory managerFactory;
	private TradeManager tradeManager;
	private TradeProcessor tradeProcessor;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.trade_login);
		
		titleBar = (TopToolsBar) findViewById(R.id.toptool_bar);
		titleBar.setTitle("交易登录");
		
		txtAccount = (EditText) findViewById(R.id.txt_account);
		txtPassword = (EditText) findViewById(R.id.txt_password);
		
		button = (SlipButton) findViewById(R.id.slipButton);
		button.SetOnChangedListener("the one", this);

		// button.setEnabled(false);//设置button不可用
		button.setChecked(true);// 设置button的初始化状态为打开
		
		BaseApplication application = ((BaseApplication) this.getApplication());
		managerFactory = application.getQuoteManagerFactory();
		tradeManager = managerFactory.getTradeManager();
		
		if (tradeProcessor == null) {
			tradeProcessor = new TradeProcessor();
		}
	}

	@Override
	public void OnChanged(String strName, boolean CheckState) {
		if (CheckState) {
			Toast.makeText(this, strName + " is opened!", Toast.LENGTH_LONG).show();
		} else {
			Toast.makeText(this, strName + " is closed!", Toast.LENGTH_LONG).show();
		}
	}
	
	public void login(View view) {
		Trader trader = new Trader();
		trader.setAccountType("Z");
		trader.setTradeAccount(txtAccount.getText().toString());
		trader.setTradeAddress("13800138000", "huawei D2", "4.7.6 20140312 66065");
		trader.setTradePassword(txtPassword.getText().toString());
		tradeManager.setTrader(trader);

		// String[] reqBody = {"Z", "030250171333", "123123", "4", "13800138000,A0000042EB58F3,4.7.6.20140310.66065","" ,"" , null,"" };
		String[] reqBody = { trader.getAccountType(), trader.getTradeAccount(), trader.getTradePassword(), "4", trader.getTradeAddress(), "", "", null, "" };
		tradeProcessor.setTradeManager(tradeManager);

		NetworkEventHandler handler = new NetworkEventHandler() {
			@Override
			public void onResponse(NetworkEvent event) {
				super.onResponse(event);
				System.out.println("response status:" + event.getStatus());
//				System.out.println("response data:" + event.getData().toString());
				if (event.getData() instanceof TradeResponse) {
					TradeResponse rsp = (TradeResponse) event.getData();
					if (rsp.packet.isError()) {
						System.out.println("--- error message ---");
						System.out.println(rsp.packet.getErrorMsg());
						Toast.makeText(getApplicationContext(), "账号或密码错误", Toast.LENGTH_LONG).show();
					} else {
						System.out.println("--- login success ---");
						tradeProcessor.parse_JY_KHXY(rsp.packet.mBodyBuffer, txtAccount.getText().toString(), txtPassword.getText().toString());
						System.out.println("account = " + TradeInfo.getLoginInfo().tradeAccount);
						startActivity(new Intent(TradeLoginActivity.this, TradeMainActivity.class));
					}
				}
			}
		};
		
		tradeProcessor.sendReq_JY_KHXY(reqBody, TradeProcessor.JY_KHXY,  handler);
//		startActivity(new Intent(TradeLoginActivity.this, TradeMainActivity.class));
	}

}
