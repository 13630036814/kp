package com.gf.view.anim;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

/**
 * Path动画类
 * 
 * @author rendongwei
 * 
 */
public class UgcAnimations {
	private static int xOffset = 15;
	private static int yOffset = -13;

	public static void initOffset(Context context) {
		xOffset = (int) (15 * context.getResources().getDisplayMetrics().density);
		yOffset = -(int) (13 * context.getResources().getDisplayMetrics().density);
	}

	public static Animation getRotateAnimation(float fromDegrees,
			float toDegrees, long durationMillis) {
		RotateAnimation rotate = new RotateAnimation(fromDegrees, toDegrees,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF,
				0.5f);
		rotate.setDuration(durationMillis);
		rotate.setFillAfter(true);
		return rotate;
	}

	public static Animation getAlphaAnimation(float fromAlpha, float toAlpha,
			long durationMillis) {
		AlphaAnimation alpha = new AlphaAnimation(fromAlpha, toAlpha);
		alpha.setDuration(durationMillis);
		alpha.setFillAfter(true);
		return alpha;
	}

	public static Animation getScaleAnimation(long durationMillis) {
		ScaleAnimation scale = new ScaleAnimation(1.0f, 1.3f, 1.0f, 1.3f,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF,
				0.5f);
		scale.setDuration(durationMillis);
		return scale;
	}

	public static Animation getTranslateAnimation(float fromXDelta,
			float toXDelta, float fromYDelta, float toYDelta,
			long durationMillis) {
		TranslateAnimation translate = new TranslateAnimation(fromXDelta,
				toXDelta, fromYDelta, toYDelta);
		translate.setDuration(durationMillis);
		translate.setFillAfter(true);
		return translate;
	}

	public static void startOpenAnimation(LinearLayout relativeLayout1,
			Button background, ImageView menu, long durationMillis,RelativeLayout relativeLayout2) {
//		background.setVisibility(View.VISIBLE);
		
		relativeLayout2.startAnimation(getAlphaAnimation(0f, 1f, durationMillis));
		relativeLayout2.setVisibility(View.VISIBLE);
		
		relativeLayout1.startAnimation(getAlphaAnimation(0f, 1f, durationMillis));
		relativeLayout1.setVisibility(View.VISIBLE);
//		menu.startAnimation(getRotateAnimation(0, 90, durationMillis * 4));
		int len1 = relativeLayout1.getChildCount();
		for (int n = 0; n < len1; n++) {
			if(relativeLayout1.getChildAt(n) instanceof LinearLayout){
			LinearLayout relativeLayout = (LinearLayout) relativeLayout1.getChildAt(n);
			int len = relativeLayout.getChildCount();
			for(int i = 0; i < len; i++){
//				if(relativeLayout.getChildAt(i) instanceof ImageView){
				Button imageView = (Button) relativeLayout.getChildAt(i);
			imageView.setVisibility(View.VISIBLE);
			MarginLayoutParams params = (MarginLayoutParams) imageView
					.getLayoutParams();
			AnimationSet set = new AnimationSet(true);
//			set.addAnimation(getRotateAnimation(-270, 0, durationMillis));
			set.addAnimation(getAlphaAnimation(0.5f, 1.0f, durationMillis));
			set.addAnimation(getTranslateAnimation(
					 -params.width, 0, 0, 0f, durationMillis));
			set.setFillAfter(true);
			set.setDuration(durationMillis);
			set.setStartOffset((i * 100)
					/ (-1 + relativeLayout.getChildCount()));
			set.setInterpolator(new OvershootInterpolator(1f));
			imageView.startAnimation(set);
//			imageView.setEnabled(true);
//			}
			}
			}
		}
	}

	public static void startCloseAnimation(final LinearLayout relativeLayout1,
			final Button background, ImageView menu, long durationMillis,RelativeLayout relativeLayout2) {
		relativeLayout1
				.startAnimation(getAlphaAnimation(1f, 0f, durationMillis));
		relativeLayout2
		.startAnimation(getAlphaAnimation(1f, 0f, durationMillis));
		
//		menu.startAnimation(getRotateAnimation(90, 0, durationMillis * 4));
		int len1 = relativeLayout1.getChildCount();
		for (int n = 0; n < len1; n++) {
			if (relativeLayout1.getChildAt(n) instanceof LinearLayout) {
				LinearLayout relativeLayout = (LinearLayout) relativeLayout1
						.getChildAt(n);
				int len = relativeLayout.getChildCount();

				for (int i = 0; i < len; i++) {

					final Button imageView = (Button) relativeLayout
							.getChildAt(i);
					MarginLayoutParams params = (MarginLayoutParams) imageView
							.getLayoutParams();
					AnimationSet set = new AnimationSet(true);
					// set.addAnimation(getRotateAnimation(0, -270,
					// durationMillis));
					set.addAnimation(getAlphaAnimation(1.0f, 0.5f,
							durationMillis));
					set.addAnimation(getTranslateAnimation(0f, -params.width,
							0f, 0, durationMillis));
					set.setFillAfter(true);
					set.setDuration(durationMillis);
					set.setStartOffset(((relativeLayout.getChildCount() - i) * 100)
							/ (-1 + relativeLayout.getChildCount()));
					set.setInterpolator(new AnticipateInterpolator(1f));
					set.setAnimationListener(new Animation.AnimationListener() {
						public void onAnimationStart(Animation arg0) {
						}

						public void onAnimationRepeat(Animation arg0) {
						}

						public void onAnimationEnd(Animation arg0) {
							imageView.clearAnimation();
							relativeLayout1.clearAnimation();//先清除动画，否则还能响应点击
							relativeLayout1.setVisibility(View.GONE);
						}
					});
					imageView.startAnimation(set);

				}
			}
		}
	}

	public static Animation clickAnimation(long durationMillis) {
		AnimationSet set = new AnimationSet(true);
		set.addAnimation(getAlphaAnimation(1.0f, 0.3f, durationMillis));
		set.addAnimation(getScaleAnimation(durationMillis));
		set.setDuration(durationMillis);
		return set;
	}
	
	public static Animation horizontalMove(long durationMillis,View v){
		AnimationSet set = new AnimationSet(true);
		MarginLayoutParams params = (MarginLayoutParams) v
				.getLayoutParams();
		set.addAnimation(getTranslateAnimation(
				 -params.width, 0, 0, 0f, durationMillis));
		return set;
	}
}
