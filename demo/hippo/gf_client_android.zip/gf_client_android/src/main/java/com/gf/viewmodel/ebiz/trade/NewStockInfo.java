package com.gf.viewmodel.ebiz.trade;

/**
 * 新股信息
 *
 */
public class NewStockInfo {

	/** 股票代码 */
	private String stockCode;
	/** 股票名称 */
	private String stockName;
	/** 申购限额 */
	private String limit;
	/** 定价 */
	private String price;
	/** 申购日 */
	private String buyDate;
	/** 可买数量 */
	private String maxAmount;
	
	public NewStockInfo() {}
	
	public NewStockInfo(String stockCode, String stockName, String limit, String price, String buyDate, String maxAmount) {
		this.stockCode = stockCode;
		this.stockName = stockName;
		this.limit = limit;
		this.price = price;
		this.buyDate = buyDate;
		this.maxAmount = maxAmount;
	}

	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public String getLimit() {
		return limit;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getBuyDate() {
		return buyDate;
	}
	public void setBuyDate(String buyDate) {
		this.buyDate = buyDate;
	}
	public String getMaxAmount() {
		return maxAmount;
	}
	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}
}
