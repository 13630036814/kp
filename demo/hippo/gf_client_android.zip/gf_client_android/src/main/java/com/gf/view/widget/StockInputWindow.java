package com.gf.view.widget;

/*
 * 输入法键盘窗口
 */
import android.app.Dialog;
import android.content.Context;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;

public class StockInputWindow extends Dialog{
    
    public StockInputWindow(Context context, int theme) {
        // TODO Auto-generated constructor stub
        super(context, theme);
        init();
    }
    
    private void init(){
        WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
        //ax
        //layoutParams.gravity = 80;
        layoutParams.gravity = Gravity.BOTTOM;
        getWindow().setAttributes(layoutParams);
        //ax
        //getWindow().setFlags(264, 266);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, 266);        
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        return super.onKeyDown(keyCode, event);
    }
    
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        return super.onKeyUp(keyCode, event);
    }
}
