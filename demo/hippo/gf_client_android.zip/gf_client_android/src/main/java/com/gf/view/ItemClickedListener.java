package com.gf.view;

import android.view.View;

/**
 * 欢迎加入QQ开发群讨论：88130145
 * 
 * @Description:
 * @author: zhuanggy
 * @see:   
 * @since:      
 * @copyright © 35.com
 * @Date:2013-10-14
 */
public interface ItemClickedListener {

	public void onItemClick(View item, int itemPosition);
}
