/**
 * 
 */
package com.gf.view.adapter;

import java.util.ArrayList;
import java.util.List;

import com.gf.client.R;
import com.gf.hippo.domain.client.quote.TickQuoteStreamItem;
import com.gf.view.adapter.MailAdapter.ItemViewHolder;
import com.gf.viewmodel.bean.VolumeItem;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 成交量的适配器
 * 
 * @author cola
 * 
 */
public class VolumeAdapter extends BaseAdapter {
	private List<TickQuoteStreamItem> volumList;
	private Context ct;

	public VolumeAdapter(final Context ct, List<TickQuoteStreamItem> volumList) {
		this.ct = ct;
		this.volumList = volumList;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return volumList.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return volumList.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int arg0, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ItemViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(ct).inflate(R.layout.volumeitem, null);
			holder = new ItemViewHolder();
			holder.level = (TextView) convertView.findViewById(R.id.level);
			holder.price = (TextView) convertView.findViewById(R.id.price);
			holder.time = (TextView) convertView.findViewById(R.id.volume_time);
			holder.volume = (TextView) convertView.findViewById(R.id.tvolume);
			convertView.setTag(holder);
		}else{
			holder = (ItemViewHolder) convertView.getTag();
		}
		
		holder.price.setText(String.format("%1$.2f",volumList.get(arg0).getPrice()));
		StringBuffer time = new StringBuffer(volumList.get(arg0).getTime() + "");
		int len = time.length();
		if (len < 6) {
			time = new StringBuffer(time.toString().substring(0, 3));
			time.insert(1, ":");
		}else{
			time = new StringBuffer(time.toString().substring(0, 4));
			time.insert(2, ":");
		}
		holder.time.setText(time.toString());
//		int volume = volumList.get(arg0).getVolume().intValue();
		holder.volume.setText(String.format("%1$.0f", Math.abs(volumList.get(arg0).getVolume() / 100)) + "");
		if(volumList.get(arg0).getVolume() > 0){
		holder.level.setText("B");
		holder.level.setTextColor(ct.getResources().getColor(
				R.color.shallow_red));
		}
		else{
			holder.level.setText("S");
			holder.level.setTextColor(ct.getResources().getColor(
					R.color.shallow_green));
		}
		return convertView;
	}

	public class ItemViewHolder {
		public TextView price;
		public TextView time;
		public TextView volume;
		public TextView level;
	}
}
