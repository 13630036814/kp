package com.gf.viewmodel.base;

import java.util.ArrayList;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.gf.hippo.domain.client.securities.Stock;
import com.gf.viewmodel.bean.IconItem;

/**
 * @author jin
 *
 */
public class GlobalMsg {
	/**
	 */
	public ArrayList<Stock> mStocksNeedToAdd = new ArrayList<Stock>();
	
	public ArrayList<IconItem> customPageData = new ArrayList<IconItem>();
	public boolean customPageDataInitFlag = false;
	
	private static GlobalMsg mInstance = null;
	
	private Context mContext;
	private static final String GLOBAL_PREF = "global_pref";
	private static final String CUSTOM_PAGE_INIT = "custom_page_init";
	
	private GlobalMsg() {
	}
	
	public static synchronized GlobalMsg getInstance() {
		if (mInstance == null) {
			mInstance = new GlobalMsg();
		}
		return mInstance;
	}
	
	public void init(Context context) {
		mContext = context;
	}
	
	public void setCustomPageDataInitFlag(boolean value) {
		SharedPreferences sharePref = mContext.getSharedPreferences(
				GLOBAL_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putBoolean(CUSTOM_PAGE_INIT, value);
		editor.commit();
	}

	public boolean getCustomPageDataInitFlag() {
		SharedPreferences sharePref = mContext.getSharedPreferences(
				GLOBAL_PREF, Context.MODE_PRIVATE);
		boolean value = sharePref.getBoolean(CUSTOM_PAGE_INIT, false);
		return value;
	}
	
	
}
