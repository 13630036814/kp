package com.gf.viewmodel.quote.components;


import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.ResBody;

public interface Serializer {
 public DomainObject unSerializeResBody(ResBody body) ;
 public DomainObject unSerializeMsgBody(MsgBody body);
 public byte[] serialize(DomainObject object);
}
