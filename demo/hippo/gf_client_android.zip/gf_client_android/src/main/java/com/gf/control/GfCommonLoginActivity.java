package com.gf.control;

import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONException;
import org.json.JSONObject;
import com.gf.client.R;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.base.HttpManager;
import com.gf.viewmodel.base.HttpManager.NetWorkCallBack;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class GfCommonLoginActivity extends Activity {
	private static final String TAG = "GfCommonLoginActivity";
	private EditText mEditTextUserName = null; // 广发通
	private EditText mEditPassword = null; // 密码
	private Button mBtnGfCommonLogin = null; // 登陆
	private Button mBtnMobilelogin = null; // 手机登陆
	private Button mBtnRegist = null; // 注册
	
	private String mUserName = null;
	private String mPassword = null;
	
	private HttpManager mHttpManager = null;
	
	private static final int INPUT_WRONG_MSG = 0;
	private static final int VERIFY_SUCCESS_MSG = 1;
	private static final int VERIFY_ERROR_MSG = 2;
	private static final int LOGIN_SUCCESS_MSG = 3;
	private static final int LOGIN_ERROR_MSG = 4;
	private static final int LOGIN_TIME_OUT_MSG = 5; // 网络超时
	private static final int LOGIN_NET_WORK_ERROR = 6; // 网络不通
	private static final int CONSTRUCTION_MSG = 7; // 建设中
	
	private static final int SUCCESS = 0;
	private static final int ERROR = -1;
	private static final int CONN = 1;
	private static final int DIS_CONN = 0;
	
	ProgressDialog mProgressDialog = null;
	
	private Timer mNetWorkTimer = null;
	private TimerTask mTask = null;
	private int mNetWorkFlag = DIS_CONN;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		if (getUserName() != null) {
			GfCommonLoginActivity.this.finish();
			Intent intent = new Intent(GfCommonLoginActivity.this, MainActivity.class);
			startActivity(intent);
			return;
		}
		setContentView(R.layout.gf_common_login);
		
		findView();
		initView();
		init();
	}

	private void findView() {
		mEditTextUserName = (EditText)this.findViewById(R.id.edit_username);
		mEditPassword = (EditText)this.findViewById(R.id.edit_password);
		mBtnGfCommonLogin = (Button)this.findViewById(R.id.btn_gf_common_login);
		mBtnMobilelogin = (Button)this.findViewById(R.id.btn_mobile_login);
		mBtnRegist = (Button)this.findViewById(R.id.btn_regist);
	}
	
	private void init() {
		mHttpManager = HttpManager.getInstance();	
	}
	
	
	private void initView() {
		mBtnGfCommonLogin.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mUserName = mEditTextUserName.getText().toString();
				mPassword = mEditPassword.getText().toString();
				// 用户名和密码为空
				if (mUserName == null || mPassword == null
						|| mUserName.length() == 0 || mPassword.length() == 0) {
					Message msg = mHandler.obtainMessage();
					msg.what = INPUT_WRONG_MSG;
					mHandler.sendMessage(msg);
					return;
				}
				mProgressDialog = ProgressDialog.show(
						GfCommonLoginActivity.this, "Login...",
						"Please wait...", true, false);
				startNetWorkTimer();
				loginVerify(mUserName, mPassword);
			}
		});
		
		// 手机登陆
		mBtnMobilelogin.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				Message msg = mHandler.obtainMessage();
				msg.what = CONSTRUCTION_MSG;
				mHandler.sendMessage(msg);
						
				// 暂时屏蔽
				/*
				GfCommonLoginActivity.this.finish();
				Intent intent = new Intent(GfCommonLoginActivity.this, PhoneLogin.class);
				startActivity(intent);
				*/
			}
		});
		
		// 注册
		mBtnRegist.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				GfCommonLoginActivity.this.finish();
				Intent intent = new Intent(GfCommonLoginActivity.this, Regist.class);
				startActivity(intent);
			}
		});
	}
	
	/**
	 * 使用用户名和密码获取token
	 * @param username
	 * @param password
	 */
	private void loginVerify(final String username, final String password) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "loginVerify result: " + result);
				// 网络不通
				/*if (result.equals(HttpManager.VISIT_NETWORK_ERROR)) {
					Message msg = mHandler.obtainMessage();
					msg.what = LOGIN_NET_WORK_ERROR;
					mHandler.sendMessage(msg);
					return;
				}*/
				
				JSONObject resultJson;
				String token = null;
				try {
					resultJson = new JSONObject(result);
					String errorInfo = (String) (resultJson.get("error_info"));
					int errorNo = (Integer)(resultJson.get("error_no"));
					// 校验失败
					if (errorNo == ERROR) {
						Message msg = mHandler.obtainMessage();
						msg.what = VERIFY_ERROR_MSG;
						mHandler.sendMessage(msg);
					} else {
						JSONObject errorInfoJson = new JSONObject(errorInfo);
						token = (String) errorInfoJson.get("access_token");
						Log.v(TAG, "token: " + token);
						
						login(token);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};
		String value = "user_id=" + username + "&" + "password=" + password;
		mHttpManager.visitNetWorkPost(HttpManager.AUTH_USERNAME_PSD_URL, value, callback);
	}
	
	/**
	 * 使用token登陆
	 * @param accessToken
	 */
	private void login(String accessToken) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "login result: " + result);
				// 网络不通
				/*if (result.equals(HttpManager.VISIT_NETWORK_ERROR)) {
					Message msg = mHandler.obtainMessage();
					msg.what = LOGIN_NET_WORK_ERROR;
					mHandler.sendMessage(msg);
					return;
				}*/
				
				JSONObject resultJson;
				try {
					resultJson = new JSONObject(result);
					JSONObject portalJson = resultJson.getJSONObject("portal");
					String name = (String)portalJson.get("mobile");
					if (name != null) {
						Message msg = mHandler.obtainMessage();
						msg.what = LOGIN_SUCCESS_MSG;
						mHandler.sendMessage(msg);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
					Message msg = mHandler.obtainMessage();
					msg.what = LOGIN_ERROR_MSG;
					mHandler.sendMessage(msg);
				} 
				
			}
		};
		String postValue = "access_token=" + accessToken;
		mHttpManager.visitNetWorkGet(HttpManager.LOGIN_URL, postValue, callback);
	}
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case INPUT_WRONG_MSG:
				Toast.makeText(GfCommonLoginActivity.this, "用户名或密码不能为空", Toast.LENGTH_LONG).show();
				break;
			case LOGIN_SUCCESS_MSG:
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				mNetWorkFlag = CONN;
				stopNetWorkTimer();
				GfCommonLoginActivity.this.finish();
				Intent intent = new Intent(GfCommonLoginActivity.this, MainActivity.class);
				startActivity(intent);
				saveCurAccount();
				break;
			case LOGIN_ERROR_MSG:
			case VERIFY_ERROR_MSG:
				stopNetWorkTimer();
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				Toast.makeText(GfCommonLoginActivity.this, "用户名或密码错误", Toast.LENGTH_LONG).show();
				break;
			case LOGIN_TIME_OUT_MSG:
				stopNetWorkTimer();
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				Toast.makeText(GfCommonLoginActivity.this, "联网超时,请检查网络", Toast.LENGTH_LONG).show();
				break;
			case LOGIN_NET_WORK_ERROR:
				stopNetWorkTimer();
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				Toast.makeText(GfCommonLoginActivity.this, "网络不通", Toast.LENGTH_LONG).show();
			case CONSTRUCTION_MSG:
				Toast.makeText(GfCommonLoginActivity.this, "建设中···", Toast.LENGTH_SHORT).show();
			}
			super.handleMessage(msg);
		}
		
	};
	
	private void startNetWorkTimer() {
		mNetWorkTimer = new Timer();
		mTask = new TimerTask() {
			@Override
			public void run() {
				if (mNetWorkFlag == DIS_CONN) {
					Message message = new Message();
					message.what = LOGIN_TIME_OUT_MSG;
					mHandler.sendMessage(message);
				}
			}
		};
		mNetWorkTimer.schedule(mTask, HttpManager.NET_WORK_TIME_OUT);
	}

	private void stopNetWorkTimer() {
		mNetWorkTimer.cancel();
	}
	
	private void saveCurAccount() {
		Global.userName = mUserName;
		saveData();
	}
	
	public void saveData() {
		SharedPreferences sharePref = getSharedPreferences(Global.USER_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putString(Global.USER_NAME, mUserName);
		editor.commit();
	}
	
	public String getUserName() {
		SharedPreferences sharePref = getSharedPreferences(Global.USER_PREF, Context.MODE_PRIVATE);
		String userName = sharePref.getString(Global.USER_NAME, null);

		return userName;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			if (GfCommonLoginActivity.this.getCurrentFocus() != null) {
				if (GfCommonLoginActivity.this.getCurrentFocus()
						.getWindowToken() != null) {
					imm.hideSoftInputFromWindow(GfCommonLoginActivity.this
							.getCurrentFocus().getWindowToken(),
							InputMethodManager.HIDE_NOT_ALWAYS);
					return true;
				}
			}
		}
		return false;
	}
	
	
}
