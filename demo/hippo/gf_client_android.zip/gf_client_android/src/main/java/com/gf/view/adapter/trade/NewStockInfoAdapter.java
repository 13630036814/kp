package com.gf.view.adapter.trade;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.viewmodel.ebiz.trade.NewStockInfo;

/**
 * 新股信息
 * 
 */
public class NewStockInfoAdapter extends BaseAdapter {

	private LayoutInflater mLayoutInflater;
	private List<NewStockInfo> mItems;

	private int selectedPosition = -1;

	public NewStockInfoAdapter(Context context, List<NewStockInfo> items) {
		mItems = items;
		mLayoutInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		if (mItems != null) {
			return mItems.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		final NewStockInfo info = mItems.get(position);
		final ViewHolder holder;
		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.new_stock_list_item, null);
			holder = new ViewHolder();

			holder.tvStockName = (TextView) view.findViewById(R.id.tv_stock_name);
			holder.tvStockCode = (TextView) view.findViewById(R.id.tv_stock_code);
			holder.tvLimit = (TextView) view.findViewById(R.id.tv_buy_limit);
			holder.tvPrice = (TextView) view.findViewById(R.id.tv_fix_price);
			holder.tvDate = (TextView) view.findViewById(R.id.tv_buy_date);

			view.setTag(R.id.layout_new_stock_info, holder);
		} else {
			holder = (ViewHolder) view.getTag(R.id.layout_new_stock_info);
		}

		if (info != null) {
			holder.tvStockName.setText(info.getStockName());
			holder.tvStockCode.setText(info.getStockCode());
			holder.tvLimit.setText(info.getLimit());
			holder.tvPrice.setText(info.getPrice());
			holder.tvDate.setText(info.getBuyDate());
		}

		return view;
	}

	public int getSelectedPosition() {
		return selectedPosition;
	}

	public void setSelectedPosition(int selectedPosition) {
		this.selectedPosition = selectedPosition;
	}

	class ViewHolder {
		TextView tvStockName; // 证券名称
		TextView tvStockCode; // 证券代码
		TextView tvLimit; // 申购限额
		TextView tvPrice; // 定价
		TextView tvDate; // 申购日
	}

}
