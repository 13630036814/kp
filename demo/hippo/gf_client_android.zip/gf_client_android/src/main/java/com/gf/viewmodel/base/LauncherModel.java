package com.gf.viewmodel.base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;

import com.gf.client.R;
import com.gf.control.SettingCenter;
import com.gf.data.sqlite.GfClientSqliteOpenHelper;
import com.gf.view.widget.Events;
import com.gf.viewmodel.bean.IconItem;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteStatement;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;
import android.util.Xml;

/**
 * @author jinjian
 *
 */
public class LauncherModel {
	protected static final String TAG = "ClientModel";
	private Context mContext;
	private static LauncherModel mInstance = null;
	public static String DBNAME = "gf_client.db";// 数据库的名字
	private static String DATABASE_PATH = "/data/data/com.gf.client/databases/";// 数据库在手机里的路径
	
	// message
	public static final int MSG = Events.EVENT_MAX + 1;	
	public static final int MSG_DATA_LOAD_END = MSG + 1;
	
	// intent
	public static final String INTENT_DATA_BASE_READY = "com.intent.action.dataBaseInit";
	
	private QuoteManagerFactory mQuoteManagerFactory = null;
	
	private LoaderTask mLoaderTask;
	
	public boolean mLoadAndBindStepFinished = false;
	
	private static final HandlerThread sWorkerThread = new HandlerThread("client-loader");
	static {
		sWorkerThread.start();
	}
	private static final Handler sWorker = new Handler(sWorkerThread.getLooper());
	
	private Callback mCallback;
	
	private GlobalMsg mGlobalMsg;
	
	private GfClientSqliteOpenHelper mSqliteHelper = null;
	
	private LauncherModel(Context context) {
		mContext = context;
		init();
	}

	public static synchronized LauncherModel getInstance(Context context) {
		if (mInstance == null) {
			mInstance = new LauncherModel(context);
		}
		return mInstance;
	}
	
	public void init() {
		mGlobalMsg = GlobalMsg.getInstance();
		mGlobalMsg.init(mContext);
		mSqliteHelper = GfClientSqliteOpenHelper.getInstance(mContext);
	}
	
	public void startLoader() {
		mLoaderTask = new LoaderTask();
		sWorkerThread.setPriority(Thread.NORM_PRIORITY);
		sWorker.post(mLoaderTask);
		initSettingPref();
	}
	
	/**
	 */
	public boolean checkDataBaseExist() {
		SQLiteDatabase checkDB = null;
		try {
			String databaseFilename = DATABASE_PATH + DBNAME;
			checkDB = SQLiteDatabase.openDatabase(databaseFilename, null, SQLiteDatabase.OPEN_READONLY);
		} catch (SQLiteException e) {
			e.printStackTrace();
		}
		if (checkDB != null) {
			checkDB.close();
		}
		return checkDB != null ? true : false;
	}

	/**
	 */
	public void copyDataBase() throws IOException {
		String databaseFilenames = DATABASE_PATH + DBNAME;
		File dir = new File(DATABASE_PATH);
		if (!dir.exists()) {
			dir.mkdir();
		}
		
		FileOutputStream os = null;
		try {
			os = new FileOutputStream(databaseFilenames);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		InputStream is = mContext.getResources().openRawResource(R.raw.gf_client);
		byte[] buffer = new byte[8192];
		int count = 0;
		try {
			while ((count = is.read(buffer)) > 0) {
				os.write(buffer, 0, count);
				os.flush();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			is.close();
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private class LoaderTask implements Runnable {
		@Override
		public void run() {
			mLoadAndBindStepFinished = false;
			// ***复制数据库
			boolean dbExist = checkDataBaseExist();

			if (!dbExist) {
				try {
					copyDataBase();
				} catch (IOException e) {
					e.printStackTrace();
					Log.v(TAG, "error copying database");
				}
			}
			
			Intent intent = new Intent(INTENT_DATA_BASE_READY);
			mContext.sendBroadcast(intent);
			mLoadAndBindStepFinished = true;
			
			initCustomPageData();
			
			mCallback.dataBaseCopyEnd();
		}
		
	}

	public Handler getHandler() {
		return sWorker;
	}
	
	/**
	 */
	public void initSettingPref() {
		SharedPreferences sharePref = mContext.getSharedPreferences(SettingCenter.SETTING_PREF, Context.MODE_PRIVATE);
		Boolean initFlag = sharePref.getBoolean(SettingCenter.INIT_FLAG, false);
		
		if (initFlag) {
			return;
		}
		Editor editor = sharePref.edit();
		editor.putInt(SettingCenter.MA1, 20);
		editor.putInt(SettingCenter.MA2, 25);
		editor.putInt(SettingCenter.MA3, 15);
		editor.putBoolean(SettingCenter.SET_DESKTOP_WIDGET, false);
		editor.putBoolean(SettingCenter.SET_MESSAGE_PUSH, true);
		editor.putBoolean(SettingCenter.SET_SHAKE_SOUND, false);
		editor.putInt(SettingCenter.LOGIN_TIMEOUT, 5);
		editor.putBoolean(SettingCenter.INIT_FLAG, true);
		editor.commit();
	}
	
	public interface Callback {
		public void dataBaseCopyEnd();
	}
	
	public void setCallback(Callback callback) {
		mCallback = callback;
	}
	
	/**
	 */
	public void initCustomPageData() {
		if (mGlobalMsg.getCustomPageDataInitFlag() == true) {
			return;
		}
		ArrayList<IconItem> iconItems;
		try {
			iconItems = getIconItemInfos(R.raw.custom_page_data);
			saveChange(iconItems);
			mGlobalMsg.setCustomPageDataInitFlag(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 从配置文件读取icon信息
	 * @param xmlFileRes
	 * @return
	 * @throws Exception
	 */
	public ArrayList<IconItem> getIconItemInfos(int xmlFileRes) throws Exception {
		//声明变量
		IconItem iconItem = null;
		ArrayList<IconItem> iconItemArr = null;
		XmlPullParser parser = Xml.newPullParser();
		//网络操作
		InputStream inputStream = mContext.getResources().openRawResource(xmlFileRes);
		parser.setInput(inputStream, "UTF-8");
		int event = parser.getEventType();
		while (event != XmlPullParser.END_DOCUMENT) {
			switch (event) {
			case XmlPullParser.START_DOCUMENT://判断是否是文档开始事件
				iconItemArr = new ArrayList<IconItem>();
				break;
			case XmlPullParser.START_TAG://判断是否是标签元素开始事件
				if ("iconItem".equalsIgnoreCase(parser.getName())) {
					iconItem = new IconItem();
				} else if (iconItem != null) {
					if ("fileName".equalsIgnoreCase(parser.getName())) {
						iconItem.setFileName(parser.nextText());
					} else if ("title".equalsIgnoreCase(parser.getName())) {
						iconItem.setTitle(parser.nextText());
					} else if ("className".equalsIgnoreCase(parser.getName())) {
						iconItem.setClassName(parser.nextText());
					} else if ("packageName".equalsIgnoreCase(parser.getName())) {
						iconItem.setPackageName(parser.nextText());
					} else if ("selectFlag".equalsIgnoreCase(parser.getName())) {
						iconItem.setSelectFlag(parser.nextText());
					}
				}
				break;
			case XmlPullParser.END_TAG:// 判断当前事件是否是标签元素结束事件
				if ("iconItem".equalsIgnoreCase(parser.getName())) {
					iconItemArr.add(iconItem);
				}
				break;
			}
			event = parser.next();// 进入下一个元素并触发相应事件
		}
		if (inputStream != null) {
			inputStream.close();
		}
		return iconItemArr;
	}
	
	private void saveChange(final ArrayList<IconItem> mCustomPageData) {
		clearOldUserStock();

		SQLiteDatabase db = mSqliteHelper.openDatabase();

		String insertsql = "insert or replace into "
				+ GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE + " ("
				+ "file_name, " 
				+ "title," 
				+ "class_name," 
				+ "package_name,"
				+ "select_flag) VALUES " 
				+ "(?,?,?,?,?)";

		db.beginTransaction();
		SQLiteStatement stmt = db.compileStatement(insertsql);

		for (int i = 0; i < mCustomPageData.size(); i++) {
			IconItem iconItem = mCustomPageData.get(i);
			stmt.bindString(1, iconItem.getFileName());
			stmt.bindString(2, iconItem.getTitle());
			stmt.bindString(3, iconItem.getClassName());
			stmt.bindString(4, iconItem.getPackageName());
			stmt.bindString(5, iconItem.getSelectFlag());

			stmt.execute();
			stmt.clearBindings();
		}
		db.setTransactionSuccessful();
		db.endTransaction();
		mSqliteHelper.closeDatabase();
	}

	public void clearOldUserStock() {
		String sql = "DELETE FROM " + GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE + ";";
		SQLiteDatabase db = mSqliteHelper.openDatabase();
		db.execSQL(sql);
		revertSeq();
		mSqliteHelper.closeDatabase();
	}

	private void revertSeq() {
		String sql = "update sqlite_sequence set seq=0 where name='"
				+ GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE + "'";
		SQLiteDatabase db = mSqliteHelper.openDatabase();
		db.execSQL(sql);
		mSqliteHelper.closeDatabase();
	}
}  
