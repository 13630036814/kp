package com.gf.viewmodel.quote.components;

import com.gf.viewmodel.ebiz.quote.BKTypes;
import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.RankReq;
import com.gf.viewmodel.ebiz.quote.RankRes;
import com.gf.viewmodel.ebiz.quote.RankRes.RankData;
import com.gf.viewmodel.ebiz.quote.RankTypes;
import com.gf.viewmodel.ebiz.quote.ReqBody;
import com.gf.viewmodel.ebiz.quote.ResBody;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.quote.BidAskQuoteItem;
import com.gf.hippo.domain.client.quote.BoardRankQuoteList;
import com.gf.hippo.domain.client.quote.RankQuoteItem;

public class BoardRandSerilizer implements Serializer {

	@Override
	public DomainObject unSerializeResBody(ResBody body)  {
		final RankRes msg = body.rankRes;
		if (msg == null)	return null;
		BoardRankQuoteList stream =  BoardRankQuoteList.newInstance(msg.intFromEnum(msg.board), msg.direct, msg.intFromEnum(msg.sort));
		//stream.setBoard(msg.intFromEnum(msg.board));
		//stream.setDirect(msg.direct);
		stream.setTotal(msg.total);
		//stream.setSort(msg.intFromEnum(msg.sort));
		for (int i = 0; i < msg.data.size(); ++i) {
			RankData data2 = msg.data.get(i);
			RankQuoteItem item = new RankQuoteItem();
			item.setAmount(data2.quote.amount);
			item.setChange(data2.quote.change);
			item.setCittdiff(data2.quote.cittdiff);
			item.setCittthan(data2.quote.cittthan);
			item.setCode(data2.code);
			item.setEps(data2.quote.eps);
			item.setHandover(data2.quote.handover);
			item.setHigh(data2.quote.high);
			item.setIn(data2.quote.in);
			item.setLow(data2.quote.low);
			item.setMarket(data2.market);
			item.setName(data2.name);
			item.setNow(data2.quote.now);
			item.setNvaps(data2.quote.nvaps);
			item.setOpen(data2.quote.open);
			item.setOut(data2.quote.out);
			item.setPclose(data2.quote.pclose);
			item.setPe(data2.quote.pe);
			// item.setPosition(data2.quote.position);
			item.setQuarter(data2.quote.quarter);
			item.setRise(data2.quote.rise);
			item.setSecurityType(data2.intFromEnum(data2.quote.type));
			item.setShare(data2.quote.share);
			item.setStop(data2.quote.stop);
			item.setTime(data2.quote.time);
			item.setTotal(data2.quote.total);
			item.setVolume(data2.quote.volume);
			for (int ii = 0; ii < data2.quote.position.size(); ii++) {
				BidAskQuoteItem postion = new BidAskQuoteItem();
				postion.setAsk(data2.quote.position.get(ii).ask);
				postion.setAsksize(data2.quote.position.get(ii).asksize);
				postion.setBid(data2.quote.position.get(ii).bid);
				postion.setBidsize(data2.quote.position.get(ii).bidsize);
				item.addBidAskQuoteItem(postion);
			}
			stream.putItem(item);
		}
		return stream;
	}

	@Override
	public DomainObject unSerializeMsgBody(MsgBody body) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public byte[] serialize(DomainObject object) {
		if(object instanceof BoardRankQuoteList){
			BoardRankQuoteList quote = (BoardRankQuoteList)object;
	        ReqBody.Builder builder = new ReqBody.Builder();
	        builder.fid(HQFuncTypes.HQ_PX );	           	        
	        RankReq.Builder req=new RankReq.Builder();	        
	        req.board(boardTypesTanslate(quote.getBoard())).count(quote.getCount()).direct(quote.getDirect()).from(quote.getFrom()).sort(rankTypesTranslate(quote.getSort()));
	       builder.rankReq=req.build();
	       ReqBody body = builder.build();
	        byte[] bytes = body.toByteArray();
	        return bytes;
		}
		return null;
	}

	public BKTypes boardTypesTanslate(int boardTypesVaule) {
		BKTypes type;
		switch (boardTypesVaule) {
		case 0:
			type = BKTypes.BK_UNKNOWN;
			break;
		case 1:
			type = BKTypes.BK_A;
			break;
		case 2:
			type = BKTypes.BK_B;
			break;
		case 3:
			type = BKTypes.BK_SZ_A;
			break;
		case 4:
			type = BKTypes.BK_SH_A;
			break;
		case 5:
			type = BKTypes.BK_SZ_B;
			break;
		case 6:
			type = BKTypes.BK_SH_B;
			break;
		case 7:
			type = BKTypes.BK_FUND;
			break;
		case 8:
			type = BKTypes.BK_WARRANT;
			break;
		case 9:
			type = BKTypes.BK_INDEX;
			break;
		case 10:
			type = BKTypes.BK_BOND;
			break;
		case 11:
			type = BKTypes.BK_GROWTH;
			break;
		case 12:
			type = BKTypes.BK_SMALL;
			break;
		case 13:
			type = BKTypes.BK_THIRD;
			break;
		default:
			type = BKTypes.BK_UNKNOWN;
		}
		return type;
	}
	
	public RankTypes rankTypesTranslate(int rankTypeValue){
		RankTypes type;
		switch(rankTypeValue){
		case 0:
			type=RankTypes.PX_NONE;
			break;
		case 1:
			type=RankTypes.PX_CHANGE_PCT;
			break;
		case 2:
			type=RankTypes.PX_NOW;
			break;
		case 3:
			type=RankTypes.PX_PCLOSE;
			break;
		case 4:
			type=RankTypes.PX_VOLUME;
			break;
		case 5:
			type=RankTypes.PX_AMOUNT;
			break;
		case 6:
			type=RankTypes.PX_OPEN;
			break;
		case 7:
			type=RankTypes.PX_HIGH;
			break;
		case 8:
			type=RankTypes.PX_LOW;
			break;
		case 9:
			type=RankTypes.PX_CODE;
			break;
		case 10:
			type=RankTypes.PX_TURNOVER;
			break;
		case 11:
			type=RankTypes.PX_PE;
			break;
		case 12:
			type=RankTypes.PX_CHANGE;
			break;
		default:
			type=RankTypes.PX_NONE;
		}
		return type;
	}

	

}
