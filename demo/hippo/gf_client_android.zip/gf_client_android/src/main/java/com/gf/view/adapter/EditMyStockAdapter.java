/**
 * 
 */
package com.gf.view.adapter;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.gf.client.R;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.view.adapter.CodeLineAdapter.StockAction;
import com.gf.view.widget.SimpleDragSortCursorAdapter;

/**
 * @author Cola
 *
 */
public class EditMyStockAdapter extends SimpleDragSortCursorAdapter{
    private Context mContext;
    private StockList mStockList;

    public EditMyStockAdapter(Context ctxt, int rmid, Cursor c, String[] cols, int[] ids, int something) {
        super(ctxt, rmid, c, cols, ids, something);
        mContext = ctxt;
    }

    public void setData(StockList mStockList){
    	this.mStockList = mStockList;
    }
    
    @Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View v = super.getView(position, convertView, parent);
		final int p = position;
		Holder holder = null;
		holder = (Holder) v.getTag();
		if (holder == null) {
			holder = new Holder();
			View tv = v.findViewById(R.id.click_remove);
			holder.text = tv;
			tv.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if(mStockAction != null){
						mStockAction.del(p);
						
					}
				}
			});

			View tv2 = v.findViewById(R.id.text);
			holder.img = tv2;
			tv2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

				}
			});
			v.setTag(holder);
		}

		return v;
	}
    
    public void setViewText(TextView v, String text) {
    	int p = text.indexOf("\n");
    	if(p != -1){
    	String tmp = text.substring(p, text.length());
    	SpannableStringBuilder sb = new SpannableStringBuilder(text); 
		//设置股票代码的小字体部分
    	sb.setSpan(new AbsoluteSizeSpan(12), p, p + tmp.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
		sb.setSpan(new ForegroundColorSpan(Color.GRAY),p,p + tmp.length(),//改变字体色
				Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
        v.setText(sb);
    	}else
    		v.setText(text);
    }
    
    public class Holder{
    	public View text;
    	public View img;
    }
    
	private StockAction mStockAction;
	public void setStockAction(StockAction sa){
		this.mStockAction = sa;
	}
	
	/**
	 * 点击添加按钮后的回调
	 * @author cola
	 *
	 */
	public interface StockAction{
		/**
		 * 
		 * @param pos 在数据的位置
		 */
		public void add(int pos);
		public void del(int pos);
		public void drop(int from, int to);
	}
	
	@Override
	public void drop(int from, int to) {
		if(mStockAction != null){
			mStockAction.drop(from,to);
			super.drop(from, to);
		}
	}
}
