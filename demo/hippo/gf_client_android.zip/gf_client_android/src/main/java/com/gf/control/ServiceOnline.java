package com.gf.control;

import com.gf.client.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

public class ServiceOnline extends Activity {
	WebView mWebView;
	ImageButton mBtnBack;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.service_online);
		findView();
		initView();
	}

	private void findView() {
		mWebView = (WebView) this.findViewById(R.id.web_view);
		mBtnBack = (ImageButton) findViewById(R.id.btn_back);
	}

	private void initView() {
		initWebView();
		mBtnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				ServiceOnline.this.finish();
			}
		});
	}

	private void initWebView() {
		WebSettings webSettings = mWebView.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setSupportZoom(true);
		webSettings.setCacheMode(webSettings.LOAD_NO_CACHE);
		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
				// mWebView.loadUrl(infoUrl);
				return super.shouldOverrideKeyEvent(view, event);
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				return super.shouldOverrideUrlLoading(view, url);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				// TODO Auto-generated method stub
				super.onPageFinished(view, url);
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				// TODO Auto-generated method stub
				super.onPageStarted(view, url, favicon);
			}
		});

		mWebView.setWebChromeClient(new WebChromeClient() {
			@Override
			public boolean onJsAlert(WebView view, String url, String message,
					final android.webkit.JsResult result) {
				new AlertDialog.Builder(ServiceOnline.this)
						.setTitle(" ")
						.setMessage(message)
						.setPositiveButton(android.R.string.ok,
								new AlertDialog.OnClickListener() {
									@Override
									public void onClick(DialogInterface arg0, int arg1) {
										result.confirm();
									}
								}).setCancelable(false).create().show();

				return true;
			}

			@Override
			public void onProgressChanged(WebView view, int newProgress) {
				super.onProgressChanged(view, newProgress);
			};
		});
		//mWebView.addJavascriptInterface(new JavaScriptBridge(),	"JavaScriptBridge");
		mWebView.loadUrl("https://service.gf.com.cn/im/");
		
		mWebView.requestFocus();
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			ServiceOnline.this.finish();
			break;
		}
		return false;
	}

}
