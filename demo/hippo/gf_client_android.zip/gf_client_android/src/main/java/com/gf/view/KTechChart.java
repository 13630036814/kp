package com.gf.view;



import java.util.Vector;

import com.gf.viewmodel.bean.DataSetKLine;
import com.gf.viewmodel.util.AFloat;

import android.graphics.Paint;
import android.graphics.Rect;
import android.util.FloatMath;
import android.util.Log;



/**
 * 技术指标()
 * 
 * @author Think
 * 
 */
public class KTechChart {
	public static final int TECH_VOLUME = 0;
	public static final int TECH_KDJ = 1;
	public static final int TECH_MACD = 2;
	public static final int TECH_OBV = 3;
	public static final int TECH_DMA = 4;
	public static final int TECH_VR = 5;
	public static final int TECH_RSI = 6;
	public static final int TECH_DMI = 7;
	public static final int TECH_BOLL = 8;
	public static final int TECH_BRAR = 9;

//	private Object[][] mTechDatas;
//	private Object[][] mTechMaxMin;

	private DataSetKLine mDataSetKLine;
	//private DataSetKLine mLastDatSet;
	
	public int techLineStyle;
	
	//public boolean isInit = false;  //是否初始化	
	public float[][] kTech=new float[5][]; //5个技术指标值;
	public int m_iTechType = TECH_VOLUME;	
	//private AFloat startFloat = new AFloat();
	//private AFloat endFloat = new AFloat();
	public float m_minTech;
	public float m_maxTech;
	
	private float mMaxPrice;
	private float mMinPrice;
	
	private Rect mDrawRect;
	
	private int mChartType;

	private int mMaxDrawLength;
	private int mTechIndex;
	private int mDataIndex;
	
	private Vector<Integer> mVtech;// = new Vector<Integer>();
	
	private boolean isEnabled;
	//public boolean isComputing;
	
	private Paint paint = Theme.factroyPaint();
	
	KLineChart mTarget;
	public KTechChart() {
		
	}
	public void setTarget(KLineChart target){
		mTarget = target;
	}
	
	public boolean isEnable(){
		return isEnabled;
	}
	
	public void reset(){
		isEnabled=false;
	}

	public void setDataSet(DataSetKLine dataset) {
		mDataSetKLine = dataset;
	}
	
	public void init(Rect r,int dataLength,int startIndex,float maxPrice,float minPrice,int chartType){
		mDrawRect=r;
		mMaxDrawLength=dataLength;
		mDataIndex=startIndex;
		
		mMaxPrice=maxPrice;
		mMinPrice=minPrice;
		mChartType=chartType;
		
		if(kTech[0]==null||kTech[0].length!=mDataSetKLine.kCount){
			kTech[0]=null;
			kTech[1]=null;
			kTech[2]=null;
			kTech[3]=null;
			kTech[4]=null;
			kTech[0]=new float[mDataSetKLine.kCount];
			kTech[1]=new float[mDataSetKLine.kCount];
			kTech[2]=new float[mDataSetKLine.kCount];
		}		
		isEnabled=true;
		refreshTech();
	}
/*	
	public void onCompute(){
		if(isComputing)return;
		Thread techThread = new Thread(new Runnable(){
			@Override
			public void run() {
				isComputing = true;
				while(mLastDatSet!=null){
					mTechDatas = null;
					mTechMaxMin = null;
					mDataSetKLine = mLastDatSet;
					mLastDatSet = null;
					final int endIndex = mDataSetKLine.kCount - 1;
					
					Object[][] techDatas = new Object[10][];
					Object[][] techMaxMin = new AFloat[10][2];
					
					for(int i=1;i<10;i++){//成交量不用算
						initTech(i,0,endIndex);
						techDatas[i] = new Object[techLineStyle];
						for(int j=0;j<techLineStyle;j++){
							techDatas[i][j]= kTech[j];
						}
						techMaxMin[i][0] = m_maxTech;
						techMaxMin[i][1] = m_minTech;
						
					}
					mTechDatas = techDatas;
					mTechMaxMin = techMaxMin;
					if(mLastDatSet!=null){
						mTarget.onRefresh();
					}
				}
				isComputing = false;
				isInit = true;		
			}});
		techThread.start();
	}
*/
	
/*	public Object[] getTechData(int techID){
		if(mTechDatas!=null){
			return (Object[]) mTechDatas[techID];
		}else{
			return null;
		}
	}
*/	
/*	public AFloat[] getTechMaxMinData(int techID){
		if(mTechMaxMin!=null){
			return (AFloat[]) mTechMaxMin[techID];
		}else{
			return null;
		}
	}
*/	
		
	public void onChangedTech(){
/*ax update 
 * 		if(SettingPersistence.isChanged()){
			boolean[] settings = SettingPersistence.getTechSetting();
			mVtech.removeAllElements();
			for(int i=0;i<settings.length;i++){
				if(settings[i]){
					mVtech.add(i);
				}
			}
		}
*/		if(mVtech.size()>0){
			mTechIndex=(mTechIndex+1)%mVtech.size();
		}
		//mTechIndex=(mTechIndex+1)%10;
		refreshTech();
	}
	
	public void onChangedTech(int type){
		mTechIndex = type;
		refreshTech();
	}
	
	/**
	 * 重新计算
	 */
	public void refreshTech(){
		if(mVtech == null){
			mVtech = new Vector<Integer>();
/*ax update 
 * 			boolean[] settings = SettingPersistence.getTechSetting();
			for(int i=0;i<settings.length;i++){
				if(settings[i]){
					mVtech.add(i);
				}
			}
*/
			for(int i=0; i<10; i++){
				mVtech.add(i);
			}
		}
		initTech(mTechIndex,0,mDataSetKLine.kCount-1);
	}
	
	public int getTechID(){
		return m_iTechType;
	}


	private void initTech(int techindex, int nStart, int nEnd) { // 计算技术指标
		final float[] kClose = mDataSetKLine.kClose;
		

		kTech[0]=null;
		kTech[1]=null;
		kTech[2]=null;
		kTech[3]=null;
		kTech[4]=null;
		kTech[0]=new float[mDataSetKLine.kCount];
		kTech[1]=new float[mDataSetKLine.kCount];
		kTech[2]=new float[mDataSetKLine.kCount];

		m_maxTech =0;
		m_minTech =0;
		
		techLineStyle = 3;
		
		if(mVtech!=null&&mVtech.size()>0){
			m_iTechType = mVtech.elementAt(techindex);
		}else{
			m_iTechType = TECH_VOLUME;
		}
		//m_iTechType = techindex;
		switch (m_iTechType) {//techindex
		case TECH_VOLUME:{
			
			float vol5 ;
			float vol10;
			float vol30;
			for (int i = nStart; i <= nEnd; i++) {
				vol5 = CalculateVolume(i, 5);
				vol10 = CalculateVolume(i, 10);
				vol30 = CalculateVolume(i, 30);
				
				setTech(vol5, vol10, vol30, i);
			}
			//m_maxTech.init(kMaxVol.nValue * 101 / 100, kMaxVol.nDigit,kMaxVol.nUnit);
			//m_minTech.init(0,3,0);
		}break;
		case TECH_KDJ:{
			CalculateKDJ(nStart,nEnd);
		}break;
		case TECH_MACD:{
			//AFloat outF=new AFloat();
			for (int i = 0; i <= nEnd; i++) {
				//outF.init(kClose[i]);
				//System.out.println("close:"+outF.toFloat());
				if (i == 0) {
					AFloat factor1 = new AFloat(100, 2, 0), factor2 = new AFloat(
							100, 2, 0), factor3 = new AFloat(1, 3, 0);
					int k = mDataIndex;
					for (; k > 0; k--) {
						factor1.mul(m_nEMA12Days - 1);
						factor1.div(m_nEMA12Days + 1);
						factor2.mul(m_nEMA26Days - 1);
						factor2.div(m_nEMA26Days + 1);
						
						if (AFloat.compare(factor1, factor3) <= 0 && AFloat.compare(factor2, factor3) <= 0){
							
							break;
						}
							
					}
//					fEMA12 = (float2int((int)(kClose[k] * 100),2,0));
//					fEMA26 = (float2int((int)(kClose[k] * 100),2,0));
					fEMA12 = kClose[k];
					fEMA26 = kClose[k];
					
					fDIF = 0;//.init(0, fEMA12.nDigit, fEMA12.nUnit);
					fDEA = 0;//.init(0, fEMA12.nDigit, fEMA12.nUnit);
					
					element[0] = fEMA12;
					element[1] = fEMA26;
					element[2] = fDIF;
					element[3] = fDEA;

					CalculateMacd(fEMA12, fEMA26,fDIF, fDEA, k);
					for (; k <= i; k++) {
						CalculateMacd(element[0], element[1], element[2],
								element[3], k);
					}
					m_maxTech =element[2];
					m_minTech =element[3];
				} else {
					CalculateMacd(element[0], element[1], element[2],
							element[3], i);
				}
				
				setTech(element[2], element[3],(element[2] - element[3]) * (2), i);
				
			}
		}break;
		case TECH_OBV:{
			techLineStyle = 2;
			float t = 0;
			float t1 = 0;
			float t2 = 0;
			float obv = 0;
			int ma = 0;
			for (int i = 0; i <= nEnd; i++) {
				obv = CalculateOBV(i);
				t = obv;
				t1 = t;
				setTech(t1, 0, 0, i);
//				if (i >= 30) {
					t2 = CalculateTechMA(kTech[0], i, 30);
					
//					t2 = t;
					setTech(t1, t2, 0, i);
//				}
			}
		}break;
		case TECH_DMA: {
			techLineStyle = 2;
			int day10 = 10, day50 = 50;
			float t = 0;
			float t1 = 0;
			float t2 = 0;
			
			for (int i = 0; i <= nEnd; i++) {
				if (day10 > i + 1 || day50 > i + 1) {
					setTech(nullAFloat, nullAFloat, nullAFloat, i);
					continue;
				}
				float ma1 = CalculateTechMA(kClose, i, day10);
				float ma2 = CalculateTechMA(kClose, i, day50);
				
				t = ma1 - ma2;//initF(AFloat.toFloat(ma1)-AFloat.toFloat(ma2), 3, 0);
				
				t1 = t;
				setTech(t1, nullAFloat, nullAFloat, i);
				if (i >= (day10 + day50)) {					
					t2 = CalculateTechMA(kTech[0], i, day10);
//					t2 = ma;
					setTech(t1, t2, nullAFloat, i);
				}
			}
		}
			break;
		case TECH_VR:{
			techLineStyle = 2;
			float t1 = 0;
			float t2 = 0;
			int ma = 0;
			for (int i = nStart; i <= nEnd; i++) {	
				if(i<26){
					setTech(nullAFloat, nullAFloat, nullAFloat, i);
					continue;
				}
				t1 = VR(i,26);
				setTech(t1, 0, 0, i);
				t2 = CalculateTechMA(kTech[0], i, 6);
//				t2 = (ma);
				setTech(t1, t2, 0, i);				
				
			}
			
		}break;
		case TECH_RSI:{//相对强弱指标
			final int day6=6;
			final int day14=14;
			final int day24=24;
			float t1 = 0;
			float t2 = 0;
			float t3 = 0;
			float[] rsima=null;
			m_minTech = 0;
			m_maxTech = 0;
			for (int i = nStart; i <= nEnd; i++) {
				rsima=RSIMA(i, day6);					
				t1 = ((rsima[0]) * (100)) / (rsima[1]);
				
				rsima=RSIMA(i, day14);	
				t2 = ((rsima[0]) * (100)) / (rsima[1]);
				
				rsima=RSIMA(i, day24);	
				t3 = ((rsima[0]) * (100)) / (rsima[1]);				
				setTech(t1, t2, t3, i);
			}
			//Log.i("RSIMA max & min", "m_minTech:"+m_minTech.toFloat()+" m_maxTech: "+m_maxTech.toFloat());
		}break;
		case TECH_DMI:{//动向指标
			this.techLineStyle = 4;
			DMI(nStart, nEnd);
		}break;
		case TECH_BOLL:
			BOLL(nStart,nEnd);
			break;
		case TECH_BRAR:
			BRAR(nStart, nEnd);
			break;
		case 26:{// CR
		
			this.techLineStyle = 5;
			int day26 = 26;
			int day10 = 10;
			int day20 = 20;
			int day40 = 40;
			int day62 = 62;

			float t1 = 0;//new AFloat();
			float t2 = 0;//new AFloat();
			float t3 = 0;//new AFloat();
			float t4 = 0;//new AFloat();
			float t5 = 0;//new AFloat();
			float cr = 0;
			float ma = 0;
			for (int i = nStart; i <= nEnd; i++) {
				cr = CalculateCR(i, day26);
				t1 = cr;
				setTech(t1, 0, 0, i);
				if (i >= (day10 + day10 * 2 / 5)) {
					ma = CalculateTechMA(kTech[0], i, day10);
					t2 = (ma);
				}
				if (i >= (day20 + day20 * 2 / 5)) {
					ma = CalculateTechMA(kTech[0], i, day20);
					t3 = (ma);
				}
				if (i >= (day40 + day40 * 2 / 5)) {
					ma = CalculateTechMA(kTech[0], i, day40);
					t4 = (ma);
				}
				if (i >= (day62 + day62 * 2 / 5)) {
					ma = CalculateTechMA(kTech[0], i, day62);
					t5 = (ma);
				}
				setTech(t1, t2, t3, i);
				setTech(t4, t5, i);
			}

		}
			break;
		case 27:{// WR
		
			this.techLineStyle = 2;
			for (int i = nStart; i <= nEnd; i++) {
				float t1 = CalculateWR(i, 10);
				float t2 = CalculateWR(i, 6);
				setTech(t1, t2, 0, i);
			}
		}
			break;
		default:
			break;
		}
		
		if(m_maxTech!=0){
			m_maxTech = (m_maxTech * 101 / 100);//, m_maxTech.nDigit,
//					m_maxTech.nUnit);
			m_minTech = (m_minTech * 99 / 100);//, m_minTech.nDigit,
//					m_minTech.nUnit);		
		}else{
			m_maxTech = 0;
			m_minTech = 0;
		}

		
	}

	public void setMaxTech(float value){
		if (value != 0 && m_maxTech < value)
			m_maxTech =value;
	}
	
	public void setMinTech(float value){
		if (value != 0 && m_minTech > value)
			m_minTech =value;
	}

	public void setTech(float fValue1, float fValue2, float fValue3, int index) {
		
		kTech[0][index] = fValue1;
		kTech[1][index] = fValue2;
		kTech[2][index] = fValue3;
		
			
		if(m_minTech==nullAFloat){
			m_minTech =fValue1;
		}
		if( m_maxTech==nullAFloat){
			m_maxTech =fValue1;
		}
		if( m_minTech==nullAFloat){
			m_minTech =fValue2;
		}
		if( m_maxTech==nullAFloat){
			m_maxTech =fValue2;
		}
		if( m_minTech==nullAFloat){
			m_minTech =fValue3;
		}
		if(m_maxTech==nullAFloat){
			m_maxTech =fValue3;
		}
		
		if (fValue1 != 0 && m_minTech > fValue1)
			m_minTech=fValue1;
		if (fValue2 != 0 && m_minTech > fValue2)
			m_minTech=fValue2;
		if (fValue3 != 0 && m_minTech > fValue3)
			m_minTech=fValue3;

		if (fValue1 != 0 && m_maxTech < fValue1)
			m_maxTech =fValue1;
		if (fValue2 != 0 && m_maxTech < fValue2)
			m_maxTech =fValue2;
		if (fValue3 != 0 && (m_maxTech < fValue3))
			m_maxTech =fValue3;
		
	}

	public void setTech(float t4, float t5, int index) {
		if (kTech[3] == null) {
			kTech[3] = new float[kTech[0].length];
			kTech[4] = new float[kTech[0].length];
		}

		kTech[3][index] = t4;
		kTech[4][index] = t5;

		if (t4!=0&&m_minTech > kTech[3][index])
			m_minTech = t4;
		if (t5!=0&&m_minTech > t5)
			m_minTech = t5;

		if (t4!=0&&m_maxTech < t4)
			m_maxTech = t4;
		if (t5!=0&&m_maxTech < t5)
			m_maxTech = t5;

	}

	/**
	 * 成交量
	 * 
	 * @param index
	 * @param day
	 * @return
	 */
	private float CalculateVolume(int index, int day) {
		int count = 0;
		final float[] iCjss = mDataSetKLine.kCjss;
		float aFloator = 0;
		for (int k = index; k >= 0; k--) {
			aFloator += (iCjss[k]);
			count++;
			if (count == day) {
				count = 0;
				aFloator /= (day);
				break;
			}
			if (k == 0) {
				aFloator /= (count);
				break;
			}
		}
		return aFloator;
	}

	public static final int mode3K2D = 0x01;
	public static final int mode3D2K = 0x02;
	public static final int m_nEMA12Days = 12;
	public static final int m_nEMA26Days = 26;
	public static final int m_nDIFDays = 9;

	public static final int m_nRSVDays = 9;
	public static final int m_nKDays = 3;
	public static final int m_nDDays = 3;
	public static final int m_nJ = mode3K2D;
	float fEMA12 = 0;
	float fEMA26 = 0;
	float fDIF = 0;
	float fDEA = 0;
	float[] element = new float[4];

	float[] CalculateMacd(float iEMA12, float iEMA26, float iDIF, float iDEA, int index) {
		final float[] iClose = mDataSetKLine.kClose;
		if (iClose == null || index >= iClose.length)
			return null;
//		if (m_nEMA12Days > index + 1 || m_nEMA26Days > index + 1
//				|| m_nDIFDays > index + 1)
//			return null;
		
		float close = iClose[index];

		fEMA12 *= m_nEMA12Days - 1;
		fEMA12 /= (m_nEMA12Days + 1);				
		fEMA12 += (close*2/(m_nEMA12Days + 1));

		fEMA26 *= (m_nEMA26Days - 1);
		fEMA26 /= (m_nEMA26Days + 1);
		fEMA26 += (close*2/(m_nEMA26Days + 1));

		fDIF = (fEMA12 - fEMA26);

		fDEA *= (m_nDIFDays - 1);
		fDEA /= (m_nDIFDays + 1);
		
		
		fDEA += (fDIF*2/(m_nDIFDays + 1));
		
		element[0] = fEMA12;
		element[1] = fEMA26;
		element[2] = fDIF;
		element[3] = fDEA;
		return element;
	}

	float fK = 50;
	float fD = 50;
	float fJ = 50;

	int[] CalculateKDJ(int nStart, int nEnd) {
		
//		fK.init(50 * 100, 2, 0);
//		fD.init(50 * 100, 2, 0);
//		fJ.init(50 * 100, 2, 0);
		for (int k = nStart; k <= nEnd; k++) {
			if (k == nStart) {
				AFloat factor1 = new AFloat(1, 2, 0), factor2 = new AFloat(1,
						2, 0), factor3 = new AFloat(1, 3, 0);
				int i = k;
				for (; i > 0; i--) {
					factor1.mul(m_nKDays - 1);
					factor1.div(m_nKDays + 1);
					factor2.mul(m_nDDays - 1);
					factor2.div(m_nDDays + 1);
					if (AFloat.compare(factor1, factor3) == -1
							&& AFloat.compare(factor2, factor3) == -1)
						break;
				}
				for (; i <= k; i++) {
					int RSV = CalculateRSV(i);
					if (RSV > -10000) {
						fK *= (m_nKDays - 1);
						fK /= (m_nKDays);
						startFloat = (RSV);
						startFloat /= (m_nKDays);
						fK += (startFloat);

						fD *= (m_nDDays - 1);
						fD /= (m_nDDays);
						startFloat =fK;//.init(fK.nValue, fK.nDigit, fK.nUnit);
						startFloat /= (m_nDDays);
						fD += (startFloat);

						fJ = fK * 3;//.init(fK.nValue * 3, fK.nDigit, fK.nUnit);
						startFloat = fD * 2;//.init(fD.nValue * 2, fD.nDigit, fD.nUnit);
						fJ -= (startFloat);
					}
				}
				setTech(fK, fD, fJ, k);
			} else {
				int RSV = CalculateRSV(k);
				if (RSV > -10000) {
					fK *= (m_nKDays - 1);
					fK /= (m_nKDays);
					startFloat = (RSV);
					startFloat /= (m_nKDays);
					fK += (startFloat);

					fD *= (m_nDDays - 1);
					fD /= (m_nDDays);
					startFloat = fK;//.init(fK.nValue, fK.nDigit, fK.nUnit);
					startFloat /= (m_nDDays);
					fD += (startFloat);

					fJ = fK * 3;//.init(fK.nValue * 3, fK.nDigit, fK.nUnit);
					startFloat = fD *2;//.init(fD.nValue * 2, fD.nDigit, fD.nUnit);
					fJ -= (startFloat);
				}
				setTech(fK, fD, fJ, k);
			}
		}
		return null;
	}

	public int float2int(int nValue,int nDigit,int nUnit) {
		int v = (nValue << 4) & 0xFFFFFFF0;
		v = v | (nDigit << 2) | nUnit;
		return v;
	}
	
	float temAFloat = 0;
	float startFloat = 0;
	float endFloat = 0;

	int CalculateRSV(int nIndex) {
		final float[] iZgcj = mDataSetKLine.kZgcj;
		final float[] iZdcj = mDataSetKLine.kZdcj;
		final float[] iClose = mDataSetKLine.kClose;
		float dH = 0, dL = 0;
		int dRSV = 100;
		startFloat = 100;
		dRSV = float2int(100 * 100,2,0);
		int nCount = 0;
		for (int k = nIndex; k >= 0; k--) {
			if (nIndex == k) {
				dH = iZgcj[k];
				dL = iZdcj[k];
			}
			if (dH < iZgcj[k])
				dH = iZgcj[k];
			if (dL > iZdcj[k])
				dL = iZdcj[k];
			nCount++;
			if (nCount == m_nRSVDays || k == 0) {
				if (dH == dL) {
					startFloat = 100;
					dRSV = 100;
				} else {
					startFloat = iClose[nIndex];
					endFloat = dL;
					startFloat -= (endFloat);
					startFloat *= (100);
					endFloat = (dH);
					temAFloat = (dL);
					endFloat -= (temAFloat);
					startFloat /= (endFloat);
					dRSV = (int) startFloat;
				}
				return dRSV;
			}
		}
		return -10000;
	}

	/**
	 * 计算威廉技术指标 H - C W%R指标值= ———— ×100 H - L H = N日内最高价, L = N日内最低价, C = 当天收盘价
	 */
	float dH = 0;
	float dL = 0;
	float dR = 0;
	float min = 1;

	float CalculateWR(int index, int nDays) {
		final float[] kZdcj = mDataSetKLine.kZdcj;
		final float[] kZgcj = mDataSetKLine.kZgcj;
		final float[] kClose = mDataSetKLine.kClose;
//		if (dH == 0) {
//			dH = new AFloat();
//			dL = new AFloat();
//			dR = new AFloat();
//			min = new AFloat(1, 4, 0);
//		}
//		dH.init(0,3,0);
//		dL.init(0,3,0);
//		dR.init(0,3,0);
		int nCount = 0;
		for (int k = index; k >= 0; k--) {
			if (index == k) {
				dH = (kZgcj[k]);
				dL = (kZdcj[k]);
			}
			if (kZgcj[k] > dH) {
				dH = (kZgcj[k]);
			}

			if (kZdcj[k] < dL) {
				dL = (kZdcj[k]);
			}
			nCount++;
			if (nCount == nDays) {
				if (dH - dL < min) {
					dR = (100);
				} else {
					
					dR = (dH - kClose[k]);
					dR *= (100);
					dR /= (dH-dL);
				}
				return dR;
			}
			if (nDays > index + 1 && k == 1) { // 当数据不够多的时候 每次相加第一条数据
				k++;
			}
		}
		dR = 0;//(0,3,0);
		return dR;
	}

	/*
	 * TH:=SUM(IF(CLOSE>REF(CLOSE,1),VOL,0),N);
     * TL:=SUM(IF(CLOSE<REF(CLOSE,1),VOL,0),N);
     * TQ:=SUM(IF(CLOSE=REF(CLOSE,1),VOL,0),N);
     * VR:100*(TH*2+TQ)/(TL*2+TQ);
     * MAVR:MA(VR,M);
	 */
	float TH;
	float TL;
	float TQ;
	final float VR(int index,int day){
		final float[] kYClose = mDataSetKLine.kYClose;
		final float[] kClose = mDataSetKLine.kClose;
		final float[] kCjss = mDataSetKLine.kCjss;
//		if(TH==null){
//			TH=new AFloat(0,2,0);
//			TL=new AFloat(0,2,0);
//			TQ=new AFloat(0,2,0);
//		}else{
			TH = 0;//.init(nullAFloat.float2int());
			TL = 0;//.init(nullAFloat.float2int());
			TQ = 0;//.init(nullAFloat.float2int());
//		}
		
		int count=0;
		for (int k = index; k >= 0; k--) {
			if(kClose[k] > kYClose[k]){
				TH += (kCjss[k]);
			}else if(kClose[k] < kYClose[k]){
				TL += (kCjss[k]);
			}else{
				TQ += (kCjss[k]);
			}
			count++;
			if (count == day || k == 0) {
				break;
			}
		}
		//VR:100*(TH*2+TQ)/(TL*2+TQ);
		
		TH *= (2);
		TH +=TQ;
		TH *= (100);
		
		TL *= (2);
		TL +=TQ;
		
		TH /= (TL);
		
		return TH;
	}

	/**
	 */
	float MA = 0;

	public float CalculateTechMA(float[] tData, int index, int day) {
		if (tData == null)
			return 0;
		int count = 0;
		MA = 0;//(0,2,0);
		for (int k = index; k >= 0; k--) {
			MA += (tData[k]);
			count++;
			if (count == day || k == 0) {
				MA /= (count);
				break;
			}
		}
//		return   float2int((int)(MA * 100),2,0);
		return MA;
	}

	/**
	 */
	float OBV = 0;

	public float CalculateOBV(int index) {

		final float[] kClose = mDataSetKLine.kClose;
		final float[] kCjss = mDataSetKLine.kCjss;
//		if (OBV == null) {
//			OBV = new AFloat();
//		}
		if (0 != index) {
			for (int k = 0; k <= index; k++) {
				if (0 == k) {
					OBV = kCjss[k];
				} else if (kClose[k] > kClose[k - 1]) {
					OBV += (kCjss[k]);
				} else if (kClose[k] < kClose[k - 1]) {
					OBV -= (kCjss[k]);
				}
			}
		} else {
			if (0 == index) {
				OBV = kCjss[index];//.init(kCjss[index].float2int());
			} else if (kClose[index] > kClose[index - 1]) {
				OBV += (kCjss[index]);
			} else if (kClose[index] < kClose[index - 1]) {
				OBV -=(kCjss[index]);
			}
		}
		return OBV;
	}

	float P1, P2;
	float YM, CR;

	public float CalculateCR(int index, int day) {
//		if (P1 == null) {
//			P1 = new AFloat();
//			P2 = new AFloat();
//			YM = new AFloat();
//			CR = new AFloat();
//		}
		final float[] kZdcj = mDataSetKLine.kZdcj;
		final float[] kZgcj = mDataSetKLine.kZgcj;
		final float[] kClose = mDataSetKLine.kClose;
		// final int[] kCjss=mDataSetKLine.kCjss;
		int count = 0;
		int nowIndex = 0;// 今日
		int lastIndex = 0;// 昨收
//		P1.init(0,3,0);
//		P2.init(0,3,0);
		for (int k = index; k >= 0; k--) {
			if (k > 0) {
				nowIndex = k;
				lastIndex = k - 1;
			}
			// M=（2C+H+L）÷4
			
			//(kClose[lastIndex].toFloat() * 2 + kZgcj[lastIndex].toFloat() + kZdcj[lastIndex].toFloat())/4
			
			float C = kClose[lastIndex];
			float H = kZgcj[lastIndex];
			float L = kZdcj[lastIndex];
			
			YM = ((C)*2) + (H + L);
			YM /= (4);
			
			
			// P1=∑（H－YM）
			temAFloat = kZgcj[nowIndex];
			temAFloat -= (YM);
			temAFloat = Math.max(0, temAFloat);
			P1 += (temAFloat);
			// P2=∑（YM－L）
			temAFloat = (kZdcj[nowIndex]);
			YM -= (temAFloat);
			YM = Math.max(0, YM);
			P2 += (YM);
			count++;
			if (count >= day)
				break;
		}
		if (P2 > 0) {
			// CR（N日）=P1÷P2×100
			CR = (P1);
			CR *= (100);
			CR /= (P2);
		}
		return CR;
	}
	/**---------------------------------------------------------------------------------------------
	* RSI:
	* LC:=REF(CLOSE,1);
	* RSI1:SMA(MAX(CLOSE-LC,0),N1,1)/SMA(ABS(CLOSE-LC),N1,1)*100;
	* RSI2:SMA(MAX(CLOSE-LC,0),N2,1)/SMA(ABS(CLOSE-LC),N2,1)*100;
	* RSI3:SMA(MAX(CLOSE-LC,0),N3,1)/SMA(ABS(CLOSE-LC),N3,1)*100;
	* LC赋值:昨收
	*///---------------------------------------------------------------------------------------------
	float nullAFloat= 0;//new AFloat(0,2,0);
	float maxMA= 0;//new AFloat(0,2,0);
	float absMA= 0;//new AFloat(0,2,0);
	int[] rsima=new int[2];
	final float[] RSIMA(int index,int day){		
		final float[] CLOSE=mDataSetKLine.kClose;
		final float[] YCLOSE=mDataSetKLine.kYClose;
		int count = 0;
		maxMA = 0;//(0,2,0);
		absMA = 0;//(0,2,0);
		for (int k = index; k >= 0; k--) {
			startFloat = (CLOSE[k] - YCLOSE[k]);
			endFloat = startFloat;//(float2int((int)(startFloat * 100),2,0));
			if(nullAFloat > startFloat)
			startFloat = (nullAFloat);			
			endFloat = Math.abs(endFloat);
			
			maxMA += (startFloat);
			absMA += (endFloat);
			count++;
			if (count == day || k == 0) {
				maxMA /= (count);
				absMA /= (count);
				break;
			}
		}
		//System.out.println("maxMA:"+maxMA.toFloat()+" absMA"+absMA.toFloat());
		float rsima[] = new float[2];
		rsima[0]= maxMA;//float2int((int)(maxMA * 100),2,0);
		rsima[1]= absMA;//float2int((int)(absMA * 100),2,0);//(int) absMA;		
		return rsima;
	}
	/**---------------------------------------------------------------------------------------------
	* DMI:
	* MTR:=EXPMEMA(MAX(MAX(HIGH-LOW,ABS(HIGH-REF(CLOSE,1))),ABS(REF(CLOSE,1)-LOW)),N);
	* HD :=HIGH-REF(HIGH,1);
	* LD :=REF(LOW,1)-LOW;
	* DMP:=EXPMEMA(IF(HD>0&&HD>LD,HD,0),N);
	* DMM:=EXPMEMA(IF(LD>0&&LD>HD,LD,0),N);
	* PDI: DMP*100/MTR;
	* MDI: DMM*100/MTR;
	* ADX: EXPMEMA(ABS(MDI-PDI)/(MDI+PDI)*100,MM);
	* ADXR:EXPMEMA(ADX,MM);
	* DMP赋值:如果HD>0并且HD>LD,返回HD,否则返回0的N日指数平滑移动平均
	* DMM赋值:如果LD>0并且LD>HD,返回LD,否则返回0的N日指数平滑移动平均
	* 输出PDI: DMP*100/MTR
	* 输出MDI: DMM*100/MTR
	* 输出ADX: MDI-PDI的绝对值/(MDI+PDI)*100的MM日指数平滑移动平均
	* 输出ADXR:ADX的MM日指数平滑移动平均
	*///---------------------------------------------------------------------------------------------
	final void DMI(int s,int e){
		final int day14=14;
		float startFloat = 0;
		float endFloat = 0;
		for(int i=s;i<=e;i++){			
			final int[] EMAs=EXPMEMA(i,day14);
	//		final int MTR=EMAs[0];
			final int PDI=EMAs[1];
			final int MDI=EMAs[2];
			//ABS(MDI-PDI)/(MDI+PDI)*100
			startFloat = (MDI);
			endFloat = (PDI);
			
			startFloat -= (endFloat);
			startFloat = Math.abs(startFloat) * (100);
			
			endFloat = (MDI);
			temAFloat = (PDI);
			endFloat += (temAFloat);			
			startFloat /= (endFloat);
			setTech(PDI, (MDI), startFloat, i);
			final int ADX=ADXADXR_MA(i,6);
			setTech(kTech[0][i], kTech[1][i], ADX, i);
			final int ADXR=ADXADXR_MA(i,6);
			setTech((ADXR), 0, i);
			
			if(startFloat==0 || endFloat==0){
				//m_maxTech = null;
				//m_minTech = null;
			}
		}
		
	}
	final int ADXADXR_MA(int index,int day){
		int count = 0;
		MA = 0;//(0, 2, 0);
		final float[] techData=kTech[2];
		for (int k = index; k >= 0; k--) {
			MA += (techData[k]);			
			count++;
			if (count == day || k == 0) {
				MA /= (count);
				break;
			}
		}	
		return (int) MA;
		
	}
	
	int[] EXPMEMAs=new int[3];
	float HD = 0;//new AFloat(0, 2, 0);
	 float LD = 0;//new AFloat(0, 2, 0);

	 float MTR = 0;//new AFloat(0, 2, 0);
	 float DMP = 0;//new AFloat(0, 2, 0);
	 float DMM = 0;//new AFloat(0, 2, 0);
	 int[] EXPMEMA(int index,int day){
		final float[] CLOSE=mDataSetKLine.kClose;
		final float[] YCLOSE=mDataSetKLine.kYClose;
		final float[] HIGH=mDataSetKLine.kZgcj;
		final float[] LOW=mDataSetKLine.kZdcj;
		
		float startFloat = 0;
		float endFloat = 0;
		
		HD = nullAFloat;//.init(nullAFloat.float2int());
		LD = nullAFloat;//(nullAFloat.float2int());
		MTR = nullAFloat;//(nullAFloat.float2int());
		DMP = nullAFloat;//(nullAFloat.float2int());
		DMM = nullAFloat;//(nullAFloat.float2int());
		int count = 0;
		for (int k = index; k >= 0; k--) {
			//MTR:=EXPMEMA(MAX(MAX(HIGH-LOW,ABS(HIGH-REF(CLOSE,1))),ABS(REF(CLOSE,1)-LOW)),N);
			startFloat = (HIGH[k]);
			startFloat -= (LOW[k]);
			endFloat = (HIGH[k]);
			endFloat -= (YCLOSE[k]);
			endFloat = Math.abs(endFloat);
//			startFloat.max(endFloat);
			startFloat = Math.max(startFloat, endFloat);
			
			endFloat = YCLOSE[k];
			endFloat -= (LOW[k]);
			startFloat = Math.max(startFloat, endFloat);
//			startFloat.max(endFloat);
			MTR += (startFloat);
			
			//end
			
			temAFloat = HIGH[k==0?k:k-1];
			HD = (HIGH[k] - temAFloat);
			temAFloat = LOW[k==0?k:k-1];
			LD = (temAFloat - LOW[k]);
			
			//DMP:=EXPMEMA(IF(HD>0&&HD>LD,HD,0),N);
			if(HD > nullAFloat&&HD > LD){
				//DMP.init(HD.float2int());
				DMP +=(HD);
			}else{
				//DMP.init(nullAFloat.float2int());
			}
			//DMM:=EXPMEMA(IF(LD>0&&LD>HD,LD,0),N);
			if(LD > nullAFloat && LD > HD){
				//DMM.init(LD.float2int());
				DMM += (LD);
			}else{
				//DMM.init(nullAFloat.float2int());
			}
			
			count++;
			if (count == day || k == 0) {
				MTR /= (count);
				DMP /= (count);
				DMM /= (count);
				break;
			}
		}
		//PDI: DMP*100/MTR;
		//MDI: DMM*100/MTR;
		DMP *= (100);
		DMP /= (MTR);
		DMM *= (100);
		DMM /= (MTR);
		EXPMEMAs[0]=(int) MTR;
		EXPMEMAs[1]=(int) DMP;//PDI
		EXPMEMAs[2]=(int) DMM;//MDI
		
		return EXPMEMAs;
	}
	/*
	 * BOLL:MA(CLOSE,N);
	 * UB:BOLL+2*STD(CLOSE,N);
	 * LB:BOLL-2*STD(CLOSE,N);
	 */
	final void BOLL(int s,int e){
		//this.techLineStyle = 1;
		float UB= 0;//new AFloat(0,2,0);
		float LB= 0;//new AFloat(0,2,0);
		float AMa = 0;
		float iMa = 0;
		for(int i=s;i<=e;i++){
			iMa=CalculateTechMA(mDataSetKLine.kClose, i, 20);
			UB = (iMa);
			LB = (iMa);
			AMa = UB;
			setTech(AMa, 0, 0, i);
			int std=STD(i,20);
//			float temAFloat = (std) *(2);
			AFloat temAFloat = new AFloat(0,3,0);
					temAFloat.init(std).mul(2);
			UB += (temAFloat.toFloat());
			LB -= (temAFloat.toFloat());
			
			setTech(AMa, UB, LB, i);
//			Log.e("setTech",mDataSetKLine.kClose[i] + "  " + AMa + "  " + AMa + "  " + LB + "   " + i);
		}		
	}
	AFloat MD;
	/**
	 * 标准差
	 */
	final int STD(int index,int day){
		if(MD==null){
			MD=new AFloat(0,3,0);
		}else{
			MD.init(0,3,0);
		}
		
		final float[] CLOSE=mDataSetKLine.kClose;
		final float[] techs=kTech[0];
		
		//计算标准差MD
		//MD=平方根N日的（CLOSE－MA）的两次方之和除以N
		
		MA = (techs[index]);
		int count = 0;
		for (int k = index; k >= 0; k--) {			
			temAFloat = (CLOSE[index] - MA);
			temAFloat *= (temAFloat);
			MD.add(temAFloat);
			count++;
			if(k==0||count==day){
				break;
			}
		}
		
		MD.div(count);
		
		double md= FloatMath.sqrt(MD.toFloat());
		MD.initF(md, MD.nDigit, MD.nDigit);
		return MD.float2int();
	}
	
	final void BRAR(int s,int e){
		techLineStyle = 2;
		for(int i=s;i<=e;i++){
			int br=BR(i,26);
			int ar=AR(i,26);
			if(i>6){
				setTech(br, ar, 0, i);
			}else{
				setTech(0, 0, 0, i);
			}
			
		}
		
		//System.out.println("m_minTech:"+m_minTech.toFloat()+"  m_maxTech:"+m_maxTech.toFloat());
	}
	/*
	 * BR:SUM(MAX(0,HIGH-REF(CLOSE,1)),N)/SUM(MAX(0,REF(CLOSE,1)-LOW),N)*100;
	 */
	float brarAdd1;
	float brarAdd2;
	final int BR(int index,int day){
//		if(brarAdd1==null){
//			brarAdd1=new AFloat(0,2,0);
//			brarAdd2=new AFloat(0,2,0);
//		}else{
			brarAdd1 = nullAFloat;//.init(nullAFloat.float2int());
			brarAdd2 = nullAFloat;//.init(nullAFloat.float2int());
//		}
		int count=0;
		final float[] HIGH=mDataSetKLine.kZgcj;
		final float[] LOW=mDataSetKLine.kZdcj;
		final float[] YCLOSE=mDataSetKLine.kYClose;
		for (int k = index; k >= 0; k--) {
			//SUM(MAX(0,HIGH-REF(CLOSE,1)),N)
			brarAdd1 += (Math.max((HIGH[k] - YCLOSE[k]),0));
			//SUM(MAX(0,REF(CLOSE,1)-LOW),N)
			brarAdd2 += (Math.max((YCLOSE[k] - LOW[k]),0));
			count++;
			if(k==0||count==day){
				break;
			}
		}
		brarAdd1 *= (100);
		brarAdd1 /= (brarAdd2);
		//System.out.println("BR:"+brarAdd1.toFloat());
		//System.out.println("BR--:"+temAFloat.init(brarAdd1.float2int()).toFloat());
		
		return (int) brarAdd1;
	}
	/*
	 * AR:SUM(HIGH-OPEN,N)/SUM(OPEN-LOW,N)*100;
	 */
	final int AR(int index,int day){
//		if(brarAdd1==null){
//			brarAdd1=new AFloat(0,2,0);
//			brarAdd2=new AFloat(0,2,0);
//		}else{
			brarAdd1 = nullAFloat;//.init(nullAFloat.float2int());
			brarAdd2 = nullAFloat;//.init(nullAFloat.float2int());
//		}
		final float[] HIGH=mDataSetKLine.kZgcj;
		final float[] LOW=mDataSetKLine.kZdcj;
		final float[] OPEN=mDataSetKLine.kOpen;
		int count=0;
		for (int k = index; k >= 0; k--) {
			//SUM(HIGH-OPEN,N)
			brarAdd1 += (HIGH[k] - OPEN[k]);
			//SUM(OPEN-LOW,N)
			brarAdd2 += (OPEN[k]-LOW[k]);
			count++;
			if(k==0||count==day){
				break;
			}
		}
		brarAdd1 *= (100);
		brarAdd1 /= (brarAdd2);
		//System.out.println("AR:"+brarAdd1.toFloat());
		return (int) brarAdd1;
	}

}
