package com.gf.viewmodel.quote.components;


import java.nio.ByteBuffer;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.quote.TickQuoteStream;
import com.gf.hippo.domain.client.quote.TickQuoteStreamItem;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.ReqBody;
import com.gf.viewmodel.ebiz.quote.ResBody;
import com.gf.viewmodel.ebiz.quote.TickData;
import com.gf.viewmodel.ebiz.quote.TickMsg;
import com.gf.viewmodel.ebiz.quote.TickRes;
import com.squareup.wire.Wire;

public class TickSerilizer implements Serializer {

	@Override
	public DomainObject unSerializeResBody(ResBody body) {
		TickRes msg = body.tickRes;
		if (msg == null)
			return null;
		TickQuoteStream stream = new TickQuoteStream();
		String market = body.market;
		Stock stock = new Stock();
		stock.setMarket(market);
		stock.setStock_code(body.code);
		stream.setSecurities(stock);
		for (int i = 0; i < msg.data.size(); ++i) {
			TickData data2 = msg.data.get(i);
			TickQuoteStreamItem item = new TickQuoteStreamItem();
			item.setPrice(data2.price);
			item.setSecurities(stock);
			item.setTick(data2.tick);
			item.setTime(data2.time);
			item.setVolume(data2.volume);
			stream.putItem(item);
		}
		return stream;
	}

	@Override
	public DomainObject unSerializeMsgBody(MsgBody body) {
		TickMsg msg = body.tick;
		if (msg == null)
			return null;
		TickQuoteStream stream = new TickQuoteStream();
		String market = body.market;
		Stock stock = new Stock();
		stock.setMarket(market);
		stock.setStock_code(body.code);

		stream.setSecurities(stock);
		TickData data2 = msg.data;
		TickQuoteStreamItem item = new TickQuoteStreamItem();
		item.setPrice(data2.price);
		item.setSecurities(stock);
		item.setTick(data2.tick);
		item.setTime(data2.time);
		item.setVolume(data2.volume);
		stream.putItem(item);
		return stream;
	}

	@Override
	public byte[] serialize(DomainObject object) {
		if (object instanceof TickQuoteStream) {
			TickQuoteStream quote = (TickQuoteStream) object;
			ReqBody.Builder builder = new ReqBody.Builder();
			builder.fid(HQFuncTypes.HQ_FB);
			Stock stock = (Stock) quote.getSecurities();
			builder.market(stock.getMarket());
			builder.code(stock.getStock_code());
			ReqBody body = builder.build();

			byte[] bytes = body.toByteArray();
			return bytes;
		} else {
			return null;
		}
	}

}
