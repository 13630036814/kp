/**
 * 
 */
package com.gf.view.widget;

import java.util.List;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListAdapter;

/**
 * 用于显示可以整体下拉式的布局
 * 
 * @author cola
 * 
 */
public abstract class StockTypeListView extends LinearLayout {

	public StockTypeListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	public StockTypeListView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public abstract ListAdapter getAdapter();

	public abstract void setAdapter(ListAdapter adapter);
	public abstract void setDivider(Drawable divider);

	public void removeView(View v) {
		this.removeView(v);
	}
}
