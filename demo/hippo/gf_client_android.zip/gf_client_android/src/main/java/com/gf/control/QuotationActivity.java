/**
 * 
 */
package com.gf.control;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.gf.client.R;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.quote.CandleQuoteStream;
import com.gf.hippo.domain.client.quote.CandleQuoteStreamItem;
import com.gf.hippo.domain.client.quote.PeriodType;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStream;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStreamItem;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.view.KlineView;
import com.gf.view.MailListView;
import com.gf.view.QuotationData;
import com.gf.view.QuotationFiveRange;
import com.gf.view.StockInfoTarget;
import com.gf.view.TimeSharingDetailView;
import com.gf.view.widget.BottomToolBar;
import com.gf.view.widget.TabIndicator;
import com.gf.view.widget.WorkSpace;
import com.gf.view.adapter.FiveRangeAdapter;
import com.gf.view.adapter.MailAdapter;
import com.gf.view.adapter.StockDetailInfoAdapter;
import com.gf.view.adapter.VolumeAdapter;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.DataSetKLine;
import com.gf.viewmodel.bean.MessageInfo;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;
import com.gf.viewmodel.bean.VolumeItem;
import com.gf.viewmodel.util.View_Util;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 个股详情
 * @author cola
 * 
 */
public class QuotationActivity extends DomainWindow implements OnClickListener {
	protected static final String TAG = "QuotationActivity";
	private StockInfoTarget mStockInfoTarget;
	private LinearLayout mTimeSharing_container,line_container;
	private TextView mFiveK,mTimeShare,mDayk,mWeekk,mMonk;
	/**
	 * 添加删除自选股按钮
	 */
	private TextView mQuotation_mystock;
	private QuotationFiveRange mTimeSharing_fiverange;
	private QuotationData mQuotationDataView;
	private TimeSharingDetailView mTimeSharingDetailView;
	private TabIndicator tabIndicator;
	private WorkSpace main_workspace;
	private BottomToolBar menu;
	private RelativeLayout mPopMenu;
	/**
	 * 五档里的变量
	 */
	private ListView listViewBuy;
	private ListView listViewSell;
	private List<VolumeItem> buyList;
	private FiveRangeAdapter buyAdapter;
	private List<VolumeItem> sellList;
	private FiveRangeAdapter sellAdapter;
	/**
	 * 成交量的两个变量
	 */
	private ListView listViewVolume;
	private List<VolumeItem> volumList;
	private VolumeAdapter volumeAdapter;
	/**
	 * 五档和成交量的容器
	 */
	private RelativeLayout container;
	public int orientation = 0;
	/**
	 * 成交量顶部的按钮
	 */
	private TextView fiverange;
	private TextView vVolume;
	private ImageView mStockIcon;
	private LinearLayout mStockIconClick;

	/**
	 * 第三页的变量
	 */
	private MailListView mListView;
	private StockDetailInfoAdapter mAdapter;

	/**
	 * 资讯相关变量
	 */
	private TextView quotation_target, quotation_info, quotation_F10;
	private String mStockCode = "",mStockMarket = "",mStockName="";
	private Stock stock;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.quotation_layout);
		init();

	}

	public void init() {
		mQuotation_mystock = (TextView) findViewById(R.id.quotation_mystock);
		mStockIcon = (ImageView) findViewById(R.id.quotation_mystock_icon);
		mStockIconClick = (LinearLayout) findViewById(R.id.quotation_mystock_click);
		setUserStockListener();
		if(this.getIntent().getExtras() != null){
			this.mStockCode = getIntent().getExtras().getString("stockCode");
			this.mStockMarket = getIntent().getExtras().getString("stockMarket");
			mStockName = getIntent().getExtras().getString("stockName");
			int len = mStockName.length();
			len += 1;
			Spannable WordtoSpan = new SpannableString((mStockName) + " " + mStockCode);  
			//设置股票代码的小字体部分
			WordtoSpan.setSpan(new AbsoluteSizeSpan(12), len, len + mStockCode.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
			((TextView) findViewById(R.id.title)).setText(WordtoSpan);

			stock = mStockManager.getStock(mStockMarket, mStockCode);
			Log.e("stock",stock.getMarket());
			mStockList.putItem(stock);
			this.setMyStockListener();
			setTimeSeriesQuote(mStockMarket,mStockCode,241);
			
			this.showDialog(true);
			
			if(isMyStock(mStockMarket, mStockCode)){
				mQuotation_mystock.setText("删除自选");
				mStockIcon.setBackgroundResource(R.drawable.del_btn);
//				mQuotation_mystock.setCompoundDrawablesWithIntrinsicBounds(null, this.getResources().getDrawable(R.drawable.del_btn), null, null);
			}else{
				mQuotation_mystock.setText("添加自选");
				mStockIcon.setBackgroundResource(R.drawable.add_btn);
//				mQuotation_mystock.setCompoundDrawablesWithIntrinsicBounds(null, this.getResources().getDrawable(R.drawable.add_btn), null, null);
			}
		}
		
		mDayk = (TextView) findViewById(R.id.dayk);
		this.mWeekk = (TextView) findViewById(R.id.weekk);
		this.mMonk = (TextView) findViewById(R.id.monk);
		
		mFiveK  = (TextView) findViewById(R.id.fivek);
		mTimeShare  = (TextView) findViewById(R.id.timeshare);
		mTimeSharing_fiverange = (QuotationFiveRange) findViewById(R.id.quotation_fiverange);
		mStockInfoTarget = (StockInfoTarget) findViewById(R.id.quotation_stocktarget);
		mTimeSharingDetailView = (TimeSharingDetailView) findViewById(R.id.TimeSharing);
		mTimeSharing_container = (LinearLayout) findViewById(R.id.qutation_quotationDataView);
		line_container = (LinearLayout) findViewById(R.id.line_container);
		mQuotationDataView = (QuotationData) findViewById(R.id.qutation_quotationDataView);
		menu = (BottomToolBar) findViewById(R.id.bottomToolBar);
		menu.getView();
		mPopMenu = (RelativeLayout) findViewById(R.id.home_ugc);
		menu.setPopMenur(mPopMenu);
		
		Global.hqCurrentPage = 0;

		quotation_target = (TextView) findViewById(R.id.quotation_target);
		quotation_target.setTextColor(getResources().getColor(
				R.color.plate_title));
		setListener();

	}

	public void setListener() {
		mFiveK.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				Toast.makeText(QuotationActivity.this, "暂未提供五日分词", Toast.LENGTH_LONG).show();
				line_container.getChildAt(1).setVisibility(View.GONE);
				line_container.getChildAt(0).setVisibility(View.VISIBLE);
				setTimeSeriesQuote(mStockMarket,mStockCode,241 * 5);
				mFiveK.setBackgroundResource(R.drawable.btn_bg);
				mTimeSharing_fiverange.setVisibility(View.GONE);
				setVisible(pressBtn);
				pressBtn = 2;
				
			}

		});
		
		mTimeShare.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				setTimeSeriesQuote(mStockMarket,mStockCode,241);
				setVisible(pressBtn);
				pressBtn = 1;
//				if(line_container.getChildCount() == 1){
//					return;
//				}
				line_container.getChildAt(1).setVisibility(View.GONE);
				line_container.getChildAt(0).setVisibility(View.VISIBLE);
				mTimeShare.setBackgroundResource(R.drawable.btn_bg);
				mTimeSharing_fiverange.setVisibility(View.VISIBLE);
			}

		});
		
		mDayk.setOnClickListener(this);
		this.mWeekk.setOnClickListener(this);
		this.mMonk.setOnClickListener(this);
		Button ib = ((Button) findViewById(R.id.top_back_btn));
//		ib.setImageResource(R.drawable.back);;
		
        ib.setBackgroundResource(R.drawable.btn_back_select);

		((LinearLayout) findViewById(R.id.top_back))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						finish();
					}

				});
		
		mStockIconClick.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(mQuotation_mystock.getText().toString().equals("添加自选") && addToMyStock(mStockMarket,mStockCode)){
					mQuotation_mystock.setText("删除自选");
					mStockIcon.setBackgroundResource(R.drawable.del_btn);
//					mQuotation_mystock.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(R.drawable.del_btn), null, null);
					Toast.makeText(QuotationActivity.this, "添加自选成功", Toast.LENGTH_LONG).show();
				}else if(delToMyStock(mStockMarket,mStockCode)){
					mQuotation_mystock.setText("添加自选");
					mStockIcon.setBackgroundResource(R.drawable.add_btn);
//					mQuotation_mystock.setCompoundDrawablesWithIntrinsicBounds(null, getResources().getDrawable(R.drawable.add_btn), null, null);
					Toast.makeText(QuotationActivity.this, "删除自选成功", Toast.LENGTH_LONG).show();
				}
			}
			
		});
		
		mTimeSharingDetailView.setOnClickListener(true);
		mTimeSharingDetailView.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent it = new Intent(QuotationActivity.this,
						QutationHorizontal.class);
				it.putExtra("stockCode", mStockCode);
				it.putExtra("stockMarket", mStockMarket);
				it.putExtra("stockName", mStockName);
				((Activity) QuotationActivity.this).startActivityForResult(it, 0);
			}
			
		});
	}

	private void positionInit() {

		int iBottomButton_H = 0;
		int iTaskHeight = 0;
		// 横竖屏计算
		if (orientation == 0)// 竖
		{
			if (Global.BottomMenu_H > 35) {
				iBottomButton_H = Global.BottomButton_H + Global.BottomMenu_H
						- 27;
			} else {
				iBottomButton_H = Global.BottomButton_H;
			}
			iTaskHeight = Global.mTaskHeight;
		} else {
			iBottomButton_H = 0;
			iTaskHeight = 0;
		}

		// tabIndicator.setPosition(Global.fullScreenHeight - iTaskHeight -
		// iBottomButton_H - 12);
		tabIndicator.setPosition(Global.fullScreenHeight - 104);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		int key = keyCode;
		switch (key) {
		case KeyEvent.KEYCODE_BACK:
			break;
		case KeyEvent.KEYCODE_SEARCH:
			break;
		case KeyEvent.KEYCODE_MENU:
			break;
		}
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * 记录前一次按钮
	 */
	private int pressBtn = 1;
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (mDayk.equals(v)) {
			
			line_container.getChildAt(0).setVisibility(View.GONE);
			line_container.getChildAt(1).setVisibility(View.VISIBLE);
			setCandlesTickQuoteListener(stock,PeriodType.KX_DAY);
			mDayk.setBackgroundResource(R.drawable.btn_bg);
//			mTimeShare.setBackgroundResource(0);
			setVisible(pressBtn);
			pressBtn = 3;
			this.showDialog(true);
		} else if (this.mWeekk.equals(v)) {
			
			line_container.getChildAt(0).setVisibility(View.GONE);
			line_container.getChildAt(1).setVisibility(View.VISIBLE);
			setCandlesTickQuoteListener(stock,PeriodType.KX_WEEK);
			this.mWeekk.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 4;
			this.showDialog(true);
		}else if (this.mMonk.equals(v)) {
			setCandlesTickQuoteListener(stock,PeriodType.KX_MONTH);
			line_container.getChildAt(0).setVisibility(View.GONE);
			line_container.getChildAt(1).setVisibility(View.VISIBLE);
			this.mMonk.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 5;
			this.showDialog(true);
		}
	}
	
	private void setVisible(int p){
		switch(p){
		case 1:
			mTimeShare.setBackgroundResource(0);
			break;
		case 2:
			mFiveK.setBackgroundResource(0);
			break;
		case 3:
			this.mDayk.setBackgroundResource(0);
			break;
		case 4:
			this.mWeekk.setBackgroundResource(0);
			break;
		case 5:
			this.mMonk.setBackgroundResource(0);
			break;
		}
	}

	public void snapToScreen() {
		if (tabIndicator != null) {
			tabIndicator.postInvalidate();
			tabIndicator.setKind(main_workspace.getCurScreen());
			Global.hqCurrentPage = main_workspace.getCurScreen();
		}
		addView();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		setResult(resultCode);
//		finish();
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);

	}

	private void addView() {
		if (main_workspace.getChildCount() >= 3)
			return;
		LayoutInflater.from(this).inflate(R.layout.stockvolume, main_workspace);
		fiverange = (TextView) findViewById(R.id.fiverange);
		vVolume = (TextView) findViewById(R.id.vvolume);
		container = (RelativeLayout) findViewById(R.id.volumeContainer);
		listViewBuy = (ListView) container.findViewById(R.id.listview_buy);
		listViewSell = (ListView) container.findViewById(R.id.listview_sell);
		listViewVolume = (ListView) findViewById(R.id.listview_volume);
		listViewVolume.setAdapter(volumeAdapter);
		sellAdapter = new FiveRangeAdapter(this, sellList);
		buyAdapter = new FiveRangeAdapter(this, buyList);

		listViewBuy.setAdapter(buyAdapter);
		listViewSell.setAdapter(sellAdapter);
		fiverange.setTextColor(getResources().getColor(R.color.plate_title));
		container.getChildAt(2).setVisibility(View.INVISIBLE);

		LayoutInflater.from(this).inflate(R.layout.stockabout, main_workspace);
		mListView = (MailListView) main_workspace
				.findViewById(R.id.stock_listview);
		mListView.setAdapter(mAdapter);
		mListView.setDivider(null);// getResources().getDrawable(R.drawable.line)
		main_workspace.invalidate();
		main_workspace.snapToScreen(1);

		vVolume.setOnClickListener(this);
		fiverange.setOnClickListener(this);
	}

	@Override
	public void onEvent(Event event) {
		// TODO Auto-generated method stub
		Log.v(TAG,"onEvent");
		if (event.getObject() instanceof RealtimeQuoteItem) {
			// 某只股票行情有更新
			quote = (RealtimeQuoteItem) event.getObject();
//			Log.e(TAG, "mHandlerRealtimeQuoteItem get time series quote item:"
//					+ quote.getTime());
			mQuotationDataView.setData(quote);
			mStockInfoTarget.setData(quote);
			mTimeSharing_fiverange.setData(quote);
		} else if (event.getObject() instanceof Stock) {
			// 某只股票属性有更新
			Stock stock = (Stock) event.getObject();

//			Log.e(TAG,
//					"mHandlerStock stock.getStock_name(): "
//							+ stock.getStock_name());
		} else if (event.getObject() instanceof StockList) {
			// 自选股票列表有更新
			// 结束旧自选股的监听
			endWatchEveryStock();
//			StockList newStockList = (StockList) event.getObject();
//			
		}else if (event.getObject() instanceof TimeSeriesQuoteStream) {//分词数据

			TimeSeriesQuoteStream quote = (TimeSeriesQuoteStream) event.getObject();
			TimeSeriesQuoteStreamItem[] items = null;
			if(pressBtn == 2)
			// 更新UI数据
				items = quote.getAllItems();
			else if(pressBtn == 1)
				items = quote.getItemsOfLastDate();
			else
				return;
//			Log.e("mHandlerStockList", "mHandlerStockList mystocks.getAllItems().length: "
//					+ items.length);
			mTimeSharingDetailView.setDataSet(reconsitution(items,mStockMarket,mStockCode));
			
		}else if (event.getObject() instanceof CandleQuoteStream) {//k 线
			CandleQuoteStream quote = (CandleQuoteStream) event.getObject();
			// 更新UI数据
			CandleQuoteStreamItem[] items = quote.getAllItems();
			KlineView kv = (KlineView)line_container.getChildAt(1);
			Log.e("k线长度 ", items.length + "");
			kv.setDataSet(reconsitution(items,mStockMarket,mStockCode));
		}
		this.dismissDialog();
	}

	@Override
	public void netStatus(boolean status) {
		// TODO Auto-generated method stub
		
	}
}
