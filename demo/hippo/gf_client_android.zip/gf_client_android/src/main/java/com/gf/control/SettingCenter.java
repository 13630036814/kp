package com.gf.control;

import com.gf.client.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ToggleButton;


public class SettingCenter extends Activity {
	protected static final String TAG = "SettingCenter";
	private ImageButton mBtnBack;
	private LinearLayout mLinMaSetting; // ma均线参数
	private LinearLayout mLinLoginTimeout; // 登录超时
	
	private ToggleButton mSwitchDesktopWidget; // 桌面小插件开关
	private ToggleButton mSwitchMessagePush; // 消息推送开关
	private ToggleButton mSwitchShakeSound; // 震动声音开关 
	
	// 保存设置相关的信息
	public static final String SETTING_PREF = "setting_pref"; // 文件名
	public static final String MA1 = "ma1"; // ma1均线参数
	public static final String MA2 = "ma2"; // ma2均线参数
	public static final String MA3 = "ma3"; // ma3均线参数
	public static final String SET_DESKTOP_WIDGET = "set_desktop_widget"; // 桌面小插件
	public static final String SET_MESSAGE_PUSH = "set_message_push"; // 消息推送
	public static final String SET_SHAKE_SOUND = "set_shake_sound"; // 震动和声音
	public static final String LOGIN_TIMEOUT = "login_timeout"; // 超时
	
	public static final String INIT_FLAG = "init_flag";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.setting_center);
		init();
		findView();
		initView();
		initViewData();
	}
	
	private void init() {
		TelephonyManager phoneMgr=(TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
		Log.v(TAG, "tel num: " + phoneMgr.getLine1Number());
	}
	
	private void findView() {
		mBtnBack = (ImageButton)findViewById(R.id.btn_back);
		mLinMaSetting = (LinearLayout)findViewById(R.id.lin_ma_setting);
		mLinLoginTimeout = (LinearLayout)findViewById(R.id.lin_login_timeout);
		mSwitchDesktopWidget = (ToggleButton)findViewById(R.id.switch_desktop_widget);
		mSwitchMessagePush = (ToggleButton)findViewById(R.id.switch_message_push);
		mSwitchShakeSound = (ToggleButton)findViewById(R.id.switch_shake_sound);
	}
	
	private void initView() {
		OnClickListener onClickListener = new OnClickListener() {

			@Override
			public void onClick(View v) {
				if(v.equals(mBtnBack)) {
					SettingCenter.this.finish();
					
				} else if (v.equals(mLinMaSetting)) {
					Intent intent = new Intent(SettingCenter.this, MaSetting.class);
					startActivity(intent);
				} else if (v.equals(mLinLoginTimeout)) {
					Intent intent = new Intent(SettingCenter.this, LoginTimeOutSetting.class);
					startActivity(intent);
				}
			}
			
		};
		mBtnBack.setOnClickListener(onClickListener);
		mLinMaSetting.setOnClickListener(onClickListener);
		mLinLoginTimeout.setOnClickListener(onClickListener);
		
		OnCheckedChangeListener onCheckedChangeListener = new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,	boolean isChecked) {
				if (buttonView.equals(mSwitchDesktopWidget)) {
					Log.v(TAG, "switch mSwitchDesktopWidget " + isChecked);
					saveDataBoolean(SET_DESKTOP_WIDGET, isChecked);
				} else if (buttonView.equals(mSwitchMessagePush)) {
					Log.v(TAG, "switch mSwitchMessagePush " + isChecked);
					saveDataBoolean(SET_MESSAGE_PUSH, isChecked);
				} else if (buttonView.equals(mSwitchShakeSound)) {
					Log.v(TAG, "switch mSwitchShakeSound " + isChecked);
					saveDataBoolean(SET_SHAKE_SOUND, isChecked);
				}
			}
			
		};
		
		mSwitchDesktopWidget.setOnCheckedChangeListener(onCheckedChangeListener);
		mSwitchMessagePush.setOnCheckedChangeListener(onCheckedChangeListener);
		mSwitchShakeSound.setOnCheckedChangeListener(onCheckedChangeListener);
		
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		initViewData();
	}

	private void initViewData() {
		mSwitchDesktopWidget.setChecked(getDataBoolean(SET_DESKTOP_WIDGET));
		mSwitchMessagePush.setChecked(getDataBoolean(SET_MESSAGE_PUSH));
		mSwitchShakeSound.setChecked(getDataBoolean(SET_SHAKE_SOUND));
		Log.v(TAG, "initViewData");
	}
	
	/**
	 * 向设置文件中写入字符串值
	 * @param key
	 * @param value
	 */
	private void saveDataString(String key, String value) {
		SharedPreferences sharePref = getSharedPreferences(SETTING_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putString(key, value);
		editor.commit();
	}
	
	/**
	 * 向设置文件中写入Int值
	 * @param key
	 * @param value
	 */
	private void saveDataInt(String key, int value) {
		SharedPreferences sharePref = getSharedPreferences(SETTING_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putInt(key, value);
		editor.commit();
	}
	
	/**
	 * 向设置文件中写入Boolean值
	 * @param key
	 * @param value
	 */
	private void saveDataBoolean(String key, boolean value) {
		SharedPreferences sharePref = getSharedPreferences(SETTING_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putBoolean(key, value);
		editor.commit();
	}
	
	
	/**
	 * 从设置文件中读取String值
	 * @param key
	 * @return
	 */
	private String getDataString(String key) {
		SharedPreferences sharePref = getSharedPreferences(SETTING_PREF, Context.MODE_PRIVATE);
		String value = sharePref.getString(key, null);
		return value;
	}
	
	/**
	 * 从设置文件中读取Int值
	 * @param key
	 * @return
	 */
	private int getDataInt(String key) {
		SharedPreferences sharePref = getSharedPreferences(SETTING_PREF, Context.MODE_PRIVATE);
		int value = sharePref.getInt(key, 0);
		return value;
	}
	
	/**
	 * 从设置文件中读取Boolean值
	 * @param key
	 * @return
	 */
	private boolean getDataBoolean(String key) {
		SharedPreferences sharePref = getSharedPreferences(SETTING_PREF, Context.MODE_PRIVATE);
		boolean value = sharePref.getBoolean(key, false);
		return value;
	}
}
