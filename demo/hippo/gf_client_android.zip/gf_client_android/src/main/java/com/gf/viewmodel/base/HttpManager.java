package com.gf.viewmodel.base;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;

import android.util.Log;


/**
 * @author jin
 *
 */
public class HttpManager {
	protected static final String TAG = "HttpManager";
	public static final String VISIT_NETWORK_ERROR = "visit_network_error";
	public static final String SUCCESS = "success";
	private static HttpManager mInstance = null;
	
	// 使用用户名和密码获取token
	public static final String AUTH_USERNAME_PSD_URL = "https://test.gf.com.cn/server/app/login/mobile?client_id=gfmstock&redirect_uri=/gf/gfmstock/callback&response_type=token";
	// 使用toker登陆
	public static final String LOGIN_URL =  "https://test.gf.com.cn/server/app/user/userinfo/get";
	public static final String VERIFY_PHONE_NUM_URL = "https://test.gf.com.cn/server/app/reg/mobile/ckmobileexist";
	// 注册手机号
	public static final String REGIST_PHONE_NUM_URL = "https://test.gf.com.cn/server/app/reg/mobile/dbb";
	public static final String REGIST_URL = "https://test.gf.com.cn/server/app/reg/mobile/general";
	public static final String GET_AUTH_CODE_RRL = "https://test.gf.com.cn/server/app/reg/mobile/ticket";
	// 检测版本更新
	public static final String CHECK_NEW_VERSION = "http://10.2.124.205:8815/containerApp/checkVersion";
	
	public static final int NET_WORK_TIME_OUT = 5000;

	private HttpManager() {
	}
	
	public static synchronized HttpManager getInstance() {
		if (mInstance == null) {
			mInstance = new HttpManager();
		}
		return mInstance;
	}
	
	public void visitNetWorkGet(final String url, final String getValue, final NetWorkCallBack callback) {
		new Thread() {
			public void run() {
				try {
					Log.v(TAG, "url: " + url);
					Log.v(TAG, "GetValue: " + getValue);
					
					HttpManager.trustAllHosts();
					StringBuilder builder = new StringBuilder();
					String getUrl = url + "?" + getValue;
					URL authUrl = new URL(getUrl);
					HttpsURLConnection httpUrlConn = (HttpsURLConnection) authUrl.openConnection();
					httpUrlConn.setRequestMethod("GET");
					httpUrlConn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
					
					InputStream inputStream = httpUrlConn.getInputStream();
					BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
					for (String s = reader.readLine(); s != null; s = reader.readLine()) {
						builder.append(s);
					}

					Log.v(TAG, builder.toString());
					callback.end(builder.toString());

				} catch (Exception e) {
					callback.end(VISIT_NETWORK_ERROR);
					Log.v(TAG, "visitNetWorkGet error");
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	public void visitNetWorkGetHttp(final String url, final String getValue, final NetWorkCallBack callback) {
		new Thread() {
			public void run() {
				try {
					Log.v(TAG, "url: " + url);
					Log.v(TAG, "GetValue: " + getValue);
					
					HttpManager.trustAllHosts();
					StringBuilder builder = new StringBuilder();
					String getUrl = url + "?" + getValue;
					URL authUrl = new URL(getUrl);
					HttpURLConnection httpUrlConn = (HttpURLConnection) authUrl.openConnection();
					httpUrlConn.setRequestMethod("GET");
					httpUrlConn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
					
					InputStream inputStream = httpUrlConn.getInputStream();
					BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
					for (String s = reader.readLine(); s != null; s = reader.readLine()) {
						builder.append(s);
					}

					Log.v(TAG, builder.toString());
					callback.end(builder.toString());

				} catch (Exception e) {
					callback.end(VISIT_NETWORK_ERROR);
					Log.v(TAG, "visitNetWorkGet error");
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	public void visitNetWorkPost(final String urlStr, final String postValue, final NetWorkCallBack callback) {
		new Thread() {
			public void run() {
				try {
					Log.v(TAG, "url: " + urlStr);
					Log.v(TAG, "postValue: " + postValue);
					
					HttpManager.trustAllHosts();
					StringBuilder builder = new StringBuilder();
					
					URL url = new URL(urlStr);
					HttpsURLConnection httpUrlConn = (HttpsURLConnection) url.openConnection();
					httpUrlConn.setRequestMethod("POST");
					httpUrlConn.setDoOutput(true);
					httpUrlConn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
					OutputStream outputStream = httpUrlConn.getOutputStream();
					outputStream.write(postValue.getBytes());
					outputStream.flush();
					
					InputStream inputStream = httpUrlConn.getInputStream();
					BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
					for (String s = reader.readLine(); s != null; s = reader.readLine()) {
						builder.append(s);
					}

					Log.v(TAG, builder.toString());
					callback.end(builder.toString());

				} catch (Exception e) {
					callback.end("visit_network_error");
					Log.v(TAG, "visitNetWork error");
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	public void visitNetWorkPostHttp(final String urlStr, final String postValue, final NetWorkCallBack callback) {
		new Thread() {
			public void run() {
				try {
					Log.v(TAG, "url: " + urlStr);
					Log.v(TAG, "postValue: " + postValue);
					
					HttpManager.trustAllHosts();
					StringBuilder builder = new StringBuilder();
					
					URL url = new URL(urlStr);
					HttpURLConnection httpUrlConn = (HttpURLConnection) url.openConnection();
					httpUrlConn.setRequestMethod("POST");
					httpUrlConn.setDoOutput(true);
					//httpUrlConn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
					httpUrlConn.setRequestProperty("Content-Type","application/json");
					OutputStream outputStream = httpUrlConn.getOutputStream();
					outputStream.write(postValue.getBytes());
					outputStream.flush();
					
					InputStream inputStream = httpUrlConn.getInputStream();
					BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
					for (String s = reader.readLine(); s != null; s = reader.readLine()) {
						builder.append(s);
					}

					Log.v(TAG, builder.toString());
					callback.end(builder.toString());

				} catch (Exception e) {
					callback.end("visit_network_error");
					Log.v(TAG, "visitNetWork error");
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	/*
	 */
	public interface NetWorkCallBack {
		public void end(String result);
	}
	
	/**
	 * Trust every server - dont check for any certificate
	 */
	public static void trustAllHosts() {
		final String TAG = "trustAllHosts";
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {

			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new java.security.cert.X509Certificate[] {};
			}

			public void checkClientTrusted(X509Certificate[] chain,
					String authType) throws CertificateException {
				Log.i(TAG, "checkClientTrusted");
			}

			public void checkServerTrusted(X509Certificate[] chain,
					String authType) throws CertificateException {
				Log.i(TAG, "checkServerTrusted");
			}

			@Override
			public void checkClientTrusted(
					java.security.cert.X509Certificate[] arg0, String arg1)
					throws java.security.cert.CertificateException {

			}

			@Override
			public void checkServerTrusted(
					java.security.cert.X509Certificate[] arg0, String arg1)
					throws java.security.cert.CertificateException {
			}
		} };

		// Install the all-trusting trust manager
		try {
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection
					.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*private void login2(final String username, final String password) {
		new Thread() {
			public void run() {
				String value = "user_id=15989318191&password=123456";

				try {
					HttpPost request = new HttpPost(mAuthUrlStr);
					// 先封装一个 JSON 对象
					JSONObject param = new JSONObject();
					param.put("name", "rarnu");
					param.put("password", "123456");

					// 绑定到请求 Entry
					// StringEntity se = new StringEntity(param.toString());
					StringEntity se = new StringEntity(value);
					request.setEntity(se);
					// 发送请求
					HttpResponse httpResponse = new DefaultHttpClient().execute(request);
					String retSrc = EntityUtils.toString(httpResponse.getEntity());
					// 生成 JSON 对象
					JSONObject result = new JSONObject(retSrc);
					String errorFlag = (String) result.get("error_no");
					String access_token = null;
					if (errorFlag != null) {
						Log.v(TAG, "login error");
					} else {
						access_token = (String) result.get("access_token");
						Log.v(TAG, access_token);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	private void GetJsonObject() {  
		new Thread() {
			public void run() {
				HttpClient client = new DefaultHttpClient();  
		        StringBuilder builder = new StringBuilder();  
		        HttpGet get = new HttpGet(mAuthUrlStr);
		        try {  
		            HttpResponse response = client.execute(get);  
		            BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));  
		            for (String s = reader.readLine(); s != null; s = reader.readLine()) {  
		                builder.append(s);  
		            }  
		        } catch (Exception e) {  
		            e.printStackTrace();  
		        }  
		        Log.v(TAG, builder.toString()); 
			}
			
		}.start();
    } 
	
	public static String httpGet(String httpUrl) {
		BufferedReader input = null;
		StringBuilder sb = null;
		URL url = null;
		HttpURLConnection con = null;
		try {
			url = new URL(httpUrl);
			try {
				// trust all hosts
				HttpManager.trustAllHosts();
				HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
				if (url.getProtocol().toLowerCase().equals("https")) {
					https.setHostnameVerifier(DO_NOT_VERIFY);
					con = https;
				} else {
					con = (HttpURLConnection) url.openConnection();
				}
				input = new BufferedReader(new InputStreamReader(con.getInputStream()));
				sb = new StringBuilder();
				String s;
				while ((s = input.readLine()) != null) {
					sb.append(s).append("\n");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		} finally {
			// close buffered
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			// disconnecting releases the resources held by a connection so they
			// may be closed or reused
			if (con != null) {
				con.disconnect();
			}
		}
		return sb == null ? null : sb.toString();
	}*/

	final static HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {

		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	};

}
