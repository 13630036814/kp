package com.gf.viewmodel.ebiz.trade;

/**
 * 股票持仓信息
 *
 */
public class StockAccountInfo {

	/** 证券代码 */
	private String stockCode;
	/** 证券名称 */
	private String stockName;
	/** 证券余额 */
	private String stockBalance;
	/** 可用余额 */
	private String maxMoney;
	/** 成本价 */
	private String basePrice;
	
	public StockAccountInfo() {}
	
	public StockAccountInfo(String stockCode, String stockName, String stockBalance, String maxMoney, String basePrice) {
		this.stockCode = stockCode;
		this.stockName = stockName;
		this.stockBalance = stockBalance;
		this.maxMoney = maxMoney;
		this.basePrice = basePrice;
	}

	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}

	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	
	public String getStockBalance() {
		return stockBalance;
	}
	public void setStockBalance(String stockBalance) {
		this.stockBalance = stockBalance;
	}
	
	public String getMaxMoney() {
		return maxMoney;
	}
	public void setMaxMoney(String maxMoney) {
		this.maxMoney = maxMoney;
	}
	
	public String getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(String basePrice) {
		this.basePrice = basePrice;
	}

}
