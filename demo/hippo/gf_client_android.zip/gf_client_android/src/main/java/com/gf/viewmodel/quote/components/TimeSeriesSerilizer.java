package com.gf.viewmodel.quote.components;

import com.gf.viewmodel.ebiz.quote.TimeSeriesReq;

import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.ReqBody;
import com.gf.viewmodel.ebiz.quote.ResBody;
import com.gf.viewmodel.ebiz.quote.TimeSeriesData;
import com.gf.viewmodel.ebiz.quote.TimeSeriesMsg;
import com.gf.viewmodel.ebiz.quote.TimeSeriesRes;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStream;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStreamItem;
import com.gf.hippo.domain.client.securities.Stock;

public class TimeSeriesSerilizer implements Serializer {

	@Override
	public DomainObject unSerializeResBody(ResBody body) {
		TimeSeriesRes msg = body.timeseriesRes;
		if (msg == null)
			return null;
		TimeSeriesQuoteStream stream = new TimeSeriesQuoteStream();
		String market = body.market;
		Stock stock = new Stock();
		stock.setMarket(market);
		stock.setStock_code(body.code);
		stream.setSecurities(stock);
		for (int i = 0; i < msg.data.size(); ++i) {
			TimeSeriesData data2 = msg.data.get(i);
			TimeSeriesQuoteStreamItem item = new TimeSeriesQuoteStreamItem();
			item.setAmount(data2.amount);
			item.setAvg(data2.avg);
			item.setChange(data2.change);
			item.setPclose(data2.pclose);
			item.setPrice(data2.price);
			item.setTime(data2.time);
			item.setRise(data2.rise);
			item.setVolume(data2.volume);
			item.setSecurities(stock);
			stream.putItem(item);
		}
		return stream;
	}

	@Override
	public DomainObject unSerializeMsgBody(MsgBody body) {
		TimeSeriesMsg msg = body.timeseries;
		if (msg == null)
			return null;
		TimeSeriesQuoteStream stream = new TimeSeriesQuoteStream();
		String market = body.market;
		Stock stock = new Stock();
		stock.setMarket(market);
		stock.setStock_code(body.code);

		stream.setSecurities(stock);
		TimeSeriesData data2 = msg.data;
		TimeSeriesQuoteStreamItem item = new TimeSeriesQuoteStreamItem();
		item.setAmount(data2.amount);
		item.setAvg(data2.avg);
		item.setChange(data2.change);
		item.setPclose(data2.pclose);
		item.setPrice(data2.price);
		item.setRise(data2.rise);
		item.setTime(data2.time);
		item.setVolume(data2.volume);
		item.setSecurities(stock);
		stream.putItem(item);
		return stream;
	}

	@Override
	public byte[] serialize(DomainObject object) {
		if (object instanceof TimeSeriesQuoteStream) {
			TimeSeriesQuoteStream quote = (TimeSeriesQuoteStream) object;
			
			ReqBody.Builder builder = new ReqBody.Builder();			
			builder.fid(HQFuncTypes.HQ_FS);
			
			TimeSeriesReq.Builder timeSericeReq=new TimeSeriesReq.Builder();
			timeSericeReq.count(quote.getCount()).time(quote.getTime());
			builder.timeseriesReq=timeSericeReq.build();
			
			Stock stock = (Stock) quote.getSecurities();
			builder.market(stock.getMarket());
			builder.code(stock.getStock_code());
			ReqBody body = builder.build();

			byte[] bytes = body.toByteArray();
			return bytes;
		}
		return null;
	}

}
