package com.gf.viewmodel.ebiz.trade;

/**
 * 通用四项信息
 * 
 */
public class FourItemInfo {

	public String one;
	public String two;
	public String three;
	public String four;

	public FourItemInfo() {}
	public FourItemInfo(String one, String two, String three, String four) {
		this.one = one;
		this.two = two;
		this.three = three;
		this.four = four;
	}
}
