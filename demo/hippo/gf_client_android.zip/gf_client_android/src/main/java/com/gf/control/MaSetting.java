package com.gf.control;

import com.gf.client.R;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class MaSetting extends Activity implements SeekBar.OnSeekBarChangeListener {
	private TextView mTextViewMa1;
	private TextView mTextViewMa2;
	private TextView mTextViewMa3;
	private SeekBar mSeekBarMa1;
	private SeekBar mSeekBarMa2;
	private SeekBar mSeekBarMa3;
	private ImageButton mBtnBack;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.ma_setting);
		findView();
		initView();
		initViewData();
	}

	private void findView() {
		mTextViewMa1 = (TextView) findViewById(R.id.txtView_ma1);
		mTextViewMa2 = (TextView) findViewById(R.id.txtView_ma2);
		mTextViewMa3 = (TextView) findViewById(R.id.txtView_ma3);
		mSeekBarMa1 = (SeekBar) findViewById(R.id.seekbar_ma1);
		mSeekBarMa2 = (SeekBar) findViewById(R.id.seekbar_ma2);
		mSeekBarMa3 = (SeekBar) findViewById(R.id.seekbar_ma3);
		mBtnBack = (ImageButton) findViewById(R.id.btn_back);

	}
	
	private void initView() {
		mSeekBarMa1.setOnSeekBarChangeListener(this);
		mSeekBarMa2.setOnSeekBarChangeListener(this);
		mSeekBarMa3.setOnSeekBarChangeListener(this);
		
		mBtnBack.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				MaSetting.this.finish();
			}
		});
	}
	
	private void initViewData() {
		mSeekBarMa1.setProgress(getDataInt(SettingCenter.MA1));
		mSeekBarMa2.setProgress(getDataInt(SettingCenter.MA2));
		mSeekBarMa3.setProgress(getDataInt(SettingCenter.MA3));
		
		mTextViewMa1.setText(""  + getDataInt(SettingCenter.MA1));
		mTextViewMa2.setText(""  + getDataInt(SettingCenter.MA2));
		mTextViewMa3.setText(""  + getDataInt(SettingCenter.MA3));
	}

	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromTouch) {
		if (seekBar.equals(mSeekBarMa1)) {
			mTextViewMa1.setText("" + progress);
		} else if (seekBar.equals(mSeekBarMa2)) {
			mTextViewMa2.setText("" + progress);
		} else if (seekBar.equals(mSeekBarMa3)) {
			mTextViewMa3.setText("" + progress);
		}
        
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
        //mTrackingText.setText(getString(R.string.seekbar_tracking_on));
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    	if (seekBar.equals(mSeekBarMa1)) {
    		saveDataInt(SettingCenter.MA1, mSeekBarMa1.getProgress());
		} else if (seekBar.equals(mSeekBarMa2)) {
			saveDataInt(SettingCenter.MA2, mSeekBarMa2.getProgress());
		} else if (seekBar.equals(mSeekBarMa3)) {
			saveDataInt(SettingCenter.MA3, mSeekBarMa3.getProgress());
		}
    }
    
    /**
	 * 从设置文件中读取Int值
	 * @param key
	 * @return
	 */
	private int getDataInt(String key) {
		SharedPreferences sharePref = getSharedPreferences(SettingCenter.SETTING_PREF, Context.MODE_PRIVATE);
		int value = sharePref.getInt(key, 0);
		return value;
	}
	
	/**
	 * 向设置文件中写入Int值
	 * @param key
	 * @param value
	 */
	private void saveDataInt(String key, int value) {
		SharedPreferences sharePref = getSharedPreferences(SettingCenter.SETTING_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putInt(key, value);
		editor.commit();
	}

}
