package com.gf.control.trade.query;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.view.adapter.trade.FourItemInfoAdapter;
import com.gf.viewmodel.ebiz.trade.FourItemInfo;

/**
 * 新股配号查询
 * 
 */
public class NewStockTradeListActivity extends Activity {

	private TextView tvTitle;
	private Button btnRight;
	private RelativeLayout layoutFilter;

	private TextView lbDate; // 配号日期
	private TextView lbStock; // 证券名称
	private TextView lbNumber; // 起始配号
	private TextView lbAmount; // 配号数量

	private ListView listView;
	private List<FourItemInfo> items = new ArrayList<FourItemInfo>();
	private FourItemInfoAdapter adapter;

	private boolean isDisplayFilterLayout = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_stock_trade_list);

		initData();
		initViews();

		btnRight.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isDisplayFilterLayout = !isDisplayFilterLayout;
				if (isDisplayFilterLayout) {
					layoutFilter.setVisibility(View.VISIBLE);
					btnRight.setText("取消");
				} else {
					layoutFilter.setVisibility(View.GONE);
					btnRight.setText("筛选");
				}
			}
		});

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// MoneyDetailInfoAdapter adapter = (MoneyDetailInfoAdapter) listView.getAdapter();
				// adapter.toggle(position);
				startActivity(new Intent(NewStockTradeListActivity.this, NewStockTradeDetailActivity.class));
			}
		});
	}

	private void initData() {
		if (!items.isEmpty()) {
			items.clear();
		}
		for (int i = 0; i < 3; i++) {
			items.add(new FourItemInfo("20140131", "紫金矿业", "526301", "1800"));
			items.add(new FourItemInfo("20140208", "中国卫星", "526302", "300"));
			items.add(new FourItemInfo("20140215", "浦发银行", "526303", "1000"));
			items.add(new FourItemInfo("20140226", "武钢股份", "526304", "600"));
			items.add(new FourItemInfo("20140305", "茅台酒业", "526305", "800"));
			items.add(new FourItemInfo("20140323", "茅台酒业", "526306", "200"));
			items.add(new FourItemInfo("20140409", "民生银行", "526307", "2600"));
		}
	}

	private void initViews() {
		tvTitle = (TextView) findViewById(R.id.tv_title);
		tvTitle.setText("配号查询");
		btnRight = (Button) findViewById(R.id.btn_right);
		btnRight.setText("筛选");

		layoutFilter = (RelativeLayout) findViewById(R.id.layout_filter);
		layoutFilter.setVisibility(View.GONE);

		lbDate = (TextView) findViewById(R.id.lb_one);
		lbStock = (TextView) findViewById(R.id.lb_two);
		lbNumber = (TextView) findViewById(R.id.lb_three);
		lbAmount = (TextView) findViewById(R.id.lb_four);
		lbDate.setText("成交时间");
		lbStock.setText("证券名称");
		lbNumber.setText("成交价格");
		lbAmount.setText("成交数量");

		listView = (ListView) findViewById(R.id.listView_four);
		adapter = new FourItemInfoAdapter(this, items);
		listView.setAdapter(adapter);
	}
}
