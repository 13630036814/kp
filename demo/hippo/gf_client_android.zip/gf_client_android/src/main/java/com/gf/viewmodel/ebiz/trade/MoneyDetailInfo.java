package com.gf.viewmodel.ebiz.trade;

/**
 * 资金流水信息
 *
 */
public class MoneyDetailInfo {
	/** 日期 */
	private String date;
	/** 货币类型 */
	private String currency;
	/** 市值 */
	private String total;
	/** 股份余额 */
	private String balance;
	/** 可用股份 */
	private String max;
	
	public MoneyDetailInfo() {}
	
	public MoneyDetailInfo(String date, String currency, String total, String balance, String max) {
		this.date = date;
		this.currency = currency;
		this.total = total;
		this.balance = balance;
		this.max = max;
	}

	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}

}
