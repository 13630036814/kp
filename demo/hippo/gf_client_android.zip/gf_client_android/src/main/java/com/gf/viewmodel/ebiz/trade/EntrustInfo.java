package com.gf.viewmodel.ebiz.trade;

/**
 * 委托信息
 *
 */
public class EntrustInfo {

	/** 买卖标志 */
	private int mode; // 0:买入  1:卖出
	/** 委托时间 */
	private String date;
	/** 股票代码 */
	private String stockCode;
	/** 股票名称 */
	private String stockName;
	/** 价格 */
	private String price;
	/** 数量 */
	private String amount;
	/** 委托状态 */
	private int state;
	
	public EntrustInfo() {}
	
	public EntrustInfo(int mode, String date, String stockCode, String stockName, String price, String amount) {
		this.mode = mode;
		this.date = date;
		this.stockCode = stockCode;
		this.stockName = stockName;
		this.price = price;
		this.amount = amount;
	}

	public int getMode() {
		return mode;
	}
	public void setMode(int mode) {
		this.mode = mode;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	
}
