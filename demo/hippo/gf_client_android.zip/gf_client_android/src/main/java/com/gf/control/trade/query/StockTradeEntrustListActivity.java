package com.gf.control.trade.query;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.view.adapter.trade.EntrustInfoAdapter;
import com.gf.viewmodel.ebiz.trade.EntrustInfo;

public class StockTradeEntrustListActivity extends Activity {

	private ListView listView;
	private List<EntrustInfo> items = new ArrayList<EntrustInfo>();
	private EntrustInfoAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.stock_trade_entrust_list);

		initData();

		((TextView) findViewById(R.id.tv_title)).setText("委托撤单");
		((Button) findViewById(R.id.btn_right)).setText("全部撤单");

		listView = (ListView) findViewById(R.id.listView);
		adapter = new EntrustInfoAdapter(this, items);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
			}
		});
	}

	private void initData() {
		if (!items.isEmpty()) {
			items.clear();
		}

		for (int i = 0; i < 3; i++) {
			items.add(new EntrustInfo(0, "2014-03-30 13:35", "广发证券", "000760", "7.62", "6300"));
			items.add(new EntrustInfo(1, "2014-03-31 09:18", "浦发银行", "600000", "11.18", "300"));
			items.add(new EntrustInfo(0, "2014-04-02 11:23", "武铁股份", "600005", "5.85", "11300"));
			items.add(new EntrustInfo(1, "2014-04-03 10:57", "平安银行", "000001", "15.71", "300"));
			items.add(new EntrustInfo(0, "2014-04-08 13:49", "四环药业", "000763", "5.39", "19000"));
		}
	}

}
