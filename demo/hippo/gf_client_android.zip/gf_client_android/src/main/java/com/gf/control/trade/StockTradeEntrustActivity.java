package com.gf.control.trade;

import java.text.DecimalFormat;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.control.BaseApplication;
import com.gf.control.BaseWindow;
import com.gf.dataProcess.trade.TradeProcessor;
import com.gf.hippo.domain.client.common.Event;
import com.gf.model.trade.KmgscxInfo;
import com.gf.model.trade.SjWtqrInfo;
import com.gf.model.trade.TrdEntrustModeId;
import com.gf.model.trade.WtqrInfo;
import com.gf.model.user.TradeInfo;
import com.gf.trade.TradeManager;
import com.gf.trade.network.NetworkEvent;
import com.gf.trade.network.NetworkEventHandler;
import com.gf.trade.network.TradeResponse;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;
import com.gf.viewmodel.util.IDialogEvent;
import com.gf.viewmodel.util.KFloat;
import com.gf.viewmodel.util.StringUtils;
import com.gf.viewmodel.util.UiTools;

public class StockTradeEntrustActivity extends BaseWindow {

	/**
	 * 五档行情控件(每条)
	 */
	private final int[] click5Names = { R.id.buy1, R.id.sale1, R.id.buy2, R.id.sale2,
			R.id.buy3, R.id.sale3, R.id.buy4, R.id.sale4, R.id.buy5,R.id.sale5 };
	/**
	 * 价格
	 */
	private final int[] pricesIDs = { R.id.buy_price1, R.id.sale_price1,
			R.id.buy_price2, R.id.sale_price2, R.id.buy_price3, R.id.sale_price3,
			R.id.buy_price4,R.id.sale_price4, R.id.buy_price5, R.id.sale_price5 };
	/**
	 * 买卖量
	 */
	private final int[] amountIDs = { R.id.buy_value1,R.id.sale_value1,
			R.id.buy_value2, R.id.sale_value2, R.id.buy_value3, R.id.sale_value3,
			R.id.buy_value4, R.id.sale_value4, R.id.buy_value5, R.id.sale_value5 };
	/**
	 * 五档价格
	 */
	private final String[] price5 = { "", "", "", "", "", "", "", "", "", "" };

	private TextView tvTitle; // 买入委托 or 卖出委托
	private Button btnChange; // 买卖切换
	
	private EditText txtStockCode; // 股票代码
	private ImageView ivDelete; // 删除
	private TextView tvStockName; // 股票名称
	private Button btnPosition; // 我的持仓

	private EditText txtPrice; // 股票价格
	private ImageButton ibtnAdd, ibtnSub; // 加减按钮
	private LinearLayout layoutWudang; // 五档行情控件

	private TextView tvMax; // 可买数量 or 可卖数量
	private EditText txtAmount; // 买入数量 or 卖出数量

	private RadioGroup rg_rates; // 选择数量：全部、1/2、1/3、1/4、rb_rate_temp: 处理点击事件作中间转换
	private RadioButton rb_rate_all, rb_rate_half, rb_rate_third, rb_rate_quarter, rb_rate_temp;

	private Button btnWudang; // 五档
	private Button submit; // 提交：买入 or 卖出
	
	private Spinner spinnerHolder; // 股东代码

	/** ----- 成员变量 ----- **/
	private Context mContext;
	private Integer wtType = 0; // 0: 限价委托; 1: 市价委托
	private Integer mode = 0; // 0: 买入; 1: 卖出; 
	private String bundleCode; // 股票代码
	private String bundleWtPrice; // 股票委托价格
	private Integer maxAmount = 0; // 可买(卖)数量
	private boolean isWudangExpanding = false; // 五档行情是否展开

	/** 是否新股票 */
	private boolean isNewStock;
	/** 是否用户输入价格 */
	private boolean isUserInputPrice;
	/** 单选按键事件 */
	private boolean isRadioGroupEvent = true;
	/** 数量输入框事件 */
	private boolean isTxtAmountEvent = true;

	private QuoteManagerFactory managerFactory;
	private TradeManager tradeManager;
	private TradeProcessor dataProcessor;
	private NetworkEventHandler networkHandler;
	/** 可买数量信息 */
	private KmgscxInfo kInfo;
	
	/**
	 * 退市整理股票风险警告
	 */ 
	private boolean delist_flag;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.stock_trade_entrust);
		mContext = this;
		
		initDataLoading(); // 初始化网络数据加载
		initIntentData(); // 接收前一个界面传递过来的初始数据
		initViews(); // 初始化界面控件
		initComponentEnvents(); // 初始化界面控件事件
		initViewData(); // 初始化界面控件显示数据
	}
	
	private void initDataLoading() {
		BaseApplication application = ((BaseApplication) this.getApplication());
		managerFactory = application.getQuoteManagerFactory();
		tradeManager = managerFactory.getTradeManager();
		
		if (dataProcessor == null) {
			dataProcessor = new TradeProcessor();
		}
		dataProcessor.setTradeManager(tradeManager);
		
		networkHandler = new NetworkEventHandler() {
			@Override
			public void onResponse(NetworkEvent event) {
				super.onResponse(event);
				System.out.println("response status:" + event.getStatus());
//				System.out.println("response data:" + event.getData().toString());
				if (event.getData() instanceof TradeResponse) {
					TradeResponse rsp = (TradeResponse) event.getData();
					if (rsp.packet.isError()) {
						System.out.println("--- error message ---");
						System.out.println(rsp.packet.getErrorMsg());
//						Toast.makeText(getApplicationContext(), "账号或密码错误", Toast.LENGTH_LONG).show();
					} else {
						System.out.println("--- login success ---");
						/*TradeInfo info = tradeProcessor.parse_JY_KHXY(rsp.packet.mBodyBuffer, txtAccount.getText().toString(), txtPassword.getText().toString());
						System.out.println("login = " + info.isLogined);
						startActivity(new Intent(TradeLoginActivity.this, TradeMainActivity.class));*/
						if (rsp.packet.subFuncNo == TradeProcessor.JY_KMGSCX) {
							kInfo = dataProcessor.kmgscx(rsp);
							if (kInfo.getDelist_flag().equals("1") && mode == 0) {
								delist_flag = true;
//								mm.showYesNoDialog("退市整理股票风险警告", kInfo.getError_info(), "继续交易", "重新输入", K.EVENT_DLG_OK, K.EVENT_DLG_CANCEL);
								Bundle b = new Bundle();
								b.putShort("mSFuncNo", TradeProcessor.JY_KMGSCX);
//								onHandleEvent(K.EVENT_DLG_OK, b);
							} else {
								delist_flag = false;
								setViewData(String.valueOf(kInfo.getwMarketID()), kInfo.getwType(),
									kInfo.getPszCode(), kInfo.getPszName(), kInfo.getnZrsp(),
									kInfo.getnJrkp(), kInfo.getnZgcj(), kInfo.getnZdcj(),
									kInfo.getnBjg1(), kInfo.getnBss1(), kInfo.getnBjg2(),
									kInfo.getnBss2(), kInfo.getnBjg3(), kInfo.getnBss3(),
									kInfo.getnBjg4(), kInfo.getnBss4(), kInfo.getnBjg5(),
									kInfo.getnBss5(), kInfo.getnSjg1(), kInfo.getnSss1(),
									kInfo.getnSjg2(), kInfo.getnSss2(), kInfo.getnSjg3(),
									kInfo.getnSss3(), kInfo.getnSjg4(), kInfo.getnSss4(),
									kInfo.getnSjg5(), kInfo.getnSss5(), kInfo.getsKMSL(),
									kInfo.getsZJKYS(), kInfo.getsGFKYS(), kInfo.getWtdw());	

								tvStockName.setText(kInfo.getPszName());
								if (mode % 2 == 0) {
									tvMax.setText(kInfo.getsKMSL());
								} else {
									tvMax.setText(kInfo.getsGFKYS());
								}
							}		
						} else if (rsp.packet.subFuncNo == TradeProcessor.JY_WTQR) {
							WtqrInfo wtqr = dataProcessor.get_JY_WTQR(rsp);
							String message = wtqr.getsXX();
//							setSubmitedMsg(wtqr.getsXX());
							UiTools.showToast(mContext, message);
							System.out.println(message);
							reset();
						} else if (rsp.packet.subFuncNo == TradeProcessor.JY_SJ_WTQR) {
							SjWtqrInfo sjWtqr = dataProcessor.get_JY_SJ_WTQR(rsp);
							String message = sjWtqr.getsXX();
//							setSubmitedMsg(wtqr.getsXX());
							UiTools.showToast(mContext, message);
							System.out.println(message);
							reset();
						}
					}
				}
			}
		};
	}
	
	private void initIntentData() {
		mode = getIntent().getIntExtra("mode", 0);
		bundleCode = getIntent().getStringExtra("code");
		bundleWtPrice = getIntent().getStringExtra("wtPrice");
	}

	private void initViews() {
		tvTitle = (TextView) findViewById(R.id.tv_title);
		btnChange = (Button) findViewById(R.id.btn_right);
		btnChange.setBackgroundResource(R.drawable.change);
		
		txtStockCode = (EditText) findViewById(R.id.txt_code);
		ivDelete = (ImageView) findViewById(R.id.iv_delete);
		tvStockName = (TextView) findViewById(R.id.tv_name);
		btnPosition = (Button) findViewById(R.id.btn_position);
		
		txtPrice = (EditText) findViewById(R.id.txt_price);
		ibtnSub = (ImageButton) findViewById(R.id.ibtn_sub);
		ibtnAdd = (ImageButton) findViewById(R.id.ibtn_add);

		layoutWudang = (LinearLayout) findViewById(R.id.layout_wudang);
		tvMax = (TextView) findViewById(R.id.tv_max);
		txtAmount = (EditText) findViewById(R.id.txt_amount);
		btnWudang = (Button) findViewById(R.id.btn_wudang);

		rg_rates = (RadioGroup) findViewById(R.id.rg_trade_rates);
		rb_rate_all = (RadioButton) findViewById(R.id.rb_trade_rate_all);
		rb_rate_half = (RadioButton) findViewById(R.id.rb_trade_rate_half);
		rb_rate_third = (RadioButton) findViewById(R.id.rb_trade_rate_third);
		rb_rate_quarter = (RadioButton) findViewById(R.id.rb_trade_rate_quarter);
		rb_rate_temp = (RadioButton) findViewById(R.id.rb_trade_rate_temp);

		ArrayAdapter<String> adapter = 
				new ArrayAdapter<String>(this, R.layout.simple_spinner_item, TradeInfo.getLoginInfo().stockholderNames);
		adapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item);
		spinnerHolder = (Spinner) findViewById(R.id.spinner_holder);
		spinnerHolder.setAdapter(adapter);

		submit = (Button) findViewById(R.id.btn_submit);

		for (int index = 0; index < click5Names.length; index++) {
			findViewById(click5Names[index]).setOnClickListener(new Click5Listener(index));
		} 
	}

	/**
	 * 初始化控件事件
	 */
	private void initComponentEnvents() {
		btnChange.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (mode == 0) {
					mode = 1;
					if (isWudangExpanding) {
						btnWudang.setBackgroundResource(R.drawable.wudang_btn_sale_sel);
					}
				} else {
					mode = 0;
					if (isWudangExpanding) {
						btnWudang.setBackgroundResource(R.drawable.wudang_btn_buy_sel);
					}
				}

				setConponentValueByMode();
			}
		});

		// 股票代码
		txtStockCode.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				String inputCode = txtStockCode.getText().toString().trim();
//				if (!StringUtils.isEmpty(inputCode) && Utils.isNum(inputCode) && inputCode.length() == 6) {
				
				tvStockName.setVisibility(View.GONE);
				btnPosition.setVisibility(View.VISIBLE);
				
				txtPrice.setText("0.00");
				tvMax.setText("0");
				txtAmount.setText("0");
				
				if (inputCode != null && !"".equals(inputCode)) {
					if (inputCode.length() == 6) {
						isNewStock = true;
						
						query5Data();
						/** --- temporary data start --- **/
//						txtPrice.setText("3.85");
//						tvMax.setText("8000");
//						txtAmount.setText("3000");
						/**  --- temporary data end --- **/
						
						tvStockName.setVisibility(View.VISIBLE);
						btnPosition.setVisibility(View.GONE);
					}
					ivDelete.setVisibility(View.VISIBLE);
				} else {
					ivDelete.setVisibility(View.GONE);
				}
			}
		});
		
		// 删除股票代码
		ivDelete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				txtStockCode.setText("");
				ivDelete.setVisibility(View.GONE);
				tvStockName.setVisibility(View.GONE);
				btnPosition.setVisibility(View.VISIBLE);
				
				txtPrice.setText("0.00");
				tvMax.setText("0");
				txtAmount.setText("0");
			}
		});

		// 初始化价格加减按钮
		ibtnAdd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isUserInputPrice = true;
				String priceStr = txtPrice.getText().toString().trim();
				int decimalLen;
				String formatStr = "#.00000";
				double value, decimal = 1;
				if (priceStr.length() == 0) {
					txtPrice.setText("1");
				} else if (priceStr.indexOf('.') == -1) {
					value = Double.valueOf(priceStr);
					value += decimal;
					txtPrice.setText(String.valueOf(value));
				} else {
					decimalLen = priceStr.length() - priceStr.indexOf('.') - 1;
					for (int i = 0; i < decimalLen; i++) {
						decimal = decimal / 10;
					}
					value = Double.valueOf(priceStr);
					value += decimal;
					formatStr = formatStr.substring(0, formatStr.indexOf('.') + 1 + decimalLen);
					DecimalFormat format = new DecimalFormat(formatStr);
					txtPrice.setText(format.format(value));
				}
			}
		});

		// 初始化价格加减按钮
		ibtnSub.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isUserInputPrice = true;
				String priceStr = txtPrice.getText().toString().trim();
				int decimalLen;
				double value, decimal = 1;
				String formatStr = "#.00000";
				if (priceStr.length() == 0) {
					UiTools.showToast(mContext, "请输入价格");
				} else if (priceStr.indexOf('.') == -1) {
					value = Double.valueOf(priceStr);
					value -= decimal;
					txtPrice.setText(String.valueOf(value));
				} else {
					value = Double.valueOf(priceStr);
					decimalLen = priceStr.length() - priceStr.indexOf('.') - 1;
					for (int i = 0; i < decimalLen; i++) {
						decimal = decimal / 10;
					}
					value -= decimal;
					formatStr = formatStr.substring(0, formatStr.indexOf('.') + 1 + decimalLen);
					DecimalFormat format = new DecimalFormat(formatStr);
					txtPrice.setText(format.format(value));
				}
			}
		});
		
		// 买入数量 or 卖出数量
		txtAmount.addTextChangedListener(new TextWatcher() {
			@Override
			public void afterTextChanged(Editable s) {
				if (isTxtAmountEvent) {
					isRadioGroupEvent = false;
					rb_rate_temp.setChecked(true);
					isRadioGroupEvent = true;
				}
				
				if (txtAmount.getText() != null && !"".equals(txtAmount.getText().toString().trim())) {
					if (Double.valueOf(txtAmount.getText().toString()) > Double.valueOf(tvMax.getText().toString())) {
						String msg = "";
						if (mode == 0) {
							msg = "买入数量不能大于可买数量";
						} else {
							msg = "卖出数量不能大于可卖数量";
						}
						System.out.println(msg);
						UiTools.showToast(mContext, msg);
						return;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
		});

		// 全部、1/2、1/3、1/4
		rg_rates.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				int amt = maxAmount;
				if (isRadioGroupEvent) {
					if (checkedId == rb_rate_quarter.getId()) {
						amt = maxAmount / 4;
					} else if (checkedId == rb_rate_third.getId()) {
						amt = maxAmount / 3;
					} else if (checkedId == rb_rate_half.getId()) {
						amt = maxAmount / 2;
					} else {
					}

					if (mode % 2 == 0) {// 买入：取数量100为单位
						amt = amt / 100 * 100;
					}

					isTxtAmountEvent = false;
					if (rb_rate_all.isChecked() || rb_rate_half.isChecked() || rb_rate_third.isChecked() || rb_rate_quarter.isChecked()) {
						txtAmount.setText(amt + "");
					}
					isTxtAmountEvent = true;
				}
			}
		});

		// 显示五档 or 隐藏五档
		btnWudang.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isWudangExpanding) {
					layoutWudang.setVisibility(View.GONE);
					btnWudang.setText("显示五档");
					btnWudang.setBackgroundResource(R.drawable.wudang_btn_nor);
					isWudangExpanding = false;
				} else {
					layoutWudang.setVisibility(View.VISIBLE);
					btnWudang.setText("隐藏五档");
					if (mode % 2 == 0) {
						btnWudang.setBackgroundResource(R.drawable.wudang_btn_buy_sel);
					} else {
						btnWudang.setBackgroundResource(R.drawable.wudang_btn_sale_sel);
					}
					isWudangExpanding = true;
				}
			}
		});
		
		submit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String stockCode = txtStockCode.getText().toString();
				if (stockCode == null && "".equals(stockCode)) {
					UiTools.showToast(mContext, "请输入股票代码！");
					return;
				}
				if (stockCode.length() < 6) {
					UiTools.showToast(mContext, "请输入正确的股票代码！");
					return;
				}
				
				//20110509修改，判断如果是市价委托则不需要输入价格
				String wtPrice = txtPrice.getText().toString();
				if (wtType == 0) {
					if (StringUtils.isEmpty(wtPrice)) {
						UiTools.showToast(mContext, "请输入委托价格！");
						return;
					} else {
						if (wtPrice.indexOf(" ") != -1) {
							UiTools.showToast(mContext, "委托价格中不能有空格！");
							return;
						}
						
						if (wtPrice.indexOf(".") == -1) {
							wtPrice = wtPrice + ".000";
						}
						if (wtPrice.substring(wtPrice.length() - 1, wtPrice.length()).equalsIgnoreCase(".") || wtPrice.substring(0, 1).equalsIgnoreCase(".")) {
							UiTools.showToast(mContext, "委托价格输入格式错误！");
							return;
						}
						
						String mSPrice = wtPrice.substring((wtPrice.indexOf(".")) + 1, wtPrice.length());
						if (!StringUtils.isEmpty(mSPrice)) {
							int len = mSPrice.length();
							if (len == 1) {
								wtPrice = wtPrice + "00";
							} else if (len == 2) {
								wtPrice = wtPrice + "0";
							}
						} else {
							wtPrice = wtPrice + "000";
						}
					}
				}
				
				String submitNum = txtAmount.getText().toString();
				if ("".equals(submitNum)) {
					UiTools.showToast(mContext, "请输入买卖股数！");
					return;
				}
				
				int holderIndex = spinnerHolder.getSelectedItemPosition();
				String holderCode = TradeInfo.getLoginInfo().stockholderCodes[holderIndex];
				String marketID = TradeInfo.getLoginInfo().stockExchangeCodes[holderIndex];
				/*
				final Bundle b = new Bundle();					
				b.putInt("mode_id", modeID);
				b.putString("wt_type", wtType);
				b.putString("wt_type_name", wtTypeName);
				b.putString("stockholder", holderCode);
				b.putString("stockCode", stockCode);
				b.putString("stockName", stockName);
				b.putString("marketID", marketID);
				b.putString("wtPrice", wtPrice);
				b.putString("amount", submitNum);
				b.putBoolean("delist_flag",delist_flag);
				*/
				String[] reqBody; 
				if (delist_flag) {
					UiTools.ShowMessageBoxYesNo(mContext, "退市整理股票风险警告", kInfo.getError_info(), "继续交易", "重新输入", new IDialogEvent (){
						@Override
						public void onYes() {
//							changeTo(KTrdEntrustSubmitHandler.class, b);
//							finish();
						}
						@Override
						public void onNo() {
//							onHandleEvent(K.EVENT_DLG_CANCEL,null);
						}
						@Override
						public void onCancel() {	
						}
						@Override
						public void onOk() {
						}});
				} else {
//					changeTo(KTrdEntrustSubmitHandler.class, b);
//					finish();
					reqBody = new String[] { marketID, holderCode, TradeInfo.getLoginInfo().tradePassword, TrdEntrustModeId.getMMLB(mode), stockCode, submitNum, wtPrice, null,
//							Sys.tradeMark, TradeInfo.getLoginInfo().deptID, TradeInfo.getLoginInfo().tradeAccount, mode == TrdEntrustModeId.BUY ? "0" : "1" };
							"13800138000, huawei D2, 4.7.6 20140312 66065", TradeInfo.getLoginInfo().deptID, TradeInfo.getLoginInfo().tradeAccount, mode == TrdEntrustModeId.BUY ? "0" : "1" };
					dataProcessor.sendReq_JY_WTQR(reqBody, TradeProcessor.JY_WTQR, networkHandler);
				}
			}
		});
	}
	
	private void initViewData() {
		setConponentValueByMode(); // 买入/卖出 设置标签名

		txtStockCode.setText(bundleCode);
		txtPrice.setText(bundleWtPrice);
		
		tvMax.setText(maxAmount + "");
		txtAmount.setText("0");
		if (txtStockCode.getText() != null && txtStockCode.getText().toString().trim().length() == 6) {
			tvStockName.setVisibility(View.VISIBLE);
			btnPosition.setVisibility(View.GONE);
//			query5Data();
		} else {
			tvStockName.setVisibility(View.GONE);
			btnPosition.setVisibility(View.VISIBLE);
		}
	}

	/**
	 * 依据买卖方向设置控件的标签名
	 */
	private void setConponentValueByMode() {
		if (mode % 2 == 0) {
			tvTitle.setText("买入委托");
			tvTitle.setTextColor(0xFFe96c41);
			((TextView) findViewById(R.id.lb_max)).setText("可买数量");
			tvMax.setTextColor(0xFFe96c41);
			((TextView) findViewById(R.id.lb_amount)).setText("买入数量");
			submit.setText("买入");
			submit.setBackgroundColor(0xFFcb5d38);
		} else {
			tvTitle.setText("卖出委托");
			tvTitle.setTextColor(0xFF3a7be9);
			((TextView) findViewById(R.id.lb_max)).setText("可卖数量");
			tvMax.setTextColor(0xFF3a7be9);
			((TextView) findViewById(R.id.lb_amount)).setText("卖出数量");
			submit.setText("卖出");
			submit.setBackgroundColor(0xFF295cb5);
		}
	}

	private void query5Data() {
		String code = txtStockCode.getText().toString().trim();
		if (!StringUtils.isEmpty(code) && code.length() == 6) {
			query5Data(code);			
		}
	}

	private void query5Data(String stockCode) {
		if (TradeInfo.getLoginInfo().stockExchangeCodes == null) {
			return;
		}
		String exCode = getExchangerCode(stockCode);
		for (int i = 0; exCode != null && i < TradeInfo.getLoginInfo().stockExchangeCodes.length; i++) {
			if (exCode.equals(TradeInfo.getLoginInfo().stockExchangeCodes[i])) {
				spinnerHolder.setSelection(i);
				break;
			}
		}
		int holderIndex = spinnerHolder.getSelectedItemPosition();
//		int bsType = spinnerBSType.getSelectedItemPosition();
		String holderCode = TradeInfo.getLoginInfo().stockholderCodes[holderIndex];
		String marketID = TradeInfo.getLoginInfo().stockExchangeCodes[holderIndex];
//		setTitle(bsTitles[modeID] + "-" + stockCode);	
		String[] reqBody;
		String price = null;
		if (!StringUtils.isEmpty(txtPrice.getText().toString())) {
			price = txtPrice.getText().toString();
		}
		reqBody = new String[] { mode % 2 == 0 ? "B" : "S", marketID, holderCode, 
				TradeInfo.getLoginInfo().tradeAccount, TradeInfo.getLoginInfo().tradePassword,
				stockCode, price, TradeInfo.getLoginInfo().deptID, TradeInfo.getLoginInfo().tradeAccount };
		dataProcessor.sendReq_JY_KMGSCX(reqBody, TradeProcessor.JY_KMGSCX, networkHandler); 
	}

	/**
	 * 获取交易所代码 0-深A 1-沪A 2-深B 3-沪B 4-三板 A-上海期货 B-大连期货 C-郑州商品 G-中金期货
	 */
	public String getExchangerCode(String stkCode) {
		String exchangerCode = null;
		int code = StringUtils.stringToInt(stkCode);
		if ((code >= 1 && code <= 9999) || (code >= 70000 && code <= 129999)
				|| (code >= 131800 && code <= 131999)
				|| (code >= 150000 && code <= 189999)
				|| (code >= 300000 && code <= 309999)
				|| (code >= 360000 && code <= 389999)
				|| (code >= 30000 && code <= 32999)
				|| (code >= 38000 && code <= 39999)) {
			// 深A
			exchangerCode = "0";
		} else if ((code >= 200000 && code <= 200999)
				|| (code >= 205000 && code <= 209999)
				|| (code >= 270000 && code <= 289999)
				|| (code >= 360000 && code <= 369999)) {
			// 深B
			exchangerCode = "2";
		} else if ((code >= 900000 && code <= 900999)
				|| (code >= 938000 && code <= 938999) || (code == 939988)) {
			// 沪b
			exchangerCode = "3";
		} else if (code >= 400000 && code <= 499999) {
			// 三板
			exchangerCode = "4";
		} else { 
			// 沪A
			exchangerCode = "1";
		}
		return exchangerCode;
	}

	private void setViewData(String wMarketID, short wType, String pszCode,
			String pszName, int nZrsp, int nJrkp, int nZgcj, int nZdcj,
			int nBjg1, int nBss1, int nBjg2, int nBss2, int nBjg3, int nBss3,
			int nBjg4, int nBss4, int nBjg5, int nBss5, int nSjg1, int nSss1,
			int nSjg2, int nSss2, int nSjg3, int nSss3, int nSjg4, int nSss4,
			int nSjg5, int nSss5, String sKMSL, String sZJKYS, String sGFKYS,
			String wtdw) {
		setMarketID(StringUtils.stringToInt(wMarketID));
		KFloat zs = new KFloat(nZrsp);
		String[] amounts = new String[price5.length];
		int[] colors = new int[price5.length];
		init5Data(price5, amounts, colors, 0, nBjg1, nBss1, zs);
		init5Data(price5, amounts, colors, 1, nSjg1, nSss1, zs);
		init5Data(price5, amounts, colors, 2, nBjg2, nBss2, zs);
		init5Data(price5, amounts, colors, 3, nSjg2, nSss2, zs);
		init5Data(price5, amounts, colors, 4, nBjg3, nBss3, zs);
		init5Data(price5, amounts, colors, 5, nSjg3, nSss3, zs);
		init5Data(price5, amounts, colors, 6, nBjg4, nBss4, zs);
		init5Data(price5, amounts, colors, 7, nSjg4, nSss4, zs);
		init5Data(price5, amounts, colors, 8, nBjg5, nBss5, zs);
		init5Data(price5, amounts, colors, 9, nSjg5, nSss5, zs);

		setPricesData(price5, colors, amounts);
		TextView tvInitPrice = (TextView) findViewById(R.id.init_price); 
		tvInitPrice.setText(new KFloat(nJrkp).toString());
		// 判断是否市价委托，如果是：不设置委托价格,如果已经填写委托价格则不设置
		/*
		 * 在买入、卖出涨跌停股票的时候，按下同方法处理： 买入委托的时候：默认价格取卖一的价格；
		 * 但股票涨停时，卖一项没有显示价格，就取买一的价格； 卖出委托的时候，默认价格取买一的价格
		 * 但股票跌停的时候，买一项没有显示价格，就取卖一的价格。如果股票停牌，取昨收的价格
		 */
		String wtPrice;
		if (mode % 2 == 0) {
			wtPrice = detailWTPrice(price5[1], price5[0], zs.toString());
		} else {
			wtPrice = detailWTPrice(price5[0], price5[1], zs.toString());
		}
		if (StringUtils.isEmpty(txtPrice.getText().toString())) {
			isUserInputPrice = false;
			txtPrice.setText(wtPrice);
		} else if (!isUserInputPrice && isNewStock) {
			isNewStock = false;
			txtPrice.setText(wtPrice);
		}

		if (mode % 2 == 0) {// 买入：取可买数量
			setAmountAvailable(sKMSL);
		} else {// 卖出：取股份可用数
			setAmountAvailable(sGFKYS);
		}

//		if (StringUtils.isEmpty(wtdw) || StringUtils.isEmpty(wtdw.trim())) {
//			wtdw = "股";
//		}
//		setUnit("[" + wtdw + "]");
//		setTitle(bsTitles[modeID] + "-" + pszName);
	}

	private void init5Data(String[] prices, String[] amounts, int[] colors, int index, int price, int count, KFloat zs) {
		int[] col = { 0XFF0A5800, 0XFFFFFFFF, 0XFFFF0000 };
		KFloat kfloat = new KFloat(price);
		prices[index] = kfloat.toString();
		colors[index] = col[KFloat.compare(kfloat, zs) + 1];
		kfloat.init(count);
		amounts[index] = kfloat.toString();
	}

	/**
	 * 设置价格
	 */
	private void setPricesData(String[] prices, int[] colors, String[] amounts) {
		TextView tv;
		for (int index = 0; index < pricesIDs.length; index++) {
			tv = (TextView) findViewById(pricesIDs[index]);
			tv.setText(prices[index]);
			tv.setTextColor(colors[index]);
			tv = (TextView) findViewById(amountIDs[index]);
			tv.setText(amounts[index]);
		}
	}

	/**
	 * 默认返回value1<br>
	 * 如果value1.equals("---"),返回value2<br>
	 * 如果value2.equals("---"),返回value3<br>
	 * 这三个值中其中一个一定要有值
	 * 
	 * @param value1
	 * @param value2
	 * @param value3
	 */
	private String detailWTPrice(String value1, String value2, String value3) {
		if (value1.equals("---")) {
			if (value2.equals("---")) {
				return value3;
			} else {
				return value2;
			}
		} else {
			return value1;
		}
	}

	/** 设置可买卖数量 */
	private void setAmountAvailable(String num) {
		tvMax.setText(num);
		maxAmount = Integer.valueOf(num);
		tvMax.invalidate();
		int amt = maxAmount;
		if (rb_rate_quarter.isChecked()) {
			amt = maxAmount / 4;
		} else if (rb_rate_third.isChecked()) {
			amt = maxAmount / 3;
		} else if (rb_rate_half.isChecked()) {
			amt = maxAmount / 2;
		} else {
		}

		if (mode % 2 == 0) {// 买入：取数量100为单位
			amt = amt/100*100;
		}
		
		if (rb_rate_all.isChecked() || rb_rate_half.isChecked() || rb_rate_third.isChecked() || rb_rate_quarter.isChecked()) {
			txtAmount.setText(amt + "");
		}
	}

	/**
	 * 设置市场
	 */
	private void setMarketID(int marketid) {
		int selectindex = spinnerHolder.getSelectedItemPosition();
		for (int i = 0; i < TradeInfo.getLoginInfo().stockExchangeCodes.length; i++) {
//			if (Utils.isNum(TradeInfo.getLoginInfo().stockExchangeCodes[i])) { }
			if (StringUtils.stringToInt(TradeInfo.getLoginInfo().stockExchangeCodes[i]) == marketid && selectindex != i) {
				spinnerHolder.setSelection(i);
			}
		}
//		int maket = marketid < 4 ? marketid % 2 : 2;
//		initWtType(maket);
	}
	
	private void reset() {
		txtStockCode.setText("");
		txtPrice.setText("");
		tvMax.setText("");
		txtAmount.setText("");
		
		rb_rate_temp.setSelected(true);
	}

	@Override
	public void onEvent(Event event) {
	}

	@Override
	public void init() {
	}

	@Override
	public void setListener() {
	}

	private class Click5Listener implements OnClickListener {
		private int index;

		Click5Listener(int index) {
			this.index = index;
		}

		@Override
		public void onClick(View v) {
			isUserInputPrice = true;
			txtPrice.setText(price5[index]);
		}
	}

	@Override
	public void netStatus(boolean status) {
		// TODO Auto-generated method stub
		
	}
}
