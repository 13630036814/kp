package com.gf.view;

import java.math.BigDecimal;
//import com.gf.common.network.Business;
//import com.gf.model.quotations.DataSetTimeSharing;

















import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.Business;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;
import com.gf.viewmodel.util.AFloat;
import com.gf.viewmodel.util.DataSetTimeSharing;
import com.gf.viewmodel.util.DrawTool;

import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;

/**
 * 分时图
 * @author Think
 *
 */
public class TimeSharingDetailChart extends AChart implements OnGestureListener{
	private Paint chartPaint = Theme.factroyPaint();
	//private Paint txtPaint = Theme.factroyTextPaintSet();
	private Paint pricePaint = Theme.factroyPricePaintSet();	
	private Paint boxPaint = Theme.factroyTextPaintSet();
	private Rect topRect = new Rect();//top区
	private Rect avRect = new Rect();//ts区
	private Rect midRect = new Rect();//mid区
	private Rect volRect = new Rect();//vol区
	private Rect timeRect = new Rect();//time区
	//private Rect mActionRect = new Rect();
	private Rect mChartBox = new Rect();
	private Rect rect = new Rect();//坐标用
	public static final String times[] = { "09:30", "13:00", "15:00" };
	
	private CornerPathEffect pathEffect;
	private boolean mDoji = false;
	
	private GestureDetector mGestureDetector;
	//private ActionDraw[] mActDraws;
//	private ActionDraw mSelectedDraw;
	
	private TimeSharingDetailView mTarget;
	
	private DataSetTimeSharing mDataSet;
	private TimeSeriesQuoteCache mTimeSeriesQuoteCache;
	
	private Path[] mAVPath;
	private float[]  mVOLLines;
	private float[]  mLinesY;
	
	private int mCursorIndex;	
	private int mBoxOffsetX;
	
	private boolean isShowBox;
	private boolean isKeepLine=false;
	
	private AFloat mFloator = new AFloat();
	
//	private StockTitleChart mStockTitleChart;
	
	private boolean _isNeedUpdate;
	
	private int m_cjlGridHeight = 0; // 成交量区域高度
	protected int m_nDataLength = 0; // 当前图形数据的长度
	private int m_gridWidth = 0; // 表格高
	private int m_fsGridHeight = 0; // 分时高	
	private float maxAvPrice = 0; // 最高价 //算
	private float minAvPrice = 0; // 最低价 //算

	private float m_maxPrice = 0; // 最高价 //算
	private float m_minPrice = 0; // 最低价 //算
	private float mRise = 0,mMinRise = 0;//最大最小涨跌幅
	private AFloat m_maxCJL = null;   // 最大成交 //算	

	private GradientDrawable mBackgroundVLine;
	private GradientDrawable mBackgroundHLine;

	public TimeSharingDetailChart(int left, int top, int right, int bottom) {
		super(left, top, right, bottom);
		pathEffect = new CornerPathEffect(10);
		setDrawable(new Rect(left, top, right, bottom));
		init();
	}
	public TimeSharingDetailChart(Rect r) {
		super(r);
		setDrawable(r);
	}

	private void setDrawable (Rect r) {
		mBackgroundVLine = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] { 0xFF3d3d3d, 0xFF181818});
		mBackgroundVLine.setShape(GradientDrawable.RECTANGLE);
		mBackgroundVLine.setGradientRadius((float) (Math.sqrt(2) * 60));
		mBackgroundVLine.setBounds(r);

		mBackgroundHLine = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[] {0xFF3d3d3d, 0xFF343434, 0xFF3d3d3d});
		mBackgroundHLine.setShape(GradientDrawable.RECTANGLE);
		mBackgroundHLine.setGradientRadius((float) (Math.sqrt(2) * 60));
		mBackgroundHLine.setBounds(r);
	}
	
//	public void setStockTitleChart(StockTitleChart title){
//		mStockTitleChart = title;
//	}
	
	public TimeSeriesQuoteCache getDataSet(){
		return mTimeSeriesQuoteCache;
	}
	
	protected void init(){
		mGestureDetector = new GestureDetector(this);
	}
	
	public void setTarget(TimeSharingDetailView target){
		mTarget = target;
	}
	
	public void clear(){
//		mDataSet = null;
	}
	
	/**
	 * 初始化画图的比例参数
	 */
	protected void initDrawParam() 
	{
//		final DataSetTimeSharing dsTs = mDataSet;
		
		final TimeSeriesQuoteCache dsTs = mTimeSeriesQuoteCache;
		m_nDataLength = dsTs != null ? dsTs.Zjcj.length : 0;
		//m_gridWidth = (m_chartRect.getWidth() - 2) / 4;
		//m_cjlGridHeight = m_chartRect.getHeight() / 3;
		//m_fsGridHeight = (m_chartRect.getHeight() - m_cjlGridHeight) / 2;
		if (m_nDataLength != 0) {
			// 最大振幅，用来计算价格的显示区间
//			float maxPrice = AFloat.max(AFloat.abs(AFloat.sub(dsTs.nZgcj, dsTs.nZrsp)),
//					AFloat.abs(AFloat.sub(dsTs.nZdcj, dsTs.nZrsp)));
//			
			float maxPrice = Math.max(Math.abs(dsTs.maxPrice - dsTs.pclose), Math.abs(dsTs.minPrice - dsTs.pclose));
//			

			if (maxPrice == 0) {
				maxPrice =  maxPrice * 100 / 1000;
						
			} else {
				maxPrice = maxPrice * 101 / 100;
			}
			m_maxPrice = new BigDecimal(maxPrice + dsTs.pclose).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();//(float) Math.floor(maxPrice + dsTs.pclose);//AFloat.add(dsTs.nZrsp, maxPrice);
			m_minPrice = new BigDecimal(dsTs.pclose - maxPrice).setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();//AFloat.sub(dsTs.nZrsp, maxPrice);
			mRise = Math.abs(dsTs.maxRise) > Math.abs(dsTs.minRise) ? dsTs.maxRise :dsTs.minRise;
			
			if (dsTs.retStockBk == Business.BK_index) {
				float maxAvPriceFd = Math.max(
						Math.abs(dsTs.nJJZgcj - dsTs.nZrsp),
						Math.abs(dsTs.nJJZdcj - dsTs.nZrsp));
				if (maxAvPriceFd == 0) {
					maxAvPriceFd = dsTs.nZrsp * 100 / 1000;
				} else {
					maxAvPriceFd = maxAvPriceFd * 101 / 100;
				}
				maxAvPrice = dsTs.nZrsp + maxAvPriceFd;
				minAvPrice = dsTs.nZrsp - maxAvPriceFd;
			} else {
				maxAvPrice = m_maxPrice;
				minAvPrice = m_minPrice;
			}
			
			// 最大成交量
//			m_maxCJL = new AFloat(dsTs.nMaxVol.toFloat() * 101 / 100, dsTs.nMaxVol.nDigit,
//					dsTs.nMaxVol.nUnit);
		}
		// 构造曲线数据和显示区域
/*		m_fsDrawRect = new KRect(m_chartRect.left + 1, m_chartRect.top,
				m_chartRect.getWidth() - 2, m_fsGridHeight * 2 - 1);
		m_cjlDrawRect = new KRect(m_chartRect.left + 1, m_chartRect.top
				+ m_fsGridHeight * 2, m_chartRect.getWidth() - 2,
				m_cjlGridHeight - 1);
*/	}
	
	public void dataBind(TimeSeriesQuoteCache dataSet){
//		mTimeSeriesQuoteCache = dataSet;
		if(mTimeSeriesQuoteCache == null) {
			mAVPath = null;
			return;
		}
		if(mTimeSeriesQuoteCache !=null && mTimeSeriesQuoteCache.Zjcj.length == 0)return;
		if(mAVPath==null){
			mAVPath = new Path[2];
		}
		//chenxi add it 20111227
		initDrawParam();
		
		int maxColumnCount = 0;
		if(dataSet.Cjjj.length > 241)
		  maxColumnCount = dataSet.Cjjj.length;//
		else
			maxColumnCount = (480) / 2 + 1;
		//Log.i("dataBind", dataSet.nZgcj.toFloat()+"::"+dataSet.nZdcj.toFloat());
		//分时线
		mLinesY = new float[dataSet.Cjjj.length];
//		Log.e("分时",
//				"分时数据: " + dataSet.Cjjj.length);
		mAVPath[0] = DrawTool.buildAVLine(dataSet.Zjcj, this.m_maxPrice, this.m_minPrice, maxColumnCount, avRect, null, 0, mLinesY);
		if(dataSet.Cjjj != null)
		//均线
		mAVPath[1] = DrawTool.buildAVLine(dataSet.Cjjj, this.maxAvPrice, this.minAvPrice, maxColumnCount, avRect, null, 0, null);
		
		mVOLLines = DrawTool.getVolumeLines(dataSet.volume, dataSet.maxVolume, maxColumnCount, volRect, null, 0);
//		mVOLLines = DrawTool.getVolumeLines(dataSet.Cjss, this.m_maxCJL, maxColumnCount, volRect, null, 0);
	}
	
/*	@Override
	public void setFrame(int left, int top, int right, int bottom) {
		super.setFrame(left, top, right, bottom);
		float itemH = frame.height()/3.0f;		
		avRect.set(left, top, right, top + (int)(itemH*2));
		//volRect.set(left, avRect.bottom+1, right,avRect.bottom + (int)(itemH*4));
		//mActionRect.set(left, volRect.bottom, right, bottom);
		
		//volRect.set(left, avRect.bottom+1, right,bottom);
		volRect.set(left, avRect.bottom+1, right,bottom-18);
		timeRect.set(left, volRect.bottom+1, right,bottom);
		
		boxPaint.setTextSize(14);
		final int maxWidth = (int)boxPaint.measureText("成交额  9999.99万")+10;
		final int itemHeight = (int) (boxPaint.getTextSize() + 8);
		
		//mChartBox.set(left, top, left + maxWidth, top + itemHeight*7);
		mChartBox.set(left, top, left + maxWidth, top + itemHeight*7-18);
		
		//initActionDraws();
	}
*/	
	
	@Override
	public void setFrame(int left, int top, int right, int bottom) {
		super.setFrame(left, top, right, bottom);
		float itemH = frame.height()/7.0f;	
		if(mShow)
		right -= 35;
		else
			right -= 2;
//		topRect.set(left, top, right, top + (int)(itemH*0.5));
		avRect.set(left + 50, topRect.bottom+1, right, top + (int)(itemH*(4 + 0.5)));
//		timeRect.set(left + 50, avRect.bottom+1, right, top + (int)(itemH*(0.5+2+0.5)));
//		midRect.set(left, avRect.bottom+1, right, top + (int)(itemH*(0.5+4+0.5)));
		volRect.set(left + 50, avRect.bottom + 18, right,bottom);
//		timeRect.set(left + 50, volRect.bottom+1, right,bottom);
		
		//chenx
		//boxPaint.setTextSize(14);
		final int maxWidth = (int)boxPaint.measureText("成交额  9999.99万")+10;
		final int itemHeight = (int) (boxPaint.getTextSize() + 8);
		
		//mChartBox.set(left, top, left + maxWidth, top + itemHeight*7);
		mChartBox.set(left, top, left + maxWidth, top + itemHeight*7-18);
		
		//initActionDraws();
	}	
	
	public void setData(){
		
	}
	/*
	private void initActionDraws(){
		
		//final String[] actionTexts = {"15分","30分","60分","日","周","月"," + ","  -  "};
		final String[] actionTexts = {"　15分　","　30分　","　60分　","　K线　","　周","　月　","　  +　  ","　  -  　"};

		final int top =  mActionRect.top;
		final int bottom = mActionRect.bottom;
		int x = mActionRect.left+5;
		
		mActDraws = new ActionDraw[actionTexts.length];
		for(int i=0;i<actionTexts.length;i++){
			mActDraws[i] = new ActionDraw(actionTexts[i]);
			int textWidth = (int) txtPaint.measureText(actionTexts[i]) + 10;
			mActDraws[i].setBounds(x, top+1, x + textWidth, bottom-1);
			mActDraws[i].setEventID(i);
			x += textWidth + 5; 
		}
	}
	*/

	private float getCursorX(int cursorIndex){
		int maxColumnCount = mTimeSeriesQuoteCache.Cjjj.length;
		if(maxColumnCount < 241)
		  maxColumnCount = (480) / 2+1;
		float perX = 100 * avRect.width() / maxColumnCount; // 水平的间隔点
		float newx = 0;
		float xfix = perX / 100;
		perX = 100 * (avRect.width() - xfix) / maxColumnCount;
		newx = avRect.left + perX * cursorIndex / 100 + xfix;
		return newx;
	}
	
	private float getCursorY(int cursorIndex){
		if(this.mLinesY != null && cursorIndex>=0 && cursorIndex <= mLinesY.length-1)
		{
			return mLinesY[cursorIndex];	
		}
		else
		{
			return -100;
		}
	}	
	
	private int getCursorIndex(float x){
		if(mTimeSeriesQuoteCache == null)return -1;
		
		int maxColumnCount = mTimeSeriesQuoteCache.Cjjj.length;
		if(maxColumnCount < 241)
		  maxColumnCount = (480) / 2+1;
//		final DataSetTimeSharing dataset = mDataSet;
		
		if(x<avRect.left + avRect.width()/2){
			mBoxOffsetX = avRect.right - mChartBox.width()-5;
		}else{
			mBoxOffsetX = 0;
		}
		
		float offsetW = x-avRect.left;
		
		int xIndex = (int)(maxColumnCount * offsetW/avRect.width())-1;
		if(xIndex<0){
			xIndex = 0;
		}
		if(xIndex>=maxColumnCount){
			xIndex = maxColumnCount-1;
		}
		if(xIndex>=mTimeSeriesQuoteCache.Cjjj.length){
			xIndex = mTimeSeriesQuoteCache.Cjjj.length - 1;
		}
		
		return xIndex;
//		return 0;
	}
	
	private void drawPrice(Canvas c, String value, int color, int x, int y) {
		pricePaint.setColor(color);
		pricePaint.setTextSize(12);
		DrawTool.drawText(c, x, y, 0, 20, pricePaint, value);		
	}
	
	/**
	 * 画价格坐标
	 * 
	 * @param g
	 */
	private void drawTSPrice(Canvas c)
	{		
		final TimeSeriesQuoteCache dsTs = mTimeSeriesQuoteCache;
		
		int iX = avRect.left - 50;//avRect.left+2;	
		int rX = avRect.right + 3;
		
		if (dsTs != null && dsTs.volume.length > 0) {
			// 最高价格
			//drawPrice(c, this.m_maxPrice.toString(), 0xffFF2626, iX, avRect.top);
			drawPrice(c, this.m_maxPrice + "", 0xfff6f6f6, iX, avRect.top);
			drawPrice(c, dsTs.pclose.toString(), 
					0xffFFFFFF, iX, avRect.top+(avRect.bottom-avRect.top-18)/2);
			//drawPrice(c, this.m_minPrice.toString(), 0xff17FF17, iX, avRect.bottom-18);
			drawPrice(c, this.m_minPrice + "", 0xfff6f6f6, iX, avRect.bottom -18);
//			drawPrice(c, m_maxCJL.toString(), 0xfff6f6f6, iX, volRect.top);
			
			if(!mShow) return;
			//画涨跌幅
			drawPrice(c, String.format("%1$.1f",Math.abs(mRise)) + "%", 0xfff6f6f6, rX, avRect.top);
			drawPrice(c, "0.0%", 
					0xffFFFFFF, rX, avRect.top+(avRect.bottom-avRect.top-18)/2);
			drawPrice(c, "-" + String.format("%1$.1f",Math.abs(mRise)) + "%", 0xfff6f6f6, rX, avRect.bottom -18);
		}
	}	
	
	
	/*
	private void drawCharBox(Canvas canvas,Paint paint,Rect frame){
		final int titleWidth = (int)paint.measureText("成交量");
		final int itemHeight = (int) (paint.getTextSize() + 8);
		paint.setPathEffect(pathEffect);
		paint.setStyle(Style.FILL);
		paint.setColor(0XCC333333);
		canvas.drawRect(mChartBox.left + mBoxOffsetX, mChartBox.top, mChartBox.right + mBoxOffsetX, mChartBox.bottom, paint);
		int y = mChartBox.top;
		int x = mChartBox.left + 3 + mBoxOffsetX+titleWidth;
		paint.setPathEffect(null);
		paint.setStyle(Style.STROKE);
		paint.setColor(0XffEEEEEE);
		paint.setTextAlign(Align.RIGHT);
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "时间");
		y +=itemHeight;
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "价位");
		y +=itemHeight;
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "均价");
		y +=itemHeight;
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "涨跌");
		y +=itemHeight;
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "涨幅");
		y +=itemHeight;
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "成交量");
		y +=itemHeight;
		DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint, "成交额");
		
		
		y = mChartBox.top;
		x = mChartBox.left + mChartBox.width()-3 + mBoxOffsetX;
		
		if(mDataSet!=null){
			final DataSetTimeSharing dataset = mDataSet;
			int index = mCursorIndex;
			paint.setTextAlign(Align.RIGHT);
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,dataset.timeFormat(dataset.nTime[index]*100));
			y +=itemHeight;
			mFloator.init(dataset.Zjcj[index]);
			paint.setColor(Theme.factoryColor(mFloator, dataset.nZrsp));
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,mFloator.toString());
			y +=itemHeight;
			mFloator.init(dataset.Cjjj[index]);
			paint.setColor(Theme.factoryColor(mFloator, dataset.nZrsp));
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,mFloator.toString());
			y +=itemHeight;
			//涨跌
			mFloator.init(0, 2, AFloat.NUMBER);
			paint.setColor(Theme.factoryColor(dataset.Zd[index], mFloator));
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,dataset.Zd[index].toString(""));
			y +=itemHeight;		
			//涨跌幅
			//paint.setColor(Theme.factoryColor(dataset.kClose[index], dataset.nZrsp));
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,dataset.Zdf[index].toString("%"));
			y +=itemHeight;
			//成交量
			mFloator.init(dataset.Cjjj[index]);
			paint.setColor(Theme.defaultColor());
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,mFloator.toString());
			y +=itemHeight;
			//成交额
			paint.setColor(Theme.defaultColor());
			DrawTool.drawText(canvas, x, y, titleWidth, itemHeight, paint,dataset.Cjje[index].toString());
			y +=itemHeight;
			
			paint.setTextAlign(Align.LEFT);
			
			float cX = getCursorX(index);
			
			paint.setColor(0xffffffff);
			canvas.drawLine(cX, avRect.top, cX, avRect.bottom, paint);
			
			canvas.drawLine(cX, volRect.top, cX, volRect.bottom, paint);
			
		}
		
	}
	*/

	//画顶部分时box明细数据
	private void drawCharBox(Canvas canvas,Paint paint,final Rect frame){
		if(mTimeSeriesQuoteCache == null)return;
		Log.e("drawCharBox", "drawCharBox");
		final int itemHeight = frame.height()/3;
		final int col_with = frame.width()/3;
//		final DataSetTimeSharing dataset = mDataSet;
		int index = mCursorIndex;
		
		//画线
		paint.setStyle(Style.STROKE);
		paint.setColor(0xffa2a2a2);
		float rectX = frame.left + frame.width()/3;
		
		//canvas.drawLine(rectX, frame.top, rectX, frame.bottom, paint);
		//canvas.drawLine(rectX + frame.width()/3, frame.top, rectX + frame.width()/3, frame.bottom, paint);
//		if (mBackgroundVLine == null) {
//			setDrawable(frame);
//		}
//		mBackgroundVLine.setBounds(new Rect((int)rectX - 1,frame.top,(int)rectX,frame.bottom));
//		mBackgroundVLine.draw(canvas);
//		mBackgroundVLine.setBounds(new Rect((int)rectX + frame.width()/3 - 1, frame.top, (int)rectX + frame.width()/3, frame.bottom));
//		mBackgroundVLine.draw(canvas);

		
		float itemH = frame.height()/3;
//		for (int i=0;i<2;i++) {
//			//canvas.drawLine(rectX, frame.top + itemH*(i+1), frame.right, frame.top + itemH*(i+1), paint);
//			mBackgroundHLine.setBounds(new Rect((int)rectX, (int)(frame.top + itemH*(i+1)), frame.right, (int)(frame.top + itemH*(i+1) + 1)));
//			mBackgroundHLine.draw(canvas);
//		}
		
		if(mTimeSeriesQuoteCache==null || index<0 || index>=mTimeSeriesQuoteCache.volume.length)return;
		
		//Log.e("drawCharBox", "index : " + index);
		
		int y = frame.top;
		int x = frame.left;
		
		int color = 0;
		
		String strTime = mTimeSeriesQuoteCache.nTime[index] + "";//dataset.timeFormat(dataset.nTime[index]*100);
//		MiniChart.drawNVItem(canvas, x+5, frame.height()/3, itemHeight, col_with-10, "时间", strTime, 0xFFffff00, paint);
		
		x = frame.left;
		//  价位   均价
//		mFloator.init(dataset.Zjcj[index]);
//		color = Theme.factoryColor(mFloator, dataset.nZrsp);
////		MiniChart.drawNVItem(canvas, x+col_with, y, itemHeight, col_with, "价位", mFloator.toString(), color, paint);
		String strPrice = mTimeSeriesQuoteCache.Zjcj[index] + "";//mFloator.toString();
//		mFloator.init(dataset.Cjjj[index]);
//		color = Theme.factoryColor(mFloator, dataset.nZrsp);	
////		MiniChart.drawNVItem(canvas, x+col_with*2, y, itemHeight, col_with, "均价", mFloator.toString(), color, paint);
//		// 涨跌      涨幅
//		mFloator.init(0, 2, AFloat.NUMBER);
//		color = Theme.factoryColor(dataset.Zd[index], mFloator);
////		MiniChart.drawNVItem(canvas, x+col_with, y+itemHeight, itemHeight, col_with, "涨跌", dataset.Zd[index].toString(""), color, paint);
////		MiniChart.drawNVItem(canvas, x+col_with*2, y+itemHeight, itemHeight, col_with, "涨幅", dataset.Zdf[index].toString("%"), color, paint);
//		// 成交量  成交额
//		mFloator.init(dataset.Cjss[index]);
//		color = 0xFFffff00;//Theme.defaultColor();
//		MiniChart.drawNVItem(canvas, x+col_with, y+itemHeight*2, itemHeight, col_with, "量", mFloator.toString(""), color, paint);
//		
//		MiniChart.drawNVItem(canvas, x+col_with*2, y+itemHeight*2, itemHeight, col_with, "金额", dataset.Cjje[index].toString(""), color, paint);
		
		paint.setTextAlign(Align.LEFT);
		
		float cX = getCursorX(index);			
		paint.setColor(0xffffffff);
		canvas.drawLine(cX, avRect.top, cX, avRect.bottom, paint);
		canvas.drawLine(cX, volRect.top, cX, volRect.bottom, paint);
		
		float cY = getCursorY(index);
		canvas.drawLine(avRect.left, cY, avRect.right, cY, paint);
		
		//draw figure price
//		pricePaint.getTextBounds(strPrice, 0, strPrice.length(), rect); 
		paint.setStyle(Style.FILL);
		paint.setColor(0xaa0000ff);
		paint.setTextSize(10);
		int iX = avRect.left+2;
		int iY = (int)(cY+rect.height()/2);
		canvas.drawRect(iX+rect.left, iY+rect.top, iX+rect.left+rect.width(), iY+rect.top+rect.height(), paint);
		paint.setColor(0XFFffffff);	
		DrawTool.drawTextMid(canvas, iX+rect.left, iY+rect.top, rect.width(), rect.height(), paint, strPrice);
		
		//draw figure time
		pricePaint.getTextBounds(strTime, 0, strTime.length(), rect); 
		paint.setStyle(Style.FILL);
		paint.setColor(0xaa0000ff);		
		
		if(cX-rect.width()/2<volRect.left+2)
		{
			iX = avRect.left+2;
		}
		else if(cX+rect.width()/2>volRect.width())
		{
			iX = volRect.width() - rect.width();
		}
		else
		{
			iX = (int)(cX-rect.width()/2);
		}
		iY =  volRect.top+3;		
		canvas.drawRect(iX+rect.left, iY, iX+rect.left+rect.width(), iY+rect.height(), paint);
		paint.setColor(0XFFffffff);	
//		Log.e("len11", strTime);
		if(strTime.length() < 4)
			strTime = "0" + strTime;
		String tmp = strTime.substring(0, 2);
//		tmp += ":";

//		Log.e("len", strTime);
		strTime = tmp + strTime.substring(2, strTime.length());
		DrawTool.drawTextMid(canvas, iX+rect.left, iY, rect.width(), rect.height(), paint, strTime);		
	}
	
	/*
	private void drawActions(Canvas canvas){
		for( ActionDraw draw : mActDraws){
			draw.draw(canvas);
		}
	}
	*/
	
	public void draw(Canvas canvas){
//		final Paint paint = getPaint();
//		final Rect f = frame;
		paint.setStyle(Style.FILL);
//		paint.setColor(255);
//		canvas.drawRect(f, paint);
		//Log.i("chartPaint.getStrokeWidth", ""+chartPaint.getStrokeWidth());
//ax		
//		chartPaint.setAntiAlias(false);
		chartPaint.setPathEffect(null);	
		chartPaint.setStrokeWidth(1.0f);		
		//chartPaint.getStrokeWidth();
		//chartPaint.setPathEffect(null);
		chartPaint.setStyle(Style.STROKE);
		chartPaint.setColor(Global.frameLineColor);


		chartPaint.setAlpha(255);
		//chartPaint.setAntiAlias(false);
		canvas.drawRect(avRect, chartPaint);
		canvas.drawRect(volRect, chartPaint);
//		canvas.drawRect(timeRect, chartPaint);
		chartPaint.setStrokeWidth(0.0f);
		//走势图背景横线
		float lineHeight = avRect.height()/2.0f;
		chartPaint.setStrokeWidth(1.0f);
		for(int i=0;i<2;i++){
			/*
			if(i==2){
				chartPaint.setStrokeWidth(1.0f);
			}else{
				chartPaint.setStrokeWidth(0.5f);
			}
			*/
			canvas.drawLine(avRect.left, avRect.top+lineHeight*(i+1), avRect.right, avRect.top+lineHeight*(i+1), chartPaint);
		}
		
		float lineWidth = avRect.width()/4.0f;
		float[] avLines = DrawTool.getDottedLine(avRect, false);
		float[] volLines = DrawTool.getDottedLine(volRect, false);
		
		//画时间
//		int newX = timeRect.left;
//		drawPrice(canvas, times[0], 0xffffffff, newX, timeRect.top);
//		newX += ((lineWidth * 2) - (pricePaint.measureText(times[1]) / 2) + 1);
//		drawPrice(canvas, times[1], 0xffffffff, newX, timeRect.top);
//		newX = timeRect.right - (int)pricePaint.measureText(times[2]);
//		drawPrice(canvas, times[2], 0xffffffff, newX, timeRect.top);
		int newX = avRect.left;
		if(mTimeSeriesQuoteCache != null && mTimeSeriesQuoteCache.Cjjj.length > 241){
			drawPrice(canvas, (mTimeSeriesQuoteCache.nTime[0] + "").substring(2, 8), 0xffffffff, newX, avRect.bottom);
			newX += ((lineWidth * 2) - (pricePaint.measureText(times[1]) / 2) + 1);
			drawPrice(canvas, (mTimeSeriesQuoteCache.nTime[mTimeSeriesQuoteCache.Cjjj.length / 2 - 1] + "").substring(2, 8), 0xffffffff, newX, avRect.bottom);
			newX = avRect.right - (int)pricePaint.measureText((mTimeSeriesQuoteCache.nTime[mTimeSeriesQuoteCache.Cjjj.length - 1] + "")) / 2;
			drawPrice(canvas, (mTimeSeriesQuoteCache.nTime[mTimeSeriesQuoteCache.Cjjj.length - 1] + "").substring(2, 8), 0xffffffff, newX, avRect.bottom);
		}else{
		
		drawPrice(canvas, times[0], 0xffffffff, newX, avRect.bottom);
		newX += ((lineWidth * 2) - (pricePaint.measureText(times[1]) / 2) + 1);
		drawPrice(canvas, times[1], 0xffffffff, newX, avRect.bottom);
		newX = avRect.right - (int)pricePaint.measureText(times[2]);
		drawPrice(canvas, times[2], 0xffffffff, newX, avRect.bottom);
		}
		
		//纵线
		for(int i=0;i<3;i++){
/*			if(i==3){
				chartPaint.setStrokeWidth(1.0f);
				canvas.drawLine(avRect.left+lineWidth*(i+1), avRect.top, avRect.left+lineWidth*(i+1), avRect.bottom, chartPaint);
				canvas.drawLine(volRect.left+lineWidth*(i+1), volRect.top, volRect.left+lineWidth*(i+1), volRect.bottom, chartPaint);				
			}else{//虚线
				//chartPaint.setStrokeWidth(0.0f);
				canvas.save();
				canvas.translate((int)lineWidth*(i+1), 0);
				canvas.drawLines(avLines, chartPaint);
				canvas.drawLines(volLines, chartPaint);
				canvas.restore();
			}
*/	
			//chartPaint.setStrokeWidth(0.0f);
			canvas.save();
			canvas.translate((int)lineWidth*(i+1), 0);
			canvas.drawLines(avLines, chartPaint);
			canvas.drawLines(volLines, chartPaint);
			canvas.restore();						
		}
		//成交量背景线
/*		lineHeight = volRect.height()/4.0f;
		for(int i=0;i<3;i++){
			canvas.drawLine(volRect.left, volRect.top+lineHeight*(i+1), volRect.right, volRect.top+lineHeight*(i+1), chartPaint);
		}
*/		
		drawTSPrice(canvas);
		//走势图
		if(mAVPath!=null){
			//均线
			chartPaint.setPathEffect(pathEffect);
			//chartPaint.setStrokeWidth(1.5f);
			chartPaint.setStrokeWidth(1f);
			
			chartPaint.setColor(0xFF2558AE);
			canvas.drawPath(mAVPath[0], chartPaint);
			
			chartPaint.setColor(0xFFffff00);
			if(mAVPath[1]!=null)
			canvas.drawPath(mAVPath[1], chartPaint);
//			//成交量
			chartPaint.setStrokeWidth(1f);
			if(mVOLLines != null)
			canvas.drawLines(mVOLLines, chartPaint);
			
			if(isShowBox){
				drawCharBox(canvas,boxPaint,frame);
			}
			
		}
		//drawActions(canvas);
//		if(mDoji)
//		drawCharBox(canvas,boxPaint,frame);
	}
	
	public void setDataSet(TimeSeriesQuoteCache dataset){
		mTimeSeriesQuoteCache =  dataset;
		//chenxi add it 20111227
		initDrawParam();		
		_isNeedUpdate = true;
	}
	
	public boolean isRequestUpdate(){
		return _isNeedUpdate;
	}
	

	
	public void update(){
		_isNeedUpdate = false;
		dataBind(mTimeSeriesQuoteCache);
	}

	private boolean startTime = false;
	private int  bx = 0, by=0;
	
	public boolean onTouchEvent(MotionEvent ev) {		
		mGestureDetector.onTouchEvent(ev);
		//兼容1.6
		//switch(ev.getAction() & MotionEvent.ACTION_MASK){
		switch(ev.getAction()){
		case MotionEvent.ACTION_UP:
			this.isShowBox = false;
			if(!isKeepLine) {
				
//				mDoji = false;
//				mStockTitleChart.setDrawTarget(null);
			}
//			WorkSpace.setbProcessBySubView(false);
//			mTarget.invalidate();
/*ax			
			mStockTitleChart.setDrawTarget(null);
			if(mSelectedDraw!=null){
				mSelectedDraw.setSelected(false);
				switch(mSelectedDraw.getEventID()){
				case 3://分时
					mTarget.handleMessage(XMessage.create(Events.EVENT_HQ_KX, null));
					break;
				case 6://zoom in
					//zoomIn();
					break;
				case 7:
					//zoomOut();
					break;
				}
				
				mSelectedDraw = null;
				mTarget.invalidate();
				
			}
*/			if(mCanClick)
			return false;
else return true;
//			break;
		case MotionEvent.ACTION_DOWN:
			this.isShowBox = true;
			startTime = true;  //開始時間			
			int x = (int) ev.getX();
			int y = (int) ev.getY();
			if(frame.contains(x, y)){
//				mStockTitleChart.setDrawTarget(this);
//				mDoji = true;
			}
//			mTarget.invalidate();
			break;
		case MotionEvent.ACTION_MOVE:
			int ex = (int) ev.getX();
			int ey = (int) ev.getY();
			int sy = Math.abs(ey-by);
			
			if(startTime)
			{
					int sx = Math.abs(ex-bx);
					System.out.println("sx:"+sx+",sy"+sy);
					if(sx <= 1 ) 
					{
						isShowBox = false;
//						WorkSpace.setbProcessBySubView(true);
					}
					else
					{
						isShowBox = true;
//						WorkSpace.setbProcessBySubView(false);
					} 
					bx = ex;
					startTime = false;
			}
			
				isShowBox = true;
			
			mCursorIndex = getCursorIndex(ev.getX());
			if(mCursorIndex!=-1){
			}
			mTarget.invalidate();
			break;
		}
		
		return true;
	}

	
	
	
	@Override
	public boolean onDown(MotionEvent e) {
		mCursorIndex = getCursorIndex(e.getX());
		
		return false;
	}
	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean onSingleTapUp(MotionEvent e) {
		onSingleTapUpAs(e);
		return false;
	}
	
	public boolean onSingleTapUpAs(MotionEvent e) {
		isKeepLine = false;
		return false;
	}
	
	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		
		return false;
	}
	@Override
	public void onLongPress(MotionEvent e) {
		isKeepLine = true;
	}
	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		Log.i("KLine", "onFling");
		//mTarget.onPage();
		return false;
	}
//	@Override
	public void draw2(Canvas canvas) {
		drawCharBox(canvas,boxPaint,frame);
	}
	
	private boolean mCanClick = false;
	/**
	 * 设置是否响应点击
	 * @param canClick
	 */
	public void setOnClickListener(boolean canClick){
		mCanClick = canClick;
	}
	
	private boolean mShow = false;
	/**
	 * 设置是否显示涨跌幅
	 * @param show
	 */
	public void setRiseShow(boolean show){
		mShow = show;
	}
}
