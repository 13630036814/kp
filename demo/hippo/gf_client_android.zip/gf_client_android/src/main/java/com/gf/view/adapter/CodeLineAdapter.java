/**
 * 
 */
package com.gf.view.adapter;

import java.util.HashMap;
import java.util.List;

import com.gf.client.R;
import com.gf.viewmodel.bean.Group;
import com.gf.viewmodel.bean.MessageInfo;
import com.gf.viewmodel.util.StockTool;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author cola
 * 
 */
public class CodeLineAdapter extends BaseAdapter {
	private static HashMap<Integer, Integer> isSelected = new HashMap<Integer, Integer>();
	private List<MessageInfo> mCodeLineList;
	private Context ct;
	private String colorWord = "";
	private int dataLen = 0;

	private static HashMap<Integer, Integer> getIsSelect() {
		return isSelected;
	}
	
	public void setSelectStatus(){
		dataLen = mCodeLineList.size() ;
		if(dataLen > 50) dataLen = 50;
		initSelectStatus();
	}
	
	private void initSelectStatus(){
		for(int n = 0; n < dataLen; n++){
			isSelected.put(n, Integer.parseInt(mCodeLineList.get(n).mField3));
			Log.v("status", mCodeLineList.get(n).mField3);
		}
	}
	
	private void initSelectStatus(boolean b){
		for(int n = 0; n < dataLen; n++){
			isSelected.put(n, 0);
		}
	}
	
	public CodeLineAdapter(final Context ct, List<MessageInfo> mCodeLineList) {
		this.ct = ct;
		this.mCodeLineList = mCodeLineList;
		dataLen = mCodeLineList.size() ;
		if(dataLen > 50) dataLen = 50;
		initSelectStatus(true);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mCodeLineList.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mCodeLineList.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		final int pos = position;
		ItemHeaderViewHolder holder = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(ct).inflate(R.layout.codelineitem,
					parent, false);
		}
			holder = new ItemHeaderViewHolder();
			
			holder.stcokName = (TextView) convertView
					.findViewById(R.id.stockName);
			holder.stockCode = (TextView) convertView
					.findViewById(R.id.stockCode);
			holder.stockRange2 = (TextView) convertView
					.findViewById(R.id.risedrop);
			holder.stockPrice = (TextView) convertView.findViewById(R.id.price);
			holder.stockRange = (TextView) convertView
					.findViewById(R.id.risedroprang);
			holder.imgArrow = (ImageView) convertView
					.findViewById(R.id.code_line_icon);
			
		holder.imgArrow.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if (mCodeLineList.get(pos).mField3.equals("1")) {
					mCodeLineList.get(pos).mField3 = "0";

					if (mStockAction != null) {
						getIsSelect().put(pos, 0);
						mStockAction.del(pos);
					}
					notifyDataSetChanged();
				} else {
					mCodeLineList.get(pos).mField3 = "1";

					if (mStockAction != null) {
						getIsSelect().put(pos, 1);
						mStockAction.add(pos);
					}
					notifyDataSetChanged();
				}
			}

		});
			
			convertView.setTag(holder);
//		} else {
//			holder = (ItemHeaderViewHolder) convertView.getTag();
//		}

		holder.stcokName.setText(mCodeLineList.get(position).getGroupName());
		holder.stockPrice.setText(mCodeLineList.get(position).mField1);
		
		String data = mCodeLineList.get(position).mField2;
		if(mCodeLineList.get(position).mField2.length() > 4){
			data = mCodeLineList.get(position).mField2.substring(0, 4) + "%";
		}
		holder.stockRange.setText(data);
		
		String color = mCodeLineList.get(position).getInfo();
		if (!colorWord.equals("")) {
			int p = color.indexOf(colorWord);
			if (p != -1) {
				SpannableStringBuilder style = new SpannableStringBuilder(
						color);
				// style.setSpan(new BackgroundColorSpan(//改变字体的背景色
				// getResources().getColor(R.color.mycolor)),start,end,Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
				style.setSpan(new ForegroundColorSpan(Color.RED),p,p + colorWord.length(),//改变字体色
						Spannable.SPAN_EXCLUSIVE_INCLUSIVE);
				holder.stockCode.setText(style);
			}else
				holder.stockCode.setText(color);
		}else
	     holder.stockCode.setText(color);
		
		if(position > 49 || getIsSelect().size() < 1) return convertView;
		
		if(mCodeLineList.get(pos).mField3.equals("2")){
			holder.stockRange2.setText("已添加");
			holder.stockRange2.setVisibility(View.VISIBLE);
			holder.imgArrow.setVisibility(View.GONE);
		}else if(getIsSelect().get(pos) == 0){//mCodeLineList.get(position).mField3.equals("1")
			holder.stockRange2.setVisibility(View.GONE);
			holder.imgArrow.setVisibility(View.VISIBLE);
			holder.imgArrow.setBackgroundResource(R.drawable.add_btn);
		}else if(getIsSelect().get(pos) == 1){//mCodeLineList.get(position).mField3.equals("0")
			holder.stockRange2.setVisibility(View.GONE);
			holder.imgArrow.setVisibility(View.VISIBLE);
			holder.imgArrow.setBackgroundResource(R.drawable.del_btn);
		}
				
		return convertView;
	}

	/**
	 * 将包含的字符串变色
	 * @param colorWord
	 */
	public void setColorString(String colorWord){
		if(StockTool.isNum(colorWord))
		this.colorWord = colorWord;
		else
			this.colorWord = "";
	}
	
	public class ItemHeaderViewHolder {

		TextView stcokName;
		ImageView imgArrow;
		TextView stockCode;
		TextView stockPrice;
		TextView stockRange;
		TextView stockRange2;

	}
	
	@Override
	public void notifyDataSetChanged() {
		
		super.notifyDataSetChanged();
	}
	
	private StockAction mStockAction;
	public void setStockAction(StockAction sa){
		this.mStockAction = sa;
	}
	
	/**
	 * 点击添加按钮后的回调
	 * @author cola
	 *
	 */
	public interface StockAction{
		/**
		 * 
		 * @param pos 在数据的位置
		 */
		public void add(int pos);
		public void del(int pos);
	}
}
