package com.gf.viewmodel.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**系统时间工具*/
public class TimeTool {
	//日期时间调整
	/**与服务器的时间差,精确到分钟*/
    public static int minuteFix;  
  public static void setMinuteFix(int minuteFix) {
		TimeTool.minuteFix = minuteFix;
	}

/**1：假日 0：交易日	*/
	 static byte isHoliday; // 是否节假日

    public static byte getIsHoliday() {
		return isHoliday;
	}
	public static void setIsHoliday(byte isHoliday) {
		TimeTool.isHoliday = isHoliday;
	}
	/**认下下发的日期与时间做一次同步*/
	public static void setDateTime(String date,String time){
		 while (time.length() < 6)time = "0" + time;
		Date serverDateTime=parseDateTime(date,time);
		Date now =new Date();
		 SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
		 minuteFix=(int)((serverDateTime.getTime()-now.getTime())/(60*1000));
	}
	public static Date parseDateTime(String date,String time){
		Date d=null;
		/*date=date.substring(0,4)+"-"+date.substring(4);
		date=date.substring(0,7)+"-"+date.substring(7);
		date+="  ";
		time=time.substring(0,2)+":"+time.substring(2);
		time=time.substring(0,5)+":"+time.substring(5);
		date+=time;*/
		 SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd  HHmmss");	   
		 try { 
			d=formatter.parse(date+"  "+time);
		} catch (ParseException e) {			
			e.printStackTrace();
		}
		//System.out.println("转换:"+formatter.format(d));
		return d;
	}
    /**
     * 获取yyyyMMdd格式的int型当前日期
     * @return
     */
    public static  int getNow(){
    	return getIntTime(new Date(),"yyyyMMdd");
    }
    /**
     * 时分秒
     * @return
     */
    public static String getTimeHHMMSS(){
    	Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
    	calendar.add(Calendar.MINUTE,minuteFix);
    	int yy = calendar.get(Calendar.YEAR);
    	int mon = calendar.get(Calendar.MONTH);
    	int d = calendar.get(Calendar.DAY_OF_MONTH);
    	
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        int s = calendar.get(Calendar.SECOND);
        String sH = h<10?"0"+h:""+h;
        String sM = m<10?"0"+m:""+m;
        String sS = s<10?"0"+s:""+s;
        return yy +"-" + (mon+1) + "-" + d + "  " + sH + ":"+sM+":"+sS;
    }
	/**
	 * 返回格式化的int型数据
	 * @param d Date对象
	 * @param format 如 yyyyMMdd
	 * @return
	 */
public static int getIntTime(Date d,String format){
	java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat(format);
	 return StringUtils.stringToInt(formatter.format(d) );
}
	/**
	 * 取得起始日期，和终止日期
	 * @param days 相差天数
	 * @return
	 */
	public static int[] getQSZZDate(int days) {
		int[] date = new int[2];
		Calendar rightNow = Calendar.getInstance();
		rightNow.add(Calendar.MINUTE,minuteFix);
		int year = rightNow.get(Calendar.YEAR);
		int month = rightNow.get(Calendar.MONTH) + 1;
		int day = rightNow.get(Calendar.DATE);
		date[0] = year * 10000 + month * 100 + day;
		Date now = rightNow.getTime();
		now.setTime(now.getTime() - days * 24 * 3600 * 1000);
		rightNow.setTime(now);
		year = rightNow.get(Calendar.YEAR);
		month = rightNow.get(Calendar.MONTH) + 1;
		day = rightNow.get(Calendar.DATE);
		date[1] = year * 10000 + month * 100 + day;
		return date;
	}
	
	  public static String getWeek(Date date) {
	        String[] weekDays = {"日", "一", "二", "三", "四", "五", "六"};
	        Calendar cal = Calendar.getInstance();
	        cal.setTime(date);

	        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
	        if (w < 0)
	            w = 0;

	        return weekDays[w];
	    }
	    
	    public static String getWeek(int time) {
	    	int y = time/10000;
			int m = time%10000/100;
			int d = time%10000%100;
	    	Date date = new Date();
			date.setYear(y);
			date.setMonth(m-1);
			date.setDate(d-1);
			return getWeek(date);
	    }
	    
		public static String getYear() {
			Calendar calendar = Calendar.getInstance(TimeZone
					.getTimeZone("GMT+08:00"));
			calendar.add(Calendar.MINUTE,minuteFix);
			return String.valueOf(calendar.get(Calendar.YEAR));
		}
	/**
     * 是否交易时间
     * @return
     */
    public static boolean isMarketTime(){
    	if (isHoliday==1) {return false;}
    	Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
    	calendar.add(Calendar.MINUTE,minuteFix);
        int w = calendar.get((Calendar.DAY_OF_WEEK));
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        boolean rv;
        int time = h*100+m;
        if(w == 1 || w == 7){//周六周日
        	rv= false;
        } else if((time>=905 && time<=1140) ||   (time>=1250 && time<=1510)) //9:05-11:40 12:50-15:10     	
        {
        	//System.out.println("h:"+h+" m:"+m+" time:"+time+" autofresh!");
        	rv= true;
        }else{      
      rv= false;
        }
        return rv;
    }
    
    /**
     * 是否集合竞价时间
     * @return
     */
    public static boolean isMatchTime(){
    	if (isHoliday==1) {return false;}
    	Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+08:00"));
    	calendar.add(Calendar.MINUTE,minuteFix);
        int w = calendar.get((Calendar.DAY_OF_WEEK));
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        
        int time = h*100+m;
        if(w == 1 || w == 7){//周六周日
        	return false;        	
        }
        //chenx update it 20120309
        //9:15-9:25
        else if((time>=915 && time<=925))
        {
        	//System.out.println("h:"+h+" m:"+m+" time:"+time+" autofresh!");
        	return true;
        }
        return false;
    }	
	
    
}
