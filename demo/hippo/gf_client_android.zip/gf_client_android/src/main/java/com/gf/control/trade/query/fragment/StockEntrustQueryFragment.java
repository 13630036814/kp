package com.gf.control.trade.query.fragment;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.view.adapter.trade.FourItemInfoAdapter;
import com.gf.viewmodel.ebiz.trade.FourItemInfo;

/**
 * 委托查询
 *
 */
public class StockEntrustQueryFragment extends Fragment {
	
	private TextView lbTime; // 委托时间
	private TextView lbStock; // 证券名称
	private TextView lbPrice; // 委托价格
	private TextView lbAmount; // 委托数量
	
	private ListView listView;
	private List<FourItemInfo> items = new ArrayList<FourItemInfo>();
	private FourItemInfoAdapter adapter;
	
	private View mView;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//		return super.onCreateView(inflater, container, savedInstanceState);
		mView = inflater.inflate(R.layout.trade_query_common_list, null);
		
		initData();
		initViews();
		setData();
		
		return mView;
	}
	
	private void initData() {
		if (!items.isEmpty()) {
			items.clear();
		}
		
		for (int i = 0; i < 2; i++) {
			items.add(new FourItemInfo("09:15:23", "武钢股份", "5.02", "600"));
			items.add(new FourItemInfo("10:39:58", "浦发银行", "9.18", "1000"));
			items.add(new FourItemInfo("13:53:75", "中国卫星", "17.89", "300"));
		}
	}

	private void initViews() {
		lbTime = (TextView) mView.findViewById(R.id.lb_one);
		lbStock = (TextView) mView.findViewById(R.id.lb_two);
		lbPrice = (TextView) mView.findViewById(R.id.lb_three);
		lbAmount = (TextView) mView.findViewById(R.id.lb_four);
		
		listView = (ListView) mView.findViewById(R.id.listView_four);
	}
	
	private void setData() {
		lbTime.setText("委托时间");
		lbStock.setText("证券名称");
		lbPrice.setText("委托价格");
		lbAmount.setText("委托数量");

		adapter = new FourItemInfoAdapter(mView.getContext(), items);
		listView.setAdapter(adapter);
	}
}
