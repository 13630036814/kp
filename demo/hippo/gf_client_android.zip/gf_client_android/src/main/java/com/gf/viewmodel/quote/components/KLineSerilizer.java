package com.gf.viewmodel.quote.components;

import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.KLineData;
import com.gf.viewmodel.ebiz.quote.KLineMsg;
import com.gf.viewmodel.ebiz.quote.KLineReq;
import com.gf.viewmodel.ebiz.quote.KLineRes;
import com.gf.viewmodel.ebiz.quote.KLineTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.ReqBody;
import com.gf.viewmodel.ebiz.quote.ResBody;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.quote.CandleQuoteStream;
import com.gf.hippo.domain.client.quote.CandleQuoteStreamItem;
import com.gf.hippo.domain.client.quote.PeriodType;
import com.gf.hippo.domain.client.securities.Stock;

public class KLineSerilizer implements Serializer  {

	
	@Override
	public DomainObject unSerializeResBody(ResBody body) {
		KLineRes msg = body.klineRes;
		if(msg==null)return null;
		CandleQuoteStream stream =  CandleQuoteStream.newInstance(msg.intFromEnum(msg.type));
		String market = body.market;

		Stock stock = new Stock();
		stock.setMarket(market);
		stock.setStock_code(body.code);
		stream.setSecurities(stock);
		
		for (int i = 0; i < msg.data.size(); ++i) {
			KLineData data2 = msg.data.get(i);
			CandleQuoteStreamItem item = new CandleQuoteStreamItem();
			item.setAmount(data2.amount);
			item.setAvg(data2.avg);
			item.setClose(data2.close);
			item.setHigh(data2.high);
			item.setLow(data2.low);
			item.setOpen(data2.open);
			item.setPclose(data2.pclose);
			item.setSecurities(stock);
			item.setTime(data2.time);
			item.setVolume(data2.volume);
			stream.putItem(item);
		}
		return stream;
	}
	
	@Override
	public DomainObject unSerializeMsgBody(MsgBody body) {
		KLineMsg msg = body.kline;
		if(msg==null)return null;
		CandleQuoteStream stream =  CandleQuoteStream.newInstance(msg.intFromEnum(msg.type));
		String market = body.market;

		Stock stock = new Stock();
		stock.setMarket(market);
		stock.setStock_code(body.code);
		stream.setSecurities(stock);
		
		KLineData data2 = msg.data;
		CandleQuoteStreamItem item = new CandleQuoteStreamItem();
		item.setAmount(data2.amount);
		item.setAvg(data2.avg);
		item.setClose(data2.close);
		item.setHigh(data2.high);
		item.setLow(data2.low);
		item.setOpen(data2.open);
		item.setPclose(data2.close);
		item.setSecurities(stock);
		item.setTime(data2.time);
		item.setVolume(data2.volume);
		stream.putItem(item);
		return stream;
	}

	

	@Override
	public byte[] serialize(DomainObject object) {
		if(object instanceof CandleQuoteStream){
		CandleQuoteStream quote = (CandleQuoteStream) object;
		ReqBody.Builder builder = new ReqBody.Builder();
		builder.fid(HQFuncTypes.HQ_KX);

		KLineReq.Builder klineReq = new KLineReq.Builder();
		KLineTypes type = klinetypeTranslate(quote.getPeriodType());		
		klineReq.count(quote.getCount()).direction(quote.getDirection()).time(quote.getTime()).type(type);		
		builder.klineReq = klineReq.build();
		Stock stock = (Stock) quote.getSecurities();
		builder.market(stock.getMarket());
		builder.code(stock.getStock_code());
		ReqBody body = builder.build();
		
		byte[] bytes = body.toByteArray();
		return bytes;
		}
		return null;
	}

	 public KLineTypes klinetypeTranslate(int periodType){ 
		 KLineTypes type = KLineTypes.KX_DAY;
			switch (periodType) {
			case PeriodType.KX_03MNT:
				type = KLineTypes.KX_03MNT;
				break;

			case PeriodType.KX_06MNT:
				type = KLineTypes.KX_06MNT;
				break;

			case PeriodType.KX_10MIN:
				type = KLineTypes.KX_10MIN;
				break;

			case PeriodType.KX_12MNT:
				type = KLineTypes.KX_12MNT;
				break;

			case PeriodType.KX_15MIN:
				type = KLineTypes.KX_15MIN;
				break;

			case PeriodType.KX_1MIN:
				type = KLineTypes.KX_1MIN;
				break;

			case PeriodType.KX_30MIN:
				type = KLineTypes.KX_30MIN;
				break;

			case PeriodType.KX_5MIN:
				type = KLineTypes.KX_5MIN;
				break;

			case PeriodType.KX_60MIN:
				type = KLineTypes.KX_60MIN;
				break;

			case PeriodType.KX_DAY:
				type = KLineTypes.KX_DAY;
				break;

			case PeriodType.KX_MONTH:
				type = KLineTypes.KX_MONTH;
				break;
			case PeriodType.KX_WEEK:
				type = KLineTypes.KX_WEEK;
				break;
			}
			return type;
	 }

	 
	
}
