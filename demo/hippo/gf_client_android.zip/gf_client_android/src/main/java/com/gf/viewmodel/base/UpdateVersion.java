package com.gf.viewmodel.base;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.gf.control.BaseApplication;
import com.gf.viewmodel.base.HttpManager.NetWorkCallBack;

import android.content.Context;
import android.os.Environment;
import android.util.Log;


/**
 * 版本更新
 * @author jinjian
 *
 */
public class UpdateVersion {
	private static final String TAG = "UpdateVersion";
	private Context mContext;
	private Callback mCallback;
	
	// 当前版本名称(contentVer)
	public String mCurVerCode = "1.0.0";

	// 当前版本号(containerVer)
	public String mCurVersion;
	
	public String mNewVersion;

	// app
	public String mApp = "gf_client_android";

	// type
	public String mType = "android-container";

	// os
	public String mOs = "android4.0";

	// 新版本名称
	public String mNewVerName = "";

	// 新版本号
	public int mNewVerCode = -1;

	public String APK_NAME = "gf_android_app.apk";
	public String mDownDir;

	// 已下载的文件大小
	private long mFileSize = 0;
	
	// 文件总大小
	private long mTotalReadSize;
	
	// 文件下载地址
	private String mUrl;
	
	public UpdateVersion(Context context) {
		mContext = context;
		init();
	}
	
	public void setCallback(Callback callback) {
		mCallback = callback;
	}
	
	public void init() {
		mDownDir = Environment.getExternalStorageDirectory() + "";
	}
	
	public void begin() {
		mCurVersion = getVerName(mContext);
		Log.v(TAG, "mCurVerName: " + mCurVersion);
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "result: " + result);
				try {
					JSONObject resultJson = new JSONObject(result);
					JSONObject dataJson = resultJson.getJSONObject("data");
					JSONObject contentJson = dataJson.getJSONObject("content");
					JSONArray contentUrls = contentJson.getJSONArray("urls");
					String contentUrl = contentUrls.getString(0);
					mUrl = contentUrl;
					String contentVersion = contentJson.getString("version");
					mNewVersion = contentVersion;
					if (!mCurVersion.equals(mNewVersion)) {
						mCallback.findNewVersion(mCurVersion, mNewVersion);
					}
					Log.v(TAG, "contentUrl: " + contentUrl);
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};

		visitServer(callback);
	}
	
	/**
	 * 获得版本名称
	 */
	private String getVerName(Context context) {
		String verName = "";
		try {
			verName = context.getPackageManager().getPackageInfo(BaseApplication.APP_PACKAGE_NAME, 0).versionName;
		} catch (Exception e) {
			Log.e("版本名称获取异常", e.getMessage());
		}
		return verName;
	}
	
	/**
	 * 访问服务器，检测是否有更新
	 * @param callback
	 */
	private void visitServer(NetWorkCallBack callback) {
		JSONObject reqBodyJson = new JSONObject();

		try {
			reqBodyJson.put("app", mApp);
			reqBodyJson.put("type", mType);
			reqBodyJson.put("containerVer", mCurVerCode);
			reqBodyJson.put("contentVer", mCurVersion);
			reqBodyJson.put("os", mOs);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		String reqBodyStr = reqBodyJson.toString();

		HttpManager httpManager = HttpManager.getInstance();
		httpManager.visitNetWorkPostHttp(HttpManager.CHECK_NEW_VERSION,	reqBodyStr, callback);
	}
	
	/**
	 * 下载文件
	 * @param url
	 */
	public void downFile() {
        new Thread(){
			public void run() {
            	Log.v(TAG, "downFile");
            	mCallback.beginDownload();
                HttpClient client = new DefaultHttpClient();
                HttpGet get = new HttpGet(mUrl);
                HttpResponse response;
                try {
					response = client.execute(get);
					HttpEntity entity = response.getEntity();
										
					mTotalReadSize = entity.getContentLength();
					
					InputStream is = entity.getContent();
					FileOutputStream fileOutputStream = null;
					if (is != null) {
						File file = new File(mDownDir, APK_NAME);
						Log.v(TAG, "dir: " + mDownDir);
						fileOutputStream = new FileOutputStream(file);
						byte[] b = new byte[1024];
						int charb = -1;
						int progress = 0;
						while ((charb = is.read(b)) != -1) {
							fileOutputStream.write(b, 0, charb);
							mFileSize += charb;
							int newValue = (int)(mFileSize * 100 / mTotalReadSize);
							Log.v(TAG, "value: " + newValue);
							if (newValue - progress > 3) {
								progress = newValue;
								Log.v(TAG, "update");
								mCallback.updateProgress(progress);
							}
						}
					}
                    fileOutputStream.flush();
                    if(fileOutputStream!=null){
                        fileOutputStream.close();
                    }
                    Log.v(TAG, "downFile end");
                    mCallback.downLoadSuccess();
                    
                }  catch (Exception e) {
                    e.printStackTrace();
                    mCallback.downError();
                }
            }
        }.start();
    }
	
	
	public interface Callback {
		public void findNewVersion(String curVersion, String newVersion);
		public void beginDownload();
		public void updateProgress(int progress);
		public void downLoadSuccess();
		public void downError();
	}
	
}
