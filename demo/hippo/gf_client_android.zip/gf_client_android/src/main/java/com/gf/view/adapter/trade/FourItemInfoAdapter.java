package com.gf.view.adapter.trade;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.viewmodel.ebiz.trade.FourItemInfo;

/**
 * 通用四项信息
 *
 */
public class FourItemInfoAdapter extends BaseAdapter {

	private LayoutInflater mLayoutInflater;
	private List<FourItemInfo> mItems;
	
	public FourItemInfoAdapter(Context context, List<FourItemInfo> items) {
		mItems = items;
		mLayoutInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		if (mItems != null) {
			return mItems.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		final FourItemInfo info = mItems.get(position);
		final ViewHolder holder;
		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.trade_query_common_list_item, null);
			holder = new ViewHolder();
			
			holder.tvOne = (TextView) view.findViewById(R.id.tv_one);
			holder.tvTwo = (TextView) view.findViewById(R.id.tv_two);
			holder.tvThree = (TextView) view.findViewById(R.id.tv_three);
			holder.tvFour = (TextView) view.findViewById(R.id.tv_four);
			
			view.setTag(R.id.layout_common_info, holder);
		} else {
			holder = (ViewHolder) view.getTag(R.id.layout_common_info);
		}
		
		if (info != null) {
			holder.tvOne.setText(info.one);
			holder.tvTwo.setText(info.two);
			holder.tvThree.setText(info.three);
			holder.tvFour.setText(info.four);
		}
		
		return view;
	}
	
    class ViewHolder {
    	TextView tvOne;
    	TextView tvTwo;
    	TextView tvThree;
    	TextView tvFour;
    }

}
