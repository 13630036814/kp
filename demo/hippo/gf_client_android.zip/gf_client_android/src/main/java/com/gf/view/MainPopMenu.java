/**
 * 
 */
package com.gf.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

import com.gf.client.R;
import com.gf.view.widget.BottomToolBar;

/**
 * 主菜单的弹出选项
 * @author cola
 *
 */
public class MainPopMenu extends BottomToolBar{
	public MainPopMenu(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
//		LayoutInflater.from(context).inflate(R.layout.bottom_menu, this);
	}

	public MainPopMenu(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
	}
	
	public View getView(){
		return LayoutInflater.from(context).inflate(R.layout.onlymainpopmenu, this);
	}
}
