/**
 * 
 */
package com.gf.viewmodel.bean;

import com.gf.viewmodel.util.AFloat;

/**
 * @author Cola
 * 
 */
public class DataSetKLine {
	public float mMaxVaol;
	public Long[] kTime;
	public float[] kYClose; // 昨日收盘
	public float[] kOpen; // 开盘价格
	public float[] kClose; // 收盘价格
	public float[] kZgcj; // 最高价格
	public float[] kZdcj; // 最低价格
	public float[] kCjss; // 成交数量
	public float[] kCjje; // 成交金额
	public  float[] Cjjj = null; // 成交均价

	public short kCount; // K线个数
	public byte retCycle; // 周期

	public float kMaxTech; // 技术指标最大值 计算出来的
	public float kMinTech; // 技术指标最小值 计算出来的

	public String wMarketID; // 板块
	public String pszCode; // 代码

	public float[] kZd; // 涨跌幅 计算出来的
	public float[] kZdf; // 涨跌幅 计算出来的
	public float kMA[][]; // 三个移动平均线 计算出来的
	public float kTech[][]; // 三个技术指标值 计算出来的

	/**
	 * 计算各类指标
	 */
	public void Calculation(int count, int cycle_5, int cycle_10, int cycle_30) {
		kZd = new float[count]; // 涨跌
		kZdf = new float[count]; // 涨跌幅
		kMA = new float[3][count]; // 三个移动平均线
		kTech = new float[3][count]; // 三个技术指标值

		calc_close_ma(count, cycle_5, cycle_10, cycle_30);
		calc_vol_ma(count, cycle_5, cycle_10, cycle_30);
		calc_change_percent(count);
		calc_max_min(count);

//		 mMaxVaol = Math.max(0.0f, kCjss[0]);
	}

	void calc_close_ma(int count, int cycle_5, int cycle_10, int cycle_30) {

		float total_5 = 0;
		float total_10 = 0;
		float total_30 = 0;
		for (int i = 0; i < count; i++) {
			// int nDigit = kClose[i].nDigit;
			total_5 += kClose[i];
			total_10 += kClose[i];
			total_30 += kClose[i];
			if (i >= cycle_5) {
				total_5 -= kClose[i - cycle_5];
				kMA[0][i] = total_5 / cycle_5;
			} else {
				kMA[0][i] = 0;// new AFloat((float) 0, nDigit, AFloat.NUMBER);
			}

			if (i >= cycle_10) {
				total_10 -= kClose[i - cycle_10];
				kMA[1][i] = total_10 / cycle_10;

			} else {
				kMA[1][i] = 0;// new AFloat((float) 0, nDigit, AFloat.NUMBER);
			}

			if (i >= cycle_30) {
				total_30 -= kClose[i - cycle_30];
				kMA[2][i] = total_30 / cycle_30;
			} else {
				kMA[2][i] = 0;// new AFloat((float) 0, nDigit, AFloat.NUMBER);
			}
		}
	}

	void calc_vol_ma(int count, int cycle_5, int cycle_10, int cycle_30) {
		double total_5 = 0.0;
		double total_10 = 0.0;
		double total_30 = 0.0;
		for (int i = 0; i < count; i++) {
			int nDigit = 1;
			total_5 += kCjss[i];
			total_10 += kCjss[i];
			total_30 += kCjss[i];
			if (i >= cycle_5) {
				total_5 -= kCjss[i - cycle_5];
				kTech[0][i] = (float) (total_5 / cycle_5);
			} else {
				kTech[0][i] = 0;// new AFloat((float) 0, nDigit, AFloat.NUMBER);
			}

			if (i >= cycle_10) {
				total_10 -= kCjss[i - cycle_10];
				kTech[1][i] = (float) (total_10 / cycle_10);
			} else {
				kTech[1][i] = 0;// new AFloat((float) 0, nDigit, AFloat.NUMBER);
			}

			if (i >= cycle_30) {
				total_30 -= kCjss[i - cycle_30];
				kTech[2][i] = (float) (total_30 / cycle_30);
			} else {
				kTech[2][i] = 0;// new AFloat((float) 0, nDigit, AFloat.NUMBER);
			}
		}
	}

	/**
	 * 计算涨跌幅
	 * 
	 * @param count
	 */
	void calc_change_percent(int count) {
		for (int i = 0; i < count; i++) {
			kZd[i] = kClose[i] - kYClose[i];
			kZdf[i] = (kClose[i] - kYClose[i]) / kYClose[i] * 100;
		}
	}

	void calc_max_min(int count) {
		if (count < 1)
			return;

		float maxTech = 0;
		float minTech = Float.MAX_VALUE;
		for (int i = 0; i < count; i++) {
			maxTech = Math.max(maxTech, kTech[0][i]);
			maxTech = Math.max(maxTech, kTech[1][i]);
			maxTech = Math.max(maxTech, kTech[2][i]);

			if (kTech[0][i] > 0)
				minTech = Math.min(minTech, kTech[0][i]);
			if (kTech[1][i] > 0)
				minTech = Math.min(minTech, kTech[1][i]);
			if (kTech[2][i] > 0)
				minTech = Math.min(minTech, kTech[2][i]);
		}

		kMaxTech = maxTech;
		kMinTech = minTech;
	}

}
