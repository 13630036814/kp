/**
 * 
 */
package com.gf.viewmodel.bean;

import android.util.Log;

/**
 * 本地画分时需要的数据结构
 * @author Cola
 *
 */
public class TimeSeriesQuoteCache {
	public float nZrsp = 0; // 昨收
	/**
	 * 最高成交 
	 */
	public  float nJJZgcj = 0; // 
	/**
	 * 最低成交
	 */
	public  float nJJZdcj = 0; // 
	/**
	 * 均线类型
	 */
	public short retStockBk = 1;
	/**
	 * 成交总量
	 */
	public  float sunVolume=0;
	/**
	 * 成交量
	 */
	public  float volume[]=null;
	public  long[]    nTime = null; // 采样的时间点
	/**
	 * 昨收价
	 */
	public Float pclose = 0f;
	/**
	 * 开盘价
	 */
	public Float open = 0f;
	/**
	 * 成交价
	 */
	public float[] Zjcj = null; // 
	/**
	 * 成交均价
	 */
	public float[] Cjjj = null; // 
	public String stockName = "";
	public float maxPrice = 0, minPrice = 0,maxVolume = 0,maxRise = 0,minRise = 0;
	
	public void CalcMaxMinPirc(int nCount)
	{	
		if (nCount < 1 || Cjjj == null)
			return;
		
		
		 nJJZgcj = 0;
		 nJJZdcj = Cjjj[0];

		for (int i = 0; i < nCount; i++) 
		{
//			mFloator.init(Cjjj[i]);
			nJJZgcj = Math.max(nJJZgcj, Cjjj[i]);
//			if(Cjjj[i] != 0)
			nJJZdcj = Math.min(nJJZdcj, Cjjj[i]);
//			Log.e("Calc", Cjjj[i] + "");
		}
//		Log.e("CalcMaxMinPirc", nJJZdcj + "");
//		mFloator.init(Cjjj[0]);

//		nJJZgcj = new AFloat(maxTech, mFloator.nDigit, AFloat.get_units(maxTech));
//		nJJZdcj = new AFloat(minTech, mFloator.nDigit, AFloat.get_units(minTech));
	}
}
