package com.gf.control;

import java.util.ArrayList;


import com.gf.client.R;
import com.gf.data.sqlite.GfClientSqliteOpenHelper;
import com.gf.viewmodel.bean.IconItem;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ListView;
import android.widget.TextView;

public class CustomPageEdit extends Activity {
	private ArrayList<IconItem> mCustomPageData = null;
	private ListView mListView = null;
	private Button mBtnSave;
	private Button mBtnCancel;
	private GfClientSqliteOpenHelper mSqliteHelper = null;
	ProgressDialog mProgressDialog = null;
	
	private static final int SAVE_END_MSG = 1;
	private static final int BEGIN_SAVE_MSG = 2;
	private static final int MSG_QUERY_END = 3;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.custom_page_edit);
		findView();
		setListener();
		init();
	}
	
	private void init() {
		mSqliteHelper = GfClientSqliteOpenHelper.getInstance(this);
		/*
		ViewAdapter viewAdapter = new ViewAdapter(this, mCustomPageData);
		mListView.setAdapter(viewAdapter);*/
		queryData();
	}
	
	private void findView() {
		mListView = (ListView)findViewById(R.id.list_view_items);
		mBtnSave = (Button)findViewById(R.id.btn_save);
		mBtnCancel = (Button)findViewById(R.id.btn_cancel);
	}
	
	private void setListener() {
		mBtnSave.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				saveChange();
			}
		});
		
		mBtnCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				finish();
			}
		});
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			setResult(MainActivity.CUSTOM_PAGE_ACTIVITY_RESULT);
			finish();
			break;
		}

		return false;
	}
	
	/**
	 */
	private void saveChange() {
		mProgressDialog = ProgressDialog.show(
				this, "正在保存数据...",
				"Please wait...", true, false);
		clearOldUserStock();
		
		new Thread() {
			public void run() {
				SQLiteDatabase db = mSqliteHelper.openDatabase();
				
				String insertsql = "insert or replace into "+GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE +" (" +
						"file_name, " +
						"title," +
						"class_name," +
						"package_name," +
						"select_flag) VALUES " +
						"(?,?,?,?,?)";
				
				db.beginTransaction();	   
			    SQLiteStatement stmt = db.compileStatement(insertsql);
				
				for (int i = 0; i < mCustomPageData.size(); i++) {
					IconItem iconItem = mCustomPageData.get(i);
					stmt.bindString(1, iconItem.getFileName());
					stmt.bindString(2, iconItem.getTitle());
					stmt.bindString(3, iconItem.getClassName());
					stmt.bindString(4, iconItem.getPackageName());
					stmt.bindString(5, iconItem.getSelectFlag());

					stmt.execute();
					stmt.clearBindings();
				}
				db.setTransactionSuccessful();
				db.endTransaction();
				mSqliteHelper.closeDatabase();
				
				Message msg = mHandler.obtainMessage();
				msg.what = SAVE_END_MSG;
				mHandler.sendMessage(msg);
			}
		}.start();
	}
	
	public void clearOldUserStock() {
		String sql = "DELETE FROM " + GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE + ";";
		SQLiteDatabase db = mSqliteHelper.openDatabase();
		db.execSQL(sql);
		revertSeq();
		mSqliteHelper.closeDatabase();
	}

	private void revertSeq() {
		String sql = "update sqlite_sequence set seq=0 where name='"
				+ GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE + "'";
		SQLiteDatabase db = mSqliteHelper.openDatabase();
		db.execSQL(sql);
		mSqliteHelper.closeDatabase();
	}
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case SAVE_END_MSG:
				if (mProgressDialog != null) {
					mProgressDialog.dismiss();
					mProgressDialog = null;
				}
				Intent intent = new Intent(CustomPage.CUSTOM_PAGE_DATA_CHANGED);
				CustomPageEdit.this.sendBroadcast(intent);
				finish();
				break;
			case BEGIN_SAVE_MSG:
				break;
			case MSG_QUERY_END:
				ViewAdapter viewAdapter = new ViewAdapter(CustomPageEdit.this, mCustomPageData);
				mListView.setAdapter(viewAdapter);
				break;
			default:
				break;
			}
		}
	};

	public void queryData() {
		
		new Thread() {
			public void run() {
				ArrayList<IconItem> selectData = new ArrayList<IconItem>();
				SQLiteDatabase db = mSqliteHelper.openDatabase();
				
				Cursor cursor;
				String tableName = GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE;
				String[] columns = new String[] {
						"file_name",
						"title",
						"class_name",
						"package_name",
						"select_flag",
				};
				
				cursor = db.query(tableName, columns, null,	null, null, null, null);
				
				int fileName = cursor.getColumnIndex("file_name");
				int title = cursor.getColumnIndex("title");
				int className = cursor.getColumnIndex("class_name");
				int packageName = cursor.getColumnIndex("package_name");
				int selectFlag = cursor.getColumnIndex("select_flag");
				
				for (cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()) {
					IconItem iconItem = new IconItem();
					/*if ((cursor.getString(selectFlag).equals("0"))) {
						continue;
					}*/
					iconItem.setFileName(cursor.getString(fileName));
					iconItem.setTitle(cursor.getString(title));
					iconItem.setClassName(cursor.getString(className));
					iconItem.setPackageName(cursor.getString(packageName));
					iconItem.setSelectFlag(cursor.getString(selectFlag));
					selectData.add(iconItem);
			    }
				mCustomPageData = selectData;
				mSqliteHelper.closeDatabase();
				
				Message msg = mHandler.obtainMessage();
				msg.what = MSG_QUERY_END;
				mHandler.sendMessage(msg);
			}
		}.start();
	}
	
	class ViewAdapter extends BaseAdapter {
		private Context mContext;
		private ArrayList<IconItem> mData;
		private LayoutInflater inflater = null;
		
		public ViewAdapter(Context context, ArrayList<IconItem> data) {
			mContext = context;
			mData = data;
			inflater = LayoutInflater.from(context);
		}
		
		@Override
		public int getCount() {
			return mData.size();
		}

		@Override
		public Object getItem(int arg0) {
			return mData.get(arg0);
		}

		@Override
		public long getItemId(int arg0) {
			return arg0;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
	        ViewHolder holder = null;
	            if (convertView == null) {
	            // 获得ViewHolder对象
	            holder = new ViewHolder();
	            // 导入布局并赋值给convertview
	            convertView = inflater.inflate(R.layout.custom_page_edit_item, null);
	            holder.tv = (TextView) convertView.findViewById(R.id.item_tv);
	            holder.cb = (CheckBox) convertView.findViewById(R.id.item_cb);
	            
	            holder.cb.setOnCheckedChangeListener(new OnCheckedChangeListener() {
					@Override
					public void onCheckedChanged(CompoundButton arg0, boolean isChecked) {
						if (isChecked) {
							mData.get(position).setSelectFlag("1");
						} else {
							mData.get(position).setSelectFlag("0");
						}
					}
				});
	            
	            // 为view设置标签
	            convertView.setTag(holder);
			} else {
				// 取出holder
				holder = (ViewHolder) convertView.getTag();
			}

	        // 设置list中TextView的显示
	        holder.tv.setText((String)(mData.get(position).getTitle()));
	        // 根据isSelected来设置checkbox的选中状况
	        String selectFlagStr = (String)(mData.get(position).getSelectFlag());
	        boolean selectFlag = false;
	        
	        if (selectFlagStr.equals("1")) {
	        	selectFlag = true;
	        }
	        holder.cb.setChecked(selectFlag);
	        
	        return convertView;
	    }

	    	    
		public final class ViewHolder {
			public TextView tv;
			public CheckBox cb;
		}

	}
}
