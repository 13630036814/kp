package com.gf.control.trade.query.fragment;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.gf.client.R;
import com.gf.view.adapter.trade.MoneyAccountAdapter;
import com.gf.view.adapter.trade.StockAccountAdapter;
import com.gf.viewmodel.ebiz.trade.MoneyAccountInfo;
import com.gf.viewmodel.ebiz.trade.StockAccountInfo;

public class AssetQueryFragment extends Fragment {
	
	/** 账号资金 */
	private ListView moneyListView;
	private List<MoneyAccountInfo> moneyAccounts = new ArrayList<MoneyAccountInfo>();
	private MoneyAccountAdapter moneyAdapter;
	
	/** 股票持仓 */
	private ListView stockListView;
	private List<StockAccountInfo> stockAccounts = new ArrayList<StockAccountInfo>();
	private StockAccountAdapter stockAdapter;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//		return super.onCreateView(inflater, container, savedInstanceState);
		View view = inflater.inflate(R.layout.trade_query_asset, null);
		
		initData();
		initViews(inflater, view);
		
		return view;
	}
	
	private void initData() {
		if (!moneyAccounts.isEmpty()) {
			moneyAccounts.clear();
		}
		
		moneyAccounts.add(new MoneyAccountInfo("人民币 ", "126501.23", "02563288", "158964.86", "340523.26", "580964.96", "+2365.85"));
		moneyAccounts.add(new MoneyAccountInfo("港币 ", "135208.81", "02563288", "168496.23", "350325.62", "590496.35", "+2478.91"));
		moneyAccounts.add(new MoneyAccountInfo("美元 ", "2043.38", "02563288", "25639.49", "54923.11", "93704.02", "+381.58"));
		
		if (!stockAccounts.isEmpty()) {
			stockAccounts.clear();
		}
		
		stockAccounts.add(new StockAccountInfo("600000", "浦发银行", "400", "3523", "9.21"));
		stockAccounts.add(new StockAccountInfo("000135", "中国卫星", "526300", "583900", "13.58"));
		stockAccounts.add(new StockAccountInfo("600005", "武钢股份", "38589", "98100", "5.03"));
		stockAccounts.add(new StockAccountInfo("600000", "浦发银行", "400", "3523", "9.21"));
		stockAccounts.add(new StockAccountInfo("000135", "中国卫星", "526300", "583900", "13.58"));
		stockAccounts.add(new StockAccountInfo("600005", "武钢股份", "38589", "98100", "5.03"));
		stockAccounts.add(new StockAccountInfo("600000", "浦发银行", "400", "3523", "9.21"));
		stockAccounts.add(new StockAccountInfo("000135", "中国卫星", "526300", "583900", "13.58"));
		stockAccounts.add(new StockAccountInfo("600005", "武钢股份", "38589", "98100", "5.03"));
	}
	
	private void initViews(LayoutInflater inflater, View view){
		
		moneyListView = (ListView) view.findViewById(R.id.listView_account_money);
		moneyAdapter = new MoneyAccountAdapter(view.getContext(), moneyAccounts);
		moneyListView.setAdapter(moneyAdapter);
//		Utility.setListViewHeightBasedOnChildren(moneyListView);
		
		moneyListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				MoneyAccountAdapter adapter = (MoneyAccountAdapter) moneyListView.getAdapter();
				adapter.toggle(position);
			}
		});
		
		stockListView = (ListView) view.findViewById(R.id.listView_account_stock);
		stockAdapter = new StockAccountAdapter(view.getContext(), stockAccounts);
		stockListView.setAdapter(stockAdapter);
//		Utility.setListViewHeightBasedOnChildren(stockListView);
		
		stockListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// TODO ;
			}
		});
	}

}
