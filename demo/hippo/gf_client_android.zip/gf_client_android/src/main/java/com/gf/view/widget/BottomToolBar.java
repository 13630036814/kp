/**
 * 
 */
package com.gf.view.widget;

import com.gf.client.R;
import com.gf.control.MainActivity;
import com.gf.control.MarketQuotes;
import com.gf.control.Desktop.onChangeViewListener;
import com.gf.control.ServiceOnline;
import com.gf.control.trade.TradeLoginActivity;
import com.gf.view.anim.UgcAnimations;
import com.gf.viewmodel.base.FlipChildView;
import com.gf.viewmodel.util.View_Util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * 
 * @author cola
 * 
 */
public class BottomToolBar extends LinearLayout implements OnClickListener {
	private FlipChildView mFlipChildView;
	private boolean isShow = false;
	private Button mInformationMenu;
	private Button mMystockMenu;  // 
	private Button mMarketQuotes; 
	private Button mTradeCenter;
	private Button mBtnServiceOnline; // 在线客服
	private ImageView menu;
	private LinearLayout menu_lineOne;
	private RelativeLayout mPopMenuBk;
	private RelativeLayout mPopMenu;
	private TextView mMystock;
	private onChangeViewListener mOnChangeViewListener;
	private LinearLayout mMenuOut;

	public BottomToolBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
//		LayoutInflater.from(context).inflate(R.layout.bottom_menu, this);
	}

	protected Context context;

	public BottomToolBar(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
		

	}
	
	public View getView(){
		return LayoutInflater.from(context).inflate(R.layout.bottom_menu, this);
	}

	private void init() {

		menu = (ImageView) findViewById(R.id.bottom_menu);
		mMenuOut = (LinearLayout) findViewById(R.id.bottom_menu2);
		mInformationMenu = (Button) mPopMenu
				.findViewById(R.id.information_pop);
		mMystockMenu = (Button) mPopMenu.findViewById(R.id.mystock_pop);
		mMarketQuotes = (Button) mPopMenu.findViewById(R.id.marketQuotes_pop);
		mTradeCenter = (Button) mPopMenu.findViewById(R.id.ugc_bg);
		mBtnServiceOnline = (Button) mPopMenu.findViewById(R.id.btn_service_online);
		
		//底部功能菜单部分(自选股、买、卖)
		mMystock = (TextView) findViewById(R.id.bottom_mystock);
		if(mMystock != null){
			mMystock.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
//					mOnChangeViewListener.onChangeView(View_Util.mystock);
					((Activity) context).setResult(MainActivity.FLOAT_MENU_MYSTOCK);
					((Activity) context).finish();
				}
				
			});
		}
	}

	public void setListener() {
		// TODO Auto-generated method stub
		mInformationMenu.setOnClickListener(this);
		mMystockMenu.setOnClickListener(this);
		mMarketQuotes.setOnClickListener(this);
		mTradeCenter.setOnClickListener(this);
		mBtnServiceOnline.setOnClickListener(this);
		
		mMenuOut.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				if (menu_lineOne == null)
					return;
				if (!isShow) {
					isShow = true;
					UgcAnimations.startOpenAnimation(menu_lineOne, null, menu,
							10,mPopMenu);
				} else {
					isShow = false;
					UgcAnimations.startCloseAnimation(menu_lineOne, null, menu,
							10,mPopMenu);
				}
			}

		});
		
//		mPopMenu.setOnClickListener(new OnClickListener() {
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				
//				if (menu_lineOne == null)
//					return;
//				if (!isShow) {
//					isShow = true;
////					UgcAnimations.startOpenAnimation(menu_lineOne, null, menu,
////							10,mPopMenu);
//				} else {
//					isShow = false;
//					UgcAnimations.startCloseAnimation(menu_lineOne, null, menu,
//							10,mPopMenu);
//				}
//			}

//		});
	}

	public void setPopMenur(View mPopMenu) {
		this.mPopMenu = (RelativeLayout) mPopMenu;
		menu_lineOne = (LinearLayout) mPopMenu.findViewById(R.id.ugc_layout);
		
//		mPopMenuBk= (RelativeLayout) mPopMenu.findViewById(R.id.ugc_layout_bk);
		init();
		setListener();
	}

	/**
	 * 关闭Path菜单
	 */
	public void closeUgc() {
		if (menu_lineOne == null)
			return;
		isShow = false;
		Log.e("closeUgc", "close");
		UgcAnimations.startCloseAnimation(menu_lineOne, null, menu, 200,mPopMenu);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		if (v.equals(mInformationMenu)) {

			if (((Activity) context) instanceof MainActivity
					&& mOnChangeViewListener != null)
				mOnChangeViewListener.onChangeView(View_Util.Information);
			else {
				((Activity) context).setResult(2);
				((Activity) context).finish();
				
			}
		} else if (v.equals(mMystockMenu)) {
			if (((Activity) context) instanceof MainActivity
					&& mOnChangeViewListener != null)
				mOnChangeViewListener.onChangeView(View_Util.mystock);
			else {
				((Activity) context).setResult(1);
				((Activity) context).finish();
			}

		} else if (mMarketQuotes.equals(v)) {
			if (((Activity) context) instanceof MarketQuotes) {

			} else
				((Activity) context).startActivityForResult(new Intent(context,
						MarketQuotes.class), 2);
			
		} else if (mTradeCenter.equals(v)) {
			if (((Activity) context) instanceof TradeLoginActivity) {
				
			} else
				((Activity) context).startActivity(new Intent(context,TradeLoginActivity.class));
		} else if (mBtnServiceOnline.equals(v)) {
			/*
			Intent intent = new Intent();
			intent.setAction(Intent.ACTION_VIEW);
			intent.setData(Uri.parse("https://service.gf.com.cn/im/"));
			
			((Activity) context).startActivity(intent);*/
			((Activity) context).startActivity(new Intent(context, ServiceOnline.class));
		}
		closeUgc();
	}

	/**
	 * 
	 * @param onChangeViewListener
	 */
	public void setOnChangeViewListener(
			onChangeViewListener onChangeViewListener) {
		this.mOnChangeViewListener = onChangeViewListener;
	}
}
