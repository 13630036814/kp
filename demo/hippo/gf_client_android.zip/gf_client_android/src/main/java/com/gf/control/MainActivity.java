package com.gf.control;

import java.io.File;

import com.gf.client.R;
import com.gf.control.Desktop.onChangeViewListener;
import com.gf.hippo.domain.client.common.Event;
import com.gf.view.InformationMenu;
import com.gf.view.Sudoku;
import com.gf.view.widget.FlipperLayout;
import com.gf.view.widget.MarqueeInfo;
import com.gf.view.widget.MarqueeTextView;
import com.gf.view.widget.FlipperLayout.OnOpenListener;
import com.gf.viewmodel.base.LauncherModel;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.base.UpdateVersion;
import com.gf.viewmodel.util.View_Util;

import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends BaseWindow implements OnOpenListener,onChangeViewListener, UpdateVersion.Callback{
	/**
	 */
	public static final int FLOAT_MENU_MYSTOCK = 0X000001;
	/**
	 */
	public static final int FLOAT_MENU_STOCKINFO = 0X000002;
	
	/**
	 * 	其它activity返回 MainActivity
	 */
	public static final int FLOAT_ACTIVITYRESULT_CALL = 0X000003;
	public static final int CUSTOM_PAGE_ACTIVITY_RESULT = 0X000004;
	/**
	 * 网络状态
	 */
	public static final int FLOAT_ACTIVITYRESULT_NETWORK = 0X000005;
	
	/**
	 * 网络状态
	 */
	public static final int FLOAT_ACTIVITYRESULT_LISTSORT = 0X000006;
	private static final String TAG = "MainActivity";
	
	public static final int DIALOG_UPDATE_VERSION = 1;
	public static final int DIALOG_BEGIN_DOWNLOAD = 2;
	
	
	public static final int MSG_UPDATE_VERSION = 1;
	public static final int MSG_UPDATE_DOWNLOAD_PROGRESS = 2;
	public static final int MSG_BEGIN_DOWNLOAD = 3;
	public static final int MSG_DOWNLOAD_SUCCESS = 4;
	

	private FlipperLayout mRoot;
	private BaseApplication mApplication;
	private Desktop mDesktop;
	private CustomPage mCustomPage;
	private Sudoku sdk;
	private InformationMenu mInformationMenu;
	private LinearLayout newStock;
	
	private Button btnProPositive;
	private Button btnProNegative;
	
	/**
	 * 保存当前 float窗口的id
	 */
	private int mCodeCache = 0;
	
	public LauncherModel mClientMode;
	
	public String mDownUrl;
	
	private ProgressDialog mProgressDialog;
	
	private UpdateVersion mUpdateVersion;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.v(TAG, "onCreate");
//		setContentView(R.layout.activity_main);
		init();
		setListener();
		//checkUpdate();
		mUpdateVersion = new UpdateVersion(this);
		mUpdateVersion.setCallback(this);
		mUpdateVersion.begin();
		
	}

	public void init(){
		mApplication = (BaseApplication) getApplication();
		mClientMode = mApplication.getClientModel();
		mRoot = new FlipperLayout(this);
		LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT,
				LayoutParams.FILL_PARENT);
		mRoot.setLayoutParams(params);
		mDesktop = new Desktop(mApplication, this);	
		mCustomPage = new CustomPage(this);
		sdk = new Sudoku(this);
		sdk.setOnChangeViewListener(this);
		sdk.setOnOpenListener(this);
		mCodeCache = sdk.getID();
		
		mInformationMenu = new InformationMenu(
				MainActivity.this);
		mInformationMenu.setOnOpenListener(MainActivity.this);
		mInformationMenu.setOnChangeViewListener(this);
		
		//mRoot.addView(mDesktop.getView(), params);
		mRoot.addView(mCustomPage.getView());
		mRoot.addView(sdk.getView(), params);
		setContentView(mRoot);
		findView();
		windowInit();
	}
	
	private void findView(){
//		newStock = (LinearLayout) findViewById(R.id.desktop_top_newstock);
//		LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT,
//				LayoutParams.WRAP_CONTENT);
//		MarqueeTextView mtv = new MarqueeTextView(this);
//		mtv.setLayoutParams(params);
//		MarqueeInfo info = new MarqueeInfo();
//		info.code = "12345";
//		info.name = "上证股";
//		info.exGe = "68%";
//		info.ppGe = "344";
//		info.interval = -200;
//		info.color = Color.BLUE;
//		mtv.addView(info);
//		newStock.addView(mtv);
//		
//		MarqueeTextView mtv2 = new MarqueeTextView(this);
//		mtv2.setLayoutParams(params);
////		MarqueeInfo info = new MarqueeInfo();
//		info.code = "123453333";
//		info.name = "上证股大";
//		info.exGe = "68%";
//		info.ppGe = "34422";
//		info.interval = -180;
//		info.color = Color.RED;
//		mtv2.addView(info);
//		newStock.addView(mtv2);
		
//		new Handler().postAtTime(r, uptimeMillis);
	}
	
	@Override
	public void open() {
		// TODO Auto-generated method stub
		if (mRoot.getScreenState() == FlipperLayout.SCREEN_STATE_CLOSE) {
			mRoot.open();
		}
	}

	public void setListener() {
		/*mDesktop.setOnChangeViewListener(new onChangeViewListener() {

			@Override
			public void onChangeView(int arg0) {
				// TODO Auto-generated method stub
				switch (arg0) {
				case View_Util.Information:
					if (mInformationMenu == null) {
						mInformationMenu = new InformationMenu(
								MainActivity.this);
						mInformationMenu.setOnOpenListener(MainActivity.this);
					}
					mRoot.close(mInformationMenu.getView());
					break;

				case View_Util.main:
					mRoot.close(sdk.getView());
					break;
				case View_Util.mystock:
					mRoot.close(sdk.getView());
					break;
				}
			}

		});*/
	}
	
	public int orientation;
	public void windowInit() {
        //Global.density = getDensity();
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		//使用标准值
		//Global.density = dm.density;		
		Global.scale_w = 1;
		Global.scale_h = 1;
		Global.fullScreenWidth = dm.widthPixels;
		Global.fullScreenHeight = dm.heightPixels - Global.beginY;
		Global.HARD_WIDTH_PIXELS = 320;//dm.widthPixels;
		Global.HARD_HEIGHT_PIXELS = 480;//dm.heightPixels;		
		
		if (Global.fullScreenHeight >= Global.fullScreenWidth)
			{orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;}
		else
			{
			if(orientation!=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
//				StatService.onEvent(this, "8", "横屏");
			}
			orientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;}
		if (orientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
			Global.arg0 = Global.fullScreenWidth * 100 / Global.HARD_WIDTH_PIXELS;
			Global.arg1 = (Global.fullScreenHeight + Global.beginY) * 100 / Global.HARD_HEIGHT_PIXELS;
			Global.arg2 = Global.arg1;
			Global.scale_w = (float) Global.fullScreenWidth / Global.HARD_WIDTH_PIXELS;
			Global.scale_h = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_HEIGHT_PIXELS;
			Global.scale_h2 = Global.scale_h;
			Global.scale_icon = (float) Global.fullScreenWidth / Global.HARD_HEIGHT_PIXELS;
			// Globe.arg00 = Globe.fullScreenWidth*1000/480;
		} else {
			Global.arg0 = Global.fullScreenWidth * 100 / Global.HARD_WIDTH_PIXELS;
			Global.arg1 = (Global.fullScreenHeight + Global.beginY) * 100 / Global.HARD_HEIGHT_PIXELS;
			Global.arg2 = (Global.fullScreenHeight + Global.beginY) * 100 / Global.HARD_WIDTH_PIXELS;
			Global.arg3 = Global.fullScreenWidth * 100 / Global.HARD_HEIGHT_PIXELS;
			Global.scale_w = (float) Global.fullScreenWidth / Global.HARD_WIDTH_PIXELS;
			Global.scale_h = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_HEIGHT_PIXELS;
			Global.scale_h2 = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_WIDTH_PIXELS;
			Global.scale_icon = (float) (Global.fullScreenHeight + Global.beginY) / Global.HARD_HEIGHT_PIXELS;
		
		}
		Global.MK_Height = 48 * Global.arg2 / 100;
	}

	@Override
	public void onChangeView(int arg0) {
		// TODO Auto-generated method stub
		switch (arg0) {
		case View_Util.Information:
			mRoot.close(mInformationMenu.getView());
			mCodeCache = mInformationMenu.getID();
			break;
		case View_Util.mystock:
			mRoot.close(sdk.getView());
			mCodeCache = sdk.getID();
			break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		switch (resultCode) {
		case FLOAT_MENU_MYSTOCK:
			if(mCodeCache != sdk.getID())
			onChangeView(View_Util.mystock);
			sdk.update(FLOAT_ACTIVITYRESULT_CALL, resultCode);
			break;
		case FLOAT_MENU_STOCKINFO:
			onChangeView(View_Util.Information);
			mInformationMenu.update(FLOAT_ACTIVITYRESULT_CALL, resultCode);
			break;
		case CUSTOM_PAGE_ACTIVITY_RESULT:
			mCustomPage.update();
		case FLOAT_ACTIVITYRESULT_LISTSORT:
			sdk.update(FLOAT_ACTIVITYRESULT_LISTSORT, resultCode);
			break;
		default:
			switch(mCodeCache){
			case FLOAT_MENU_MYSTOCK:
//				onChangeView(View_Util.mystock);
				sdk.update(FLOAT_ACTIVITYRESULT_CALL, resultCode);
				break;
			case FLOAT_MENU_STOCKINFO:
//				onChangeView(View_Util.Information);
				mInformationMenu.update(FLOAT_ACTIVITYRESULT_CALL, resultCode);
				break;
			}
		break;
		}
	}
	
	public void bindData() {
		if (sdk != null) {
			sdk.refreshView();
		}
	}

	@Override
	public void onEvent(Event event) {
		// TODO Auto-generated method stub
		
	}
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case MSG_UPDATE_VERSION:
				showDialog(DIALOG_UPDATE_VERSION);
				break;
			case MSG_UPDATE_DOWNLOAD_PROGRESS:
				mProgressDialog.setProgress(msg.arg1);
				break;
			case MSG_BEGIN_DOWNLOAD:
				showDialog(DIALOG_BEGIN_DOWNLOAD);
				btnProPositive = mProgressDialog.getButton(DialogInterface.BUTTON_POSITIVE);
	            btnProNegative = mProgressDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
	            btnProPositive.setClickable(false);
	            btnProPositive.setEnabled(false);
				mProgressDialog.setProgress(0);
				break;
			case MSG_DOWNLOAD_SUCCESS:
				mProgressDialog.setTitle(R.string.down_end);
				btnProPositive.setClickable(true);
				btnProPositive.setEnabled(true);
	            break;
			}
			super.handleMessage(msg);
		}
		
	};
	
	protected Dialog onCreateDialog(int id) {
		switch(id) {
		case DIALOG_UPDATE_VERSION:
			String msgCurVersion = getString(R.string.cur_version) + mUpdateVersion.mCurVersion + "\n";
			String msgNewVersion = getString(R.string.new_version) + mUpdateVersion.mNewVersion + "\n";
			
			return new AlertDialog.Builder(MainActivity.this)
            .setTitle(R.string.prompt)
            .setMessage(msgCurVersion + msgNewVersion)
            .setPositiveButton(R.string.alert_dialog_update, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                	mUpdateVersion.downFile();
                }
            })
            .setNegativeButton(R.string.alert_dialog_cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                }
            })
            .create();
		case DIALOG_BEGIN_DOWNLOAD:
			mProgressDialog = new ProgressDialog(MainActivity.this);
            mProgressDialog.setTitle(R.string.down_new_version);
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            mProgressDialog.setMax(100);
            
            mProgressDialog.setButton(DialogInterface.BUTTON_POSITIVE,
                    getText(R.string.setup), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                	// 手动安装
		        	Log.v(TAG, "update");
		            Intent intent = new Intent(Intent.ACTION_VIEW);
		            intent.setDataAndType(Uri.fromFile(new File(mUpdateVersion.mDownDir, mUpdateVersion.APK_NAME)), "application/vnd.android.package-archive");
		            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		            startActivity(intent);
                }
            });
            mProgressDialog.setButton(DialogInterface.BUTTON_NEGATIVE,
                    getText(R.string.alert_dialog_cancel), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {

                }
            });
            
            return mProgressDialog;
		}
		return null;
	}

	@Override
	public void findNewVersion(String curVersion, String newVersion) {
		Log.v(TAG, "findNewVersion");
		Message msg = mHandler.obtainMessage();
		msg.what = MSG_UPDATE_VERSION;
		mHandler.sendMessage(msg);
	}

	@Override
	public void beginDownload() {
		Log.v(TAG, "beginDownload");
		Message msg = mHandler.obtainMessage();
		msg.what = MSG_BEGIN_DOWNLOAD;
		mHandler.sendMessage(msg);
		
	}

	@Override
	public void updateProgress(int progress) {
		Log.v(TAG, "updateProgress");
		Message msg = mHandler.obtainMessage();
		msg.what = MSG_UPDATE_DOWNLOAD_PROGRESS;
		msg.arg1 = progress;
		mHandler.sendMessage(msg);
	}
	
	
	@Override
	public void downLoadSuccess() {
		Log.v(TAG, "downLoadSuccess");
		Message msg = mHandler.obtainMessage();
		msg.what = MSG_DOWNLOAD_SUCCESS;
		mHandler.sendMessage(msg);
	}

	@Override
	public void downError() {
		Log.v(TAG, "downError");
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
		System.exit(0);
	}

	@Override
	public void netStatus(boolean status) {
		// TODO Auto-generated method stub
		if(mCodeCache == sdk.getID())
		sdk.update(FLOAT_ACTIVITYRESULT_NETWORK, status);
	}
}
