/**
 * 
 */
package com.gf.view;

import com.gf.client.R;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * @author cola
 * 
 */
public class StockitemDetail extends LinearLayout {
	private TimeSeriesQuoteCache mTimeSeriesQuoteCache;
	private TextView mOpen, mVolume, mTop, mLow;

	public StockitemDetail(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;

	public StockitemDetail(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	public void init() {
		LayoutInflater.from(context).inflate(R.layout.stockitem_detail, this);
		this.mOpen = (TextView) findViewById(R.id.minichar_open);
		this.mLow = (TextView) findViewById(R.id.minichar_low);
		this.mTop = (TextView) findViewById(R.id.minichar_top);
		this.mVolume = (TextView) findViewById(R.id.minichar_volume);
	}

	public void setData(TimeSeriesQuoteCache mTimeSeriesQuoteCache) {
		this.mTimeSeriesQuoteCache = mTimeSeriesQuoteCache;
		draw();
	}

	private void draw() {
		this.mOpen.setText(mTimeSeriesQuoteCache.open + "");
		this.mTop.setText(mTimeSeriesQuoteCache.maxPrice + "");
		this.mLow.setText(mTimeSeriesQuoteCache.minPrice + "");
		float volume = mTimeSeriesQuoteCache.sunVolume / 10000;
		
		this.mVolume.setText(String.format("%1$.2f", volume) + "万");
	}
}
