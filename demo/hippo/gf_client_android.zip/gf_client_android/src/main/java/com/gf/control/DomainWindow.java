/**
 * 
 */
package com.gf.control;

import java.text.SimpleDateFormat;

import android.util.Log;

import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.quote.CandleQuoteStreamItem;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.quote.TickQuoteStreamItem;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStreamItem;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.DataSetKLine;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;

/**
 * 基于域模型的数据 baseactivity
 * @author Cola
 *
 */
public abstract class DomainWindow extends BaseWindow{
	protected String mStockCode = "",mStockMarket = "";
	protected RealtimeQuoteItem quote;
	protected Stock stock;

	@Override
	public void onEvent(Event event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		
	}

	
	/**
	 * 重构成k线数据
	 * @param items
	 * @param maketid
	 * @param stockcode
	 * @return
	 */
	protected DataSetKLine reconsitution(CandleQuoteStreamItem[] items,String maketid, String stockcode){
		DataSetKLine dataSetKLine = new DataSetKLine();
		
		dataSetKLine.kCjje = new float[items.length];
		dataSetKLine.kClose = new float[items.length];
		dataSetKLine.kYClose = new float[items.length];
		dataSetKLine.kOpen = new float[items.length];
		dataSetKLine.kZgcj = new float[items.length];
		dataSetKLine.kTime = new Long[items.length];
		dataSetKLine.kCjss = new float[items.length];
		dataSetKLine.kZdcj = new float[items.length];
		dataSetKLine.Cjjj = new float[items.length];
		dataSetKLine.wMarketID = maketid;
		dataSetKLine.pszCode = stockcode;
		dataSetKLine.kCount = (short) items.length;
		dataSetKLine.mMaxVaol = items[0].getVolume();
//		SimpleDateFormat dateformat2=new SimpleDateFormat("yyyy-MM-dd");
//		int n = 0;
//		for (int i = items.length - 1; i >= 0; i--) {
		for (int n = 0; n < items.length; n++) {
			CandleQuoteStreamItem item = items[n];
			dataSetKLine.kZgcj[n] = item.getHigh();
			dataSetKLine.kCjss[n] = item.getVolume();
			dataSetKLine.kClose[n] = item.getClose();
			dataSetKLine.kOpen[n] = item.getOpen();
			dataSetKLine.kTime[n] = item.getTime();
			dataSetKLine.Cjjj[n] = item.getAvg();
	        
//			Log.e("k线",
//					"时间: " + dateformat2.format(new Date(item.getTime())) + " 顺序：i="  + " n =" + n);
			dataSetKLine.kYClose[n] = item.getPclose();
			dataSetKLine.kZdcj[n] = item.getLow();
			dataSetKLine.mMaxVaol = Math.max(dataSetKLine.mMaxVaol,item.getVolume());
//			n++;
		}
		
		dataSetKLine.Calculation(dataSetKLine.kCount, Global.getMacycle1(),Global.getMacycle2(),Global.getMacycle3());
		return dataSetKLine;
	}
	
	/**
	 * 重构成分时画图需要的数据
	 * @param items
	 */
	protected TimeSeriesQuoteCache reconsitution(TimeSeriesQuoteStreamItem[] items,String maketid, String stockcode){
		TimeSeriesQuoteCache timeSeriesQuoteCache = new TimeSeriesQuoteCache();
		
		timeSeriesQuoteCache.pclose = items[items.length - 1].getPclose();
		timeSeriesQuoteCache.Zjcj = new float[items.length];
		timeSeriesQuoteCache.Cjjj = new float[items.length];
		timeSeriesQuoteCache.volume = new float[items.length];
		timeSeriesQuoteCache.nTime = new long[items.length];
		timeSeriesQuoteCache.minPrice = items[0].getPrice();
//		Log.e("rise",
//		"价格: " + items.length);
		getTimeSeries(timeSeriesQuoteCache,maketid,stockcode);
		float sumPrice = 0,sumVolume = 0;
		long pre = items[0].getTime();
		for (int n = 0;  n < items.length; n++) {
			
			TimeSeriesQuoteStreamItem item = items[n];
			timeSeriesQuoteCache.Zjcj[n] = item.getPrice();
			//用来画多日分词均线
			if(!(pre + "").substring(0, 8).equals((item.getTime() + "").substring(0, 8))){
				sumPrice = 0;
				sumVolume = 0;
				pre = item.getTime();
			}
			//计算分词均线
			sumPrice += item.getAmount();
			sumVolume += item.getVolume();
			if(sumVolume == 0)
				timeSeriesQuoteCache.Cjjj[n] = item.getPrice();
			else
			timeSeriesQuoteCache.Cjjj[n] = sumPrice/sumVolume;
			
			timeSeriesQuoteCache.volume[n] = item.getVolume();
//			timeSeriesQuoteCache.volume += item.getVolume();
			timeSeriesQuoteCache.maxVolume = Math.max(item.getVolume(),
			timeSeriesQuoteCache.maxVolume);
			timeSeriesQuoteCache.nTime[n] = item.getTime();
			
			timeSeriesQuoteCache.maxRise = Math.max(item.getRise(),
					timeSeriesQuoteCache.maxRise);
			
			timeSeriesQuoteCache.minRise = Math.min(item.getRise(),
					timeSeriesQuoteCache.minRise);
//			if(item.getPrice() > 10.58)
//			Log.e("mHandlerStockList", "price: "
//					+ timeSeriesQuoteCache.Cjjj[n] + " time:  " + item.getTime() + "  "+ n);
			
			timeSeriesQuoteCache.maxPrice = Math.max(timeSeriesQuoteCache.maxPrice, item.getPrice());
			timeSeriesQuoteCache.minPrice = Math.min(timeSeriesQuoteCache.minPrice, item.getPrice());
//			timeSeriesQuoteCache.pclose = item.getPclose();
//			n++;
		}
		timeSeriesQuoteCache.CalcMaxMinPirc(timeSeriesQuoteCache.Zjcj.length);
		return timeSeriesQuoteCache;
	}
	
	protected TimeSeriesQuoteCache reconsitution(TickQuoteStreamItem[] items,String maketid, String stockcode){
		return null;
		
	}
	
	protected void getTimeSeries(TimeSeriesQuoteCache timeSeriesQuoteCache,
			String maketid, String stockcode) {
		if(quote == null || timeSeriesQuoteCache.Cjjj.length > 241) return;
		timeSeriesQuoteCache.maxPrice = quote.high;
		timeSeriesQuoteCache.minPrice = quote.low;
		timeSeriesQuoteCache.open = quote.open;
		timeSeriesQuoteCache.nZrsp = quote.pclose;
	}
}
