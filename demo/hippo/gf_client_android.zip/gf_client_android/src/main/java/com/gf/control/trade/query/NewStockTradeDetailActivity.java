package com.gf.control.trade.query;

import com.gf.client.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/**
 * 新股配号明细
 *
 */
public class NewStockTradeDetailActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_stock_trade_detail);
		
		((TextView)findViewById(R.id.tv_title)).setText("配号明细");
		((Button)findViewById(R.id.btn_right)).setVisibility(View.GONE);
		
		findViewById(R.id.btn_left).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}

}
