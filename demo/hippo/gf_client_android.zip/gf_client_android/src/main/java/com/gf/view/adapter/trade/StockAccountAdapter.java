package com.gf.view.adapter.trade;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.viewmodel.ebiz.trade.StockAccountInfo;

/**
 * 股票持仓信息
 *
 */
public class StockAccountAdapter extends BaseAdapter {

	private LayoutInflater mLayoutInflater;
	private List<StockAccountInfo> mStockAccounts;
	
	public StockAccountAdapter(Context context, List<StockAccountInfo> accounts) {
		mStockAccounts = accounts;
		mLayoutInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		if (mStockAccounts != null) {
			return mStockAccounts.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return mStockAccounts.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		final StockAccountInfo info = mStockAccounts.get(position);
		final ViewHolder holder;
		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.trade_query_asset_stock_item, null);
			holder = new ViewHolder();
			
			holder.tvStockCode = (TextView) view.findViewById(R.id.tv_stock_code);
			holder.tvStockName = (TextView) view.findViewById(R.id.tv_stock_name);
			holder.tvBalance = (TextView) view.findViewById(R.id.tv_stock_balance);
			holder.tvMaxMoney = (TextView) view.findViewById(R.id.tv_max_money);
			holder.tvBasePrice = (TextView) view.findViewById(R.id.tv_base_price);
			
			view.setTag(R.id.layout_asset_stock, holder);
		} else {
			holder = (ViewHolder) view.getTag(R.id.layout_asset_stock);
		}
		
		if (info != null) {
			holder.tvStockCode.setText(info.getStockCode());
			holder.tvStockName.setText(info.getStockName());
			holder.tvBalance.setText(info.getStockBalance());
			holder.tvMaxMoney.setText(info.getMaxMoney());
			holder.tvBasePrice.setText(info.getBasePrice());
		}
		
		return view;
	}
	
    class ViewHolder {
    	TextView tvStockCode; // 证券代码
    	TextView tvStockName; // 证券名称
    	TextView tvBalance; // 证券余额
    	TextView tvMaxMoney; // 可用余额
    	TextView tvBasePrice; // 成本价
    }

}
