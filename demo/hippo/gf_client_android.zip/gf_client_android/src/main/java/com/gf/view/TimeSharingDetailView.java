package com.gf.view;

import com.gf.control.BaseWindow;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;


public class TimeSharingDetailView extends View{
	protected BaseWindow application;
	private TimeSharingDetailChart mTSChart;
//	private MiniChart mMiniChart;
//	public StockTitleChart mTitleChart;
	
	private GestureDetector mGestureDetector;
    private OnGestureListener mOnGestureListener;
	private Bundle mExtras = new Bundle();
    private int mMatchId;    
    
    private String mStockName;
    private String mStockCode;
    private int    mStockMarket;
    private int    mStockIndex;
    private int    mStockType;
    
	public TimeSharingDetailView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.application = (BaseWindow) context;
		// TODO Auto-generated constructor stub
		init();
		intGesture();
		
		setFocusable(true);
		setClickable(true);		
	}
	
	public void init(){
		final int w = getWidth();//Global.fullScreenWidth;
		final int h = this.getHeight();//Global.fullScreenHeight;
		final int r = w - 90;//170
		final int top = 10;
//		final int bottom =h-50;
		int temp_bottom = h - 50;
		if (Global.BottomMenu_H > 35) {
			temp_bottom = temp_bottom - Global.BottomMenu_H + 25;
		}
		final int bottom = temp_bottom;
//		mTitleChart = new StockTitleChart(0,top,r,top+56);
		mTSChart = new TimeSharingDetailChart(0,0,w,h);
//		mMiniChart = new MiniChart(r+5,top,w,bottom);		
		mTSChart.setTarget(this);
//		mTSChart.setStockTitleChart(mTitleChart);
	}
	
	//设置当前证券，横竖屏切换时恢复，为兼容4.0
	public void setCurStock(String code,String name,int market,int index){
		mStockName = name;
		mStockCode = code;
		mStockMarket = market;
		mStockIndex = index;
//		mTitleChart.setStock(name, code);
	}	
	
	private void initDraw(){
		
		final int w = getWidth();
		final int h = getHeight() > 120 ? getHeight() : 120;//若不指定最小值,在联想手机上DrawTool.getDottedLine(volRect, false)会导致程序崩溃
//		Log.e("initDraw: ", h + "");
		final int top = 0;
		final int bottom =h-1;
		
		final int left = 1;
		
		final int title_height = 0;
		
//		mMiniChart.setLand(Global.isLandscape());
//		
//		if(mTitleChart.isRequestUpdate()){
//			mTitleChart.update();
//		}
//		if(mMiniChart.isRequestUpdate()){
//			mMiniChart.update();
//		}
		
		final int r = 100;//(int) (w - mMiniChart.getPortWidth());
				
//		mTitleChart.setFrame(0,top,Global.isLandscape()?r:w,top+title_height);
		if(mTSChart != null)
			mTSChart.setFrame(left,top,w,bottom);
//		mMiniChart.setFrame(r,Global.isLandscape()?top:mTitleChart.frame.bottom,w,bottom);
		
		if(mTSChart!=null && mTSChart.isRequestUpdate()){
			mTSChart.update();
		}		
	}
	
	private void intGesture(){
		mOnGestureListener=new OnGestureListener(){
			@Override
			public boolean onDown(MotionEvent e) {				
				invalidate();
				return false;
			}
			@Override
			public void onShowPress(MotionEvent e) {	
				
			}
			@Override
			public boolean onSingleTapUp(MotionEvent e) {
				
				return false;
			}
			@Override
			public boolean onScroll(MotionEvent e1, MotionEvent e2,
					float distanceX, float distanceY) {
				
				return false;
			}
			@Override
			public void onLongPress(MotionEvent e) {		
				
			}
			@Override
			public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
					float velocityY) {
				
				return false;
			}};
			
			mGestureDetector = new GestureDetector(mOnGestureListener);
	}
		
//	public void request(boolean isRefresh){
//		Req req = null;
//		boolean bShowDialog;
//		if(isRefresh && mTSChart.getDataSet()!=null)
//		{
//			bShowDialog = false;
//			application.startNetworkUi(bShowDialog);
//			StockRequest.reqFS(mStockMarket, mStockCode, mTSChart.getDataSet().mLastTime,true);
//		}
//		else
//		{
//			bShowDialog = true;
//			application.startNetworkUi(bShowDialog);
//		 StockRequest.reqFS(mStockMarket, mStockCode, 0,false);
//		}
//		
//	}

	public String getCurStockCode()
	{
		return this.mStockCode;
	}
	
	public String getCurStockName()
	{
		return this.mStockName;
	}
	
	public int getCurStockMarket()
	{
		return this.mStockMarket;
	}
	
	public int getCurStockType()
	{
		return this.mStockType;
	}	
	
	public int getCurStockIndex()
	{
		return this.mStockIndex;
	}
	
//	public boolean handleMessage(XMessage msg) {
//		final int event = msg.event;
//		Bundle extras = null;
//		if(msg.obj instanceof Bundle){
//			extras = (Bundle) msg.obj;
//		}
//
//		switch(event){
//		case Events.EVENT_ON_LOAD:
//			Intent intent = application.getIntent();
//			if(mStockName!=null && mStockCode!=null){
//				String stkName = intent.getStringExtra("stock_name");
//				String stkCode = intent.getStringExtra("stock_code");
//				int stkMarket = intent.getIntExtra("stock_market", 0);
//				int stkType = intent.getIntExtra("stock_type", 0);
//				if(stkName!=null && stkCode!=null){
//					mStockName = stkName;
//					mStockCode = stkCode;
//					mStockMarket = stkMarket;
//					mStockIndex = 0;
//					mStockType = stkType;
//					clear();
//					request(false);
//				}
//			}
//			break;
//		case Events.EVENT_ACCESS_PARA:
//		case Events.EVENT_ACCESS_PARA_DIALOG:
//			if(extras!=null){
//				mStockName = extras.getString("stock_name");
//				mStockCode = extras.getString("stock_code");
//				mStockMarket = extras.getInt("stock_market");
//				mStockIndex = extras.getInt("stock_index");
//				mStockType = extras.getInt("stock_type");
//			}
//
//			mTitleChart.setStock(mStockName, mStockCode);
//			if(event == Events.EVENT_ACCESS_PARA_DIALOG){
//				clear();
//				request(false);
//			}
//			break;		
//		case Events.EVENT_HQ_KX_CYCLE:
//			final int cycle = extras.getInt("kx_cycle");
//			StockRequest.reqKLine(mStockMarket, mStockCode, 0, cycle, 1000,false);
//			break;
//		case Events.EVENT_HQ_KX_CYCLE_F:
//			final int[] kcycles = {Business.KX_5MIN,Business.KX_15MIN,Business.KX_30MIN,Business.KX_60MIN};
//			final int cycle_f = kcycles[msg.cmd1];
//			StockRequest.reqKLine(mStockMarket, mStockCode, 0, cycle_f, 1000,false);
//			break;
//		case Events.EVENT_HQ_ZX_ADD:
//			int index = msg.cmd1;
//			
//			ZXInfo[] mystocks = StockPersistence.getInstance().getStocks(index);
//			ZXInfo[] savestocks = StockPersistence.getInstance().addStock(mystocks, mStockMarket, mStockCode, mStockName);
//			if(savestocks != mystocks){
//				StockPersistence.getInstance().saveMyStock(savestocks, index);	
//				if(application!=null)application.SyncMyStock(true);//同代码代码链
//				Toast.makeText(application, "添加成功", Toast.LENGTH_LONG).show();
//			}else{
//				Toast.makeText(application, "已经加入了自选股", Toast.LENGTH_LONG).show();
//			}
//			
//			break;
//		case Events.EVENT_HQ_ZX_ADD_EXIST:
//			Toast.makeText(application, "股票已存在", Toast.LENGTH_LONG).show();
//			break;
//		case Events.EVENT_HQ_ZX_ADD_SUCCESSFUL:
//			UiTools.showToast(application, "加入成功");
//			break;
//		case Events.EVENT_HQ_NEXT:
//			mStockIndex +=1;
//			if(StockPersistence.sPollingStocks != null){
//				if(mStockIndex>=StockPersistence.sPollingStocks.length){
//					mStockIndex = 0;
//				}
//				StockInfo so = StockPersistence.sPollingStocks[mStockIndex];				
//				mStockName = so.GetName();
//				mStockCode = so.GetCode();
//				mStockMarket = so.GetMarket();
//			}else if(StockPersistence.sPollingCodes!=null){
//				if(mStockIndex>=StockPersistence.sPollingCodes.length){
//					mStockIndex = 0;
//				}
//				mStockName = StockPersistence.sPollingNames[mStockIndex];
//				mStockCode = StockPersistence.sPollingCodes[mStockIndex];
//				mStockMarket = StockPersistence.sPollingMarkets[mStockIndex];
//			}
//			mStockType = -1;
//			mTitleChart.setStock(mStockName, mStockCode);
//			//onDisplay();
//			break;
//		case Events.EVENT_HQ_PREV:
//			mStockIndex -=1;
//			if(StockPersistence.sPollingStocks != null){
//				if(mStockIndex<0){
//					mStockIndex = StockPersistence.sPollingStocks.length-1;
//				}
//				StockInfo so = StockPersistence.sPollingStocks[mStockIndex];
//				mStockName = so.GetName();
//				mStockCode = so.GetCode();
//				mStockMarket = so.GetMarket();
//			}else if(StockPersistence.sPollingCodes!=null){
//				if(mStockIndex<0){
//					mStockIndex = StockPersistence.sPollingCodes.length-1;
//				}
//				mStockName = StockPersistence.sPollingNames[mStockIndex];
//				mStockCode = StockPersistence.sPollingCodes[mStockIndex];
//				mStockMarket = StockPersistence.sPollingMarkets[mStockIndex];
//			}
//			mStockType = -1;
//			mTitleChart.setStock(mStockName, mStockCode);
//			//onDisplay();
//			break;
//		}		
//		
//		return false;
//	}
	
	public void clear(){
		mTSChart.clear();
//		mMiniChart.clear();
//		mTitleChart.clear();
	}

//	public boolean handleData(Rsp rsp){
//	
//		final byte[] data = (byte[]) rsp.packet.mBodyBuffer;
//		if(data==null)return false;
//		
//		DataSetTimeSharing ds = new DataSetTimeSharing();	
//		boolean refreshall = false;
//		//Log.e("msg.packet.mVersion", "msg.packet.mVersion:"+msg.packet.mVersion);
//		ds.setCmdVersion(rsp.packet.mVersion);
//		int uuiq=StockTool.buildStockUUIQ(mStockMarket, mStockCode);
//		if(!StockTool.compareDataByUUIQ(rsp.packet.mBodyBuffer, uuiq)){
//			Log.e("证券内码对不上","uuiq:"+uuiq);
//			return false;//如果证券内码对不上，不处理
//		}
//		if(rsp.packet.mReserved == 1){//增量
//			
//			if(ds.Analysis(data,mTSChart.getDataSet())){
//				refreshall = true;
//			}
//		}else{
//			ds.Analysis(data,null);
//		}					
//		setDataSet(ds);
//		
//		if(refreshall){
//			StockRequest.reqFS(mStockMarket, mStockCode, 0,false);
//			StockRequest.reqKLine(mStockMarket, mStockCode, 0, Business.KX_DAY, 1000,false);
//		}
//	
//		Functions.removeCashe(application.bizId);		
//		Functions.putCashe(application.bizId, mTSChart.getDataSet());//分时数据进栈
//		Global.stockCode = this.mStockCode;
//		Global.stockName = this.mStockName;
//		Global.mStockMarket = this.mStockMarket;
//		Global.mStockIndex = this.mStockIndex;		
//		return true;
//	}

	public void setDataSet(TimeSeriesQuoteCache dataset){
		mTSChart.setDataSet(dataset);
//		mMiniChart.setDataSet(dataset);
//		mTitleChart.setDataSet(dataset);
//		KlineView.mTitleChart.setDataSet(dataset);
		this.postInvalidate();
	}
	
//	public boolean matchMessage(XMessage msg) {		
//		mMatchId = 0;
////		if(msg.match(Business.MF_HQ, Business.HQ_FS)){
////			mMatchId = 1;
////		}else if(msg.match(Business.MF_HQ, Business.HQ_KX)){
////			mMatchId = 2;
////		}
//		return mMatchId != 0;
//	}

	public Bundle getExtras() {		
		return mExtras;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		initDraw();
		//canvas.drawColor(0xff333333);
//		canvas.drawColor(0xFF000000);				
		canvas.save();		
		
		if(Global.isLandscape()){
			mTSChart.draw(canvas);
//			mMiniChart.draw(canvas);
		}else{
			mTSChart.draw(canvas);
//			mMiniChart.draw(canvas);		
		}			
//		mTSChart.draw2(canvas);
//		mTitleChart.draw(canvas);
		
		canvas.restore();
		
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		
		mGestureDetector.onTouchEvent(ev);
		int x = (int) ev.getX();
		int y = (int) ev.getY();
		boolean b = true;
		if(mTSChart.frame.contains(x, y)){		
			b = mTSChart.onTouchEvent(ev);
		}
		final int action = ev.getAction();
		//兼容1.6
		//switch(action & MotionEvent.ACTION_MASK){
		switch(action){
		case MotionEvent.ACTION_DOWN:
//			mMiniChart.touch((int)ev.getX(), (int)ev.getY());
			break;
		case MotionEvent.ACTION_UP:		
			
//			if(mMiniChart.clickChart((int)ev.getX(), (int)ev.getY()) && !Global.isLandscape()){
//				initDraw();
				mTSChart.update();
//			}
			invalidate();
			break;
		}
		if(!b) {
			this.performClick();
		}
			return true;
		
	}
	public TimeSharingDetailChart getmTSChart() {
		return mTSChart;
	}
	
	public TimeSeriesQuoteCache getDataSetTimeSharing(){
		return mTSChart.getDataSet();
	}
	
	public void update(){
		mTSChart.update();
	}
	
	public void setOnClickListener(boolean canClick){
		mTSChart.setOnClickListener(canClick);
	}
	
	/**
	 * 设置是否显示涨跌幅
	 * @param show
	 */
	public void setRiseShow(boolean show){
		mTSChart.setRiseShow(true);
	}
}
