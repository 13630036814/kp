package com.gf.viewmodel.util;

public interface IDialogEvent {
	public void onYes();
	public void onNo();
	public void onCancel();
	public void onOk();
}
