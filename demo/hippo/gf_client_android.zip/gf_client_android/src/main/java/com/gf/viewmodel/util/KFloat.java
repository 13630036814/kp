package com.gf.viewmodel.util;





/**
 * <p>Title: 一个整数模拟浮点数的封装</p>
 * <p>Description: KJava 平台</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 * 备忘：当把KFloat作为计算器时，不能在KFloat变量之间进行赋值‘=’，切记切记！
 */
public class KFloat {
    public final static int NUMBER = 0; //单位(个)
    public final static int TEN_THOUSAND = 1; //单位(万)
    public final static int HUNDRED_MILLION = 2; //单位(亿)
    //public static KFloat sub = new KFloat();
    public long longVlaue;
    public int nValue; //实际数值
    public int nDigit; //小数点位数
    public int nUnit; //单位
    private int format;//
    public KFloat() {
        this.nValue = 0;
        this.nDigit = 0;
        this.nUnit = NUMBER;
    }

    public KFloat(int nFloat) {
        this.nUnit = (nFloat & 0x00000003);
        this.nDigit = ((nFloat & 0x0000000C) >> 2);
        this.nValue = (nFloat >> 4);
    }
    public KFloat init(int nFloat){
        this.nUnit = (nFloat & 0x00000003);
        this.nDigit = ((nFloat & 0x0000000C) >> 2);
        this.nValue = (nFloat >> 4);
        return this;
    }
    public int float2int(){
      int v=(this.nValue<<4)&0xFFFFFFF0;
      v=v|(this.nDigit<<2)|this.nUnit;
      return v;
    }

    /**
     *
     * @param nValue
     * @param nDigit 小数点位数
     * @param nUnit 单位
     */
    public KFloat(int nValue, int nDigit, int nUnit) {
        this.nValue = nValue;
        this.nDigit = nDigit;
        this.nUnit = nUnit;
    }
    public void init(int nValue, int nDigit, int nUnit){
        this.nValue = nValue;
        this.nDigit = nDigit;
        this.nUnit = nUnit;
        //return this;
    }

    public KFloat(KFloat kFloat) {
        this.nValue = kFloat.nValue;
        this.nDigit = kFloat.nDigit;
        this.nUnit = kFloat.nUnit;
    }

    public int getDigitBase() {
        int nBase = 1;
        for (int i = 0; i < this.nDigit; i++) {
            nBase *= 10;
        }
        return nBase;
    }

    public void keepSame(KFloat end){
        if(this.nUnit == end.nUnit)return;
        if (this.nUnit > end.nUnit) {
            this.nValue *=Utils.pow(10,4*(this.nUnit-end.nUnit));//有溢出可能
            this.nUnit=end.nUnit;
        } else {
            this.nValue /=Utils.pow(10,4*(end.nUnit-this.nUnit)-1);
            int round=this.nValue%10;
            this.nValue /=10;
            if(round>=5)this.nValue +=1;
            this.nUnit=end.nUnit;
        }
        if (this.nDigit > end.nDigit) {
            this.nValue /=Utils.pow(10,(this.nDigit-end.nDigit)-1);
            int round=this.nValue%10;
            this.nValue /=10;
            if(round>=5)this.nValue +=1;
            this.nDigit=end.nDigit;

        }else if(this.nDigit < end.nDigit){
            this.nValue *=Utils.pow(10,end.nDigit-this.nDigit);//有溢出可能
            this.nDigit=end.nDigit;
        }
    }


    /**
     * 两个浮点数比较(假设小数点和单位都相等的情况下)
     */
    public static final int compare(KFloat val1, KFloat val2) {
        int nRtn = 0;
        //prepare(val1,val2,true);
        if (val1.nValue > val2.nValue)
            nRtn = 1;
        else if (val1.nValue < val2.nValue)
            nRtn = -1;
        return nRtn;
    }

    /**
     * 加运算(假设小数点和单位都相等的情况下)
     */
    public static final KFloat add(KFloat val1, KFloat val2) {
        prepare(val1,val2,true);
        return new KFloat((val1.nValue + val2.nValue), val1.nDigit, val1.nUnit);
    }
    public void add(KFloat val2){
      prepare(this,val2,true);
      this.nValue += val2.nValue;
    }

    /**
     * 减运算(假设小数点和单位都相等的情况下)
     */
    //public static final KFloat sub(KFloat val1, KFloat val2) {
    //  prepare(val1,val2,true);
    //  return new KFloat((val1.nValue - val2.nValue), val1.nDigit, val1.nUnit);
    //}
    public KFloat sub(KFloat f){
      prepare(this,f,true);
      this.nValue = this.nValue - f.nValue;
      return this;
    }
    public final KFloat singleSub(KFloat val1, KFloat val2){
      prepare(val1,val2,true);
      this.nValue = val1.nValue - val2.nValue;
      this.nDigit = val1.nDigit;
      this.nUnit = val1.nUnit;
      return this;
    }

    /**
     * 乘运算
     */
    public static final KFloat mul(KFloat val1, int val2) {
        return new KFloat((val1.nValue * val2), val1.nDigit, val1.nUnit);
    }
    public void mul(KFloat val2) {
        if(val2==null)return;
        int maxDigit=Math.max(this.nDigit,val2.nDigit);
        while (this.nUnit != val2.nUnit&&this.nUnit>0&&val2.nUnit>0) { //统一单位,向大单位靠
            if (this.nUnit > val2.nUnit) {
                val2.nUnit--;
                val2.nDigit -= 4;
            } else {
                this.nUnit--;
                this.nDigit -= 4;
            }
        }
        if(this.nDigit<0){
            this.nValue *=Utils.pow(10,-this.nDigit);
        }
        if(val2.nDigit<0){
            val2.nValue *=Utils.pow(10,-val2.nDigit);
        }

        long lValue1 = this.nValue;
        long lValue2 = val2.nValue;
        longVlaue = lValue1 * lValue2;

        this.nDigit += val2.nDigit;
        this.nUnit=Math.max(this.nUnit,val2.nUnit);
        while(this.nDigit!=maxDigit){
            if(this.nDigit>maxDigit){
                this.nDigit--;
                longVlaue /=10L;
            }else{
                this.nDigit++;
                longVlaue *=10L;
            }
        }
        if (longVlaue > (Integer.MAX_VALUE)) {
            System.out.println("浮点计算溢出");
        }
        this.nValue = (int) longVlaue;
    }


    public void mul(int val2) {
      this.longVlaue *=val2;
      this.nValue *=val2;
    }
    public void div(int val2) {
      this.longVlaue /=val2;
      this.nValue /=val2;
    }

    /**
     * 除运算(假设小数点和单位都相等的情况下)
     */
    public static final KFloat div(KFloat val1, int val2) {
        return new KFloat((val1.nValue / val2), val1.nDigit, val1.nUnit);
    }
    public static final KFloat div(KFloat val1, KFloat val2) {
        if(val2.nValue==0)return new KFloat();
        prepare(val1,val2,false);
        int i=val1.nValue / val2.nValue;
        int iMod = val1.nValue % val2.nValue;
        for(int t=0;t<val1.nDigit;t++){
            i=i*10+(iMod*10/val2.nValue);
            iMod = iMod*10%val2.nValue;
        }
        return new KFloat(i, val1.nDigit, val1.nUnit);//(val1.nValue / val2.nValue)
    }
    public void div(KFloat val2) {
      if(val2.nValue==0)return;
        prepare(this,val2,false);
        int i=this.nValue / val2.nValue;
        int iMod = this.nValue % val2.nValue;
        for(int t=0;t<this.nDigit;t++){
            i=i*10+(iMod*10/val2.nValue);
            iMod = iMod*10%val2.nValue;
        }
        this.nValue=i;
    }

    public static void prepare(KFloat val1, KFloat val2,boolean enlarge){
        while(val1.nDigit!=val2.nDigit){
            if(enlarge){
                if(val1.nDigit<val2.nDigit){
                    val1.nValue=val1.nValue*10;
                    val1.nDigit++;
                }else if(val1.nDigit>val2.nDigit){
                    val2.nValue=val2.nValue*10;
                    val2.nDigit++;
                }
            }else{
                if(val1.nDigit>val2.nDigit){
                    val1.nValue=val1.nValue/10;
                    val1.nDigit--;
                }else if(val1.nDigit<val2.nDigit){
                    val2.nValue=val2.nValue/10;
                    val2.nDigit--;
                }
            }

        }
    }

    public static int tenPow(int n){
        int v=1;
        for(int i=0;i<n;i++)v *=10;
        return v;
    }

    /**
     * 绝对值
     */
    public static final KFloat abs(KFloat ftValue) {
        if (ftValue.nValue < 0)
            return new KFloat((0 - ftValue.nValue), ftValue.nDigit,
                              ftValue.nUnit);
        else
            return new KFloat(ftValue.nValue, ftValue.nDigit, ftValue.nUnit);
    }

    /**
     * 最大值(假设小数点和单位都相等的情况下)
     */
    public static final KFloat max(KFloat val1, KFloat val2) {
        if (val1.nValue > val2.nValue)
            return new KFloat(val1.nValue, val1.nDigit, val1.nUnit);
        else
            return new KFloat(val2.nValue, val2.nDigit, val2.nUnit);
    }

    /**
     * 最小值(假设小数点和单位都相等的情况下)暂时没用到关闭
     */
    //public static final KFloat min(KFloat val1, KFloat val2) {
    //    if (val1.nValue < val2.nValue)
    //        return new KFloat(val1.nValue, val1.nDigit, val1.nUnit);
    //    else
    //        return new KFloat(val2.nValue, val2.nDigit, val2.nUnit);
    //}

    /**
     * 四舍五入
     * @param val 原始值
     * @param nDigit 小数点后需保留的位数
     * @return
     */
    public static final KFloat round(KFloat val, int nDigit) {
        if ((val.nDigit <= nDigit) || (nDigit < 0)) {
            return val;
        }
        int nHalfBase = 5;
        int nDigitBase = 10;
        for (int i = 1; i < (val.nDigit - nDigit); i++) {
            nHalfBase *= 10;
            nDigitBase *= 10;
        }
        if(val.nValue<0) nHalfBase *= -1;
        return new KFloat((val.nValue + nHalfBase) / nDigitBase, nDigit,val.nUnit);

    }

    public String toString(String ch){
        format = ch!=null?1:0;
        String s = toString()+ch;
        format = 0;
        return s;
    }

    
	@Override
	public String toString() {
        if(format == 0 && nValue == 0)return "---";
        StringBuffer strRtn = new StringBuffer(12);
        strRtn.append(this.nValue);
        int nLen = strRtn.length();
        int nPos = 0;
        if (this.nValue < 0) {
            nPos = 1;
        }
        if (this.nDigit > 0) {
            if ((nLen - nPos) > this.nDigit)
                strRtn.insert(nLen - this.nDigit, '.');
            else {
                strRtn.insert(nPos, "0.");
                while ((nLen - nPos) < this.nDigit) {
                    strRtn.insert(nPos + 2, '0');
                    nLen++;
                }
            }
        }
        switch (this.nUnit) {
        case TEN_THOUSAND: // 单位(万)
            strRtn.append("万");
            break;
        case HUNDRED_MILLION: //单位(亿)
            strRtn.append("亿");
            break;
        default:
            break;
        }
        return strRtn.toString();
    }
}
