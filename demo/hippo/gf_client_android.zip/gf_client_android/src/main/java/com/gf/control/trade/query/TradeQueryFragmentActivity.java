package com.gf.control.trade.query;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.control.trade.query.fragment.AssetQueryFragment;
import com.gf.control.trade.query.fragment.MoneyDetailQueryFragment;
import com.gf.control.trade.query.fragment.StockEntrustQueryFragment;
import com.gf.control.trade.query.fragment.StockTradeQueryFragment;

public class TradeQueryFragmentActivity extends FragmentActivity {

	private TextView tvTitle;
	private Button btnRight;
	private RelativeLayout layoutFilter;
	private FragmentTabHost mTabHost; // 资金查询、委托查询、成交查询、资金流水
	
	private boolean isDisplayFilterLayout = false;

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		setContentView(R.layout.trade_query_fragment);
		
		tvTitle = (TextView) findViewById(R.id.tv_title);
		tvTitle.setText("综合查询");
		
		btnRight = (Button) findViewById(R.id.btn_right);
		btnRight.setText("筛选");
		
		layoutFilter = (RelativeLayout) findViewById(R.id.layout_filter);
		layoutFilter.setVisibility(View.GONE);
		
		btnRight.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isDisplayFilterLayout = !isDisplayFilterLayout;
				if (isDisplayFilterLayout) {
					layoutFilter.setVisibility(View.VISIBLE);
					btnRight.setText("取消");
				} else {
					layoutFilter.setVisibility(View.GONE);
					btnRight.setText("筛选");
				}
			}
		});
		
		mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
//		mTabHost.setup(this, getSupportFragmentManager(), android.R.id.tabcontent);
		mTabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);
		
		mTabHost.addTab(mTabHost.newTabSpec("asset").setIndicator(getIndicatorView("资金查询")), AssetQueryFragment.class, null);
		mTabHost.addTab(mTabHost.newTabSpec("entrust").setIndicator(getIndicatorView("委托查询")), StockEntrustQueryFragment.class, null);
		mTabHost.addTab(mTabHost.newTabSpec("transaction").setIndicator(getIndicatorView("成交查询")), StockTradeQueryFragment.class, null);
		mTabHost.addTab(mTabHost.newTabSpec("detail").setIndicator(getIndicatorView("资金流水")), MoneyDetailQueryFragment.class, null);
		
	}
	
	private View getIndicatorView(String title) {
		View v = getLayoutInflater().inflate(R.layout.trade_query_tab_indicator, null);
		
		TextView tv = (TextView) v.findViewById(R.id.tv_title);
		tv.setText(title);
		
		return v;
	}
	
}
