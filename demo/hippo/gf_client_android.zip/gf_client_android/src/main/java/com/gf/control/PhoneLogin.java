package com.gf.control;

import org.json.JSONException;
import org.json.JSONObject;

import com.gf.client.R;
import com.gf.view.URLSpanNoUnderline;
import com.gf.viewmodel.base.HttpManager;
import com.gf.viewmodel.base.HttpManager.NetWorkCallBack;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.TypefaceSpan;
import android.text.style.URLSpan;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class PhoneLogin extends Activity {
	protected static final String TAG = "PhoneLogin";
	private EditText mEditTextPhoneNum;
	private Button mButtonLogin;
	private Button mSendMessage;
	private Button mButtonBack;
	private TextView mTextViewPrompt;
	private TextView mTextViewPromptContent1;
	private TextView mTextViewPromptContent2;
	private Button mBtnPromptContent2;
	
	
	private HttpManager mHttpManager;
	
	
	private static final int PHONE_NUM_HAVE_REGIST = 0;
	private static final int VERIFY_SUCCESS_MSG = 1;
	private static final int VERIFY_ERROR_MSG = 2;
	private static final int LOGIN_SUCCESS_MSG = 3;
	private static final int LOGIN_ERROR_MSG = 4;
	private static final int INPUT_WRONG_MSG = 5;
	
	private static final int SUCCESS = 0;
	private static final int ERROR = -1;
	
	private static final String SUCCESS_STR = "success";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.phone_login);
		findView();
		init();
		initView();
	}
	
	private void init() {
		mHttpManager = HttpManager.getInstance();
	}
	
	private void findView() {
		mEditTextPhoneNum = (EditText)this.findViewById(R.id.edit_phnoe_num);
		mButtonLogin = (Button)this.findViewById(R.id.btn_login);
		mButtonBack = (Button)this.findViewById(R.id.btn_back);
		mSendMessage = (Button)this.findViewById(R.id.btn_send_message);
		mTextViewPrompt = (TextView)findViewById(R.id.tv_prompt);
		mTextViewPromptContent1 = (TextView)findViewById(R.id.tv_prompt_content1);
		mTextViewPromptContent2 = (TextView)findViewById(R.id.tv_prompt_content2);
		//mBtnPromptContent2 = (Button)findViewById(R.id.btn_prompt_content2);
	}
	
	private void initView() {
		OnClickListener onClickListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (v.equals(mButtonLogin)) {
					// 登录
									
					String phoneNum = mEditTextPhoneNum.getText().toString();
					if (phoneNum == null || phoneNum.length() == 0) {
						Message msg = mHandler.obtainMessage();
						msg.what = INPUT_WRONG_MSG;
						mHandler.sendMessage(msg);
						return;
					}
					
					verifyPhoneNum(phoneNum);
					registPhoneNum(phoneNum);
				} else if (v.equals(mSendMessage)) {
					// 发送短信
					Uri smsUri = Uri.parse("mms:95575");
					Intent intent = new Intent(Intent.ACTION_SENDTO, smsUri);
					intent.putExtra("sms_body", "DB B");
					intent.putExtra(Intent.EXTRA_STREAM, smsUri);
					startActivity(intent);
				} else if (v.equals(mButtonBack)) {
					// 返回上一页
					Intent intent = new Intent(PhoneLogin.this, GfCommonLoginActivity.class);
					startActivity(intent);
					PhoneLogin.this.finish();
				}
			}
		};
		mButtonLogin.setOnClickListener(onClickListener);
		mButtonBack.setOnClickListener(onClickListener);
		mSendMessage.setOnClickListener(onClickListener);
		String promptContent1 = (String) mTextViewPromptContent1.getText();
		int colorBlue = getResources().getColor(R.color.prompt_blue);
		int colorRed = getResources().getColor(R.color.prompt_red);
		
		SpannableString spanString1 = new SpannableString(promptContent1);
		spanString1.setSpan(new ForegroundColorSpan(colorBlue), 13, 17, Spanned.SPAN_INCLUSIVE_INCLUSIVE);  //设置前景色为洋红色  
		spanString1.setSpan(new ForegroundColorSpan(colorRed), 32, 36, Spanned.SPAN_INCLUSIVE_INCLUSIVE);  //设置前景色为洋红色  
		spanString1.setSpan(new ForegroundColorSpan(colorRed), 42, 47, Spanned.SPAN_INCLUSIVE_INCLUSIVE);  //设置前景色为洋红色 
		
		Uri smsUri = Uri.parse("mms:95575");
		Intent intent = new Intent(Intent.ACTION_SENDTO, smsUri);
		intent.putExtra("sms_body", "hello");
		intent.putExtra(Intent.EXTRA_STREAM, smsUri);
		mTextViewPromptContent1.setText(spanString1); 
		
	}
	
	
	/**
	 * @param phoneNum
	 */
	public void verifyPhoneNum(String phoneNum) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "verifyPhoneNum result: " + result);
				JSONObject resultJson;
				try {
					resultJson = new JSONObject(result);
					String errorInfo = (String)resultJson.get("error_info");
					// 已经注册过广发通
					if (errorInfo.equals(SUCCESS_STR)) {
						Message msg = mHandler.obtainMessage();
						msg.what = PHONE_NUM_HAVE_REGIST;
						mHandler.sendMessage(msg);
					} else {
						
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};
		String value = "mobile=" + phoneNum;
		Log.v(TAG, "verifyPhoneNum value: " + value);
		mHttpManager.visitNetWorkGet(HttpManager.VERIFY_PHONE_NUM_URL, value, callback);
	}
	
	/**
	 * @param phoneNum
	 */
	public void registPhoneNum(final String phoneNum) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "registPhoneNum result: " + result);
				try {
					JSONObject resultJson = new JSONObject(result);
					//{"error_no":0,"password":"538dfb","error_info":"success"}
					int errorNo = (Integer)resultJson.get("error_no");
					String password = (String)resultJson.get("password");
					String errorInfo = (String)resultJson.get("error_info");
					
					if (errorNo == SUCCESS && errorInfo.equals(SUCCESS_STR)) {
						loginVerify(phoneNum, password);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};
		String value = "mobile=" + phoneNum;
		Log.v(TAG, "registPhoneNum value: " + value);
		mHttpManager.visitNetWorkGet(HttpManager.REGIST_PHONE_NUM_URL, value, callback);
	}
	
	/**
	 * 使用用户名和密码获取token
	 * @param username
	 * @param password
	 */
	private void loginVerify(final String username, final String password) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "loginVerify result: " + result);
				JSONObject resultJson;
				String token = null;
				try {
					resultJson = new JSONObject(result);
					String errorInfo = (String) (resultJson.get("error_info"));
					int errorNo = (Integer)(resultJson.get("error_no"));
					// 校验失败
					if (errorNo == ERROR) {
						Message msg = mHandler.obtainMessage();
						msg.what = VERIFY_ERROR_MSG;
						mHandler.sendMessage(msg);
					} else {
						JSONObject errorInfoJson = new JSONObject(errorInfo);
						token = (String) errorInfoJson.get("access_token");
						Log.v(TAG, "token: " + token);
						
						login(token);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};
		String value = "user_id=" + username + "&" + "password=" + password;
		mHttpManager.visitNetWorkPost(HttpManager.AUTH_USERNAME_PSD_URL, value, callback);
	}
	
	/**
	 * 使用token登陆
	 * @param accessToken
	 */
	private void login(String accessToken) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "login result: " + result);
				
				JSONObject resultJson;
				try {
					resultJson = new JSONObject(result);
					JSONObject portalJson = resultJson.getJSONObject("portal");
					String mobile = (String)portalJson.get("mobile");
					if (mobile != null) {
						Message msg = mHandler.obtainMessage();
						msg.what = LOGIN_SUCCESS_MSG;
						mHandler.sendMessage(msg);
					} else {
						Message msg = mHandler.obtainMessage();
						msg.what = LOGIN_ERROR_MSG;
						mHandler.sendMessage(msg);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				} 
			}
		};
		String postValue = "access_token=" + accessToken;
		mHttpManager.visitNetWorkGet(HttpManager.LOGIN_URL, postValue, callback);
	}
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case PHONE_NUM_HAVE_REGIST:
				Toast.makeText(PhoneLogin.this, "手机号已经注册过广发通", Toast.LENGTH_LONG).show();
				break;
			case LOGIN_SUCCESS_MSG:
				PhoneLogin.this.finish();
				Intent intent = new Intent(PhoneLogin.this, MainActivity.class);
				startActivity(intent);
				break;
			case LOGIN_ERROR_MSG:
			case VERIFY_ERROR_MSG:
				Toast.makeText(PhoneLogin.this, "用户名或密码错误", Toast.LENGTH_LONG).show();
				break;
			case INPUT_WRONG_MSG:
				Toast.makeText(PhoneLogin.this, "手机号不能为空", Toast.LENGTH_SHORT).show();
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			Intent intent = new Intent(PhoneLogin.this, GfCommonLoginActivity.class);
			startActivity(intent);
			finish();
			break;
		}

		return false;
	}
}
