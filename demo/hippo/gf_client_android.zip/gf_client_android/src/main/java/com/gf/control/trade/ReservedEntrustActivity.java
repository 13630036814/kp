package com.gf.control.trade;

import java.text.DecimalFormat;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.gf.client.R;

public class ReservedEntrustActivity extends Activity {

	private TextView tvTitle; // 可买数量 or 可卖数量
	private EditText txtStockCode; // 股票代码
	private ImageView ivDelete; // 删除
	private TextView tvStockName; // 股票名称
	private Button btnPosition; // 我的持仓

	private EditText txtPrice; // 股票价格
	private ImageButton ibtnAdd, ibtnSub; // 加减按钮
	private LinearLayout layoutWudang; // 五档行情控件

	private TextView lbMax; // 标签：可买数量 or 可卖数量
	private TextView tvMax; // 可买数量 or 可卖数量

	private TextView lbAmount; // 标签：买入数量 or 卖出数量
	private EditText txtAmount; // 买入数量 or 卖出数量

	private RadioGroup rg_rates; // 选择数量：全部、1/2、1/3、1/4、rb_rate_temp:
									// 处理点击事件作中间转换
	private RadioButton rb_rate_all, rb_rate_half, rb_rate_third, rb_rate_quarter, rb_rate_temp;

	private Button btnWudang; // 五档
	private Button submit; // 提交：买入 or 卖出

	/** 成员变量 **/
	private Integer mode = 0; // 0: 买入; 1: 卖出
	private Integer maxAmount = 8000; // 可买(卖)数量
	private boolean isWudangExpanding = false; // 五档行情是否打开

	/** 是否新股票 */
	private boolean isNewStock;
	/** 是否用户输入价格 */
	private boolean isUserInputPrice;
	/** 单选按键事件 */
	private boolean isRadioGroupEvent = true;
	/** 数量输入框事件 */
	private boolean isTxtAmountEvent = true;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.trade_reserved_entrust);
		initViews();
		initComponentEnvents();

		setConponentValueByMode(); // 买入/卖出 设置标签名

		tvMax.setText(maxAmount + "");
		txtAmount.setText("3000");
		if (txtStockCode.getText() != null && txtStockCode.getText().toString().trim().length() == 6) {
			tvStockName.setVisibility(View.VISIBLE);
			btnPosition.setVisibility(View.GONE);
		} else {
			tvStockName.setVisibility(View.GONE);
			btnPosition.setVisibility(View.VISIBLE);
		}
	}

	private void initViews() {
		tvTitle = (TextView) findViewById(R.id.tv_title);
		
		txtStockCode = (EditText) findViewById(R.id.txt_code);
		ivDelete = (ImageView) findViewById(R.id.iv_delete);
		tvStockName = (TextView) findViewById(R.id.tv_name);
		btnPosition = (Button) findViewById(R.id.btn_position);
		
		txtPrice = (EditText) findViewById(R.id.txt_price);
		ibtnSub = (ImageButton) findViewById(R.id.ibtn_sub);
		ibtnAdd = (ImageButton) findViewById(R.id.ibtn_add);

		layoutWudang = (LinearLayout) findViewById(R.id.layout_wudang);
		lbMax = (TextView) findViewById(R.id.lb_max);
		tvMax = (TextView) findViewById(R.id.tv_max);
		lbAmount = (TextView) findViewById(R.id.lb_amount);
		txtAmount = (EditText) findViewById(R.id.txt_amount);
		btnWudang = (Button) findViewById(R.id.btn_wudang);

		rg_rates = (RadioGroup) findViewById(R.id.rg_trade_rates);
		rb_rate_all = (RadioButton) findViewById(R.id.rb_trade_rate_all);
		rb_rate_half = (RadioButton) findViewById(R.id.rb_trade_rate_half);
		rb_rate_third = (RadioButton) findViewById(R.id.rb_trade_rate_third);
		rb_rate_quarter = (RadioButton) findViewById(R.id.rb_trade_rate_quarter);
		rb_rate_temp = (RadioButton) findViewById(R.id.rb_trade_rate_temp);

		submit = (Button) findViewById(R.id.btn_submit);
	}
	
	/**
	 * 初始化控件事件
	 */
	private void initComponentEnvents() {

		// 股票代码
		txtStockCode.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {
				String inputCode = txtStockCode.getText().toString().trim();
//				if (!StringUtils.isEmpty(inputCode) && Utils.isNum(inputCode) && inputCode.length() == 6) {
				
				tvStockName.setVisibility(View.GONE);
				btnPosition.setVisibility(View.VISIBLE);
				
				txtPrice.setText("0.00");
				tvMax.setText("0");
				txtAmount.setText("0");
				
				if (inputCode != null && !"".equals(inputCode)) {
					if (inputCode.length() == 6) {
//						if (isSanBan()) {
//							String codeHeand = inputCode.substring(0, 2);
//							if (!codeHeand.equalsIgnoreCase("43") && !codeHeand.equalsIgnoreCase("40")) {
//								showMessage("输入的是非三板股票，请重新输入股票代码！");
//								return;
//							}
//						}
						isNewStock = true;
						
//						query5Data();
						/** --- temporary data start --- **/
						txtPrice.setText("3.85");
						tvMax.setText("8000");
						txtAmount.setText("3000");
						/**  --- temporary data end --- **/
						
						tvStockName.setVisibility(View.VISIBLE);
						btnPosition.setVisibility(View.GONE);
					}
					ivDelete.setVisibility(View.VISIBLE);
				} else {
					ivDelete.setVisibility(View.GONE);
				}
			}
		});
		
		// 删除股票代码
		ivDelete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				txtStockCode.setText("");
				ivDelete.setVisibility(View.GONE);
				tvStockName.setVisibility(View.GONE);
				btnPosition.setVisibility(View.VISIBLE);
				
				txtPrice.setText("0.00");
				tvMax.setText("0");
				txtAmount.setText("0");
			}
		});

		// 初始化价格加减按钮
		ibtnAdd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isUserInputPrice = true;
				String priceStr = txtPrice.getText().toString().trim();
				int decimalLen;
				String formatStr = "#.00000";
				double value, decimal = 1;
				if (priceStr.length() == 0) {
					txtPrice.setText("1");
				} else if (priceStr.indexOf('.') == -1) {
					value = Double.valueOf(priceStr);
					value += decimal;
					txtPrice.setText(String.valueOf(value));
				} else {
					decimalLen = priceStr.length() - priceStr.indexOf('.') - 1;
					for (int i = 0; i < decimalLen; i++) {
						decimal = decimal / 10;
					}
					value = Double.valueOf(priceStr);
					value += decimal;
					formatStr = formatStr.substring(0, formatStr.indexOf('.') + 1 + decimalLen);
					DecimalFormat format = new DecimalFormat(formatStr);
					txtPrice.setText(format.format(value));
				}
			}
		});

		// 初始化价格加减按钮
		ibtnSub.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isUserInputPrice = true;
				String priceStr = txtPrice.getText().toString().trim();
				int decimalLen;
				double value, decimal = 1;
				String formatStr = "#.00000";
				if (priceStr.length() == 0) {
					showMessage("请输入价格");
				} else if (priceStr.indexOf('.') == -1) {
					value = Double.valueOf(priceStr);
					value -= decimal;
					txtPrice.setText(String.valueOf(value));
				} else {
					value = Double.valueOf(priceStr);
					decimalLen = priceStr.length() - priceStr.indexOf('.') - 1;
					for (int i = 0; i < decimalLen; i++) {
						decimal = decimal / 10;
					}
					value -= decimal;
					formatStr = formatStr.substring(0, formatStr.indexOf('.') + 1 + decimalLen);
					DecimalFormat format = new DecimalFormat(formatStr);
					txtPrice.setText(format.format(value));
				}
			}
		});
		
		// 买入数量 or 卖出数量
		txtAmount.addTextChangedListener(new TextWatcher() {
			@Override
			public void afterTextChanged(Editable s) {
				if (isTxtAmountEvent) {
					isRadioGroupEvent = false;
					rb_rate_temp.setChecked(true);
					isRadioGroupEvent = true;
				}
				
				if (txtAmount.getText() != null && !"".equals(txtAmount.getText().toString().trim())) {
					if (Double.valueOf(txtAmount.getText().toString()) > Double.valueOf(tvMax.getText().toString())) {
						String msg = "";
						if (mode == 0) {
							msg = "买入数量不能大于可买数量";
						} else {
							msg = "卖出数量不能大于可卖数量";
						}
						System.out.println(msg);
						showMessage(msg);
						return;
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			}
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			}
		});

		// 全部、1/2、1/3、1/4
		rg_rates.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				int amt = maxAmount;
				if (isRadioGroupEvent) {
					if (checkedId == rb_rate_quarter.getId()) {
						amt = maxAmount / 4;
					} else if (checkedId == rb_rate_third.getId()) {
						amt = maxAmount / 3;
					} else if (checkedId == rb_rate_half.getId()) {
						amt = maxAmount / 2;
					} else {
					}

					if (mode % 2 == 0) {// 买入：取数量100为单位
						amt = amt / 100 * 100;
					}

					isTxtAmountEvent = false;
					if (rb_rate_all.isChecked() || rb_rate_half.isChecked() || rb_rate_third.isChecked() || rb_rate_quarter.isChecked()) {
						txtAmount.setText(amt + "");
					}
					isTxtAmountEvent = true;
				}
			}
		});

		// 显示五档 or 隐藏五档
		btnWudang.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				if (isWudangExpanding) {
					layoutWudang.setVisibility(View.GONE);
					btnWudang.setText("显示五档");
					btnWudang.setBackgroundResource(R.drawable.wudang_btn_nor);
					isWudangExpanding = false;
				} else {
					layoutWudang.setVisibility(View.VISIBLE);
					btnWudang.setText("隐藏五档");
					if (mode % 2 == 0) {
						btnWudang.setBackgroundResource(R.drawable.wudang_btn_buy_sel);
					} else {
						btnWudang.setBackgroundResource(R.drawable.wudang_btn_sale_sel);
					}
					isWudangExpanding = true;
				}
			}
		});
	}

	/**
	 * 依据买卖方向设置控件的标签名
	 */
	private void setConponentValueByMode() {
		if (mode % 2 == 0) {
			tvTitle.setText("预约委托买入");
			tvTitle.setTextColor(0xFFe96c41);
			lbMax.setText("可买数量");
			tvMax.setTextColor(0xFFe96c41);
			lbAmount.setText("买入数量");
			submit.setText("买入");
			submit.setBackgroundColor(0xFFcb5d38);
		} else {
			tvTitle.setText("预约委托卖出");
			tvTitle.setTextColor(0xFF3a7be9);
			lbMax.setText("可卖数量");
			tvMax.setTextColor(0xFF3a7be9);
			lbAmount.setText("卖出数量");
			submit.setText("卖出");
			submit.setBackgroundColor(0xFF295cb5);
		}
	}

	/**
	 * 买卖切换
	 * 
	 * @param view
	 */
	public void change(View view) {
		if (mode == 0) {
			mode = 1;
			if (isWudangExpanding) {
				btnWudang.setBackgroundResource(R.drawable.wudang_btn_sale_sel);
			}
		} else {
			mode = 0;
			if (isWudangExpanding) {
				btnWudang.setBackgroundResource(R.drawable.wudang_btn_buy_sel);
			}
		}

		setConponentValueByMode();
	}

	private void showMessage(String string) {
		Toast.makeText(this, string, Toast.LENGTH_LONG).show();;
	}

}
