package com.gf.viewmodel.util;


import android.util.Log;


/**
 * 分时数据
 */
public class DataSetTimeSharing implements Cloneable
{
	public short retStockBk = 0;
	public  int   nDate = 0; // 分时数据日期
	
	/* 报盘数据 */
	public byte   stop; // 停牌标示 1为真 0为假
	public AFloat nZrsp = null; // 昨收
	public AFloat nJrkp = null; // 今日开盘
	public AFloat nZjcj = null; // 最近成交
	public AFloat nCjss = null; // 成交数量
	public AFloat nCjje = null; // 成交金额
	public AFloat price_average = null; // 成交均价
	public AFloat price_rate = null; // 5分钟涨跌幅
	public AFloat price_ratio = null; // 委比
	public AFloat base_pe = null; // 市盈率
	public AFloat volume_ratio = null; // 量比
	public AFloat volume_buy = null; // 买盘
	public AFloat volume_sell = null; // 卖盘
	public AFloat volume_turnover = null; // 换手率
	public  AFloat nZgcj = null; // 最高成交 
	public  AFloat nZdcj = null; // 最低成交 
	
	public  AFloat nJJZgcj = null; // 最高成交 
	public  AFloat nJJZdcj = null; // 最低成交 
	
	//cmd version >= 1
	public  AFloat  total_shares;       //总股本
	public  AFloat  negotiable_shares;  // 流通股本
	public  AFloat  net_assets_per_share; // 每股净资产

    //仅对上证指数和深圳指数有效 cmd version >= 1
    public short up;                 //上涨股票数统计
    public short down;               //下跌股票数统计
    public short nochange;           //不涨不跌股票数统计
    
    public AFloat net_profit_per_share; //每股净利润 cmd version >= 2
	
	//客户端计算
	public AFloat nZd = null; // 昨收
	public AFloat nZdf = null; // 今日开盘
	
	/* 买卖盘 */
	public  short  pkLen = 0;
	
	public  AFloat nSsjg[] = null; // 卖价
	public  AFloat nSss[] = null; // 卖量
	public  AFloat nBjg[] = null; // 买价
	public  AFloat nBss[] = null; // 买量


	/* 分时数据 */
	public  short    wCount = 0; // 总采样点数
	public  int[]    nTime = null; // 采样的时间点
	//public  AFloat[] Zjcj = null; // 成交价
	//public  AFloat[] Cjjj = null; // 成交均价
	//public  AFloat[] Cjss = null; // 成交量
	
	public  int[] Zjcj = null; // 成交价
	public  int[] Cjjj = null; // 成交均价
	public  int[] Cjss = null; // 成交量
	
	public  AFloat[] Zdf = null; // 涨跌幅  -算
	public  AFloat[] Zd = null;  // 涨跌  -算
	public  AFloat[] Cjje = null; // 成交金额
	/** 中焯协议用到的涨跌幅 */
	public String sZDF;
	/* 分笔数据 */
	public  short FBLen = 0;
	public  AFloat[][] fblistData; // 分笔数据
	public String[]   fbtime = null;
	public String[] fbState = null;
	
	public  AFloat nMaxVol = null; // 数据中最大成交量 //算
	
	public int       mLastTime;
	
	private int mCmdVersion;
	public DataSetTimeSharing()
	{
		FBLen = 0;
		wCount = 0; 
		pkLen = 0;
	}
	
	public DataSetTimeSharing(DataSetTimeSharing dts)
	{
		retStockBk = dts.retStockBk;
		nDate = dts.nDate; // 分时数据日期
		
		/* 报盘数据 */
		stop = dts.stop; // 停牌标示 1为真 0为假
		nZrsp = dts.nZrsp; // 昨收
		nJrkp = dts.nJrkp; // 今日开盘
		nZjcj = dts.nZjcj; // 最近成交
		nCjss = dts.nCjss; // 成交数量
		nCjje = dts.nCjje; // 成交金额
		price_average = dts.price_average; // 成交均价
		price_rate = dts.price_rate;       // 5分钟涨跌幅
		price_ratio = dts.price_ratio;     // 委比
		base_pe = dts.base_pe;             // 市盈率
		volume_ratio = dts.volume_ratio;   // 量比
		volume_buy = dts.volume_buy;       // 买盘
		volume_sell = dts.volume_sell;     // 卖盘
		volume_turnover = dts.volume_turnover; // 换手率
		
		/* 买卖盘 */
		pkLen = dts.pkLen;
		nSss = dts.nSss;    // 卖价
		nSsjg = dts.nSsjg;  // 买量
		nBjg = dts.nBjg;    // 买价
	    nBss = dts.nBss;    // 买量


		/* 分时数据 */
		wCount = dts.wCount; // 总采样点数
		nTime = dts.nTime;   // 采样的时间点
		Zjcj = dts.Zjcj;     // 成交价
		Cjjj = dts.Cjjj;     // 成交均价
		Cjss = dts.Cjss;     // 成交量
		Zdf = dts.Zdf;       // 涨跌幅 //算
		Cjje = dts.Cjje;     // 成交金额


		/* 分笔数据 */
		FBLen = dts.FBLen;
		fblistData = dts.fblistData; // 分笔数据
		fbtime = dts.fbtime;
		
		nZgcj = dts.nZgcj; // 最高成交 
		nZdcj = dts.nZdcj; // 最低成交 
		nMaxVol = dts.nMaxVol; // 数据中最大成交量 //算
	}
	
	public void setCmdVersion(int ver){
		mCmdVersion = ver;
	}
	
	public void dealloc()
	{
		retStockBk = 0;
		nDate = 0; // 分时数据日期
		
		/* 报盘数据 */
		stop = 0; // 停牌标示 1为真 0为假
		nZrsp = null; // 昨收
		nJrkp = null; // 今日开盘
		nZjcj = null; // 最近成交
		nCjss = null; // 成交数量
		nCjje = null; // 成交金额
		price_average = null; // 成交均价
		price_rate = null; // 5分钟涨跌幅
		price_ratio = null; // 委比
		base_pe = null; // 市盈率
		volume_ratio = null; // 量比
		volume_buy = null; // 买盘
		volume_sell = null; // 卖盘
		volume_turnover = null; // 换手率
		
		/* 买卖盘 */
		pkLen = 0;
		nSss = null; // 卖价
		nSsjg = null; // 买量
		nBjg = null; // 买价
	    nBss = null; // 买量


		/* 分时数据 */
		wCount = 0; // 总采样点数
		nTime = null; // 采样的时间点
		Zjcj = null; // 成交价
		Cjjj = null; // 成交均价
		Cjss = null; // 成交量
		Zdf = null; // 涨跌幅 //算
		Cjje = null; // 成交金额


		/* 分笔数据 */
		FBLen = 0;
		fblistData = null; // 分笔数据
		fbtime = null;
		
		nZgcj = null; // 最高成交 //算
		nZdcj = null; // 最低成交 //算
		nMaxVol = null; // 数据中最大成交量 //算
	}
	
	public Object clone() 
	{
		return new DataSetTimeSharing(this);
	}
	
	// 解析数据
	public boolean Analysis(byte[] data,DataSetTimeSharing oldDataSet) 
	{
		FBLen = 0;
		wCount = 0; 
		pkLen = 0;
		
		int pos = 0;
		int count = 0;
		
		//int unid = KUtils.bytes2Integer(data, pos); // 证券内码
		pos += 4;
		retStockBk = Utils.bytes2Short(data, pos);
		pos += 2;
		nDate = Utils.bytes2Integer(data, pos); // 日期
		pos += 4;

		/* 取报盘数据 */
		stop = data[pos]; // 停牌标示 1为真 0为假
		pos += 1;
		nZrsp = new AFloat(Utils.bytes2Integer(data, pos)); // 昨收
		pos += 4;
		Log.e("昨收", "昨收:" + nZrsp.toString());
		nJrkp = new AFloat(Utils.bytes2Integer(data, pos)); // 今日开盘
		pos += 4;
		nZjcj = new AFloat(Utils.bytes2Integer(data, pos)); // 最近成交
		pos += 4;
		nCjss = new AFloat(Utils.bytes2Integer(data, pos)); // 成交数量
		pos += 4;
		nCjje = new AFloat(Utils.bytes2Integer(data, pos)); // 成交金额
		pos += 4;
		price_average = new AFloat(Utils.bytes2Integer(data, pos)); // 成交均价
		pos += 4;
		price_rate = new AFloat(Utils.bytes2Integer(data, pos)); // 5分钟涨跌幅
		pos += 4;
		price_ratio = new AFloat(Utils.bytes2Integer(data, pos)); // 委比		
		pos += 4;
		base_pe = new AFloat(Utils.bytes2Integer(data, pos)); // 市盈率
		pos += 4;
		volume_ratio = new AFloat(Utils.bytes2Integer(data, pos)); // 量比
		pos += 4;
		volume_buy = new AFloat(Utils.bytes2Integer(data, pos)); // 买盘
		pos += 4;
		volume_sell = new AFloat(Utils.bytes2Integer(data, pos)); // 卖盘
		pos += 4;
		volume_turnover = new AFloat(Utils.bytes2Integer(data, pos)); // 换手率
		pos += 4;
		nZgcj = new AFloat(Utils.bytes2Integer(data, pos)); // 最高
		pos += 4;
		nZdcj = new AFloat(Utils.bytes2Integer(data, pos)); // 最低
		pos += 4;
		
		if(mCmdVersion >= 0x10){
			/*public  AFloat  total_shares;       //总股本
			public  AFloat  negotiable_shares;  // 流通股本
			public  AFloat  net_assets_per_share; // 每股净资产
			

		    //仅对上证指数和深圳指数有效 cmd version >= 1
		    public short up;                 //上涨股票数统计
		    public short down;               //下跌股票数统计
		    public short nochange;           //不涨不跌股票数统计*/	
			
			total_shares = new AFloat(Utils.bytes2Integer(data, pos)); // 总股本
			pos += 4;
			negotiable_shares = new AFloat(Utils.bytes2Integer(data, pos)); // 流通股本
			pos += 4;
			net_assets_per_share = new AFloat(Utils.bytes2Integer(data, pos)); //  每股净资产
			pos += 4;
			
			up = Utils.bytes2Short(data, pos);
			pos += 2;
			down = Utils.bytes2Short(data, pos);
			pos += 2;
			nochange = Utils.bytes2Short(data, pos);
			pos += 2;
			
			if(mCmdVersion >= 0x20){
				net_profit_per_share = new AFloat(Utils.bytes2Integer(data, pos)); // 每股净利润(收益)
				pos += 4;
			}
		}
		
		//计算涨跌、涨跌幅
		nZd = AFloat.sub(nZjcj, nZrsp);		
		float zdf= nZd.toFloat()*100/nZrsp.toFloat();		
		//nZdf = new AFloat(zdf,nZd.nDigit,AFloat.get_units(zdf));
		nZdf = new AFloat(zdf,2,AFloat.get_units(zdf));
		
		boolean isDateChanged =oldDataSet!=null? nDate != oldDataSet.nDate:false;

		/* 取盘口数据 */
		pkLen = Utils.bytes2Short(data, pos);
		pos += 2;
		if (pkLen > 0) 
		{
			nSss = new AFloat[pkLen]; // 卖价
			nSsjg = new AFloat[pkLen]; // 买量
			nBjg = new AFloat[pkLen]; // 买价
			nBss = new AFloat[pkLen]; // 买量

			for (int i = 0; i < pkLen; i++)
			{
				nSsjg[i] = new AFloat(Utils.bytes2Integer(data, pos));				
				pos += 4;
				nSss[i] = new AFloat(Utils.bytes2Integer(data, pos));
				pos += 4;
				nBjg[i] = new AFloat(Utils.bytes2Integer(data, pos));
				pos += 4;
				nBss[i] = new AFloat(Utils.bytes2Integer(data, pos));
				pos += 4;
			}
		}
		
		int mergeIndex = oldDataSet==null?0:oldDataSet.wCount;

		/* 取具体分时数据 */
		count = Utils.bytes2Short(data, pos);
		pos += 2;
		if (count > 0)
		{
			int beginTime = Utils.bytes2Short(data, pos);
			for (int i = mergeIndex-1; i > 0; i--) {
				if(beginTime <= oldDataSet.nTime[i]){
					mergeIndex--;
				}else{
					break;
				}
			}
			mergeIndex = mergeIndex < 0?0:mergeIndex;
			
			nTime = new int[count+mergeIndex];
			Zjcj = new int[count+mergeIndex];
			Cjss = new int[count+mergeIndex];
			Cjje = new AFloat[count+mergeIndex];
			Cjjj = new int[count+mergeIndex];
			for (int i = 0; i < mergeIndex; i++) {
				nTime[i] = oldDataSet.nTime[i];
				Zjcj[i] = oldDataSet.Zjcj[i];
				Cjss[i] = oldDataSet.Cjss[i];
				Cjje[i] = oldDataSet.Cjje[i];
				Cjjj[i] = oldDataSet.Cjjj[i];
			}
			
			for (int i = 0; i < count; i++) 
			{
				nTime[mergeIndex+i] = (int) Utils.bytes2Short(data, pos); // 采样的时间点
				pos += 2;
				Zjcj[mergeIndex+i] = Utils.bytes2Integer(data, pos); // 成交价
				pos += 4;
				Cjss[mergeIndex+i] = Utils.bytes2Integer(data, pos); // 成交量
				pos += 4;
				Cjje[mergeIndex+i] = new AFloat(Utils.bytes2Integer(data, pos)); // 成交金额
				pos += 4;
				Cjjj[mergeIndex+i] = Utils.bytes2Integer(data, pos); // 成交均价
				pos += 4;
			}
			mLastTime = nTime[mergeIndex+count-1];
		}
		

		/* 取分比数据 */
		FBLen = Utils.bytes2Short(data, pos);
		pos += 2;
		if (FBLen > 0) 
		{
			fblistData = new AFloat[3][FBLen];
			fbtime = new String[FBLen];
			fbState = new String[FBLen];

			for (int i = 0; i < FBLen; i++) 
			{
				fbtime[i] = timeFormat(Utils.bytes2Integer(data, pos));
				pos += 4;
				for (int index = 0; index < 2; index++) 
				{
					fblistData[index][i] = new AFloat(Utils.bytes2Integer(data, pos));
					pos += 4;
				}				
				fbState[i] = fblistData[1][i].toFloat()>0?"B":"S";
				fblistData[1][i].abs();
			}
		}

		CalcShowRecord(count+mergeIndex);
		wCount = (short) (count+mergeIndex);
		
		if(wCount > 0)
		{
			price_average =new AFloat(Cjjj[wCount-1]);
		}
		
//		if(Business.BK_index == retStockBk)
//		{
//			CalcMaxMinPirc(count,oldDataSet);
//		}
		
		return isDateChanged;
	}
	
	/**
	 * 计算可现实的记录
	 */
	private void CalcShowRecord(int nCount) 
	{

		float maxVol = 0;
		Zdf = new AFloat[nCount];
		Zd = new AFloat[nCount];

		if (nCount == 0)
			return;
		
		AFloat tem = new AFloat();

		for (int i = 0; i < nCount; i++)
		{		
			maxVol = Math.max(maxVol, tem.init(Cjss[i]).toFloat());
//chenx update it 20130515				
//			Zd[i] = new AFloat((tem.init(Zjcj[i]).toFloat() - nZrsp.toFloat()), 2, AFloat.NUMBER);
//			Zdf[i] = new AFloat((tem.init(Zjcj[i]).toFloat() - nZrsp.toFloat()) / nZrsp.toFloat() * 100, 2, AFloat.NUMBER);	
			Zd[i] = AFloat.sub(tem.init(Zjcj[i]), nZrsp);	
			Zdf[i] = new AFloat((tem.init(Zjcj[i]).toFloat() - nZrsp.toFloat()) / nZrsp.toFloat() * 100, 2, AFloat.NUMBER);				
		}

		nMaxVol = new AFloat(maxVol, 0, AFloat.NUMBER);
	}
	
	private void CalcMaxMinPirc(int nCount,DataSetTimeSharing oldDataSet)
	{	
		if (nCount < 1)
			return;
		
		
		float maxTech = 0;
		float minTech = Float.MAX_VALUE;
		AFloat mFloator = new AFloat();
		if(oldDataSet!=null){
			maxTech = oldDataSet.nJJZgcj.toFloat();
			minTech = oldDataSet.nJJZdcj.toFloat();
		}
		for (int i = 0; i < nCount; i++) 
		{
			mFloator.init(Cjjj[i]);
			maxTech = Math.max(maxTech, mFloator.toFloat());
			minTech = Math.min(minTech, mFloator.toFloat());
		}
		
		mFloator.init(Cjjj[0]);

		nJJZgcj = new AFloat(maxTech, mFloator.nDigit, AFloat.get_units(maxTech));
		nJJZdcj = new AFloat(minTech, mFloator.nDigit, AFloat.get_units(minTech));
	}
	
	public String timeFormat(int time) {
		int t = time/100;//不显示秒
		int h = t/100;
		int m = t%100;		
		String hour = h<10?"0"+h:""+h;
		String minute = m<10?"0"+m:""+m;
		return hour + ":" + minute;
	}
}
