package com.gf.view.adapter.trade;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.viewmodel.ebiz.trade.EntrustInfo;

/**
 * 股票委托信息
 *
 */
public class EntrustInfoAdapter extends BaseAdapter {

	private LayoutInflater mLayoutInflater;
	private List<EntrustInfo> mItems;
	
	private int selectedPosition = -1;
	
	public EntrustInfoAdapter(Context context, List<EntrustInfo> items) {
		mItems = items;
		mLayoutInflater = LayoutInflater.from(context);
	}
	
	@Override
	public int getCount() {
		if (mItems != null) {
			return mItems.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		final EntrustInfo info = mItems.get(position);
		final ViewHolder holder;
		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.stock_trade_entrust_list_item, null);
			holder = new ViewHolder();
			
			holder.ivMode = (ImageView) view.findViewById(R.id.iv_mode);
			holder.tvDate = (TextView) view.findViewById(R.id.tv_date);
			holder.tvStockName = (TextView) view.findViewById(R.id.tv_stock_name);
			holder.tvStockCode = (TextView) view.findViewById(R.id.tv_stock_code);
			
			holder.tvPrice = (TextView) view.findViewById(R.id.tv_price);
			holder.tvAmount = (TextView) view.findViewById(R.id.tv_price);
			
			view.setTag(R.id.layout_entrust_info, holder);
		} else {
			holder = (ViewHolder) view.getTag(R.id.layout_entrust_info);
		}
		
		if (info != null) {
			holder.tvDate.setText(info.getDate());
			holder.tvStockName.setText(info.getStockName());
			holder.tvStockCode.setText(info.getStockCode());
			holder.tvPrice.setText(info.getPrice());
			holder.tvAmount.setText(info.getAmount());
		}
		
		return view;
	}
	
    public int getSelectedPosition() {
		return selectedPosition;
	}
	public void setSelectedPosition(int selectedPosition) {
		this.selectedPosition = selectedPosition;
	}

	class ViewHolder {
    	ImageView ivMode; // 买卖标志
    	TextView tvDate; // 委托时间
    	TextView tvStockCode; // 证券代码
    	TextView tvStockName; // 证券名称
    	TextView tvPrice; // 价格
    	TextView tvAmount; // 数量
    }

}
