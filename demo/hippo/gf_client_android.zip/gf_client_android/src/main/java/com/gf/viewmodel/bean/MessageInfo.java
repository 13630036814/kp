package com.gf.viewmodel.bean;

/**
 * 
 * 
 * @Description:
 * @see:   
 * @since:      
 * @copyright © 35.com
 * @Date:2013-10-14
 */
public class MessageInfo {

	private String groupName;
	private int groupId;
	private String info = "";
	/**
	 * 成交量
	 */
	public Float volume;
	/**
	 * 涨跌幅
	 */
	public String stockRang = "";
	/**
	 * 在本组中的位置
	 */
	public int order = 0;
	public String mTitle = "";
	
	/**
	 * 最高价
	 */
	public Float high;
	/**
	 * 最低价
	 */
	public Float low;
	
	/**
	 * 开盘价
	 */
	public Float open;
	
	/**
	 * 市场代码
	 * @return
	 */
	public String mField4="";
	public String mField1="",mField2="",mField3="",shortPy = "",longPy = "";

	public int getGroupId() {
		return groupId;
	}

	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
