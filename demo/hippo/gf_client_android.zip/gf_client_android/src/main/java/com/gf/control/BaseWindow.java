/**
 * 
 */
package com.gf.control;


import java.util.List;

import com.gf.client.R;
import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.common.EventHandler;
import com.gf.hippo.domain.client.common.EventObject;
import com.gf.hippo.domain.client.quote.BoardRankQuoteManager;
import com.gf.hippo.domain.client.quote.BoardRankQuoteList;
import com.gf.hippo.domain.client.quote.BoardTypes;
import com.gf.hippo.domain.client.quote.CandleQuoteManager;
import com.gf.hippo.domain.client.quote.CandleQuoteStream;
import com.gf.hippo.domain.client.quote.CandleQuoteStreamItem;
import com.gf.hippo.domain.client.quote.PeriodType;
import com.gf.hippo.domain.client.quote.RankQuoteItem;
import com.gf.hippo.domain.client.quote.RankSortType;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.quote.RealtimeQuoteManager;
import com.gf.hippo.domain.client.quote.TickQuoteManager;
import com.gf.hippo.domain.client.quote.TickQuoteStream;
import com.gf.hippo.domain.client.quote.TickQuoteStreamItem;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteManager;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStream;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStreamItem;
import com.gf.hippo.domain.client.securities.SimpleStockManager;
import com.gf.hippo.domain.client.securities.SimpleUserStockManager;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.hippo.domain.client.securities.StockManager;
import com.gf.messaging.NetUtil;
import com.gf.viewmodel.base.GlobalMsg;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

/**
 * activity 基类
 * @author cola
 * 
 */
public abstract class BaseWindow extends FragmentActivity {
	private static NetReceiver sNetReceiver;
	/**
	 * 判断网络是否可用
	 */
	private static boolean netEnale = false;
	protected static final String TAG = "BaseWindow";
	protected SimpleUserStockManager mUserStockManager = null;
	private Dialog dialog;
//	protected NetworkQuoteManager mQuoteManager = new NetworkQuoteManager();
	protected SimpleUserStockManager mSimpleUserStockManager = null;
	protected RealtimeQuoteManager mRealtimeQuoteManager = null;
	protected StockList mStockList = new StockList();

	//protected StockManager stockManager = new SimpleStockManager();
	protected TimeSeriesQuoteStream timeSeriesQuote;
	protected EventHandler mTimeSeriesHandler,mCandlestickHandler,mBoardRankHandler;
	protected EventObject mEventObjectSeries, mEventObjectCandlestick, mEventObjectboardRank;
	protected CandleQuoteStream candleQuote;

	protected StockManager mStockManager = null;
	protected QuoteManagerFactory mQuoteManagerFactory = null;       
	protected GlobalMsg mGlobal = GlobalMsg.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mQuoteManagerFactory = ((BaseApplication)getApplication()).getQuoteManagerFactory();
		mStockManager = mQuoteManagerFactory.getStockManager();
		mSimpleUserStockManager = mQuoteManagerFactory.getUserStockManager(); 
		
		mEventObjectSeries = new EventObject(); 
		mEventObjectCandlestick= new EventObject(); 
		mEventObjectboardRank= new EventObject(); 
		mEventObjectStock.setEventHandler(mHandlerStock);
		mEventObjectStockList.setEventHandler(mHandlerStockList);
		mEventObjectRealtimeQuoteItem.setEventHandler(mHandlerRealtimeQuoteItem);
		mEventObjectTick.setEventHandler(mTickHandler);
		
		if(sNetReceiver != null) return;
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        sNetReceiver = new NetReceiver();
        registerReceiver(sNetReceiver, intentFilter);
	}

	/**
	 * 显示进度框
	 * 
	 * @param showDialog
	 */
	public void showDialog(boolean showDialog) {

		if (showDialog) {
			if (dialog == null) {
				dialog = new Dialog(this, R.style.Dialog_Fullscreen);
				dialog.setContentView(R.layout.progress);
				RelativeLayout iv = (RelativeLayout) dialog
						.findViewById(R.id.tipslayout);

				ProgressBar m_progress = (ProgressBar) iv
						.findViewById(R.id.m_progress);
				m_progress.setVisibility(View.VISIBLE);
				m_progress.setIndeterminate(true);

				m_progress.setIndeterminateDrawable(this.getResources()
						.getDrawable(R.anim.loading));
				iv.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.dismiss();
						dialog = null;
					}
				});

			}
			try {
				dialog.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void dismissDialog() {
		if (dialog != null) {
			dialog.dismiss();
//			dialog = null;
		}
	}

	EventObject mEventObjectStockList = new EventObject();
	EventHandler mHandlerStockList = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			BaseWindow.this.onEvent(event);
		}
	};

	EventObject mEventObjectStock = new EventObject();
	EventHandler mHandlerStock = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			BaseWindow.this.onEvent(event);
		}
	};

	EventObject mEventObjectRealtimeQuoteItem = new EventObject();
	EventHandler mHandlerRealtimeQuoteItem = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			BaseWindow.this.onEvent(event);
		}
	};

	/**
	 */
	protected void setMyStockListener() {
		mSimpleUserStockManager.beginWatch(mStockList, mEventObjectStockList);
		
		mSimpleUserStockManager.beginWatch(mStockList, mEventObjectStockList);
		beginWatchMyStock();
	}
	
	/**
	 * @param maketid
	 * @param stockcode
	 * @param itemPosition
	 */
	public void setTimeSeriesQuote(final String maketid,final String stockcode,int count) {
		TimeSeriesQuoteManager timeSeriesManager = mQuoteManagerFactory.getTimeSeriesQuoteManager();

		Stock stock = mStockManager.getStock(maketid, stockcode);

		timeSeriesQuote = timeSeriesManager.getTimeSeriesQuoteStream(stock);
		if(mEventObjectSeries != null)
			timeSeriesManager.endWatch(timeSeriesQuote, mEventObjectSeries);
		timeSeriesQuote.setTime(0);
		timeSeriesQuote.setCount(count);
		mTimeSeriesHandler = new EventHandler() {
			@Override
			public void onEvent(Event event) {
				BaseWindow.this.onEvent(event);
			}
		};
		mEventObjectSeries.setEventHandler(mTimeSeriesHandler);
		timeSeriesManager.beginWatch(timeSeriesQuote, mEventObjectSeries);
	}

	/**
	 * 设置获取 k 线数据
	 * @param stock
	 */
	public void setCandlesTickQuoteListener(Stock stock,int type) {//
		CandleQuoteManager candleQuoteManager = this.mQuoteManagerFactory.getCandleQuoteManager();

		candleQuote = candleQuoteManager.getCandleQuoteStream(stock, type);		
		candleQuote.setCount(300);
		candleQuote.setTime(0L);//20140318L
		if(mCandlestickHandler != null)
			candleQuoteManager.endWatch(candleQuote, mEventObjectCandlestick);
		mCandlestickHandler = new EventHandler() {
			@Override
			public void onEvent(Event event) {
				BaseWindow.this.onEvent(event);
			}
		};
		mEventObjectCandlestick.setEventHandler(mCandlestickHandler);
		candleQuoteManager.beginWatch(candleQuote, mEventObjectCandlestick);
	}
	
	/**
	 */
	public void setBoardRankListener(){
		BoardRankQuoteManager boardRankQuoteManager=mQuoteManagerFactory.getboardRankQuoteManager();
		BoardRankQuoteList quote=boardRankQuoteManager.getBoardQuoteList(BoardTypes.BK_A,0,RankSortType.PX_CHANGE_PCT);
		quote.setCount(30);
		//quote.setDirect(0);
		quote.setFrom(0);
		//quote.setSort(RankSortType.PX_CHANGE_PCT);
		if(mBoardRankHandler == null)
		mBoardRankHandler= new EventHandler() {
			@Override
			public void onEvent(Event event) {
				BoardRankQuoteList quote = (BoardRankQuoteList) event.getObject();
				// 更新UI数据
				System.out.println("get BoardRankQuoteStream:");
				for (RankQuoteItem item : quote.getAllItems()) {
					System.out.println("get BoardRankQuoteStream, stock name:" + item.getName());
				}
			}
		};
		mEventObjectboardRank.setEventHandler(mBoardRankHandler);
		boardRankQuoteManager.beginWatch(quote, mEventObjectboardRank);
	//终止时
	//	boardRankQuoteManager.endWatch(quote, boardRankHandler);
	}

	/**
	 */
	protected void setAttributeListener() {
		for (Stock stock : mStockList.getAllItems()) {
			mStockManager.beginWatch(stock, mEventObjectStock);
		}
	}

	protected void setRealtimeQuoteListener(Stock stock) {
//		for (Stock stock : mStockList.getAllItems()) {
			RealtimeQuoteManager realtimeQuoteManager = mQuoteManagerFactory
					.getRealtimeQuoteManager();
			RealtimeQuoteItem quote = realtimeQuoteManager
					.getRealtimeQuoteItem(stock);
			realtimeQuoteManager.beginWatch(quote, mEventObjectRealtimeQuoteItem);
//		}
	}
	
	/**
	 * @param stock
	 */
	public void setTickQuote(Stock stock) {
		final TickQuoteManager tickQuoteManager = mQuoteManagerFactory.getTickQuoteManager();
		TickQuoteStream quote = tickQuoteManager.getTickQuoteStream(stock);

		tickQuoteManager.beginWatch(quote, mEventObjectTick);
		// 终止时
		
	}
	
	private EventObject mEventObjectTick = new EventObject();
	private EventHandler mTickHandler = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			BaseWindow.this.onEvent(event);
		}
	};
	
	private void beginWatchMyStock() {
		for (Stock stock : mStockList.getAllItems()) {
			mStockManager.beginWatch(stock, mEventObjectStock);
			RealtimeQuoteManager realtimeQuoteManager = mQuoteManagerFactory
					.getRealtimeQuoteManager();
			RealtimeQuoteItem quote = realtimeQuoteManager
					.getRealtimeQuoteItem(stock);
			realtimeQuoteManager.beginWatch(quote, mEventObjectRealtimeQuoteItem);
		}
	}

	/**
	 * @param eventList
	 */
	protected void beginWatchEveryStock(List<DomainObject> eventList){
		for(DomainObject list : eventList){
			if (list instanceof RealtimeQuoteItem) {
				mQuoteManagerFactory.getRealtimeQuoteManager().beginWatch((RealtimeQuoteItem)list, mEventObjectRealtimeQuoteItem);
			}else if (list instanceof TimeSeriesQuoteStream) {//分词数据
				mQuoteManagerFactory.getTimeSeriesQuoteManager().beginWatch((TimeSeriesQuoteStream)list, mEventObjectSeries);
			}else if (list instanceof CandleQuoteStream) {//k 线
				mQuoteManagerFactory.getCandleQuoteManager().beginWatch((CandleQuoteStream)list, mEventObjectCandlestick);
			}else if (list instanceof TickQuoteStream) {//成交明细
				mQuoteManagerFactory.getTickQuoteManager().beginWatch((TickQuoteStream)list, mEventObjectTick);
			}
		}
		
	}
	
	/**
	 * @param eventList DomainObject对象列表
	 */
	protected void endWatchEveryStock(List<DomainObject> eventList){
		for(DomainObject list : eventList){
			if (list instanceof RealtimeQuoteItem) {
				mQuoteManagerFactory.getRealtimeQuoteManager().endWatch((RealtimeQuoteItem)list, mEventObjectRealtimeQuoteItem);
			}else if (list instanceof TimeSeriesQuoteStream) {//分词数据
				mQuoteManagerFactory.getTimeSeriesQuoteManager().endWatchObject(list, mEventObjectSeries);
			}else if (list instanceof CandleQuoteStream) {//k 线
				mQuoteManagerFactory.getCandleQuoteManager().endWatch((CandleQuoteStream)list, mEventObjectCandlestick);
			}else if (list instanceof TickQuoteStream) {//成交明细
				mQuoteManagerFactory.getTickQuoteManager().endWatchObject(list, mEventObjectTick);
			}
		}
		
	}
	
	/**
	 */
	protected void endWatchEveryStock() {
		for (Stock stock : mStockList.getAllItems()) {
			mStockManager.endWatch(stock, mEventObjectStock);
			RealtimeQuoteManager realtimeQuoteManager = mQuoteManagerFactory
					.getRealtimeQuoteManager();
			RealtimeQuoteItem quote = realtimeQuoteManager
					.getRealtimeQuoteItem(stock);
			realtimeQuoteManager.endWatch(quote, mEventObjectRealtimeQuoteItem);
			mQuoteManagerFactory.getTimeSeriesQuoteManager().endWatchObject(timeSeriesQuote, mEventObjectSeries);
			if(candleQuote != null)
			mQuoteManagerFactory.getCandleQuoteManager().endWatch(candleQuote, mEventObjectCandlestick);
			
			mQuoteManagerFactory.getTickQuoteManager().endWatchObject(mQuoteManagerFactory.getTickQuoteManager().getTickQuoteStream(stock), mEventObjectTick) ;
		}
		
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		
		endWatchEveryStock();
	}
	
	protected void unregisterReceiver(){
		if(sNetReceiver != null )
		unregisterReceiver(sNetReceiver);
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			finish();
			Log.e("KEYCODE_BACK",
					"KEYCODE_BACK");
			break;
		}
		return false;

	}
	
	/**
	 */
	protected void setUserStockListener(){
		mUserStockManager = mQuoteManagerFactory.getUserStockManager();
	}
	
	/**
	 * @param market
	 * @param code
	 */
	public boolean addToMyStock(String market, String code) {
		Stock stock = mStockManager.getStock(market, code);
		// 添加到数据库
		if (stock != null) {
			mUserStockManager.addUserStock(stock);
			return true;
		}
		return false;
	}
	
	/**
	 * @param market
	 * @param code
	 */
	public boolean delToMyStock(String market, String code) {
		Stock stock = mStockManager.getStock(market, code);
		// 添加到数据库
		if (stock != null) {
			mUserStockManager.removeUserStock(stock);
			return true;
		}
		return false;
	}

	/**
	 * @param market
	 * @param code
	 * @return
	 */
	public boolean isMyStock(String market, String code){
		StockList mStockList = mSimpleUserStockManager.getUserStocks();
		for (Stock stock : mStockList.getAllItems()) {
			if(stock.getMarket().equals(market) && stock.getStock_code().equals(code))
				return true;
		}
//		Stock stock = mStockManager.getStock(market, code);
//		if(stock != null) 
		 return false;
	}
	
	/**
	 * 确保网打开app时首次网络请求的重复
	 */
	private static Boolean NetWorkS = true;
	public class NetReceiver extends BroadcastReceiver{

		@Override
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			
			if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
				if(NetUtil.isNetAvailable(context)) {
					Log.e(TAG, "Reconnected");
					if(NetWorkS){
						NetWorkS = false;
						return;
					}
					
					netEnale = true;
					netStatus(netEnale);
				}else{
					Log.e(TAG, "connecten faile");
					netEnale = false;
					NetWorkS = false;
					netStatus(netEnale);
				}
			}
		}

	}
	
	
	/**
	 * @param event
	 */
	public abstract void onEvent(Event event);//参考 QuotationActivity 中的实现
	public abstract void init();
	public abstract void setListener();
	/**
	 * 当前网络状态
	 * @param status
	 */
	public abstract void netStatus(boolean status);
}
