/**
 * 
 */
package com.gf.viewmodel.base;

import com.gf.data.sqlite.GfClientSqliteOpenHelper;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

/**
 * @author cola
 *
 */
public class GfClientSqliteProvider extends ContentProvider {
	public static final String URI_CODELINE_SEARCH = "content://com.gf.codeline";
	private final String TAG = "ProcessProvider";
	private GfClientSqliteOpenHelper mGfClientSqliteOpenHelper;

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		SQLiteDatabase db = mGfClientSqliteOpenHelper.getWritableDatabase();
		int count = db.delete(GfClientSqliteOpenHelper.TABLE_WBW_INFO, selection, selectionArgs);
		if (count > 0) {
			getContext().getContentResolver().notifyChange(uri, null);
		}
		db.close();
		return count;
	}

	@Override
	public String getType(Uri uri) {
		return "vnd.android.cursor.dir/" + GfClientSqliteOpenHelper.TABLE_WBW_INFO;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		SQLiteDatabase db = mGfClientSqliteOpenHelper.getWritableDatabase();

		final long rowId = db.insert(GfClientSqliteOpenHelper.TABLE_WBW_INFO, null, values);
		if (rowId <= 0) {
			return null;
		}
		uri = ContentUris.withAppendedId(uri, rowId);
		getContext().getContentResolver().notifyChange(uri, null);
		db.close();
		return uri;
	}

	@Override
	public boolean onCreate() {
		mGfClientSqliteOpenHelper = GfClientSqliteOpenHelper.getInstance(getContext());
		//mGfClientSqliteOpenHelper.getWritableDatabase();
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		qb.setTables(GfClientSqliteOpenHelper.TABLE_WBW_INFO);

		SQLiteDatabase db = mGfClientSqliteOpenHelper.getReadableDatabase();// getWritableDatabase();
		Cursor result = qb.query(db, projection, selection, selectionArgs,
				null, null, sortOrder);
		if (result != null) {
			result.setNotificationUri(getContext().getContentResolver(), uri);
		}

		return result;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		//SqlArguments args = new SqlArguments(uri, selection, selectionArgs);
		SQLiteDatabase db = mGfClientSqliteOpenHelper.getWritableDatabase();

		int count = db.update(GfClientSqliteOpenHelper.TABLE_WBW_INFO, values, selection, selectionArgs);
		if (count > 0) {
			getContext().getContentResolver().notifyChange(uri, null);
		}
		db.close();
		return count;
	}

	
	/**
	 * Uri 功能类
	 * 
	 * @author cola
	 * 
	 */
	static class SqlArguments {
		public final String table;
		public final String where;
		public final String[] args;

		SqlArguments(Uri url, String where, String[] args) {
			if (url.getPathSegments().size() == 1) {
				this.table = url.getPathSegments().get(0);
				this.where = where;
				this.args = args;
			} else if (url.getPathSegments().size() != 2) {
				throw new IllegalArgumentException("Invalid URI: " + url);
			} else if (!TextUtils.isEmpty(where)) {
				throw new UnsupportedOperationException(
						"WHERE clause not supported: " + url);
			} else {
				this.table = url.getPathSegments().get(0);
				this.where = "_id=" + ContentUris.parseId(url);
				this.args = null;
			}
		}

		SqlArguments(Uri url) {
			if (url.getPathSegments().size() == 1) {
				table = url.getPathSegments().get(0);
				where = null;
				args = null;
			} else {
				throw new IllegalArgumentException("Invalid URI: " + url);
			}
		}
	}// SqlArguments
}
