package com.gf.view.widget;

import com.gf.client.R;

import android.app.Activity;
import android.content.Context;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.inputmethodservice.KeyboardView.OnKeyboardActionListener;
import android.text.InputType;
import android.text.method.MetaKeyKeyListener;
import android.util.AttributeSet;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.FrameLayout;

public class StockInput extends AutoCompleteTextView implements
		OnKeyboardActionListener, OnClickListener {
	protected Activity application;
	InputMethodManager mImm;
	LayoutInflater mInflater;
	View mRootView;
	StockInputWindow mWindow;
	ViewGroup mFullscreenArea;
	FrameLayout mExtractFrame;
	FrameLayout mCandidatesFrame;
	FrameLayout mInputFrame;
	KeyboardView mInputView;
	private LatinKeyboard mSymbolsKeyboard;
	private LatinKeyboard mSymbolsShiftedKeyboard;
	private LatinKeyboard mQwertyKeyboard;
	private String mWordSeparators;
	private StringBuilder mComposing = new StringBuilder();
	private long mMetaState;
	InputConnection mStartedInputConnection;
	InputConnection mInputConnection;
	EditorInfo mInputEditorInfo;
	private long mLastShiftTime;
	private boolean mCapsLock;
	private int[] mDiKey = new int[] { 9900, 99002, 99600, 99000, 99300 };
	private String[] mDiValue = new String[] { "00", "002", "600", "000", "300" };
	private static final int CLOSE_KZ_INPUTMETHOD = 10000;

	// private boolean isWindowShowing;

	public StockInput(Context context) {
		super(context);
		this.application = (Activity) context;
	}

	public StockInput(Context context, AttributeSet attributes) {
		super(context, attributes);
		this.application = (Activity) context;
		this.setOnClickListener(this);

	}

	private void createSoftInput() {
		mImm = (InputMethodManager) application
				.getSystemService(Context.INPUT_METHOD_SERVICE);
		mInputView = (KeyboardView) application.getLayoutInflater().inflate(
				R.layout.input, null);
		mQwertyKeyboard = new LatinKeyboard(application, R.xml.qwerty);
		mSymbolsKeyboard = new LatinKeyboard(application, R.xml.symbols);
		mSymbolsShiftedKeyboard = new LatinKeyboard(application,
				R.xml.symbols_shift);
		// mInputView.setKeyboard(mQwertyKeyboard);
		mInputView.setKeyboard(mSymbolsKeyboard);
		mInputView.setOnKeyboardActionListener(this);
		mWordSeparators = application.getResources().getString(
				R.string.word_separators);
		mWindow = new StockInputWindow(application,
				android.R.style.Theme_InputMethod);
		mInflater = (LayoutInflater) application
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		mRootView = mInflater.inflate(R.layout.input_method, null);
		mWindow.setContentView(mRootView);
		mFullscreenArea = (ViewGroup) mRootView
				.findViewById(R.id.fullscreenArea);
		mExtractFrame = (FrameLayout) mRootView
				.findViewById(android.R.id.extractArea);
		mCandidatesFrame = (FrameLayout) mRootView
				.findViewById(android.R.id.candidatesArea);
		mInputFrame = (FrameLayout) mRootView
				.findViewById(android.R.id.inputArea);
		setInputView(mInputView);

		if (!mWindow.isShowing()) {
			showWindow();
		}
	}

	void setInputView(View view) {
		mInputFrame.removeAllViews();
		mInputFrame.addView(view, new FrameLayout.LayoutParams(
				ViewGroup.LayoutParams.FILL_PARENT,
				ViewGroup.LayoutParams.WRAP_CONTENT));
	}

	public void updateInputView() {
		createSoftInput();
	}

	public void showWindow() {
		if (!mWindow.isShowing()) {
			this.setInputType(InputType.TYPE_DATETIME_VARIATION_NORMAL);
			mInputFrame.setVisibility(View.VISIBLE);
			mWindow.show();
			// isWindowShowing = true;
		}
	}

	public boolean isShowWindow() {
		return mWindow.isShowing();
	}

	private String getWordSeparators() {
		return mWordSeparators;
	}

	public InputConnection getCurrentInputConnection() {
		if (mStartedInputConnection == null) {
			mStartedInputConnection = new BaseInputConnection(this, false);
		}
		return mStartedInputConnection;
	}

	private void sendKey(int keyCode) {
		switch (keyCode) {
		case '\n':
			keyDownUp(KeyEvent.KEYCODE_ENTER);
			break;
		default:
			if (keyCode >= '0' && keyCode <= '9') {
				keyDownUp(keyCode - '0' + KeyEvent.KEYCODE_0);
			} else {
				getCurrentInputConnection().commitText(
						String.valueOf((char) keyCode), 1);
			}
			break;
		}
	}

	private void keyDownUp(int keyEventCode) {
		getCurrentInputConnection().sendKeyEvent(
				new KeyEvent(KeyEvent.ACTION_DOWN, keyEventCode));
		getCurrentInputConnection().sendKeyEvent(
				new KeyEvent(KeyEvent.ACTION_UP, keyEventCode));
	}

	private boolean translateKeyDown(int keyCode, KeyEvent event) {
		mMetaState = MetaKeyKeyListener.handleKeyDown(mMetaState, keyCode,
				event);
		int c = event.getUnicodeChar(MetaKeyKeyListener
				.getMetaState(mMetaState));
		mMetaState = MetaKeyKeyListener.adjustMetaAfterKeypress(mMetaState);
		InputConnection ic = getCurrentInputConnection();
		if (c == 0 || ic == null) {
			return false;
		}
		boolean dead = false;
		if ((c & KeyCharacterMap.COMBINING_ACCENT) != 0) {
			dead = true;
			c = c & KeyCharacterMap.COMBINING_ACCENT_MASK;
		}
		if (mComposing.length() > 0) {
			char accent = mComposing.charAt(mComposing.length() - 1);
			int composed = KeyEvent.getDeadChar(accent, c);
			if (composed != 0) {
				c = composed;
				mComposing.setLength(mComposing.length() - 1);
			}
		}
		onKey(c, null);
		return true;
	}

	private boolean isAlphabet(int code) {
		if (Character.isLetter(code)) {
			return true;
		} else {
			return false;
		}
	}

	private void commitTyped(InputConnection inputConnection) {
		if (mComposing.length() > 0) {
			inputConnection.commitText(mComposing, mComposing.length());
		}
	}

	public boolean isWordSeparator(int code) {
		String separators = getWordSeparators();
		return separators.contains(String.valueOf((char) code));
	}

	public EditorInfo getCurrentInputEditorInfo() {
		return mInputEditorInfo;
	}

	private void updateShiftKeyState(EditorInfo attr) {
		if (attr != null && mInputView != null
				&& mQwertyKeyboard == mInputView.getKeyboard()) {
			int caps = 0;
			EditorInfo ei = getCurrentInputEditorInfo();
			if (ei != null && ei.inputType != EditorInfo.TYPE_NULL) {
				caps = getCurrentInputConnection().getCursorCapsMode(
						attr.inputType);
			}
			mInputView.setShifted(mCapsLock || caps != 0);
		}
	}

	private void checkToggleCapsLock() {
		long now = System.currentTimeMillis();
		if (mLastShiftTime + 800 > now) {
			mCapsLock = !mCapsLock;
			mLastShiftTime = 0;
		} else {
			mLastShiftTime = now;
		}
	}

	public void clearWords() {
		mComposing.setLength(0);
		getCurrentInputConnection().commitText("", 0);
	}

	private void handleBackspace() {
		final int length = mComposing.length();
		if (length > 1) {
			mComposing.delete(length - 1, length);
			getCurrentInputConnection().setComposingText(mComposing, 1);
		} else if (length > 0) {
			mComposing.setLength(0);
			getCurrentInputConnection().commitText("", 0);
		} else {
			keyDownUp(KeyEvent.KEYCODE_DEL);
		}
		updateShiftKeyState(getCurrentInputEditorInfo());
	}

	private void handleShift() {
		if (mInputView == null) {
			return;
		}
		Keyboard currentKeyboard = mInputView.getKeyboard();
		if (mQwertyKeyboard == currentKeyboard) {
			// Alphabet keyboard
			checkToggleCapsLock();
			mInputView.setShifted(mCapsLock || !mInputView.isShifted());
		} else if (currentKeyboard == mSymbolsKeyboard) {
			mSymbolsKeyboard.setShifted(true);
			mInputView.setKeyboard(mSymbolsShiftedKeyboard);
			mSymbolsShiftedKeyboard.setShifted(true);
		} else if (currentKeyboard == mSymbolsShiftedKeyboard) {
			mSymbolsShiftedKeyboard.setShifted(false);
			mInputView.setKeyboard(mSymbolsKeyboard);
			mSymbolsKeyboard.setShifted(false);
		}
	}

	private void handleCharacter(int primaryCode, int[] keyCodes) {
		if (mInputView.isShown()) {
			if (mInputView.isShifted()) {
				primaryCode = Character.toUpperCase(primaryCode);
			}
		}
		if (isAlphabet(primaryCode)) {
			// mComposing.append((char) primaryCode);
			// getCurrentInputConnection().setComposingText(mComposing, 1);
			// getCurrentInputConnection().commitText(mComposing, 1);
			getCurrentInputConnection().commitText(
					String.valueOf((char) primaryCode), 1);
			updateShiftKeyState(getCurrentInputEditorInfo());
		} else {
			// getCurrentInputConnection().commitText(
			// String.valueOf((char) primaryCode), 1);
			// this.setText(mComposing);
			for (int i = 0; i < mDiKey.length; i++) {
				if (primaryCode == mDiKey[i]) {
					getCurrentInputConnection().commitText(mDiValue[i], 1);
					return;
				}
			}
			getCurrentInputConnection().commitText(
					String.valueOf((char) primaryCode), 1);
		}
	}

	public void handleClose() {
		// commitTyped(getCurrentInputConnection());
		mInputView.closing();
		mWindow.dismiss();
	}

	public void onClick(View v) {
		if (!mWindow.isShowing()) {
			showWindow();
		}
		mImm.hideSoftInputFromWindow(this.getWindowToken(),
				InputMethodManager.HIDE_NOT_ALWAYS);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (mWindow.isShowing()) {
			return true;
		}
		return super.onTouchEvent(event);
	}

	public void closeWindow() {
		// isWindowShowing = false;
		mWindow.dismiss();
	}

	private void showOriSoftInputMethod() {
		if (mWindow.isShowing()) {
			mWindow.dismiss();
			this.setInputType(InputType.TYPE_CLASS_TEXT);
			mImm.showSoftInput(this, 0);
		}
	}

	public void onPress(int primaryCode) {
		// TODO Auto-generated method stub
	}

	public void onRelease(int primaryCode) {
		// TODO Auto-generated method stub
	}

	public void onKey(int primaryCode, int[] keyCodes) {
		if (isWordSeparator(primaryCode)) {
			// Handle separator
			// if (mComposing.length() > 0) {
			// commitTyped(getCurrentInputConnection());
			// }
			sendKey(primaryCode);
			updateShiftKeyState(getCurrentInputEditorInfo());
		} else if (primaryCode == StockInput.CLOSE_KZ_INPUTMETHOD) {
			showOriSoftInputMethod();
		} else if (primaryCode == Keyboard.KEYCODE_DELETE) {
			handleBackspace();
		} else if (primaryCode == Keyboard.KEYCODE_SHIFT) {
			handleShift();
		} else if (primaryCode == Keyboard.KEYCODE_CANCEL) {
			handleClose();
			return;
		} else if (primaryCode == LatinKeyboardView.KEYCODE_OPTIONS) {
			// Show a menu or somethin'
		} else if (primaryCode == Keyboard.KEYCODE_MODE_CHANGE
				&& mInputView != null) {
			Keyboard current = mInputView.getKeyboard();
			if (current == mSymbolsKeyboard
					|| current == mSymbolsShiftedKeyboard) {
				current = mQwertyKeyboard;
			} else {
				current = mSymbolsKeyboard;
			}
			mInputView.setKeyboard(current);
			if (current == mSymbolsKeyboard) {
				current.setShifted(false);
			}
		} else {
			handleCharacter(primaryCode, keyCodes);
		}
	}

	public void onText(CharSequence text) {
		// TODO Auto-generated method stub
		InputConnection ic = getCurrentInputConnection();
		if (ic == null)
			return;
		ic.beginBatchEdit();
		if (mComposing.length() > 0) {
			commitTyped(ic);
		}
		ic.commitText(text, 0);
		ic.endBatchEdit();
		updateShiftKeyState(getCurrentInputEditorInfo());
	}

	public void swipeLeft() {
		handleBackspace();
	}

	public void swipeRight() {
		// TODO Auto-generated method stub
	}

	public void swipeDown() {
		handleClose();
	}

	public void swipeUp() {
		// TODO Auto-generated method stub
	}
}
