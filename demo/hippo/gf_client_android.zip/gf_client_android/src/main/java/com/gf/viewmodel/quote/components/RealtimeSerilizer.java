package com.gf.viewmodel.quote.components;

import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.QuoteMsg;
import com.gf.viewmodel.ebiz.quote.ReqBody;
import com.gf.viewmodel.ebiz.quote.ResBody;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.quote.BidAskQuoteItem;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.securities.Stock;

public class RealtimeSerilizer implements Serializer {

	@Override
	public DomainObject unSerializeResBody(ResBody body) {
		Stock stock;
		QuoteMsg msg = body.quoteRes.quote;
		stock = new Stock();
		stock.setMarket(body.market);
		stock.setStock_code(body.code);
		if (msg != null) {
			// RealtimeQuoteItemBundle stream = new RealtimeQuoteItemBundle();
			// stream.setSecurities(stock);
			RealtimeQuoteItem item = new RealtimeQuoteItem();
			item.setAmount(msg.amount);
			item.setChange(msg.change);
			item.setCittdiff(msg.cittdiff);
			item.setCittthan(msg.cittthan);
			// item.setCode(msg.code);
			// item.setMarket(stock.getMarket());
			item.setEps(msg.eps);
			item.setHandover(msg.handover);
			item.setHigh(msg.high);
			item.setIn(msg.in);
			item.setLow(msg.low);
			// item.setName(msg.name);
			item.setNow(msg.now);
			item.setNvaps(msg.nvaps);
			item.setOpen(msg.open);
			item.setOut(msg.out);
			item.setPclose(msg.pclose);
			item.setPe(msg.pe);
			// item.setPosition(msg.position);
			item.setQuarter(msg.quarter);
			item.setRise(msg.rise);
			item.setSecurityType(msg.intFromEnum(msg.type));
			item.setShare(msg.share);
			item.setStop(msg.stop);
			item.setTime(msg.time);
			item.setTotal(msg.total);
			item.setVolume(msg.volume);
			item.setSecurities(stock);

			for (int i = 0; i < msg.position.size(); i++) {
				BidAskQuoteItem postion = new BidAskQuoteItem();
				postion.setAsk(msg.position.get(i).ask);
				postion.setAsksize(msg.position.get(i).asksize);
				postion.setBid(msg.position.get(i).bid);
				postion.setBidsize(msg.position.get(i).bidsize);
				item.addBidAskQuoteItem(postion);
			}
			// stream.putItem(item);
			return item;
		}
		return null;

	}

	@Override
	public DomainObject unSerializeMsgBody(MsgBody body) {
		Stock stock;
		QuoteMsg msg = body.quote;
		stock = new Stock();
		stock.setMarket(body.market);
		stock.setStock_code(body.code);
		if (msg != null) {
			// RealtimeQuoteItemBundle stream = new RealtimeQuoteItemBundle();
			// stream.setSecurities(stock);
			RealtimeQuoteItem item = new RealtimeQuoteItem();
			item.setAmount(msg.amount);
			item.setChange(msg.change);
			item.setCittdiff(msg.cittdiff);
			item.setCittthan(msg.cittthan);
			// item.setCode(msg.code);
			// item.setMarket(stock.getMarket());
			item.setEps(msg.eps);
			item.setHandover(msg.handover);
			item.setHigh(msg.high);
			item.setIn(msg.in);
			item.setLow(msg.low);
			// item.setName(msg.name);
			item.setNow(msg.now);
			item.setNvaps(msg.nvaps);
			item.setOpen(msg.open);
			item.setOut(msg.out);
			item.setPclose(msg.pclose);
			item.setPe(msg.pe);
			// item.setPosition(msg.position);
			item.setQuarter(msg.quarter);
			item.setRise(msg.rise);
			item.setSecurityType(msg.intFromEnum(msg.type));
			item.setShare(msg.share);
			item.setStop(msg.stop);
			item.setTime(msg.time);
			item.setTotal(msg.total);
			item.setVolume(msg.volume);
			item.setSecurities(stock);

			for (int i = 0; i < msg.position.size(); i++) {
				BidAskQuoteItem postion = new BidAskQuoteItem();
				postion.setAsk(msg.position.get(i).ask);
				postion.setAsksize(msg.position.get(i).asksize);
				postion.setBid(msg.position.get(i).bid);
				postion.setBidsize(msg.position.get(i).bidsize);
				item.addBidAskQuoteItem(postion);
			}
			// stream.putItem(item);
			return item;
		}
		return null;
	}

	@Override
	public byte[] serialize(DomainObject object) {
		if (object instanceof RealtimeQuoteItem) {
			RealtimeQuoteItem quote = (RealtimeQuoteItem) object;
			ReqBody.Builder builder = new ReqBody.Builder();
			builder.fid(HQFuncTypes.HQ_SS);
			Stock stock = (Stock) quote.getSecurities();
			builder.market(stock.getMarket());
			builder.code(stock.getStock_code());
			ReqBody body = builder.build();

			byte[] bytes = body.toByteArray();
			return bytes;
		}
		return null;
	}

}
