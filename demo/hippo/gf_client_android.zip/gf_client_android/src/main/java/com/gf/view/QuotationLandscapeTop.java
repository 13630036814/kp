/**
 * 
 */
package com.gf.view;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.gf.client.R;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 横屏顶部数据
 * 
 * @author Cola
 * 
 */
public class QuotationLandscapeTop extends LinearLayout {
	private RealtimeQuoteItem mRealtimeQuoteItem;
	private TextView mOpen, mVolume, mPclose, mHeight, mLow, mName, mPrice,mTime;
	/** 涨跌值 */
	private TextView mChange;
	/** 涨跌幅 */
	public TextView mRise;
	/**
	 * 换手率
	 */
	public TextView mHandover;
	private String mStockName = "";

	public QuotationLandscapeTop(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;

	public QuotationLandscapeTop(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	public void init() {
		LayoutInflater.from(context).inflate(R.layout.qutation_landscape, this);
		this.mOpen = (TextView) findViewById(R.id.quotation_open);
		// this.mHandover = (TextView) findViewById(R.id.quotation_handover);
		this.mChange = (TextView) findViewById(R.id.quotation_change);
		this.mVolume = (TextView) findViewById(R.id.quotation_volume);
		this.mRise = (TextView) findViewById(R.id.quotation_rise);
		this.mPclose = (TextView) findViewById(R.id.quotation_pclose);
		mHeight = (TextView) findViewById(R.id.quotation_height);
		mLow = (TextView) findViewById(R.id.quotation_low);
		mName = (TextView) findViewById(R.id.quotation_stockname);
		mPrice = (TextView) findViewById(R.id.quotation_price);
		mTime = (TextView) findViewById(R.id.quotation_time);
	}

	private void draw() {
		if (mRealtimeQuoteItem.rise == 0) {
			mRise.setTextColor(getResources().getColor(R.color.shallow_grey));
			mPrice.setTextColor(getResources().getColor(R.color.shallow_grey));
			mChange.setTextColor(getResources().getColor(R.color.shallow_grey));
		} else if (mRealtimeQuoteItem.rise > 0) {
			mRise.setTextColor(getResources().getColor(R.color.shallow_red));
			mPrice.setTextColor(getResources().getColor(R.color.shallow_red));
			mChange.setTextColor(getResources().getColor(R.color.shallow_red));
		} else if (mRealtimeQuoteItem.rise < 0) {
			mRise.setTextColor(getResources().getColor(R.color.shallow_green));
			mPrice.setTextColor(getResources().getColor(R.color.shallow_green));
			mChange.setTextColor(getResources().getColor(R.color.shallow_green));
		}

		this.mChange.setText(mRealtimeQuoteItem.change + "");
		this.mPrice.setText(mRealtimeQuoteItem.now + "");
		this.mRise.setText(String.format("%1$.2f", mRealtimeQuoteItem.rise)
				+ "%");
		this.mOpen.setText(mRealtimeQuoteItem.open + "");
		this.mPclose.setText(mRealtimeQuoteItem.pclose + "");
		// this.mHandover.setText(String.format("%1$.2f",
		// mRealtimeQuoteItem.handover));
		float volume = mRealtimeQuoteItem.volume / 10000;
		this.mName.setText(mStockName);
		this.mVolume.setText(String.format("%1$.2f", volume) + "万");
		this.mHeight.setText(String.format("%1$.2f",
				mRealtimeQuoteItem.getHigh()));
		this.mLow.setText(String.format("%1$.2f", mRealtimeQuoteItem.getLow()));
		SimpleDateFormat dateformat2=new SimpleDateFormat("yyyyMMdd");
		this.mTime.setText(dateformat2.format(new Date()));
	}

	public void setData(RealtimeQuoteItem mTimeSeriesQuoteCache) {
		this.mRealtimeQuoteItem = mTimeSeriesQuoteCache;
		draw();
	}

	public void setStockName(String name) {
		mStockName = name;
	}
}
