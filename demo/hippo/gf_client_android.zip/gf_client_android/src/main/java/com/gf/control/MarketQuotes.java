/**
 * 
 */
package com.gf.control;

import java.util.ArrayList;
import java.util.List;

import com.gf.client.R;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.common.EventHandler;
import com.gf.hippo.domain.client.common.EventObject;
import com.gf.hippo.domain.client.quote.BoardRankQuoteManager;
import com.gf.hippo.domain.client.quote.BoardRankQuoteList;
import com.gf.hippo.domain.client.quote.BoardTypes;
import com.gf.hippo.domain.client.quote.CandleQuoteStreamItem;
import com.gf.hippo.domain.client.quote.RankQuoteItem;
import com.gf.hippo.domain.client.quote.RankSortType;
import com.gf.view.ListSortHeader;
import com.gf.view.ListSortHeader.OnSortListener;
import com.gf.view.adapter.MailAdapter;
import com.gf.view.adapter.PlateAdapter;
import com.gf.view.widget.BottomToolBar;
import com.gf.view.widget.Navigation;
import com.gf.view.widget.NavigationFragment;
import com.gf.view.widget.PullToRefreshBaseView;
import com.gf.view.widget.PullToRefreshView;
import com.gf.view.widget.PullToRefreshView.OnFooterRefreshListener;
import com.gf.view.widget.PullToRefreshView.OnHeaderRefreshListener;
import com.gf.view.widget.TapeStockTypeListView;
import com.gf.view.widget.NavigationFragment.onSelectorNavigationListener;
import com.gf.viewmodel.bean.DataSetKLine;
import com.gf.viewmodel.bean.MessageInfo;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * @author cola
 * 
 */
public class MarketQuotes extends FragmentActivity implements
		onSelectorNavigationListener,
		OnHeaderRefreshListener, OnFooterRefreshListener{
	private BoardRankQuoteList quote;
	private Dialog dialog;
	private List<Navigation> navs = buildNavigation();
	private NavigationFragment mNavigationFragment;
	private PullToRefreshView mPullToRefreshView;
	private PlateAdapter mPlateAdapter;
	private BottomToolBar menu;
	private RelativeLayout mPopMenu;
	private ListView mTapeStockTypeListView;
	private List<MessageInfo> MessageInfos;
	protected QuoteManagerFactory mQuoteManagerFactory = null; 
	/**
	 */
	private int mIndex = 0;
	private int mCommand = 0;
	private int prePrice = 1,preRise = 1 ,preRange = 1;
	private ListSortHeader mListSortHeader;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.marketquotes);
		init();
		setListener();
	}

	public void init() {
		MessageInfos = new ArrayList<MessageInfo>();
		mListSortHeader = ((com.gf.view.ListSortHeader) findViewById(R.id.header));
		mQuoteManagerFactory = ((BaseApplication)getApplication()).getQuoteManagerFactory();
//		mScrollView = (ScrollView) findViewById(R.id.scrollView);
		mPullToRefreshView = (PullToRefreshView) findViewById(R.id.main_pull_refresh_view);
		menu = (BottomToolBar) findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) findViewById(R.id.home_ugc);
		menu.getView();
		menu.setPopMenur(mPopMenu);
		((TextView) findViewById(R.id.title)).setText("行情中心");
//		mListView = (ListView) findViewById(R.id.rise_listview);
		mTapeStockTypeListView = (ListView) findViewById(R.id.rise_listview);
		mNavigationFragment = (NavigationFragment) getSupportFragmentManager()
				.findFragmentById(R.id.fragment_navigation);
		mNavigationFragment.setNavs(navs);
		mNavigationFragment.setOnSelectorNavigationListener(this);
		fillContent(navs.get(0));
		buildNavigation();
		
		mPlateAdapter = new PlateAdapter(this, MessageInfos);//第三个参数是：第一次填充listview时，分组是否展开
//		mTapeStockTypeListView.setDivider(this.getResources().getDrawable(R.drawable.horizontal_line));
		mTapeStockTypeListView.setAdapter(mPlateAdapter);
////		mListView.setAdapter(mPlateAdapter);
		
		menu = (BottomToolBar) findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) findViewById(R.id.home_ugc);
		menu.setPopMenur(mPopMenu);
//		mScrollView.setLayoutParams(params);
		mCommand = BoardTypes.BK_A;
		this.showDialog(true);
		setBoardRankListener(BoardTypes.BK_A,0,RankSortType.PX_CHANGE_PCT);
		mEventObjectRankHandler.setEventHandler(mBoardRankHandler);
	}

	private void fillContent(Navigation navigation) {
		Fragment fragment = null;
	}
	
	private void setListener() {
		((Button) findViewById(R.id.top_back_btn)).setBackgroundResource(R.drawable.back);
		((LinearLayout) findViewById(R.id.top_back)).setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
				MarketQuotes.this.setResult(MainActivity.FLOAT_MENU_MYSTOCK);
			}
			
		});
		
		mTapeStockTypeListView.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int pos,
					long arg3) {
				// TODO Auto-generated method stub
				Intent it = new Intent(MarketQuotes.this,QuotationActivity.class);
				Bundle b = new Bundle();
				b.putString("stockCode", MessageInfos.get(pos).getInfo());
				b.putString("stockMarket", MessageInfos.get(pos).mField4);
				b.putString("stockName", MessageInfos.get(pos).getGroupName());
				it.putExtras(b);
				((Activity) MarketQuotes.this).startActivityForResult(it,1);
			}
			
		});
		
		mPullToRefreshView.setOnHeaderRefreshListener(this);
		mPullToRefreshView.setOnFooterRefreshListener(this);
		
//		((TextView) findViewById(R.id.stockRang)).setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				mPlateAdapter.sort(preRange,0);
//				if(preRange == 1)
//					preRange = 2;
//				else
//					preRange = 1;
//			}
//			
//		});
//		
//		((TextView) findViewById(R.id.stock_price)).setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				mPlateAdapter.sort(prePrice,2);
//				if(prePrice == 1)
//					prePrice = 2;
//				else
//					prePrice = 1;
//			}
//			
//		});
//		
//		((TextView) findViewById(R.id.stock_rise)).setOnClickListener(new OnClickListener(){
//
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				mPlateAdapter.sort(preRise,1);
//				if(preRise == 1)
//					preRise = 2;
//				else
//					preRise = 1;
//			}
//			
//		});
//		
		mListSortHeader.setOnSortListener(new OnSortListener(){

			@Override
			public void sort(View v, int sort, int sortField) {
				// TODO Auto-generated method stub
				mPlateAdapter.sort(sort,sortField);
			}
			
		});
	}

	private List<Navigation> buildNavigation() {
		List<Navigation> navigations = new ArrayList<Navigation>();
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "A股"));
		navigations.add(new Navigation(Navigation.TYPE_1, "url", "B股"));
		navigations.add(new Navigation(Navigation.TYPE_2, "url", "基金"));
		navigations.add(new Navigation(Navigation.TYPE_3, "url", "指数"));
		navigations.add(new Navigation(Navigation.TYPE_4, "url", "权证"));
		navigations.add(new Navigation(Navigation.TYPE_5, "url", "债券"));
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "创业板"));
		navigations.add(new Navigation(Navigation.TYPE_3, "url", "中小版"));
		
		navigations.add(new Navigation(Navigation.TYPE_3, "url", "三板"));
		navigations.add(new Navigation(Navigation.TYPE_4, "url", "深A"));
		navigations.add(new Navigation(Navigation.TYPE_5, "url", "沪A"));
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "深B"));
		navigations.add(new Navigation(Navigation.TYPE_3, "url", "沪B"));
		return navigations;
	}

	@Override
	public void selector(Navigation navigation, int position) {
		// TODO Auto-generated method stub
		MessageInfos.clear();
		mQuoteManagerFactory.getboardRankQuoteManager().endWatch(quote, mEventObjectRankHandler);
		showDialog(true);
		switch(position){
		case 0:
			mCommand = BoardTypes.BK_A;
			setBoardRankListener(BoardTypes.BK_A,0,RankSortType.PX_CHANGE_PCT);
		break;
		case 1:
			mCommand = BoardTypes.BK_B;
			setBoardRankListener(BoardTypes.BK_B,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 2:
			mCommand = BoardTypes.BK_FUND;
			setBoardRankListener(BoardTypes.BK_FUND,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 3:
			mCommand = BoardTypes.BK_INDEX;
			setBoardRankListener(BoardTypes.BK_INDEX,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 4:
			mCommand = BoardTypes.BK_WARRANT;
			setBoardRankListener(BoardTypes.BK_WARRANT,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 5:
			mCommand = BoardTypes.BK_BOND;
			setBoardRankListener(BoardTypes.BK_BOND,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 6:
			mCommand = BoardTypes.BK_GROWTH;
			setBoardRankListener(BoardTypes.BK_GROWTH,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 7:
			mCommand = BoardTypes.BK_SMALL;
			setBoardRankListener(BoardTypes.BK_SMALL,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 8:
			mCommand = BoardTypes.BK_THIRD;
			setBoardRankListener(BoardTypes.BK_THIRD,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 9:
			mCommand = BoardTypes.BK_SZ_A;
			setBoardRankListener(BoardTypes.BK_SZ_A,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 10:
			mCommand = BoardTypes.BK_SH_A;
			setBoardRankListener(BoardTypes.BK_SH_A,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 11:
			mCommand = BoardTypes.BK_SZ_B;
			setBoardRankListener(BoardTypes.BK_SZ_B,0,RankSortType.PX_CHANGE_PCT);
			break;
		case 12:
			mCommand = BoardTypes.BK_SH_B;
			setBoardRankListener(BoardTypes.BK_SH_B,0,RankSortType.PX_CHANGE_PCT);
			break;
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		setResult(resultCode);
//		finish();
	}
	
	/**
	 */
	public void setBoardRankListener(int type,int dir,int sort){
		BoardRankQuoteManager boardRankQuoteManager=mQuoteManagerFactory.getboardRankQuoteManager();
		quote=boardRankQuoteManager.getBoardQuoteList(type,dir,sort);
		quote.setCount(30);
		//quote.setDirect(0);
		quote.setFrom(mIndex * 30);
		//quote.setSort(RankSortType.PX_CHANGE_PCT);

		
		boardRankQuoteManager.beginWatch(quote, mEventObjectRankHandler);
	//终止时
//		boardRankQuoteManager.endWatch(quote, boardRankHandler);
	}
	
	EventObject mEventObjectRankHandler = new EventObject();
	
	EventHandler mBoardRankHandler= new EventHandler() {
		@Override
		public void onEvent(Event event) {
			BoardRankQuoteList quote = (BoardRankQuoteList) event.getObject();
			// 更新UI数据
			reconsitution(quote.getAllItems());
			mPlateAdapter.notifyDataSetChanged();
			
			mPullToRefreshView.onFooterRefreshComplete();
			mPullToRefreshView.onHeaderRefreshComplete();
			dismissDialog();
		}
	};
	
	protected void reconsitution(RankQuoteItem[] items) {
		// MessageInfos.clear();
		if (MessageInfos.size() == 0) {
			for (RankQuoteItem item : items) {
				MessageInfo msg = new MessageInfo();
				msg.setGroupName(item.getName());
				msg.setInfo(item.getCode());
				msg.mField3 = String.valueOf(item.getRise());
				msg.mField2 = String.valueOf(item.getChange());
				msg.mField1 = String.valueOf(item.getNow());
				msg.mField4 = item.getMarket();
				msg.high = item.getHigh();
				msg.low = item.getLow();
				msg.open = item.getOpen();
				msg.volume = item.getVolume();
				MessageInfos.add(msg);
			}
		} else {
			boolean add = false;
			int len = MessageInfos.size();
			for (RankQuoteItem item : items) {
				for (int n = 0; n < len; n++) {
					MessageInfo msg = MessageInfos.get(n);
					if (item.getCode().equals(msg.getInfo())
							&& item.getMarket().equals(
									MessageInfos.get(n).mField4)) {
						msg.mField3 = String.valueOf(item.getRise());
						msg.mField2 = String.valueOf(item.getChange());
						msg.mField1 = String.valueOf(item.getNow());
						msg.volume = item.getVolume();
						add = false;
						break;
					}
					
					if(n == len - 1)
						add = true;
				}
				
				if(add){
					MessageInfo msg = new MessageInfo();
					msg.setGroupName(item.getName());
					msg.setInfo(item.getCode());
					msg.mField3 = String.valueOf(item.getRise());
					msg.mField2 = String.valueOf(item.getChange());
					msg.mField1 = String.valueOf(item.getNow());
					msg.mField4 = item.getMarket();
					msg.high = item.getHigh();
					msg.low = item.getLow();
					msg.open = item.getOpen();
					msg.volume = item.getVolume();
					MessageInfos.add(msg);
					add = false;
				}
			}
		}
		mPlateAdapter.notifyDataSetChanged();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		mQuoteManagerFactory.getboardRankQuoteManager().endWatch(quote, mEventObjectRankHandler);
		super.onDestroy();
		
	}

	@Override
	public void onFooterRefresh(PullToRefreshView view) {
		// TODO Auto-generated method stub
		mQuoteManagerFactory.getboardRankQuoteManager().endWatch(quote, mEventObjectRankHandler);
		mIndex++;
		MessageInfos.clear();
		setBoardRankListener(this.mCommand,0,RankSortType.PX_CHANGE_PCT);
		
		new Handler().postDelayed(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				mPullToRefreshView.onFooterRefreshComplete();
				
			}
			 
		 },4000);
	}

	@Override
	public void onHeaderRefresh(PullToRefreshView view) {
		// TODO Auto-generated method stub
		
		if(mIndex > 0)
			mIndex--;
		else{
			mPullToRefreshView.onHeaderRefreshComplete();
			return;
		}
		mQuoteManagerFactory.getboardRankQuoteManager().endWatch(quote, mEventObjectRankHandler);
		MessageInfos.clear();
		setBoardRankListener(this.mCommand,0,RankSortType.PX_CHANGE_PCT);
		
		new Handler().postDelayed(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				mPullToRefreshView.onHeaderRefreshComplete();
			}
			 
		 },4000);
	}
	
	/**
	 * 显示进度框
	 * 
	 * @param showDialog
	 */
	public void showDialog(boolean showDialog) {

		if (showDialog) {
			if (dialog == null) {
				dialog = new Dialog(this, R.style.Dialog_Fullscreen);
				dialog.setContentView(R.layout.progress);
				RelativeLayout iv = (RelativeLayout) dialog
						.findViewById(R.id.tipslayout);

				ProgressBar m_progress = (ProgressBar) iv
						.findViewById(R.id.m_progress);
				m_progress.setVisibility(View.VISIBLE);
				m_progress.setIndeterminate(true);

				m_progress.setIndeterminateDrawable(this.getResources()
						.getDrawable(R.anim.loading));
				iv.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});

			}
			try {
				dialog.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void dismissDialog() {
		if (dialog != null) {
			dialog.dismiss();
		}
	}
	
	private void show(){
		new Handler().postDelayed(new Runnable() {

			@Override
			public void run() {//设置超时自动隐藏
				dismissDialog();
			}
		}, 5000);
	}
}
