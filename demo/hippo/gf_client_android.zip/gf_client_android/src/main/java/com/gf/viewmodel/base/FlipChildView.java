/**
 * 
 */
package com.gf.viewmodel.base;

import com.gf.control.Desktop.onChangeViewListener;
import com.gf.view.widget.FlipperLayout.OnOpenListener;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;

/**
 * 各主界面功能的父类
 * @author mrcola
 *
 */
public abstract class FlipChildView {
	protected OnOpenListener mOnOpenListener;
	protected Activity mActivity;
	protected LayoutInflater mLayoutInflater;
	
	
	public FlipChildView(Activity mActivity){
		this.mActivity = mActivity;
		mLayoutInflater = LayoutInflater.from(mActivity);

	}
	abstract public View getView();
	abstract public void findViewById() ;
	abstract public void init();
	abstract public void setListener();
	abstract public int getID();
	/**
	 * activity 回调通知
	 * @param type 回调类型
	 * @param data 回调的数据
	 */
	abstract public void update(int type,Object data);
	/**
	 * 获取子类类型
	 */
	abstract public int getChildId();
	public void setOnOpenListener(OnOpenListener onOpenListener) {
		mOnOpenListener = onOpenListener;
	}
	
}
