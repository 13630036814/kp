package com.gf.viewmodel.quote.components;

import android.os.Handler;


public class QuoteTimer extends com.gf.hippo.domain.client.common.Timer {
	private Handler mHandler;
	
	public QuoteTimer(Handler handler) {
		mHandler = handler;
	}
	
    @Override
    public Object startTimer(int interval, final Runnable runnable) {
    	Timer mTimer = new Timer(mHandler);
        mTimer.setInterval(interval);
        
        mTimer.start(new Callback(){
            @Override
            public void run() {
                runnable.run();
            }
        });
        return mTimer;
    }

    @Override
    public void stopTimer(Object timer) {
    	((Timer)timer).stop();
    }
    
    static interface Callback{
        public void run();
    }
    
    class Timer {
        private Handler mHandler;
        private Runnable mRunnable;
        private Callback mCallback;
        private long mInterval = 0;
        private int mTimes = -1;
        private int mCurrentTimes = 0;
        private boolean mPaused = false;
        
        public Timer(Handler handler) {
        	mHandler = handler;
        	init();
        }
        
        public Timer(long interval, int times){
        	mInterval = interval;
        	mTimes = times;
        	init();
        }
        
		private void init() {
            mRunnable = new Runnable() {
                @Override
                public void run() {
                    if (mPaused) {
                    	return;
                    }
                    if (mCallback == null) {
                    	return;
                    }
                    mCurrentTimes++;
                    mCallback.run();
                    postDelayed();
                }
            };
        }
        
        public void setInterval(long interval){
            mInterval = interval;
        }
        
        public void setTimes(int times){
            mTimes = times;
        }
        
        public void start(Callback callback){
            if (mCallback != null) {
            	stop();
            }
            mCallback = callback;
            postDelayed();
        }
        
        private boolean postDelayed(){
            if (!isFinished()){
                mHandler.postDelayed(mRunnable, mInterval);
                return true;
            }
            return false;
        }
        
        public void stop(){
            mHandler.removeCallbacks(mRunnable);
            mCallback = null;
            mCurrentTimes = 0;
            mPaused = false;
        }
        
        public void pause(){
            mPaused = true;
            mHandler.removeCallbacks(mRunnable);
        }
        
        public boolean isFinished(){
            return !(mTimes < 0 || mCurrentTimes < mTimes);
        }
        
        public void resume(){
            mPaused = false;
            postDelayed();
        }
    }

}
