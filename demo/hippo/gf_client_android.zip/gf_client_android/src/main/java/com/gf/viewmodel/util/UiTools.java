package com.gf.viewmodel.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class UiTools {

	/***
	 * 显示确定对话框
	 * 
	 * @param context
	 * @param Title
	 * @param Msg
	 * @param idevent onOK()
	 */
	public static void ShowMessageBox(Context context, String Title, String Msg, final IDialogEvent idevent) {
		AlertDialog.Builder alert = new AlertDialog.Builder(context);
		alert.setTitle(Title).setMessage(Msg);
		alert.setPositiveButton("确定", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				if (idevent != null)
					idevent.onOk();
			}
		});
		alert.setCancelable(false);
		alert.create().show();
	}

	/***
	 * 显示确定取消对话框
	 * 
	 * @param context
	 * @param Title
	 * @param Msg
	 * @param positiveLabel 确定按钮显示字符串
	 * @param NegativeLabel 取消按钮显示字符串
	 * @param idevent onYes(), onNo()
	 */
	public static void ShowMessageBoxYesNo(Context context, String Title, String Msg, String positiveLabel, String NegativeLabel, final IDialogEvent idevent) {
		AlertDialog.Builder alert = new AlertDialog.Builder(context);
		alert.setTitle(Title).setMessage(Msg);
		alert.setPositiveButton(positiveLabel, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				if (idevent != null)
					idevent.onYes();
			}
		}).setNegativeButton(NegativeLabel, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				if (idevent != null)
					idevent.onNo();
			}
		});
		alert.setCancelable(false);
		alert.create().show();
	}
	
	/**
	 * 显示自定义toast信息
	 * @param context
	 * @param tip
	 */
	public static void showToast(Context context, String tip) {
		ShowMessageBox(context, "", tip, new IDialogEvent() {

			@Override
			public void onYes() {
			}

			@Override
			public void onNo() {
			}

			@Override
			public void onCancel() {
			}

			@Override
			public void onOk() {
			}
		});
	}

}
