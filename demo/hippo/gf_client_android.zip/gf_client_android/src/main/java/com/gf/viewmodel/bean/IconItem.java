package com.gf.viewmodel.bean;

public class IconItem {
	private String fileName;
	private String title;
	private String className;
	private String packageName;
	private String selectFlag;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getSelectFlag() {
		return selectFlag;
	}

	public void setSelectFlag(String selectFlag) {
		this.selectFlag = selectFlag;
	}

	public String toString() {
		String str = "";
		str += fileName + " ";
		str += title + " ";
		str += className + " ";
		str += packageName + " ";
		str += selectFlag;
		return str;
	}
}
