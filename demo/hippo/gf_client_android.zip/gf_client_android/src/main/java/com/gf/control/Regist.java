package com.gf.control;

import java.security.MessageDigest;

import org.json.JSONException;
import org.json.JSONObject;

import com.gf.client.R;
import com.gf.viewmodel.base.HttpManager;
import com.gf.viewmodel.base.HttpManager.NetWorkCallBack;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class Regist extends Activity {
	protected static final String TAG = "Regist";  
	private ImageButton mBtnBack = null;
	private Button mBtnGetAuthCode = null;
	private Button mBtnFinish;
	private EditText mEditTextPhoneNum = null; //手机号
	private EditText mEditTextAuthCode = null; // 验证码
	private EditText mEditTextGfComm = null; // 广发通
	private EditText mEditTextPsd = null; // 密码
	private EditText mEditTextPsdAgain = null; // 确认密码
	
	private String mPhoneNum = null;
	private String mAuthCodeFromEdit = null;
	private String mAuthCodeFromServer = null;
	private String mGfComm = null;
	private String mPsd = null;
	private String mPsdAgain = null;
	
	private HttpManager mHttpManager = null;
	private static final int AUTH_CODE_ERR_MSG = 0;
	private static final int PHONE_NUM_HAVE_REGIST = 1;
	private static final int PHONE_NUM_NOT_REGIST = 2;
	private static final int AUTH_CODE_RIGHT_MSG = 3;
	private static final int INPUT_WRONG_MSG = 4;
	private static final int REGIST_SUCCESS = 5;
	private static final int PSD_ERROR_MSG = 6;
	private static final int PSD_NULL = 7;
	private static final int GF_COMM_NULL = 8;
	
	private static final String SUCCESS = "success";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.regist);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_UNSPECIFIED);
		findView();
		init();
		initView();
	}

	private void init() {
		mHttpManager = HttpManager.getInstance();
	}

	private void findView() {
		mBtnBack = (ImageButton)(findViewById(R.id.btn_back));
		mBtnGetAuthCode = (Button)(findViewById(R.id.btn_auth_code));
		mBtnFinish = (Button)findViewById(R.id.btn_finish);
		mEditTextPhoneNum = (EditText)findViewById(R.id.edit_phnoe_num);
		mEditTextAuthCode = (EditText)findViewById(R.id.edit_auth_code);
		mEditTextGfComm = (EditText)findViewById(R.id.edit_username);
		mEditTextPsd = (EditText)findViewById(R.id.edit_password);
		mEditTextPsdAgain = (EditText)findViewById(R.id.edit_password_again);
	}
	
	private void initView() {
		
		mBtnFinish.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// 判断手机号是否为空
				mPhoneNum = mEditTextPhoneNum.getText().toString();
				if (mPhoneNum == null || mPhoneNum.length() == 0) {
					Message msg = mHandler.obtainMessage();
					msg.what = INPUT_WRONG_MSG;
					mHandler.sendMessage(msg);
					return;
				}
				
				mPsd = mEditTextPsd.getText().toString();
				mPsdAgain = mEditTextPsdAgain.getText().toString();
				if (!mPsd.equals(mPsdAgain)) {
					Message msg = mHandler.obtainMessage();
					msg.what = PSD_ERROR_MSG;
					mHandler.sendMessage(msg);
					return;
				}
				
				// 判断账户是否为空
				mGfComm = mEditTextGfComm.getText().toString();
				if (mPsd == null || mPsd.length() ==0) {
					Message msg = mHandler.obtainMessage();
					msg.what = GF_COMM_NULL;
					mHandler.sendMessage(msg);
					return;
				}
				
				// 判断密码是否为空
				if (mGfComm == null || mGfComm.length() == 0) {
					Message msg = mHandler.obtainMessage();
					msg.what = PSD_NULL;
					mHandler.sendMessage(msg);
					return;
				}
				
				
				// 判断验证码是否正确
				mAuthCodeFromEdit = mEditTextAuthCode.getText().toString();
				if (!mAuthCodeFromEdit.equals(mAuthCodeFromServer)) {
					Message msg = mHandler.obtainMessage();
					msg.what = AUTH_CODE_ERR_MSG;
					mHandler.sendMessage(msg);
					return;
				} else {
					Message msg = mHandler.obtainMessage();
					msg.what = AUTH_CODE_RIGHT_MSG;
					mHandler.sendMessage(msg);
				}
				
				verifyPhoneNum(mPhoneNum);
				
				// 开始注册
				beginRegist();
			}
		});
		
		// 返回
		mBtnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(Regist.this, GfCommonLoginActivity.class);
				startActivity(intent);
				Regist.this.finish();
			}
		});
		
		// 获取验证码
		mBtnGetAuthCode.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				mPhoneNum = mEditTextPhoneNum.getText().toString();
				if (mPhoneNum == null || mPhoneNum.length() == 0) {
					Message msg = mHandler.obtainMessage();
					msg.what = INPUT_WRONG_MSG;
					mHandler.sendMessage(msg);
					return;
				}
				
				NetWorkCallBack callback = new NetWorkCallBack() {
					@Override
					public void end(String result) {
						Log.v(TAG, "getAuthCode result: " + result);
						try {
							JSONObject resultJson = new JSONObject(result);
							String mobileTicket = (String)resultJson.get("mobile_ticket");
							mAuthCodeFromServer = mobileTicket;
							Log.v(TAG, "mobile_ticket: " + mobileTicket);
						} catch (JSONException e) {
							e.printStackTrace();
						}
					}
				};
				
				getAuthCode(mPhoneNum, callback);
			}
		});
	}
	
	
	/**
	 * 注册
	 */
	private void beginRegist() {
		NetWorkCallBack callback = new NetWorkCallBack() {
			public void end(String result) {
				Log.v(TAG, "beginRegist result: " + result);
				try {
					JSONObject resultJson = new JSONObject(result);
					String errorInfo = (String) (resultJson.get("error_info"));
					if (errorInfo.equals(HttpManager.SUCCESS)) {
						Regist.this.finish();
						Intent intent = new Intent(Regist.this, MainActivity.class);
						startActivity(intent);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};
		
		String value = "mobile=" + mPhoneNum + "&"
					+ "password=" + toMD5StringCapital(mPsd) + "&" 
					+ "service_name=" + mGfComm + "&" 
					+ "smsticket=" + mAuthCodeFromEdit;
		
		Log.v(TAG, "beginRegist value: " + value);
		
		mHttpManager.visitNetWorkGet(HttpManager.REGIST_URL, value, callback);
	}
	
	/**
	 * 获取验证码
	 */
	public void getAuthCode(String phoneNum, NetWorkCallBack callback) {
		String value = "mobile=" + phoneNum + "&" + "MD5PSW=" +  toMD5String(phoneNum + "gfzqsms");
		Log.v(TAG, "getAuthCode value: " + value);
		mHttpManager.visitNetWorkGet(HttpManager.GET_AUTH_CODE_RRL, value, callback);
	}
	
	/**
	 * @param phoneNum
	 */
	public void verifyPhoneNum(String phoneNum) {
		NetWorkCallBack callback = new NetWorkCallBack() {
			@Override
			public void end(String result) {
				Log.v(TAG, "verifyPhoneNum result: " + result);
				try {
					JSONObject resultJson = new JSONObject(result);
					String errorInfo = (String)resultJson.get("error_info");
					// 手机号已经被注册
					if (errorInfo.equals(SUCCESS)) {
						Message msg = mHandler.obtainMessage();
						msg.what = PHONE_NUM_HAVE_REGIST;
						mHandler.sendMessage(msg);
					} else {
						Message msg = mHandler.obtainMessage();
						msg.what = PHONE_NUM_NOT_REGIST;
						mHandler.sendMessage(msg);
					}
					
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		};
		String value = "mobile=" + phoneNum;
		Log.v(TAG, "verifyPhoneNum value: " + value);
		
		mHttpManager.visitNetWorkGet(HttpManager.VERIFY_PHONE_NUM_URL, value, callback);
	}
	
	/**
	 * 加密
	 * @param s
	 * @return
	 */
	public String toMD5String(String s) {
		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'a', 'b', 'c', 'd', 'e', 'f' };
		try {
			byte[] strTemp = s.getBytes();
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(strTemp);
			byte[] md = messageDigest.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				str[k++] = hexDigits[byte0 >>> 4 & 0xf];
				str[k++] = hexDigits[byte0 & 0xf];
			}
			return new String(str);
		} catch (Exception e) {
			return null;
		}
	}
	
	public String toMD5StringCapital(String s) {
		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'A', 'B', 'C', 'D', 'E', 'F' };
		try {
			byte[] strTemp = s.getBytes();
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(strTemp);
			byte[] md = messageDigest.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				str[k++] = hexDigits[byte0 >>> 4 & 0xf];
				str[k++] = hexDigits[byte0 & 0xf];
			}
			return new String(str);
		} catch (Exception e) {
			return null;
		}
	}
	
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case AUTH_CODE_ERR_MSG:
				Toast.makeText(Regist.this, "验证码输入错误", Toast.LENGTH_LONG).show();
				break;
			case PHONE_NUM_HAVE_REGIST:
				//Toast.makeText(Regist.this, "手机号已经注册", Toast.LENGTH_LONG).show();
				phoneNumHaveRegistHandler();
				break;
			case PHONE_NUM_NOT_REGIST:
				break;
			case AUTH_CODE_RIGHT_MSG:
				break;
			case INPUT_WRONG_MSG:
				Toast.makeText(Regist.this, "手机号不能为空", Toast.LENGTH_LONG).show();
				break;
			case PSD_ERROR_MSG:
				Toast.makeText(Regist.this, "两次输入的密码不一致", Toast.LENGTH_LONG).show();
				break;
			case PSD_NULL:
				Toast.makeText(Regist.this, "密码不能为空", Toast.LENGTH_LONG).show();
				break;
			case GF_COMM_NULL:
				Toast.makeText(Regist.this, "账户不能为空", Toast.LENGTH_LONG).show();
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	public void phoneNumHaveRegistHandler() {
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);     
        alertDialog     
                .setTitle(R.string.warn)     
                .setMessage(R.string.warn_msg)     
                .setPositiveButton("ok",
                        new DialogInterface.OnClickListener() {     
                            @Override     
                            public void onClick(DialogInterface dialog, int which) {     
                            	Intent intent = new Intent(Regist.this, GfCommonLoginActivity.class);
                    			startActivity(intent);
                    			Regist.this.finish();
                            }     
                        }).show();
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			Intent intent = new Intent(Regist.this, GfCommonLoginActivity.class);
			startActivity(intent);
			Regist.this.finish();
			break;
		}

		return false;
	}
}
