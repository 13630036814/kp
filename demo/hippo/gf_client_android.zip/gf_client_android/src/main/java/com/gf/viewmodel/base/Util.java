package com.gf.viewmodel.base;

import java.security.MessageDigest;

public class Util {
	public static final int LOWER_CASE = 0;
	public static final int CAPITAL = 1;
	
	public static String toMD5String(String s, int flag) {
		char strLowerCase[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'a', 'b', 'c', 'd', 'e', 'f' };
		
		char strCapital[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'A', 'B', 'C', 'D', 'E', 'F' };
		
		try {
			byte[] strTemp = s.getBytes();
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(strTemp);
			byte[] md = messageDigest.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			if (flag == LOWER_CASE) {
				for (int i = 0; i < j; i++) {
					byte byte0 = md[i];
					str[k++] = strLowerCase[byte0 >>> 4 & 0xf];
					str[k++] = strLowerCase[byte0 & 0xf];
				}
			} else if (flag == CAPITAL) {
				for (int i = 0; i < j; i++) {
					byte byte0 = md[i];
					str[k++] = strCapital[byte0 >>> 4 & 0xf];
					str[k++] = strCapital[byte0 & 0xf];
				}
			} else {
				
			}
			
			return new String(str);
		} catch (Exception e) {
			return null;
		}
	}
}
