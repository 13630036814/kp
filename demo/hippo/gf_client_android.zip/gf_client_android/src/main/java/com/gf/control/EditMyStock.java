/**
 * 
 */
package com.gf.control;

import java.util.ArrayList;
import java.util.Collections;

import android.content.Intent;
import android.database.MatrixCursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gf.client.R;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.securities.SimpleUserStockManager;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.view.adapter.EditMyStockAdapter;
import com.gf.view.adapter.EditMyStockAdapter.StockAction;
import com.gf.view.widget.DSLVFragmentClicks;
import com.gf.view.widget.DragSortController;
import com.gf.view.widget.DragSortListView;
import com.gf.view.widget.DragSortListView.DragSortListener;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;

/**
 * 编辑我的自选股页面
 * 
 * @author Cola
 * 
 */
public class EditMyStock extends FragmentActivity implements StockAction{
	private boolean mSortEnabled = true;
	private boolean mDragEnabled = true;
	private String mTag = "EditMyStock";
	private int mNumHeaders = 0;
	private int mNumFooters = 0;
	private int mDragStartMode = DragSortController.ON_DRAG;
	private boolean mRemoveEnabled = true;
	private int mRemoveMode = DragSortController.FLING_REMOVE;
	private EditMyStockAdapter adapter;
	protected SimpleUserStockManager mUserStockManager = null;
	protected QuoteManagerFactory mQuoteManagerFactory = null;
	protected SimpleUserStockManager mSimpleUserStockManager = null;
	protected StockList mStockList = new StockList();
	protected ArrayList<Stock> mCacheStockList = new ArrayList<Stock>();
	private DragSortListView dslv;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.editmystock);

		init();

	}

	private void init() {
		((TextView) findViewById(R.id.title)).setText("编辑");
		((Button) findViewById(R.id.top_back_btn)).setBackgroundResource(R.drawable.back);
		((Button) findViewById(R.id.in_stock)).setBackgroundResource(R.drawable.edit_add);
		((LinearLayout) findViewById(R.id.top_back)).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				save();
				finish();
			}

		});

		String[] cols = { "name" };
		int[] ids = { R.id.text };
		adapter = new EditMyStockAdapter(this, R.layout.list_item_click_remove,
				null, cols, ids, 0);
		adapter.setStockAction(this);
		dslv = (DragSortListView) findViewById(R.id.drag_list);
		dslv.setAdapter(adapter);
		setUserStockListener();
		mStockList = mSimpleUserStockManager.getUserStocks();
		Log.e(mTag,mStockList.getAllItems().length + "");
		// build a cursor from the String array
		MatrixCursor cursor = new MatrixCursor(new String[] { "_id", "name" });
		// String[] artistNames =
		// getResources().getStringArray(R.array.jazz_artist_names);
		int len = mStockList.getAllItems().length;
		for (int i = 0; i < len; i++) {
			cursor.newRow()
					.add(i)
					.add(mStockList.getItemAt(i).getStock_name() + "\n"
							+ mStockList.getItemAt(i).getStock_code());
		}
		adapter.changeCursor(cursor);
		
	}

	protected void setUserStockListener() {

		mQuoteManagerFactory = ((BaseApplication) getApplication())
				.getQuoteManagerFactory();
		mUserStockManager = mQuoteManagerFactory.getUserStockManager();
		mSimpleUserStockManager = mQuoteManagerFactory.getUserStockManager();
		
//		dslv.setDropListener(this);
	}
	
	private void sort(int from, int to){
//		mCacheStockList.clear();
		
		Collections.swap(mCacheStockList, from, to);
	}

	private void copy(){
		int len = mStockList.getAllItems().length;
		for(int n = 0; n < len; n++){
			mCacheStockList.add(mStockList.getItemAt(n));
		}
	}
	
	@Override
	public void drop(int from, int to) {
		// TODO Auto-generated method stub
		Log.e(mTag, "from: " + from + " to: " + to);
		if(mCacheStockList.size() == 0){
			copy();
		}
		 
		sort(from,to);
//		adapter.notifyDataSetChanged();
		
	}

	@Override
	public void add(int pos) {
		// TODO Auto-generated method stub
		Stock stock = mStockList.getItemAt(pos);
		// 添加到数据库
		if (stock != null) {
			mUserStockManager.addUserStock(stock);
		}
	}

	@Override
	public void del(int pos) {
		// TODO Auto-generated method stub
		Stock stock = mStockList.getItemAt(pos);
		Toast.makeText(this, stock.getStock_name() + "删除成功", Toast.LENGTH_LONG).show();
		mUserStockManager.removeUserStock(stock);
		adapter.remove(pos);
	}
	
	private void save(){
		if(mCacheStockList.size() == 0) return;
		
//		clean();
		int len = mCacheStockList.size();
		Stock sa[] = new Stock[len];
		for(int n = 0; n < len; n++){
			
			Stock stock = mCacheStockList.get(n);
			Log.e(mTag,stock.getStock_name() + " : " + n);
//			mUserStockManager.removeUserStock(stock);
//			mStockList.putItem(stock);
			sa[n] = stock;

		}
//		Log.e(mTag,mSimpleUserStockManager.getUserStocks().getAllItems().length + " 1111");
//		mUserStockManager.addUserStock(mStockList);
		mUserStockManager.setUserStocks(sa);
		
//		Log.e(mTag,mSimpleUserStockManager.getUserStocks().getAllItems().length + " gfgf");
		
		this.setResult(MainActivity.FLOAT_ACTIVITYRESULT_LISTSORT);
	}
	
	private void clean(){
//		Stock stock[] = mStockList.getAllItems();
//		for(Stock s : stock){
			mUserStockManager.removeUserStock(mStockList);
//			mUserStockManager.removeUserStock(s);
//			Log.e(mTag,mSimpleUserStockManager.getUserStocks().getAllItems().length + " 13312");
//		}
		mStockList.removeAllItems();
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			save();
			finish();
			break;
		}
		return false;

	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
//		setResult(resultCode);
//		finish();
		MatrixCursor cursor = new MatrixCursor(new String[] { "_id", "name" });
		mStockList = mSimpleUserStockManager.getUserStocks();
		int len = mStockList.getAllItems().length;
		for (int i = 0; i < len; i++) {
			cursor.newRow()
					.add(i)
					.add(mStockList.getItemAt(i).getStock_name() + "\n"
							+ mStockList.getItemAt(i).getStock_code());
		}
		adapter.swapCursor(cursor);
		mCacheStockList.clear();
//		adapter.changeCursor(cursor);
//		adapter.notifyDataSetChanged();
	}
}
