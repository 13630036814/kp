/**
 * 
 */
package com.gf.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;

/**
 * @author Cola
 *
 */
public class QuotationData extends LinearLayout{
	private RealtimeQuoteItem mRealtimeQuoteItem;
	private TextView mOpen, mVolume, mPclose, mPrice;
	/** 涨跌值 */
	private TextView mChange;
	/** 涨跌幅 */
	public TextView mRise;
	/**
	 * 换手率
	 */
	public TextView mHandover;

	public QuotationData(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;

	public QuotationData(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	public void init() {
		LayoutInflater.from(context).inflate(R.layout.quotation_data2, this);
		this.mOpen = (TextView) findViewById(R.id.quotation_open);
		this.mHandover = (TextView) findViewById(R.id.quotation_handover);
		this.mChange = (TextView) findViewById(R.id.quotation_change);
		this.mVolume = (TextView) findViewById(R.id.quotation_volume);
		this.mRise = (TextView) findViewById(R.id.quotation_rise);
		this.mPclose = (TextView) findViewById(R.id.quotation_pclose);
		mPrice = (TextView) findViewById(R.id.quotation_price);
	}

	public void setData(RealtimeQuoteItem mTimeSeriesQuoteCache) {
		this.mRealtimeQuoteItem = mTimeSeriesQuoteCache;
		draw();
	}

	private void draw() {
		if(mRealtimeQuoteItem.rise == 0){
			mRise.setTextColor(getResources().getColor(
					R.color.shallow_grey));
			mPrice.setTextColor(getResources().getColor(
					R.color.shallow_grey));
			mChange.setTextColor(getResources().getColor(
					R.color.shallow_grey));
		}else if(mRealtimeQuoteItem.rise > 0){
			mRise.setTextColor(getResources().getColor(
					R.color.shallow_red));
			mPrice.setTextColor(getResources().getColor(
					R.color.shallow_red));
			mChange.setTextColor(getResources().getColor(
					R.color.shallow_red));
		}else if(mRealtimeQuoteItem.rise < 0){
			mRise.setTextColor(getResources().getColor(
					R.color.shallow_green));
			mPrice.setTextColor(getResources().getColor(
					R.color.shallow_green));
			mChange.setTextColor(getResources().getColor(
					R.color.shallow_green));
		}
		
		this.mChange.setText(mRealtimeQuoteItem.change + "");
		this.mPrice.setText(mRealtimeQuoteItem.now + "");
		this.mRise.setText(String.format("%1$.2f", mRealtimeQuoteItem.rise) + "%");
		this.mOpen.setText(mRealtimeQuoteItem.open + "");
		this.mPclose.setText(mRealtimeQuoteItem.pclose + "");
		this.mHandover.setText(String.format("%1$.2f", mRealtimeQuoteItem.handover));
		float volume = mRealtimeQuoteItem.volume / 10000;
		
		this.mVolume.setText(String.format("%1$.2f", volume) + "万");
	}
}
