package com.gf.viewmodel.quote.components;


import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.common.Parser;
import com.gf.hippo.domain.client.securities.CodeList;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockManager;
import com.gf.viewmodel.ebiz.quote.CodeListRes;
import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.ReqBody;
import com.gf.viewmodel.ebiz.quote.ResBody;
import com.gf.viewmodel.ebiz.quote.CodeListRes.CodeListData;
import com.squareup.wire.Wire;

public class CodeListSerilizer implements Serializer {

	@Override
	public DomainObject unSerializeResBody(ResBody body) {
		final CodeListRes msg = body.codelistRes;
		if (msg == null)
			return null;
		CodeList codeList = new CodeList();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
		codeList.setCurrentHash(msg.sha);
		codeList.setUpdateDate(formatter.format(new Date()));
		for (int i = 0; i < msg.data.size(); ++i) {
			CodeListData data2 = msg.data.get(i);
			Stock item = new Stock();
			item.setBoard(data2.board);
			item.setStock_code(data2.code);
			item.setExchangecode(data2.exchangecode);
			item.setStock_name(data2.name);
			item.setPinyin(data2.pinyin);
			item.setStockType(data2.type);
			item.setMarket(data2.market);
			codeList.getItems().putItem(item);

		}
		return codeList;
	}

	@Override
	public DomainObject unSerializeMsgBody(MsgBody body) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] serialize(DomainObject object) {
		if (object instanceof CodeList) {
			CodeList quote = (CodeList) object;
			ReqBody.Builder builder = new ReqBody.Builder();
			builder.fid(HQFuncTypes.HQ_DM);

			ReqBody body = builder.build();

			byte[] bytes = body.toByteArray();
			return bytes;
		} else
			return null;

	}

}
