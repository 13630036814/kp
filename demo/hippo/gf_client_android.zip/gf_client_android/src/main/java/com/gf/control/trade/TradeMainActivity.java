package com.gf.control.trade;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.control.trade.query.NewStockLimitListActivity;
import com.gf.control.trade.query.NewStockTradeListActivity;
import com.gf.control.trade.query.StockTradeEntrustListActivity;
import com.gf.control.trade.query.TradeQueryFragmentActivity;

public class TradeMainActivity extends Activity implements OnClickListener {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.trade_main);
		
		((TextView) findViewById(R.id.tv_title)).setText("交易");
		((Button) findViewById(R.id.btn_right)).setBackgroundResource(R.drawable.v5_0_1_friend_search_icon);
		
		setViewOnClickListener();
	}
	
	private void setViewOnClickListener() {
		findViewById(R.id.layout_buy).setOnClickListener(this);
		findViewById(R.id.layout_sale).setOnClickListener(this);
		findViewById(R.id.layout_entrust_cancel).setOnClickListener(this);
		findViewById(R.id.layout_search).setOnClickListener(this);
		findViewById(R.id.layout_reserve).setOnClickListener(this);
		findViewById(R.id.layout_reserve_cancel).setOnClickListener(this);
		findViewById(R.id.layout_new_stock_buy).setOnClickListener(this);
		findViewById(R.id.layout_match_search).setOnClickListener(this);
		findViewById(R.id.layout_new_stock_limit).setOnClickListener(this);
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
			case R.id.layout_buy:
				Intent itBuy = new Intent(this, StockTradeEntrustActivity.class);
				itBuy.putExtra("mode", 0);
				startActivity(itBuy);
				break;
	
			case R.id.layout_sale:
				Intent itSale = new Intent(this, StockTradeEntrustActivity.class);
				itSale.putExtra("mode", 1);
				startActivity(itSale);
				break;
				
			case R.id.layout_entrust_cancel:
				startActivity(new Intent(this, StockTradeEntrustListActivity.class));
				break;
				
			case R.id.layout_reserve:
				startActivity(new Intent(this, ReservedEntrustActivity.class));
				break;
				
			case R.id.layout_reserve_cancel:
				startActivity(new Intent(this, StockTradeEntrustListActivity.class));
				break;
				
			case R.id.layout_search:
				startActivity(new Intent(this, TradeQueryFragmentActivity.class));
				break;
				
			case R.id.layout_new_stock_buy:
				startActivity(new Intent(this, NewStockPurchaseActivity.class));
				break;
				
			case R.id.layout_match_search:
				startActivity(new Intent(this, NewStockTradeListActivity.class));
				break;
				
			case R.id.layout_new_stock_limit:
				startActivity(new Intent(this, NewStockLimitListActivity.class));
				break;
				
			default:
				break;
		}
	}
		

}
