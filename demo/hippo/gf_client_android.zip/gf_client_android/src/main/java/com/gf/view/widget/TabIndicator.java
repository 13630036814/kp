package com.gf.view.widget;

import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.util.Functions;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

public class TabIndicator extends View{
	int kind;
	int num;
	int r;
	int y;
	int x;
	int space;
	public TabIndicator(Context context,int number,int space,int r) {
		super(context);
		// TODO Auto-generated constructor stub
		this.num = number;
		this.space = space;
		this.r = r;

		kind=0;
		
		x = (Global.fullScreenWidth - r*num - space*(num-1))/2;
	}
	
	public void setPosition(int y){
		this.y = y;
	}
	
	public void setKind(int kind){
		this.kind = kind;
	}
	
	
	public void onDraw(Canvas g){
		super.onDraw(g);
		
//		System.out.println("tab y="+y);
		
		for(int i=0;i<num;i++){
			if(i==kind){
				//BaseFuction.mPaint.setColor(Color.WHITE);
				//Functions.mPaint.setColor(0XFFC2C2FF);
				Functions.mPaint.setColor(Color.WHITE);
			}
			else
				Functions.mPaint.setColor(Color.GRAY);
			
			Functions.fillArc(x+(r+space)*i, y, r, r, 0, 360, g);
		}
	}
	
}
