package com.gf.control;

import com.gf.client.R;
import com.gf.viewmodel.base.LauncherModel;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;
import com.gf.viewmodel.quote.components.QuoteNetworkProvider;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

/**
 * 
 * @author jinjian
 * 
 */
public class Launcher extends Activity implements LauncherModel.Callback {
	private static final String TAG = "GfLauncher";
	private static final boolean DEBUG = true;
	private LauncherModel mModel;

	private static final int MSG_LOAD_DATA_END = 1;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (DEBUG) {
			Log.v(TAG, "oncreate");
		}
		setContentView(R.layout.launch_prepare);

		BaseApplication app = ((BaseApplication) getApplication());
		mModel = app.setLauncher(this);
		mModel.startLoader();
	}

	/**
	 * LauncherModel加载完毕后的回调
	 */
	@Override
	public void dataBaseCopyEnd() {
		if (DEBUG) {
			Log.v(TAG, "dataBaseCopyEnd");
		}
		
		Message msg = mHandler.obtainMessage();
		msg.what = MSG_LOAD_DATA_END;
		mHandler.sendMessage(msg);
	}

	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case MSG_LOAD_DATA_END:
				BaseApplication app = ((BaseApplication) getApplication());
				app.initDomainModel();
				finish();
				Intent intent = new Intent(Launcher.this, MainActivity.class);
				startActivity(intent);
				break;
			}
		}
	};
}
