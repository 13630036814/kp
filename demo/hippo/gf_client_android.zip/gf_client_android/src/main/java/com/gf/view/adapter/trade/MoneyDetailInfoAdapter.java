package com.gf.view.adapter.trade;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.viewmodel.ebiz.trade.MoneyDetailInfo;

/**
 * 资金流水信息
 *
 */
public class MoneyDetailInfoAdapter extends BaseAdapter {

	private LayoutInflater mLayoutInflater;
	private List<MoneyDetailInfo> mItems;
	
	private int selectedPosition = -1;
	private boolean isSelectedItemExpanded = false;
	
	public MoneyDetailInfoAdapter(Context context, List<MoneyDetailInfo> items) {
		mItems = items;
		mLayoutInflater = LayoutInflater.from(context);
	}
	

	@Override
	public int getCount() {
		if (mItems != null) {
			return mItems.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return mItems.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		final MoneyDetailInfo info = mItems.get(position);
		final ViewHolder holder;
		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.trade_query_money_detail_list_item, null);
			holder = new ViewHolder();
			
			holder.tvDate = (TextView) view.findViewById(R.id.tv_date);
			holder.tvCurrency = (TextView) view.findViewById(R.id.tv_currency);
			holder.tvTotal = (TextView) view.findViewById(R.id.tv_total);
			
			holder.layoutDetail = (LinearLayout) view.findViewById(R.id.layout_detail);
			holder.tvBalance = (TextView) view.findViewById(R.id.tv_balance);
			holder.tvMax = (TextView) view.findViewById(R.id.tv_max);
			holder.tvPrice = (TextView) view.findViewById(R.id.tv_price);
			
			view.setTag(R.id.layout_money_detail, holder);
		} else {
			holder = (ViewHolder) view.getTag(R.id.layout_money_detail);
		}
		
		if (info != null) {
			holder.tvDate.setText(info.getDate());
			holder.tvCurrency.setText(info.getCurrency());
			holder.tvTotal.setText(info.getTotal());
			
			holder.layoutDetail.setVisibility(View.GONE);
			if (selectedPosition == position) {
				if (isSelectedItemExpanded) {
					holder.layoutDetail.setVisibility(View.VISIBLE);
				}
			}
				
			if (holder.layoutDetail.getVisibility() == View.VISIBLE) {
				holder.tvBalance.setText(info.getBalance());
				holder.tvMax.setText(info.getMax());
				holder.tvPrice.setText(info.getTotal());
			}
		}
		
		return view;
	}
	
	/**
	 * 开关设置
	 * 
	 * @param position
	 */
	public void toggle(int position) {
		if (selectedPosition == position) {
			isSelectedItemExpanded = !isSelectedItemExpanded;
		} else {
			isSelectedItemExpanded = true;
		}
		selectedPosition = position;
		
		notifyDataSetChanged();
	}
	
    class ViewHolder {
    	TextView tvDate; // 日期
    	TextView tvCurrency; // 货币名称
    	TextView tvTotal; // 总额
    	
    	LinearLayout layoutDetail; // 明细部分
    	TextView tvBalance; // 股份余额
    	TextView tvMax; // 可用股份
    	TextView tvPrice; // 市值
    }

}
