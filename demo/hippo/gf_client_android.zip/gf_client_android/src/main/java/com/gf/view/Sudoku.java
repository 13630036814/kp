/**
 * 
 */
package com.gf.view;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gf.client.R;
import com.gf.control.BaseApplication;
import com.gf.control.BaseWindow;
import com.gf.control.CodeLine;
import com.gf.control.MainActivity;
import com.gf.control.QuotationActivity;
import com.gf.control.Desktop.onChangeViewListener;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.common.EventHandler;
import com.gf.hippo.domain.client.common.EventObject;
import com.gf.hippo.domain.client.common.NetworkListener;
import com.gf.hippo.domain.client.quote.RealtimeQuoteManager;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteManager;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStream;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStreamItem;
import com.gf.hippo.domain.client.securities.SimpleStockManager;
import com.gf.hippo.domain.client.securities.SimpleUserStockManager;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.hippo.domain.client.securities.StockManager;
import com.gf.hippo.domain.client.storage.StorageProvider;
import com.gf.hippo.domain.client.storage.StorageRequestHandler;
import com.gf.view.ListSortHeader.OnSortListener;
import com.gf.view.adapter.MailAdapter;
import com.gf.view.anim.UgcAnimations;
import com.gf.view.widget.BottomToolBar;
import com.gf.view.widget.PullToRefreshBaseView;
import com.gf.view.widget.TopToolsBar;
import com.gf.view.widget.PullToRefreshBaseView.OnFooterRefreshListener;
import com.gf.view.widget.PullToRefreshBaseView.OnHeaderRefreshListener;
import com.gf.viewmodel.base.GlobalMsg;
import com.gf.viewmodel.base.FlipChildView;
import com.gf.viewmodel.bean.MessageInfo;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;
import com.gf.viewmodel.quote.components.QuoteNetworkProvider;
import com.gf.viewmodel.quote.components.QuoteTimer;

/**
 * @author mrcola
 *
 */
public class Sudoku extends FlipChildView implements
OnHeaderRefreshListener, OnFooterRefreshListener{
	protected static final String TAG = "Sudoku";
	private PullToRefreshBaseView mPullToRefreshView;
	private MainPopMenu menu;
	private RelativeLayout mPopMenu;
	private LinearLayout menu_lineOne;
	private View parent,mFoot;
	private boolean isShow = false;
	private ImageView mUgc;
	private ImageView mUgcBg;
	private ImageView mUgcVoice;
	private ImageView mUgcPhoto;
	private ImageView mUgcRecord;
	private ImageView mRang_arrows;
	private MailListView mListView;
	private List<MessageInfo> MessageInfos;
	private MailAdapter mAdapter;
	protected onChangeViewListener mOnChangeViewListener;
	private TopToolsBar mTopToolsBar;
	private static final int UPDATE_LIST_VIEW = 0;
	private static final int MSG_PUT_KLINE_CACHE = 1;
	private int prePrice = 1,preRise = 1 ,preRange = 1;
//	NetworkQuoteManager mQuoteManager = new NetworkQuoteManager();
	SimpleUserStockManager mSimpleUserStockManager = null;
	RealtimeQuoteManager mRealtimeQuoteManager = null;
	StockList mStockList = new StockList();
	
	//private StockManager stockManager = new SimpleStockManager();
	private TimeSeriesQuoteStream timeSeriesQuote;
	private EventHandler timeSeriesHandler;
//	private TextView mStockRange;
	private ListSortHeader mListSortHeader;
	
	StockManager mStockManager = null;
	QuoteManagerFactory mQuoteManagerFactory = null;
	GlobalMsg mGlobal = GlobalMsg.getInstance();
	private boolean mListSort = false;
	
	private int count = 0;
	
	public Sudoku(Activity mActivity) {
		super(mActivity);
		// TODO Auto-generated constructor stub
		parent = LayoutInflater.from(mActivity).inflate(R.layout.sudoku, null);
		findViewById();
		init();
		setListener();
		
	}

	@Override
	public View getView() {
if(MessageInfos.size() == 0)
		refreshView();
		return parent;//mLayoutInflater.inflate(R.layout.sudoku, null);
	}

	@Override
	public void findViewById() {
		// TODO Auto-generated method stub
		mListView = (MailListView) parent.findViewById(R.id.stock_listview);
		mTopToolsBar = (TopToolsBar) parent.findViewById(R.id.toptool_bar);
		menu = (MainPopMenu) parent.findViewById(R.id.bottomToolBar);
		mPopMenu = (RelativeLayout) parent.findViewById(R.id.home_ugc);
		menu.getView();
		menu.setPopMenur(mPopMenu);
		mPullToRefreshView = (PullToRefreshBaseView) parent.findViewById(R.id.main_pull_refresh_view);
		mTopToolsBar.setActivityCode(getID());
		
//		menu_lineOne = (LinearLayout) parent.findViewById(R.id.ugc_layout);
//		mUgcLbs = (ImageView) parent.findViewById(R.id.ugc_lbs);
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		MessageInfos = new ArrayList<MessageInfo>();
		mRang_arrows = ((ImageView) parent.findViewById(R.id.rang_arrows));
		mAdapter = new MailAdapter(mActivity, MessageInfos, false);//第三个参数是：第一次填充listview时，分组是否展开
		mFoot = LayoutInflater.from(mActivity).inflate(R.layout.morestock, null);
		mListView.addFooterView(mFoot);
		mListView.setAdapter(mAdapter);
		mListView.setDivider(mActivity.getResources().getDrawable(R.drawable.line));
		mListSortHeader = ((com.gf.view.ListSortHeader) parent.findViewById(R.id.list_sort));
		mEventObjectStockList.setEventHandler(mHandlerStockList);
		mEventObjectRealtimeQuoteItem.setEventHandler(mHandlerRealtimeQuoteItem);
		mEventObjectStock.setEventHandler(mHandlerStock);
		
//		mStockRange = ((TextView) parent.findViewById(R.id.stockRang));
		
	}

	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		mPullToRefreshView.setOnHeaderRefreshListener(this);
		mPullToRefreshView.setOnFooterRefreshListener(this);
		((LinearLayout) parent.findViewById(R.id.top_edit)).setVisibility(View.VISIBLE);
		mListView.setOnItemHeaderClickedListener(new ItemHeaderClickedListener() {

			@Override
			public void onItemHeaderClick(View header, final int itemPosition, long headerId) {
				if(MessageInfos.size() + 1 == itemPosition)
					((Activity) mActivity).startActivityForResult(new Intent(mActivity,QuotationActivity.class),1);
				
				// 展开或收起分组
				if (mAdapter != null) {
					if(mAdapter.onListHeaderClicked(itemPosition)){
						((BaseWindow)mActivity).showDialog(true);
						MessageInfo msg = MessageInfos.get(itemPosition);
						timeSeriesQuote(msg.mField4,msg.getInfo(),itemPosition);
					}
				}
				mListView.setSelection(itemPosition);
			}
		});

		mFoot.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				((Activity) mActivity).startActivityForResult(new Intent(mActivity,CodeLine.class),1);
			}
			
		});
		
		((LinearLayout) parent.findViewById(R.id.top_back)).setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if(mOnOpenListener != null)
					mOnOpenListener.open();
			}
			
		});
		
		mListSortHeader.setOnSortListener(new OnSortListener(){

			@Override
			public void sort(View v, int sort, int sortField) {
				// TODO Auto-generated method stub
				mAdapter.sort(sort,sortField);
			}
			
		});
	}

	/**
	 * 
	 * @param onChangeViewListener
	 */
	public void setOnChangeViewListener(
			onChangeViewListener onChangeViewListener) {
		this.mOnChangeViewListener = onChangeViewListener;
		menu.setOnChangeViewListener(mOnChangeViewListener);
	}

	@Override
	public int getChildId() {
		// TODO Auto-generated method stub
		return MainActivity.FLOAT_MENU_MYSTOCK;
	}

	@Override
	public void onFooterRefresh(PullToRefreshBaseView view) {
		// TODO Auto-generated method stub
		mPullToRefreshView.postDelayed(new Runnable() {

			@Override
			public void run() {//设置超时自动隐藏
				mPullToRefreshView.onFooterRefreshComplete();
			}
		}, 3000);
	}

	@Override
	public void onHeaderRefresh(PullToRefreshBaseView view) {
		// TODO Auto-generated method stub
		mPullToRefreshView.postDelayed(new Runnable() {

			@Override
			public void run() {//设置超时自动隐藏
				mPullToRefreshView.onHeaderRefreshComplete();
			}
		}, 3000);
	}
	

	@Override
	public void update(int type, Object data) {
		if (MainActivity.FLOAT_ACTIVITYRESULT_NETWORK == type) {
			if (((Boolean) data) == true){
//				restart();
				beginWatchEveryStock();
			}
			else
				endWatchEveryStock();
			return;
		}else if(MainActivity.FLOAT_ACTIVITYRESULT_LISTSORT == type){
			mListSort = true;
			mAdapter.setDataLen(0);
			mAdapter.cleanKlineCache();
			return;
		}

		
		natifyDataChange();
		mAdapter.cleanKlineCache();
	}

	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return 0x1;
	}
	
	public void refreshView() {
		BaseApplication app = ((BaseApplication)mActivity.getApplication());
		mQuoteManagerFactory = app.getQuoteManagerFactory();
		mStockManager = mQuoteManagerFactory.getStockManager();
		mSimpleUserStockManager = mQuoteManagerFactory.getUserStockManager(); 
		
		getMyStock();
	}
	
	EventObject mEventObjectStockList = new EventObject();
	EventHandler mHandlerStockList = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			if (event.getObject() instanceof StockList) {
				endWatchEveryStock();
				
				StockList newStockList = (StockList) event.getObject();
				//mStockList.copy(newStockList, mStockManager);
				mStockList = (StockList) event.getObject();
				
				// 界面重新填充
				initViewContents();
				beginWatchEveryStock();
				
				Log.v(TAG, "mHandlerStockList mystocks.getAllItems().length: " + newStockList.getAllItems().length);
			}
		}
	};
	
	EventObject mEventObjectStock = new EventObject();
	EventHandler mHandlerStock = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			if (event.getObject() instanceof Stock) {
				Stock stock = (Stock) event.getObject();
				updateViewContents(stock);
				natifyDataChange();
				Log.v(TAG, "mHandlerStock stock.getStock_name(): " + stock.getStock_name());
			}
		}
	};
	
	EventObject mEventObjectRealtimeQuoteItem = new EventObject();
	EventHandler mHandlerRealtimeQuoteItem = new EventHandler() {
		@Override
		public void onEvent(Event event) {
			if (event.getObject() instanceof RealtimeQuoteItem) {
				RealtimeQuoteItem quote = (RealtimeQuoteItem) event.getObject();
				updateViewContents(quote);
				natifyDataChange();
				Log.v(TAG, "mHandlerRealtimeQuoteItem get time series quote item:" + quote.getTime());
			}
		}
	};
	
	private void getMyStock() {
		// 监听 Userlist
		mStockList = mSimpleUserStockManager.getUserStocks();
		mStockList.copy(mSimpleUserStockManager.getUserStocks(), mStockManager);
		
		if (mStockList.getAllItems().length > 0) {
			endWatchEveryStock();
			initViewContents();
		}
		
		mSimpleUserStockManager.beginWatch(mStockList, mEventObjectStockList);
		
		beginWatchEveryStock();
	}
	
	private void beginWatchEveryStock() {
		for (Stock stock : mStockList.getAllItems()) {
			mStockManager.beginWatch(stock, mEventObjectStock);
			RealtimeQuoteManager realtimeQuoteManager = mQuoteManagerFactory.getRealtimeQuoteManager();
			RealtimeQuoteItem quote = realtimeQuoteManager.getRealtimeQuoteItem(stock);
			realtimeQuoteManager.beginWatch(quote, mEventObjectRealtimeQuoteItem);
		}
	}
	
	private void endWatchEveryStock() {
		for (Stock stock : mStockList.getAllItems()) {
			mStockManager.endWatch(stock, mEventObjectStock);
			RealtimeQuoteManager realtimeQuoteManager = mQuoteManagerFactory.getRealtimeQuoteManager();
			RealtimeQuoteItem quote = realtimeQuoteManager.getRealtimeQuoteItem(stock);
			realtimeQuoteManager.endWatch(quote, mEventObjectRealtimeQuoteItem);
		}
	}
	
	/**
	 * 界面初始化
	 */
	private void initViewContents() {
		MessageInfos.clear();
		Stock[] s = mStockList.getAllItems();
		for (Stock stock : s) {
			MessageInfo msg = new MessageInfo();
//			msg.setGroupName("no_name" + count++);
			msg.setGroupName("--");
			msg.setInfo(stock.getStock_code());
			msg.mField4 = stock.getMarket();
			Log.v(TAG, count++ + "");
//			Log.v(TAG, stock.getStock_name());
			MessageInfos.add(msg);
		}
		
		if(mListSort){
			mListSort = false;
			mAdapter.setDataLen(0);
		}
		natifyDataChange();
	}
	
	/**
	 */
	private void updateViewContents(Object data) {
		if (data instanceof Stock) {
			Stock stock = (Stock) data;
			//for (MessageInfo msg : MessageInfos) {
			for (MessageInfo msg : MessageInfos) {	
				if (msg.getInfo().equals(stock.getStock_code()) 
						&& msg.mField4.equals(stock.getMarket())) {
					Log.v(TAG, "update stock name: " + stock.getStock_name());
					msg.setGroupName(stock.getStock_name());
//					natifyDataChange();
					return;
				}
			}
			
		} else if (data instanceof RealtimeQuoteItem) {
			RealtimeQuoteItem item = (RealtimeQuoteItem) data;
			Stock stock = (Stock) item.getSecurities();
			
			for (MessageInfo msg : MessageInfos) {
				if (msg.getInfo().equals(stock.getStock_code()) 
						&& msg.mField4.equals(stock.getMarket())) {
//					msg.setGroupName("no_name" + count++);
					msg.setInfo(stock.getStock_code());
					msg.mField1 = String.valueOf(item.getNow());
					msg.mField2 = String.valueOf(item.getChange());
					msg.mField3 = String.valueOf(item.getRise());
					msg.mField4 = stock.getMarket();
					msg.high = item.getHigh();
					msg.low = item.getLow();
					msg.open = item.getOpen();
					msg.volume = item.getVolume();
					return;
				}
			}
		}
	}
	
	private EventObject eventObject;

	private void timeSeriesQuote(final String maketid, final String stockcode,
			final int itemPosition) {
		TimeSeriesQuoteManager timeSeriesManager = mQuoteManagerFactory
				.getTimeSeriesQuoteManager();
		if (eventObject != null)
			timeSeriesManager.endWatch(timeSeriesQuote, eventObject);
		Stock stock = mStockManager.getStock(maketid, stockcode);
		timeSeriesQuote = timeSeriesManager.getTimeSeriesQuoteStream(stock);
		timeSeriesQuote.setCount(241);
		timeSeriesQuote.setTime(0);
		timeSeriesHandler = new EventHandler() {
			@Override
			public void onEvent(Event event) {
				TimeSeriesQuoteStream quote = (TimeSeriesQuoteStream) event
						.getObject();
				// 更新UI数据
				TimeSeriesQuoteStreamItem[] items = quote.getItemsOfLastDate();
				mAdapter.putKlineCache(itemPosition,
						reconsitution(items, maketid, stockcode));
				((BaseWindow) mActivity).dismissDialog();
				// mQuoteManager.endWatch(timeSeriesQuote, timeSeriesHandler);
			}
		};

		eventObject = new EventObject();
		eventObject.setEventHandler(timeSeriesHandler);
		timeSeriesManager.beginWatch(timeSeriesQuote, eventObject);
	}
	
	/**
	 * @param items
	 */
	private TimeSeriesQuoteCache reconsitution(TimeSeriesQuoteStreamItem[] items,String maketid, String stockcode){
		TimeSeriesQuoteCache timeSeriesQuoteCache = new TimeSeriesQuoteCache();
		timeSeriesQuoteCache.pclose = items[items.length - 1].getPclose();
		
		timeSeriesQuoteCache.Zjcj = new float[items.length];
		timeSeriesQuoteCache.Cjjj = new float[items.length];
		timeSeriesQuoteCache.volume = new float[items.length];

		getTimeSeries(timeSeriesQuoteCache,maketid,stockcode);
		int n = 0;
		
//		for (int i = items.length - 1; i >= 0; i--) {\
		for ( n = 0; n < items.length; n++) {
			TimeSeriesQuoteStreamItem item = items[n];
			timeSeriesQuoteCache.Zjcj[n] = item.getPrice();
			timeSeriesQuoteCache.Cjjj[n] = item.getAvg();
			timeSeriesQuoteCache.volume[n] = item.getVolume();
			timeSeriesQuoteCache.maxVolume = Math.max(item.getVolume(),
					timeSeriesQuoteCache.maxVolume);
//			n++;
		}
		
		return timeSeriesQuoteCache;
	}
	
	private void getTimeSeries(TimeSeriesQuoteCache timeSeriesQuoteCache,String maketid, String stockcode){
		if(timeSeriesQuoteCache == null || MessageInfos.size() == 0) return;
		System.out.print(timeSeriesQuoteCache);
		for(MessageInfo msg : MessageInfos){
			if(msg.mField4.equals(maketid) && msg.getInfo().equals(stockcode)){
				timeSeriesQuoteCache.sunVolume = msg.volume;
				timeSeriesQuoteCache.maxPrice = msg.high;
				timeSeriesQuoteCache.minPrice = msg.low;
				timeSeriesQuoteCache.open = msg.open;
				break;
			}
		}
	}
	
	private void natifyDataChange() {
		Log.v(TAG, "natifyDataChange");
		Message msg = mHandler.obtainMessage();
		msg.what = UPDATE_LIST_VIEW;
		mHandler.sendMessage(msg);
	}
	
	private Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			switch(msg.what) {
			case UPDATE_LIST_VIEW:
				Log.v(TAG, "mHandler UPDATE_LIST_VIEW");
				mAdapter.notifyDataSetChanged();
				break;
			case MSG_PUT_KLINE_CACHE:
				break;
			}
			super.handleMessage(msg);
		}
	};
	
	private void restart(){
//		mSimpleUserStockManager.beginWatch(mStockList, mEventObjectStockList);
//		mEventObjectStockList = new EventObject();
//		mEventObjectStock = new EventObject();
//		mEventObjectRealtimeQuoteItem = new EventObject();
		mEventObjectStockList.setEventHandler(mHandlerStockList);
		mEventObjectRealtimeQuoteItem.setEventHandler(mHandlerRealtimeQuoteItem);
		mEventObjectStock.setEventHandler(mHandlerStock);
	}
}
