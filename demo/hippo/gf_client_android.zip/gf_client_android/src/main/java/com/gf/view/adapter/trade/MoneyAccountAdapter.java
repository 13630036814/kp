package com.gf.view.adapter.trade;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.viewmodel.ebiz.trade.MoneyAccountInfo;

/**
 * 账号资金信息
 *
 */
public class MoneyAccountAdapter extends BaseAdapter {

	private LayoutInflater mLayoutInflater;
	private List<MoneyAccountInfo> mMoneyAccounts;
	
	private int selectedPosition = -1;
	private boolean isSelectedItemExpanded = false;
	
	public MoneyAccountAdapter(Context context, List<MoneyAccountInfo> accounts) {
		mMoneyAccounts = accounts;
		mLayoutInflater = LayoutInflater.from(context);
	}

	@Override
	public int getCount() {
		if (mMoneyAccounts != null) {
			return mMoneyAccounts.size();
		}
		return 0;
	}

	@Override
	public Object getItem(int position) {
		return mMoneyAccounts.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View view, ViewGroup parent) {
		final MoneyAccountInfo info = mMoneyAccounts.get(position);
		final ViewHolder holder;
		if (view == null) {
			view = mLayoutInflater.inflate(R.layout.trade_query_asset_money_item, null);
			holder = new ViewHolder();
			
			holder.tvCurrencyName = (TextView) view.findViewById(R.id.tv_currency_name);
			holder.tvTotalMoney = (TextView) view.findViewById(R.id.tv_total_money);
			
			holder.layoutDetail = (LinearLayout) view.findViewById(R.id.layout_detail);
			holder.tvAccount = (TextView) view.findViewById(R.id.tv_account);
			holder.tvBalance = (TextView) view.findViewById(R.id.tv_balance);
			holder.tvMaxMoney = (TextView) view.findViewById(R.id.tv_max_money);
			holder.tvTotalPrice = (TextView) view.findViewById(R.id.tv_total_price);
			holder.tvProfit = (TextView) view.findViewById(R.id.tv_profit);
			
			view.setTag(R.id.layout_account_money, holder);
		} else {
			holder = (ViewHolder) view.getTag(R.id.layout_account_money);
		}
		
		if (info != null) {
			holder.tvCurrencyName.setText(info.getCurrencyName());
			holder.tvTotalMoney.setText(info.getTotalMoney());
			
			holder.layoutDetail.setVisibility(View.GONE);
			if (selectedPosition == position) {
				if (isSelectedItemExpanded) {
					holder.layoutDetail.setVisibility(View.VISIBLE);
				}
			}
			
			holder.tvAccount.setText(info.getAccount());
			holder.tvBalance.setText(info.getBalance());
			holder.tvMaxMoney.setText(info.getMaxMoney());
			holder.tvTotalPrice.setText(info.getTotalPrice());
			holder.tvProfit.setText(info.getProfit());
		}
		
		return view;
	}
	
	/**
	 * 开关设置
	 * 
	 * @param position
	 */
	public void toggle(int position) {
		if (selectedPosition == position) {
			isSelectedItemExpanded = !isSelectedItemExpanded;
		} else {
			isSelectedItemExpanded = true;
		}
		selectedPosition = position;
		
		notifyDataSetChanged();
	}
	
    class ViewHolder {
    	TextView tvCurrencyName; // 货币名称
    	TextView tvTotalMoney; // 总资产
    	
    	LinearLayout layoutDetail; // 资金明细部分
    	TextView tvAccount; // 资金账号
    	TextView tvBalance; // 资金余额
    	TextView tvMaxMoney; // 资金可用数
    	TextView tvTotalPrice; // 证券市值
    	TextView tvProfit; // 参考盈亏
    }

}
