/**
 * 
 */
package com.gf.view;

import com.gf.client.R;
import com.gf.hippo.domain.client.quote.BidAskQuoteItem;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 个股详情里的五档
 * @author Cola
 * 
 */
public class QuotationFiveRange extends LinearLayout implements MiniView {
	private LinearLayout mContainer;
	private LinearLayout mFiveRange_buy,mFiveRange_sell;
	private RealtimeQuoteItem mRealtimeQuoteItem;
	
	public QuotationFiveRange(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;

	public QuotationFiveRange(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
//		Log.e("QuotationFiveRange", "QuotationFiveRange");
		LayoutInflater.from(context).inflate(R.layout.quotation_fiverange, this);
		mContainer = (LinearLayout) findViewById(R.id.quotation_fiverange_co);
//		mContainer.setGravity(Gravity.CENTER_VERTICAL);
		
		mFiveRange_buy = new LinearLayout(context);
		mFiveRange_buy.setOrientation(LinearLayout.VERTICAL);
		
		mFiveRange_sell = new LinearLayout(context);
		mFiveRange_sell.setOrientation(LinearLayout.VERTICAL);
		
		//卖的数据
		for(int n = 0; n < 5;n++){
			mFiveRange_sell.addView(LayoutInflater.from(context).inflate(R.layout.fiverangeitem, null));
		}
		mContainer.addView(mFiveRange_sell);
		
		ImageView img = new ImageView(context);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				1);
		layoutParams.setMargins(0, 4, 0, 2);
		img.setLayoutParams(layoutParams);
		img.setBackgroundResource(R.color.five_line);
		mContainer.addView(img);
		
		//买的数据
		for(int n = 0; n < 5;n++){
			mFiveRange_buy.addView(LayoutInflater.from(context).inflate(R.layout.fiverangeitem, null));
		}
		mContainer.addView(mFiveRange_buy);
	}

	@Override
	public void setData(Object object) {
		// TODO Auto-generated method stub
		this.mRealtimeQuoteItem = (RealtimeQuoteItem) object;
		draw();
	}
	
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		BidAskQuoteItem[] data =  mRealtimeQuoteItem.getBidAskQuote();
		int len = data.length;
		int i = len;
		for(int n = 0; n < len;n++){
			LinearLayout buy = (LinearLayout) getBuyFive().getChildAt(n);
			((TextView)buy.getChildAt(0)).setText("@买" + (n + 1));
			((TextView)buy.getChildAt(1)).setText( String.format("%1$.2f",data[n].ask));
			((TextView)buy.getChildAt(2)).setText( String.format("%1$.0f",data[n].asksize / 100));
			
			LinearLayout sell = (LinearLayout) getSellFive().getChildAt(n);
			((TextView)sell.getChildAt(0)).setText("@卖" + (i));
			((TextView)sell.getChildAt(1)).setText( String.format("%1$.2f",data[i - 1].bid));
			((TextView)sell.getChildAt(2)).setText( String.format("%1$.0f",data[i - 1].bidsize / 100));
			i--;
		}

	}
	
	/**
	 * 返回买的父容器
	 * @return
	 */
	public LinearLayout getBuyFive(){
		return mFiveRange_buy;
	}
	
	/**
	 * 返回买的卖容器
	 * @return
	 */
	public LinearLayout getSellFive(){
		return mFiveRange_sell;
	}

}
