package com.gf.viewmodel.quote.components;

import android.content.Context;
import android.os.Handler;

import com.gf.data.sqlite.SqliteStorageProvider;
import com.gf.hippo.domain.client.common.NetworkListener;
import com.gf.hippo.domain.client.common.Parser;
import com.gf.hippo.domain.client.quote.BoardRankQuoteManager;
import com.gf.hippo.domain.client.quote.CandleQuoteManager;
import com.gf.hippo.domain.client.quote.RealtimeQuoteManager;
import com.gf.hippo.domain.client.quote.TickQuoteManager;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteManager;
import com.gf.hippo.domain.client.securities.SimpleStockManager;
import com.gf.hippo.domain.client.securities.SimpleUserStockManager;
import com.gf.hippo.domain.client.securities.StockManager;
import com.gf.hippo.domain.client.storage.StorageProvider;
import com.gf.trade.TradeConstant;
import com.gf.trade.TradeManager;
import com.gf.trade.network.TradeNetworkListener;
import com.gf.trade.network.codec.TradeParser;

public class QuoteManagerFactory {

	QuoteNetworkProvider mNetwork;
	QuoteTimer mTimer;
	StorageProvider mProvider;
	RealtimeQuoteManager mRealtimeManager;
	TimeSeriesQuoteManager mTimerManager;
	CandleQuoteManager mCandleQuteManager;
	SimpleStockManager mStockManager;
	SimpleUserStockManager myStockQuoteManager;
	TickQuoteManager mTickQuoteManager;
	BoardRankQuoteManager mBoardRankQuoteManager;
	NetworkListener mQuoteListener = new NetworkListener();
	
	/** --- add by frank start --- */
	TradeManager mTradeManager;
	TradeNetworkListener mTradeListener;
	/** --- add by frank end --- */

	private Context mContext;
	private static QuoteManagerFactory mInstance = null;
	public static final String mQuoteTopic = "quote";
	
	private QuoteManagerFactory(QuoteNetworkProvider network, Context context, Handler handler) {
		super();
		this.mNetwork = network;
		mTimer = new QuoteTimer(handler);
		Parser parser=new QuoteParser();
		mNetwork.registeParser(mQuoteTopic, parser);
		mContext = context;
		mProvider = new SqliteStorageProvider(mContext); 
		//mProvider=new MockStorageProvider();
		getStockManager();
	}
	
	public static synchronized QuoteManagerFactory getInstance(QuoteNetworkProvider network, Context context, Handler handler) {
		if (mInstance == null) {
			mInstance = new QuoteManagerFactory(network, context, handler);
		}
		return mInstance;
	}

	public TimeSeriesQuoteManager getTimeSeriesQuoteManager() {
		if (mTimerManager == null) {
			mTimerManager = new TimeSeriesQuoteManager();
			mTimerManager.preInit();
			mTimerManager.setTimer(mTimer);
			mNetwork.setListener(mQuoteListener);
			mQuoteListener.registerManager(mQuoteTopic, mTimerManager);
			mTimerManager.setNetwork(mNetwork);
			mTimerManager.setStockManager(mStockManager);
			mTimerManager.setStorageProvider(mProvider);
			// timerManager.setParser(tiemSeriesParser);
			mTimerManager.postInit();
		}
		return mTimerManager;
	}

	public CandleQuoteManager getCandleQuoteManager() {
		if (mCandleQuteManager == null) {
			mCandleQuteManager = new CandleQuoteManager();
			mCandleQuteManager.preInit();
			mCandleQuteManager.setTimer(mTimer);
			mNetwork.setListener(mQuoteListener);
			mQuoteListener.registerManager(mQuoteTopic, mCandleQuteManager);
			mCandleQuteManager.setNetwork(mNetwork);
			mCandleQuteManager.setStockManager(mStockManager);
			mCandleQuteManager.setStorageProvider(mProvider);
			// candleQuteManager.setParser(kLineParser);
			mCandleQuteManager.postInit();
		}
		return mCandleQuteManager;
	}

	public RealtimeQuoteManager getRealtimeQuoteManager() {
		if (mRealtimeManager == null) {
			mRealtimeManager = new RealtimeQuoteManager();
			mRealtimeManager.preInit();
			mRealtimeManager.setTimer(mTimer);
			mRealtimeManager.setNetwork(mNetwork);
			mRealtimeManager.setStockManager(mStockManager);
			mRealtimeManager.setStorageProvider(mProvider);
			// NetworkListener listener = new NetworkListener();
			mNetwork.setListener(mQuoteListener);
			mQuoteListener.registerManager(mQuoteTopic, mRealtimeManager);
			mRealtimeManager.postInit();

		}
		return mRealtimeManager;
	}

	public StockManager getStockManager() {
		if (mStockManager == null) {
			mStockManager = new SimpleStockManager();
			mStockManager.preInit();
			mStockManager.setTimer(mTimer);
			mStockManager.setStorageProvider(mProvider);
			mStockManager.setNetwork(mNetwork);

			// 代码链不需要req,所以屏蔽
			// codelistParser.setCodeliseReq(codelistReq);
			mNetwork.setListener(mQuoteListener);
			mQuoteListener.registerManager(mQuoteTopic, mStockManager);
			mStockManager.postInit();
		}
		return mStockManager;
	}

	public SimpleUserStockManager getUserStockManager() {
		if (myStockQuoteManager == null) {
			myStockQuoteManager = new SimpleUserStockManager();
			myStockQuoteManager.preInit();
			myStockQuoteManager.setStockManager(mStockManager);
			myStockQuoteManager.setStorageProvider(mProvider);
			myStockQuoteManager.postInit();

		}
		return myStockQuoteManager;
	}
  
	public TickQuoteManager getTickQuoteManager() {
		if (mTickQuoteManager == null) {
			mTickQuoteManager = new TickQuoteManager();
			mTickQuoteManager.preInit();
			mTickQuoteManager.setTimer(mTimer);
			mTickQuoteManager.setStorageProvider(mProvider);
			mTickQuoteManager.setNetwork(mNetwork);
			mTickQuoteManager.setStockManager(mStockManager);
			// 代码链不需要req,所以屏蔽
			// codelistParser.setCodeliseReq(codelistReq);
			mNetwork.setListener(mQuoteListener);
			mQuoteListener.registerManager(mQuoteTopic, mTickQuoteManager);
			mTickQuoteManager.postInit();
		}
		return mTickQuoteManager;
	}
	
	public BoardRankQuoteManager getboardRankQuoteManager() {
		if (mBoardRankQuoteManager == null) {
			mBoardRankQuoteManager = new BoardRankQuoteManager();
			mBoardRankQuoteManager.preInit();
			mBoardRankQuoteManager.setTimer(mTimer);
			mBoardRankQuoteManager.setStorageProvider(mProvider);
			mBoardRankQuoteManager.setNetwork(mNetwork);
			mBoardRankQuoteManager.setStockManager(mStockManager);
			mNetwork.setListener(mQuoteListener);
			mQuoteListener.registerManager(mQuoteTopic, mBoardRankQuoteManager);
			mBoardRankQuoteManager.postInit();
		}
		return mBoardRankQuoteManager;
	}

	public TradeManager getTradeManager() {
		if (mTradeManager == null) {
			mTradeManager = new TradeManager();
			mTradeListener = new TradeNetworkListener();
			mNetwork.registeParser(TradeConstant.TRADE_SERVER_TOPIC, new TradeParser());
			mNetwork.setTradeListener(mTradeListener);
			mTradeManager.setTradeListener(mTradeListener);
			mTradeManager.setNetwork(mNetwork);
		}
		return mTradeManager;
	}
}
