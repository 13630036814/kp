package com.gf.control;

import com.gf.client.R;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class LoginTimeOutSetting extends Activity implements SeekBar.OnSeekBarChangeListener {
	private TextView mTextViewTimeOut;
	private SeekBar mSeekBarTimeOut;
	private ImageButton mBtnBack;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_timeout_setting);
		findView();
		initView();
		initViewData();
	}
	
	private void findView() {
		mTextViewTimeOut = (TextView)findViewById(R.id.txt_view_timeout);
		mSeekBarTimeOut = (SeekBar)findViewById(R.id.seekbar_timeout);
		mBtnBack = (ImageButton)findViewById(R.id.btn_back);
	}
	
	private void initView() {
		mSeekBarTimeOut.setOnSeekBarChangeListener(this);
		
		mBtnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				LoginTimeOutSetting.this.finish();
			}
		});
	}
	
	private void initViewData() {
		mSeekBarTimeOut.setProgress(getDataInt(SettingCenter.LOGIN_TIMEOUT));
		mTextViewTimeOut.setText(""  + getDataInt(SettingCenter.LOGIN_TIMEOUT));
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
		if (seekBar.equals(mSeekBarTimeOut)) {
			mTextViewTimeOut.setText("" + progress);
		} 
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {

	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		if (seekBar.equals(mSeekBarTimeOut)) {
    		saveDataInt(SettingCenter.LOGIN_TIMEOUT, mSeekBarTimeOut.getProgress());
		}
	}
	
	/**
	 * 从设置文件中读取Int值
	 * @param key
	 * @return
	 */
	private int getDataInt(String key) {
		SharedPreferences sharePref = getSharedPreferences(SettingCenter.SETTING_PREF, Context.MODE_PRIVATE);
		int value = sharePref.getInt(key, 0);
		return value;
	}
	
	/**
	 * 向设置文件中写入Int值
	 * @param key
	 * @param value
	 */
	private void saveDataInt(String key, int value) {
		SharedPreferences sharePref = getSharedPreferences(SettingCenter.SETTING_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putInt(key, value);
		editor.commit();
	}

}
