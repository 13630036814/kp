package com.gf.viewmodel.ebiz.trade;

public class MoneyAccountInfo {
	
	/** 账号类型名称 */
	private String currencyName;
	/** 总资产 */
	private String totalMoney;
	
	/** 资金账号 */
	private String account;
	/** 资金余额 */
	private String balance;
	/** 资金可用数 */
	private String maxMoney;
	/** 证券市值 */
	private String totalPrice;
	/** 参考盈亏 */
	private String profit;
	
	public MoneyAccountInfo() { }
	
	public MoneyAccountInfo(String currencyName, String totalMoney, String account, String balance, String maxMoney, String totalPrice, String profit) {
		this.currencyName = currencyName;
		this.totalMoney = totalMoney;
		this.account = account;
		this.balance = balance;
		this.maxMoney = maxMoney;
		this.totalPrice = totalPrice;
		this.profit = profit;
	}
	
	public String getCurrencyName() {
		return currencyName;
	}
	public void setCurrencyName(String currencyName) {
		this.currencyName = currencyName;
	}
	
	public String getTotalMoney() {
		return totalMoney;
	}
	public void setTotalMoney(String totalMoney) {
		this.totalMoney = totalMoney;
	}
	
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	
	public String getMaxMoney() {
		return maxMoney;
	}
	public void setMaxMoney(String maxMoney) {
		this.maxMoney = maxMoney;
	}
	
	public String getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	public String getProfit() {
		return profit;
	}
	public void setProfit(String profit) {
		this.profit = profit;
	}

}
