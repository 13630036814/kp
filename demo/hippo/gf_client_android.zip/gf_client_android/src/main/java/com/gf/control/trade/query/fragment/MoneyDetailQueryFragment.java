package com.gf.control.trade.query.fragment;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.gf.client.R;
import com.gf.view.adapter.trade.MoneyDetailInfoAdapter;
import com.gf.viewmodel.ebiz.trade.MoneyDetailInfo;

/**
 * 资金流水
 *
 */
public class MoneyDetailQueryFragment extends Fragment {
	
	private ListView listView;
	private List<MoneyDetailInfo> items = new ArrayList<MoneyDetailInfo>();
	private MoneyDetailInfoAdapter adapter;
	
	private View mView;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//		return super.onCreateView(inflater, container, savedInstanceState);
		mView = inflater.inflate(R.layout.trade_query_money_detail_list, null);
		
		initData();
		listView = (ListView) mView.findViewById(R.id.listView);
		adapter = new MoneyDetailInfoAdapter(mView.getContext(), items);
		listView.setAdapter(adapter);
		
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				MoneyDetailInfoAdapter adapter = (MoneyDetailInfoAdapter) listView.getAdapter();
				adapter.toggle(position);
			}
			
		});
		
		return mView;
	}
	
	private void initData() {
		if (!items.isEmpty()) {
			items.clear();
		}
		
		items.add(new MoneyDetailInfo("2013-12-31", "人民币", "126501.23", "120,033.55", "64,380"));
		items.add(new MoneyDetailInfo("2014-01-18", "美元", "12501.23", "12,054.55", "6,380"));
		items.add(new MoneyDetailInfo("2014-02-21", "欧元", "26501.23", "120,038.55", "654,380"));
		items.add(new MoneyDetailInfo("2014-03-08", "英磅", "1251.23", "120,013.55", "4,380"));
		items.add(new MoneyDetailInfo("2014-03-26", "日元", "1865901.23", "180,033.55", "6635,380"));
	}

}
