/**
 * 
 */
package com.gf.view;

import com.gf.client.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.ListView;

/**
 * @author cola
 *
 */
public class CListView extends LinearLayout{
	private MailListView listView;
	
	public CListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		LayoutInflater.from(context).inflate(R.layout.stock_listview, this);
		init();
	}

	public CListView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		LayoutInflater.from(context).inflate(R.layout.stock_listview, this);
		init();
	}
	
	private void init(){
		listView = (MailListView) findViewById(R.id.stock_listview);
	}
	
	public ListView getListView(){
		return listView;
	}

}
