/**
 * 
 */
package com.gf.view.widget;

import java.util.ArrayList;
import java.util.List;

import com.gf.client.R;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.RelativeLayout;

/**
 * 实现类似listview的功能
 * @author cola
 *
 */
public class TapeStockTypeListView extends StockTypeListView{
	private Drawable divider;
	private LinearLayout mContainer;
	private ListAdapter adapter;
	private List<View> mViewList = new ArrayList<View>();
	private Context context;
	
	public TapeStockTypeListView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
//		LayoutInflater.from(context).inflate(R.layout.stocktypelistview, this);
		init(context);
	}
	
	public TapeStockTypeListView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		init(context);
		
	}
	
	private void init(Context context){
		LayoutInflater.from(context).inflate(R.layout.stocktypelistview, this);
		mContainer = (LinearLayout) findViewById(R.id.Container);
		this.context = context;
	}

	@Override
	public ListAdapter getAdapter() {
		// TODO Auto-generated method stub
		return adapter;
	}

	@Override
	public void setAdapter(ListAdapter adapter) {
		// TODO Auto-generated method stub
		this.adapter = adapter;
		int len = adapter.getCount();
		mViewList.clear();
		for(int n = 0; n < len; n++){
			View v = adapter.getView(n, null, this);
			mViewList.add(v);
			mContainer.addView(v);
			
			if(divider!= null){
			ImageView line = new ImageView(context);
			line.setScaleType(ImageView.ScaleType.FIT_XY);
			line.setLayoutParams(new android.view.ViewGroup.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, 1));

			line.setBackgroundDrawable(divider);
			mContainer.addView(line);
			}
		}
//		this.invalidate();
	}

	@Override
	public void setDivider(Drawable divider) {
		// TODO Auto-generated method stub
		this.divider = divider;
	}

}
