package com.gf.viewmodel.quote.components;


import java.nio.ByteBuffer;

import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.common.Parser;
import com.gf.hippo.domain.client.quote.BoardRankQuoteList;
import com.gf.hippo.domain.client.quote.CandleQuoteStream;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.quote.TickQuoteStream;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStream;
import com.gf.hippo.domain.client.securities.CodeList;
import com.gf.viewmodel.ebiz.quote.HQFuncTypes;
import com.gf.viewmodel.ebiz.quote.MsgBody;
import com.gf.viewmodel.ebiz.quote.ResBody;
import com.squareup.wire.Wire;

public class QuoteParser extends Parser {
	BoardRandSerilizer boardRankSerilizer;
	CodeListSerilizer codeListSerilizer;
	KLineSerilizer kLineSerilizer;
	RealtimeSerilizer realtimeSerilizer;
	TickSerilizer tickSerilizer;
	TimeSeriesSerilizer timeSeriesSerilizer;

	public QuoteParser() {
		boardRankSerilizer = new BoardRandSerilizer();
		codeListSerilizer = new CodeListSerilizer();
		kLineSerilizer = new KLineSerilizer();
		realtimeSerilizer = new RealtimeSerilizer();
		tickSerilizer = new TickSerilizer();
		timeSeriesSerilizer = new TimeSeriesSerilizer();
	}

	public static byte[] get(byte[] array, int offset) {
		return get(array, offset, array.length - offset);
	}

	public static byte[] get(byte[] array, int offset, int length) {
		byte[] result = new byte[length];
		System.arraycopy(array, offset, result, 0, length);
		return result;
	}

	@Override
	public DomainObject unserialize(Object _data) {
		byte[] data = (byte[]) _data;
		DomainObject returnObject = null;
		try {
			byte flag = data[41];
			if (flag == 1) {
				Wire wire = new Wire();
				ResBody body = wire.parseFrom(get(data, 42, data.length - 42), ResBody.class);
				if (body.fid.compareTo(HQFuncTypes.HQ_DM) == 0) {
					returnObject = codeListSerilizer.unSerializeResBody(body);
				} else if (body.fid.compareTo(HQFuncTypes.HQ_FB) == 0) {
					returnObject = tickSerilizer.unSerializeResBody(body);
				} else if (body.fid.compareTo(HQFuncTypes.HQ_FS) == 0) {
					returnObject = timeSeriesSerilizer.unSerializeResBody(body);
				} else if (body.fid.compareTo(HQFuncTypes.HQ_KX) == 0) {
					returnObject = kLineSerilizer.unSerializeResBody(body);
				} else if (body.fid.compareTo(HQFuncTypes.HQ_PX) == 0) {
					returnObject = boardRankSerilizer.unSerializeResBody(body);
				} else if (body.fid.compareTo(HQFuncTypes.HQ_SS) == 0) {
					returnObject = realtimeSerilizer.unSerializeResBody(body);
				}
			} else {
				Wire wire = new Wire();
				MsgBody body = wire.parseFrom(get(data, 42, data.length - 42), MsgBody.class);
				if (body.tick != null) {
					returnObject = tickSerilizer.unSerializeMsgBody(body);
				}
				if (body.timeseries != null) {
					returnObject = timeSeriesSerilizer.unSerializeMsgBody(body);
				}
				if (body.kline != null) {
					returnObject = kLineSerilizer.unSerializeMsgBody(body);
				}
				if (body.quote != null) {
					returnObject = realtimeSerilizer.unSerializeMsgBody(body);
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return returnObject;

	}

	@Override
	public byte[] serialize(DomainObject object) {
		byte[] bytes=null;
		if(object instanceof BoardRankQuoteList){
		bytes=	boardRankSerilizer.serialize(object);
		}else if (object instanceof CodeList) {
			bytes=codeListSerilizer.serialize(object);
		}else if(object instanceof CandleQuoteStream){
			bytes=kLineSerilizer.serialize(object);
		}else if(object instanceof RealtimeQuoteItem){
			bytes=realtimeSerilizer.serialize(object);
		}else if(object instanceof TickQuoteStream){
			bytes=tickSerilizer.serialize(object);
		}else if(object instanceof TimeSeriesQuoteStream){
			bytes=timeSeriesSerilizer.serialize(object);
		}
		
		short length = (short) (bytes.length + 42);
		ByteBuffer buffer = ByteBuffer.allocate(length);
		buffer.putShort(length);
		buffer.putShort((short) 134);
		buffer.position(40);
		buffer.putShort((short) 0);
		buffer.put(bytes);
		buffer.flip();
		return buffer.array();

	}

}
