/**
 * 
 */
package com.gf.viewmodel.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import com.gf.control.BaseApplication;
import com.gf.viewmodel.bean.StockInfo;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

/**
 * 获取股票信息工具
 * 
 * @author cola
 * 
 */
public class StockTool {
	private static StockTool mStockTool;
	private static Vector<String> mSearchStrs = new Vector<String>();
//	private Vector<CodeListQuoteStreamItem> vStockInfo = new Vector<CodeListQuoteStreamItem>();
//	private Vector<StockInfo> mMatchStocks = new Vector<StockInfo>();
//	public static int m_filter = -1;
//	private static boolean isRunning = false;
//	private CodeListQuoteStreamItem[] mCodeListQuoteStreamItem;
//
//	public static StockTool getInstance() {
//		if (mStockTool == null) {
//			mStockTool = new StockTool();
//		}
//		return mStockTool;
//	}
//
//	public void setCodeListQuoteStreamItem(CodeListQuoteStreamItem[] mCodeListQuoteStreamItem){
//		this.mCodeListQuoteStreamItem = mCodeListQuoteStreamItem;
//	}
//	
//	public CodeListQuoteStreamItem[] getCodeListQuoteStreamItem(){
//		return mCodeListQuoteStreamItem;
//	}
//	
//	/**
//	 * 此方法不要调出vstockinfo来修改
//	 * */
//	public Vector<CodeListQuoteStreamItem> getStocksInfo() {
//		return vStockInfo;//
//	}
//
//	/**
//	 * 获取已match的数据
//	 * 
//	 * @return
//	 */
//	public CodeListQuoteStreamItem[] copyMatchStocks() {
//		if (vStockInfo.size() == 0)
//			return null;
//		CodeListQuoteStreamItem[] copyStocks = new CodeListQuoteStreamItem[vStockInfo.size()];
//		vStockInfo.copyInto(copyStocks);
//		return copyStocks;
//	}
//	
//	public void setMatchStocks(Vector<StockInfo> mMatchStocks){
//		this.mMatchStocks = mMatchStocks;
//	}
//
//	/**
//	 * 匹配证券（自动识别按代码或者拼音）
//	 * 
//	 * @param strMatch
//	 * @return
//	 */
//	public void matchStock(String strMatch, Handler h) {
//		mSearchStrs.add(strMatch);
//		if (isRunning || mCodeListQuoteStreamItem == null)
//			return;
//		final Handler handler = h;
//		index = 0;
////		ScheduledExecutorService scheduledThreadPool = Executors.newScheduledThreadPool(5);
////		scheduledThreadPool.schedule(new Runnable() {
////
////			@Override
////			public void run() {
////				// TODO Auto-generated method stub
////				threadPoolWord(handler);
////			}
////			
////		}, 0, TimeUnit.SECONDS);
////		
////		scheduledThreadPool.schedule(new Runnable() {
////
////			@Override
////			public void run() {
////				// TODO Auto-generated method stub
////				threadPoolWord(handler);
////			}
////			
////		}, 0, TimeUnit.SECONDS);
//		
//		Thread t = new Thread(new Runnable() {
//			@Override
//			public void run() {
//				isRunning = true;
//				while (mSearchStrs.size() > 0) {
//					String str = mSearchStrs.elementAt(mSearchStrs.size() - 1);
//					mSearchStrs.removeAllElements();
//					searchStock(str);
//					if (mSearchStrs.size() == 0) {
//						Message msg = Message.obtain();
//						msg.what = BaseApplication.MSG_SEARCH_UPDATE;
//						handler.sendMessage(msg);
//						try {
//							// Thread.sleep(500);
//							Thread.sleep(50);
//						} catch (InterruptedException e) {
//							e.printStackTrace();
//						}
//					}
//
//				}
//				isRunning = false;
//			}
//		});
//		t.start();
//
////		vStockInfo.removeAllElements();
////		Thread t = new Thread(new Runnable() {
////			@Override
////			public void run() {
////				threadPoolWord(handler);
////			}
////		});
////		t.start();
////		
////		Thread t2 = new Thread(new Runnable() {
////			@Override
////			public void run() {
////				threadPoolWord(handler);
////			}
////		});
////		t2.start();
////		Thread t3 = new Thread(new Runnable() {
////			@Override
////			public void run() {
////				threadPoolWord(handler);
////			}
////		});
////		t3.start();
//
//		
//	}
//	
//	private volatile int index = 0;
//
//	private void threadPoolWord(Handler handler) {
//
//		isRunning = true;
//		
////		while (mSearchStrs.size() > 0) {
//			String strMatch = mSearchStrs.elementAt(mSearchStrs.size() - 1);
////			mSearchStrs.removeAllElements();
//			// searchStock(str);
//			String strPy = "", strStockCode = "";
//			int iMatchNum = 0;
//			int iLen = strMatch.length();
//			Vector<CodeListQuoteStreamItem> matchStocks = getStocksInfo();// StockPersistence.getInstance()
//			// .getMatchStocks();
////			matchStocks.removeAllElements();
//			if (iLen <= 0 || iLen > 6) {
//				return;
//			}
//
//			int len = mCodeListQuoteStreamItem.length;
//			while (len > index) {
//				CodeListQuoteStreamItem s;
//
//				synchronized (matchStocks) {
//					if(len <= index || matchStocks.size() >= 50){
//						index = len;
//						break;
//					}
//					
//					s = mCodeListQuoteStreamItem[index];
//					Log.e("index ID:", index + ":" + s.getName());
//					index++;
//				}
//				if (isNum(strMatch))// 数字
//				{
//					strStockCode = s.getCode();
//					if (strStockCode.length() < iLen)
//						continue;
//					if (strStockCode.substring(0, iLen).equals(strMatch)) {
//						// chenxi add it 20110905 增加类别判断
//						if (m_filter != -1) {
//							int value = Integer.parseInt(s.getType())
//									& m_filter;
//							if (value <= 0)
//								continue;
//						}
//						iMatchNum++;
//						if (iMatchNum < 50) {
//							// info.setSelected(false);
//							matchStocks.addElement(s);
//						} else {
//							break;
//						}
//					}
//				} else {
//					String sort_key = s.getPinyin();
//
//					boolean show = true;
//					// strPy = strMatch.toUpperCase();
//					if (isPinYin(strMatch)) {
//						// if(containCn(sort_key)) {
//						show = pyMatches(sort_key, strMatch.replaceAll(" ", ""));
//						Date date = new Date(System.currentTimeMillis());
//						SimpleDateFormat format = new SimpleDateFormat(
//								"yyyy-MM-dd hh:mm:ss");
//
////						Log.e("time", format.format(date));
////						Log.e("thread ID:", Thread.currentThread().getId() + "");
//					}
//					if (show) {
//						iMatchNum++;
//						// info.setSelected(false);
////						Log.e("iMatchNum",iMatchNum + "");
//							matchStocks.addElement(s);
//					}
//					
//				}
//				
//			}
//
//			synchronized (mCodeListQuoteStreamItem) {
//			if(index >= mCodeListQuoteStreamItem.length)
//				mSearchStrs.removeAllElements();
//			if (mSearchStrs.size() == 0 && index != 0) {
//				index = 0;
//				Message msg = Message.obtain();
//				msg.what = BaseApplication.MSG_SEARCH_UPDATE;
//				handler.sendMessage(msg);
//				try {
//					// Thread.sleep(500);
//					Thread.sleep(50);
//				} catch (InterruptedException e) {
//					e.printStackTrace();
//				}
//			}
//			}
//
////		}
//		isRunning = false;
//	}
//
//	public void searchStock(String strMatch) {
//		String strStockCode = "";
//		String strPy = "";
//		int iMatchNum = 0;
//		int iLen = strMatch.length();
//		Vector<CodeListQuoteStreamItem> matchStocks = getStocksInfo();// StockPersistence.getInstance()
//		// .getMatchStocks();
//		matchStocks.removeAllElements();
//		if (iLen <= 0 || iLen > 6) {
//			return;
//		}
//
////		Enumeration<StockInfo> enu = mMatchStocks.elements();//getStocksInfo().elements();
//		for (CodeListQuoteStreamItem s : mCodeListQuoteStreamItem) {//enu.hasMoreElements()
////			StockInfo info = enu.nextElement();
//			if (isNum(strMatch))// 数字
//			{
//				strStockCode = s.getCode();
//				if (strStockCode.length() < iLen)
//					continue;
//				if (strStockCode.substring(0, iLen).equals(strMatch)) {
//					// chenxi add it 20110905 增加类别判断
//					if (m_filter != -1) {
//						int value = Integer.parseInt(s.getType()) & m_filter;
//						if (value <= 0)
//							continue;
//					}
//					iMatchNum++;
//					if (iMatchNum < 50) {
////						info.setSelected(false);
//						matchStocks.addElement(s);
//					} else {
//						break;
//					}
//				}
//			} else {
//				strPy = s.getPinyin();
//				if (strPy.length() < iLen)
//					continue;
//				if (strPy.substring(0, iLen).equals(strMatch.toUpperCase())) {
//					iMatchNum++;
//					if (iMatchNum < 50) {
////						info.setSelected(false);
//						matchStocks.addElement(s);
//					} else {
//						break;
//					}
//				}
//				
////				String sort_key = s.getPinyin();
////				boolean show = true;
////				if (isPinYin(strMatch) ) {
////						show = pyMatches(sort_key,strMatch.replaceAll(" ", "") );
//////						Date date = new Date(System.currentTimeMillis());
//////				        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//////				
//////						Log.e("time", format.format(date));
////				}
////				if(show){
////					iMatchNum++;
//////					info.setSelected(false);
////					if (iMatchNum < 50)
////					matchStocks.addElement(s);
////					else
////						break;
////				}
////				System.out.println("is show " + show);
//				
//			}
//		}
//	}

	/**
	 * 判断字符串首字母是否数字
	 * 
	 * @param msg
	 * @return
	 */
	public static boolean isNum(String msg) {
		if (java.lang.Character.isDigit(msg.charAt(0))) {
			return true;
		}
		return false;
	}
	
	////////////////////////////////////////////////////////////////
    /**
     * 
     * @param str 搜索字符串
     * @param exp 追加的正则表达式
     * @return 拼音搜索正则表达式
     */
    public String getPYSearchRegExp(String str, String exp) {
		int start = 0;
		String regExp = "";
		str = str.toLowerCase();
		boolean isFirstSpell = true;
		for (int i = 0; i < str.length(); ++i) {
			String tmp = str.substring(start, i + 1);
			isFirstSpell = binSearch(tmp) ? false : true;
			
			if (isFirstSpell) {
				regExp += str.substring(start, i) + exp;
				start = i;
			} else {
				isFirstSpell = true;
			}
			
			if (i == str.length() - 1)
				regExp += str.substring(start, i + 1) + exp;		
		}
		return regExp;
	}
	
    /**
     * 2分法查找拼音列表
     * @param str 拼音字符串
     * @return 是否是存在于拼音列表
     */
	public boolean binSearch(String str) {
		int mid = 0;
		int start = 0;
		int end = pinyin.length - 1;
		
		while (start < end) {
			mid = start + ((end - start) / 2 );
			if (pinyin[mid].matches(str + "[a-zA-Z]*"))
				return true;
			
			if (pinyin[mid].compareTo(str) < 0) 
				start = mid + 1;
			else 
				end = mid - 1;
		}
		return false;
	}

	/**
	 * 拼音匹配
	 * @param src 含有中文的字符串  
	 * @param des 查询的拼音
	 * @return 是否能匹配拼音
	 */
	public boolean pyMatches(String src, String des) {
		if (src != null) {
			src = src.replaceAll("[^ a-zA-Z]", "").toLowerCase();//
			src = src.replaceAll("[ ]+", " ");
			String condition = getPYSearchRegExp(des, "[a-zA-Z]* ");
			
			String[] tmp = condition.split("[ ]");
			String[] tmp1 = src.split("[ ]");
			
			for(int i = 0; i + tmp.length <= tmp1.length; ++i) {
				String str = "";
				for (int j = 0; j < tmp.length; j++)
					str += tmp1[i+j] + " ";
				if (str.matches(condition))
					return true;
			}
		} 
		return false;
	}
	
	public static boolean isNumeric(String str) {
	    Pattern pattern = Pattern.compile("[0-9]*");
        return pattern.matcher(str).matches();
	}
	
	public boolean isPinYin(String str) {
		Pattern pattern = Pattern.compile("[ a-zA-Z]*");
        return pattern.matcher(str).matches();
	}
	
	public boolean containCn(String str) {        
	    Pattern pattern = Pattern.compile("[\\u4e00-\\u9fa5]");          
	    return pattern.matcher(str).find();
	}
	
	//用这个二分查找的词典，有可能造成在这表中没有的拼音查找不了，自己加上去会因为不符合二分查找的结构会出现更多的bug
	static String[] pinyin = { "a", "ai",  "an", "ang", "ao", "ba", "bai", "ban", "bang",   
		"bao", "bei", "ben", "beng", "bi", "bian", "biao", "bie", "bin",   
		"bing", "bo", "bu", "ca", "cai", "can", "cang", "cao",  "ce",   
		"ceng", "cha", "chai", "chan", "chang", "chao", "che",  "chen",   
		"cheng", "chi", "chong", "chou", "chu", "chuai", "chuan",
		"chuang", "chui", "chun", "chuo", "ci", "cong", "cou", "cu", 
		"cuan", "cui", "cun", "cuo", "da", "dai", "dan", "dang", "dao",   
		"de", "deng", "di", "dian", "diao", "die", "ding", "diu", "dong",   
		"dou", "du", "duan", "dui", "dun", "duo", "e", "en", "er",  "fa",   
		"fan", "fang", "fei", "fen", "feng", "fo", "fou", "fu", "ga", 
		"gai", "gan", "gang", "gao", "ge", "gei", "gen", "geng",  "gong",   
		"gou", "gu", "gua", "guai", "guan", "guang", "gui", "gun", "guo",   
		"ha", "hai", "han", "hang", "hao", "he", "hei", "hen", "heng",   
		"hong", "hou", "hu", "hua", "huai", "huan", "huang", "hui", "hun",  
		"huo", "ji", "jia", "jian", "jiang", "jiao", "jie", "jin", "jing",   
		"jiong", "jiu", "ju", "juan", "jue", "jun", "ka", "kai", "kan",   
		"kang", "kao", "ke", "ken", "keng", "kong", "kou", "ku", "kua",    
		"kuai", "kuan", "kuang", "kui", "kun", "kuo", "la", "lai", "lan",    
		"lang", "lao", "le", "lei", "leng", "li", "lia", "lian", "liang",   
		"liao", "lie", "lin", "ling", "liu", "long", "lou", "lu", "lv",   
		"luan", "lue", "lun", "luo", "ma", "mai", "man", "mang", "mao",   
		"me", "mei", "men", "meng", "mi", "mian", "miao", "mie", "min",    
		"ming", "miu", "mo", "mou", "mu", "na", "nai", "nan", "nang",   
		"nao", "ne", "nei", "nen", "neng", "ni", "nian", "niang", "niao",   
		"nie", "nin", "ning", "niu", "nong", "nu", "nv", "nuan", "nue",   
		"nuo", "o", "ou", "pa", "pai", "pan", "pang", "pao", "pei", "pen",   
		"peng", "pi", "pian", "piao", "pie", "pin", "ping", "po", "pu",
		"qi", "qia", "qian", "qiang", "qiao", "qie", "qin", "qing", 
		"qiong", "qiu", "qu", "quan", "que", "qun", "ran", "rang", "rao",    
		"re", "ren", "reng", "ri", "rong", "rou", "ru", "ruan", "rui",   
		"run", "ruo", "sa", "sai", "san", "sang", "sao", "se", "sen",    
		"seng", "sha", "shai", "shan", "shang", "shao", "she", "shen",    
		"sheng", "shi", "shou", "shu", "shua", "shuai", "shuan", "shuang",   
		"shui", "shun", "shuo", "si", "song", "sou", "su", "suan", "sui",    
		"sun", "suo", "ta", "tai", "tan", "tang", "tao", "te", "teng",
		"ti", "tian", "tiao", "tie", "ting", "tong", "tou",  "tu", "tuan",   
		"tui", "tun", "tuo", "wa", "wai", "wan", "wang", "wei", "wen",   
		"weng", "wo", "wu", "xi", "xia", "xian", "xiang", "xiao", "xie",   
		"xin", "xing", "xiong", "xiu", "xu", "xuan", "xue", "xun", "ya",   
		"yan", "yang", "yao", "ye", "yi", "yin", "ying", "yo", "yong",   
		"you", "yu", "yuan", "yue", "yun", "za", "zai", "zan", "zang",   
		"zao", "ze", "zei", "zen", "zeng", "zha", "zhai", "zhan",   
		"zhang", "zhao", "zhe", "zhen", "zheng", "zhi", "zhong", "zhou",    
		"zhu", "zhua", "zhuai", "zhuan", "zhuang", "zhui", "zhun", "zhuo",   
		"zi", "zong", "zou", "zu", "zuan", "zui", "zun", "zuo"};
	
	
}
