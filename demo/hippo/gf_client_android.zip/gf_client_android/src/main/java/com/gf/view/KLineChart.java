package com.gf.view;



import java.text.SimpleDateFormat;
import java.util.Date;

import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.Business;
import com.gf.viewmodel.bean.DataSetKLine;
import com.gf.viewmodel.util.AFloat;
import com.gf.viewmodel.util.DrawTool;

import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;


/**
 * K线图
 * 
 * @author Think
 * 
 */
public class KLineChart extends AChart implements OnGestureListener {
	// 技术指标类型定义
	public static final int T_VOLUME = 0;
	public static final int T_KDJ = 1;
	public static final int T_MACD = 2;
	public static final int T_OBV = 3;
	public static final int T_DMA = 4;
	public static final int T_VR = 5;
	/**
	 * 线条宽度
	 */
	public static final int[] LINEWIDTHS = { 15, 13, 9, 5, 3, 2, 1 };
	/**
	 * 线条之间的间隔
	 */
	public static final int[] LINEGAPS = { 2, 2, 2, 1, 1, 0, 0 };
	/**
	 * 画线类型
	 */
	public static final int[] LINETYPES = { 0, 0, 0, 0, 1, 2, 3 };

	public static final String[] techFlags = { "VOLUME", "KDJ   ", "MACD  ",
			"OBV   ", "DMA   ", "VR    ", "RSI   ", "DMI   ", "BOLL  ",
			"BRAR  " };

	private DataSetKLine mDataSet;
	private CornerPathEffect pathEffect;
	private Paint txtPaint = Theme.factroyTextPaintSet();
	private Paint pricePaint = Theme.factroyPricePaintSet();
	private Paint boxPaint = Theme.factroyTextPaintSet();
	private int chartType = 3;
	private int[] mMACDLines;
	private Path[] mCurvePaths;
	private int[] mCurveColors = { 0xffffffff, 0xffFFFF00, 0xff7B00F7 };

	private Path[] mMaPaths;
	private final int[] mMaColors = { 0XFFFFFFFF, 0xffFFFF0B, 0XFF8811FF };

	private Path[] mTechPaths = new Path[5];
	private int[] mTechColors = { 0XFFFFFFFF, 0XFFFFFF00, 0XFFC800FF,
			0XFF00FF00, 0XFFAAAAAA };
	
	private float[]  mLinesY;

	private Rect mChartBox;
	private Rect mMaRect;
	private Rect mChartRect;
	private Rect mTechValRect;
	private Rect mTechRect;
	//private Rect mActionRect;
    private Rect mTimeRect;
    private Rect rect = new Rect();//坐标用
	
	private float mMaxPrice;
	private float mMinPrice;

	private int mStartIndex;

	private int mCursorIndex;// 光标线在X轴的位置

	private int mBoxOffsetX;

	private KlineView mTarget;
//	private StockTitleChart mStockTitleChart;

	private boolean isShowBox=false;
	private boolean isKeepLine=false;

	private KTechChart mKTechChart = new KTechChart();
	private GestureDetector mGestureDetector;

//	private ActionDraw[] mActDraws;//K线中按钮
//	private ActionDraw mSelectedDraw;

	private boolean _isNeedUpdate;

	private float aFloat = 0;
	
	private Drawable mArrow,mBig,mSmall;

	private GradientDrawable mBackgroundVLine;
	private GradientDrawable mBackgroundHLine;

	public KLineChart(int left, int top, int right, int bottom) {
		super(left, top, right, bottom);
		setDrawable(new Rect(left, top, right, bottom));
		init();

	}

	public KLineChart(Rect r) {
		super(r);
		setDrawable(r);
	}

	private void setDrawable (Rect r) {
		mBackgroundVLine = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] { 0xFF3d3d3d, 0xFF181818});
		mBackgroundVLine.setShape(GradientDrawable.RECTANGLE);
		mBackgroundVLine.setGradientRadius((float) (Math.sqrt(2) * 60));
		mBackgroundVLine.setBounds(r);

		mBackgroundHLine = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[] {0xFF3d3d3d, 0xFF343434, 0xFF3d3d3d});
		mBackgroundHLine.setShape(GradientDrawable.RECTANGLE);
		mBackgroundHLine.setGradientRadius((float) (Math.sqrt(2) * 60));
		mBackgroundHLine.setBounds(r);
	}

	public void setArrowDrawable(Drawable a, Drawable b, Drawable s) {
		mArrow = a;
		mBig = b;
		mSmall = s;
	}

	public void setTarget(KlineView target) {
		mTarget = target;
		mKTechChart.setTarget(this);
	}

//	public void setStockTitleChart(StockTitleChart title) {
////		mStockTitleChart = title;
//	}

/*	@Override
	public void setFrame(int left, int top, int right, int bottom) {
		super.setFrame(left, top, right, bottom);
		int iValueHeight = 20;
		float itemH = (frame.height() - iValueHeight * 2) / 9.0f;
		mMaRect.set(left, top, right, top + iValueHeight);

		int tTop = mMaRect.bottom;
		mChartRect.set(left, tTop, right, tTop + (int) (itemH * 5));

		tTop = (int) (mChartRect.bottom);
		mTechValRect.set(left, tTop, right, tTop + iValueHeight);

		tTop = (int) (mTechValRect.bottom);
		mTechRect.set(left, tTop, right, tTop + (int) (itemH * 3));
		mActionRect.set(left, mTechRect.bottom, right, bottom);
		
		//Log.e("mActionRect", String.format("mTechRect.bottom=%d", mTechRect.bottom));
		
		boxPaint.setTextSize(14);
		final int maxWidth = (int) boxPaint.measureText("最高价:  2011/05/18/日") + 10;
		final int itemHeight = (int) (boxPaint.getTextSize() + 8);
		mChartBox.set(left, top, left + maxWidth, top + itemHeight * 9);

		initActionDraws();
	}
*/
	
	@Override
	public void setFrame(int left, int top, int right, int bottom) {
		super.setFrame(left, top, right, bottom);
		int iValueHeight = 30;
		right -= 5;
		float itemH = (frame.height() - iValueHeight * 1 - 20) / 7.0f;
//		mMaRect.set(left, top, right, top + iValueHeight);//

		int tTop = top + 5 ;//+ iValueHeight;//mMaRect.bottom;
		mChartRect.set(50 + left, tTop, right, tTop + (int) (itemH * 5));

		tTop = (int) (mChartRect.bottom);
		mTechValRect.set(50 + left, tTop, right, tTop + iValueHeight);

		tTop = (int) (mTechValRect.bottom);
		//ax test 20130118
		//mTechRect.set(left, tTop, right, tTop + (int) (itemH * 2));
		mTechRect.set(50 + left, tTop, right, tTop + (int)(itemH * 2));
		//mActionRect.set(left, mTechRect.bottom, right, bottom);
//		mTimeRect.set(100 + left, mChartRect.bottom, right, bottom);
		
		//Log.e("mActionRect", String.format("mTechRect.bottom=%d", mTechRect.bottom));
		
		//chenx
		//boxPaint.setTextSize(14);
		final int maxWidth = (int) boxPaint.measureText("最高价:  2011/05/18/日") + 10;
		final int itemHeight = (int) (boxPaint.getTextSize() + 8);
		mChartBox.set(left, top, left + maxWidth, top + itemHeight * 9);

		//initActionDraws();
	}	

	protected void init() {
		pathEffect = new CornerPathEffect(10);
		mChartRect = new Rect();
		mMaRect = new Rect();
		mTechValRect = new Rect();
		mTechRect = new Rect();
		//mActionRect = new Rect();
		mChartBox = new Rect();
		mTimeRect = new Rect();

		mGestureDetector = new GestureDetector(this);

	}

	private float getMax(int p,float[] kZgcj){
		
		float max = kZgcj[p];
		for(int n = p ;n < mDataSet.kCount; n++){
			
			max = Math.max(max, kZgcj[n]);
		}
		return max;
	}
	
	private float getMin(int p,float[] kZdcj){
		float min = kZdcj[p];
		for(int n = p ;n < mDataSet.kCount; n++){
			min = Math.min(min, kZdcj[n]);
		}
		return min;
	}
	
	private void initChart() {
		if (mDataSet == null || mDataSet.kCount < 1)
			return;
		final DataSetKLine dataset = mDataSet;
		final int itemWidth = LINEWIDTHS[chartType] + LINEGAPS[chartType];
		final int dataLength = dataset.kCount;
		int width = (mChartRect.width() - 2);
		
		final int colCount = width / itemWidth;
		mStartIndex = dataLength - ((mChartRect.width() - 2) / itemWidth);
		if (mStartIndex >= dataLength) {
			mStartIndex = dataLength - 1;
		}

		if (mStartIndex < 0) {
			mStartIndex = 0;
		}

		mMaxPrice = getMax(mStartIndex, dataset.kZgcj);
		mMinPrice = getMin(mStartIndex, dataset.kZdcj);

		mLinesY = new float[dataset.kYClose.length];
		
		Path[] maPaths = new Path[3];
		maPaths[0] = buildAVPath(dataset.kMA[0], mMaxPrice, mMinPrice,
				mStartIndex, colCount, mChartRect);
		maPaths[1] = buildAVPath(dataset.kMA[1], mMaxPrice, mMinPrice,
				mStartIndex, colCount, mChartRect);
		maPaths[2] = buildAVPath(dataset.kMA[2], mMaxPrice, mMinPrice,
				mStartIndex, colCount, mChartRect);
//		for(int n = 0;n < mDataSet.kZdcj.length;n++){
//		Log.e("initChart", mDataSet.kZdcj[n] + " n = " + n);
//		Log.e("initMA", dataset.kMA[1][n] + " n = " + n);
//		Log.e("initkTech", dataset.kTech[1][n] + " n = " + n);
//	}
		mMaPaths = maPaths;
		if (mKTechChart.getTechID() == 0 || mCurvePaths == null) {
			mCurvePaths = new Path[3];
			mCurvePaths[0] = buildAVPath(dataset.kTech[0], dataset.kMaxTech,
					dataset.kMinTech, mStartIndex, colCount, mTechRect);
			mCurvePaths[1] = buildAVPath(dataset.kTech[1], dataset.kMaxTech,
					dataset.kMinTech, mStartIndex, colCount, mTechRect);
			mCurvePaths[2] = buildAVPath(dataset.kTech[2], dataset.kMaxTech,
					dataset.kMinTech, mStartIndex, colCount, mTechRect);

		}
		if (mKTechChart.getTechID() != 0) {
			mTechPaths[0] = null;
			mTechPaths[1] = null;
			mTechPaths[2] = null;
			mTechPaths[3] = null;
			mTechPaths[4] = null;

			// final Object[] techData =
			// mKTechChart.getTechData(mKTechChart.getTechID());
			final Object[] techData = mKTechChart.kTech;

			if (techData == null)
				return;
			// final AFloat[] techMaxMin =
			// mKTechChart.getTechMaxMinData(mKTechChart.getTechID());

			for (int i = 0; i < techData.length; i++) {
				if (i == 2 && mKTechChart.getTechID() == KTechChart.TECH_MACD) {
					mMACDLines = buildMACDLines((float[]) techData[i],
							mKTechChart.m_maxTech, mKTechChart.m_minTech,
							mStartIndex, colCount, mTechRect);

				} else {
					mTechPaths[i] = buildAVPath((float[]) techData[i],
							mKTechChart.m_maxTech, mKTechChart.m_minTech,
							mStartIndex, colCount, mTechRect);
				}
			}
		}

	}

	public void clear() {
		mDataSet = null;
	}

	public void onRefresh() {
		update();
		mTarget.postInvalidate();
	}

	public DataSetKLine getDataSet() {
		return mDataSet;
	}

	public void setDataSet(DataSetKLine dataset) {
		mDataSet = dataset;
		_isNeedUpdate = true;
	}

	public boolean isRequestUpdate() {
		return _isNeedUpdate;
	}

	public void dataBind(DataSetKLine dataset) {
		mDataSet = dataset;
		if (mDataSet == null)
			return;
		mKTechChart.setDataSet(mDataSet);
		mKTechChart.init(mTechRect, mDataSet.kCount, mStartIndex,
				this.mMaxPrice, mMinPrice, chartType);
		initChart();
		// mKTechChart.onCompute();

	}

	public void update() {
		_isNeedUpdate = false;
		dataBind(mDataSet);
		//mActDraws = null;
		//initActionDraws();
	}

	public void zoomIn() {
		chartType--;
		if (chartType < 0) {
			chartType = 0;
		}
		initChart();
	}

	public void zoomOut() {
		chartType++;
		if (chartType >= LINEWIDTHS.length) {
			chartType = LINEWIDTHS.length - 1;
		}
		initChart();
	}

	private boolean startTime = false;
	private int  bx = 0, by=0;
	
	public boolean onTouchEvent(MotionEvent ev) {
		
		mGestureDetector.onTouchEvent(ev);
		//兼容1.6
		//switch (ev.getAction() & MotionEvent.ACTION_MASK) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_UP:
			
			if(!isKeepLine) {
				this.isShowBox = false;
//				mStockTitleChart.setDrawTarget(null);
			}
//			WorkSpace.setbProcessBySubView(false);
			mTarget.invalidate();
			
/*			if (mSelectedDraw != null) {
				mSelectedDraw.setSelected(false);
				switch (mSelectedDraw.getEventID()) {				
				case 'A':// zoom in
					zoomIn();
					break;
				case 'F':
//					PopupMenu pm = new PopupMenu(mTarget.getManager().droid,mTarget.getManager().handler,RelativeLayout.CENTER_HORIZONTAL);
//					pm.setPtype(PopupMenu.TYPE_CYCLE_KLINE);
//					pm.show();
					break;
				case 'M':
					zoomOut();
					break;
				default:
					if (mSelectedDraw.getEventID() >= Business.KX_DAY) {
						Bundle txtras = mTarget.getExtras();
						txtras.putInt("kx_cycle", mSelectedDraw.getEventID());
						mTarget.handleMessage(XMessage.create(0,
								Events.EVENT_HQ_KX_CYCLE, txtras));
					}
					break;
				}
				mSelectedDraw = null;
				mTarget.invalidate();
			}
*/			
			//onSingleTapUpAs(ev);
			
			break;
		case MotionEvent.ACTION_DOWN:
			this.isShowBox = false;
			startTime = true;  //開始時間
			int x = (int) ev.getX();
			int y = (int) ev.getY();
			bx = x;
			by = y;
			//isShowBox = true;
			//WorkSpace.bProcessBySubView = true;
/*ax del
 * 			if (mActionRect.contains(x, y)) {
				for (int i = 0; i < mActDraws.length; i++) {
					if (mActDraws[i].contains(x, y)) {
						if (mSelectedDraw != null) {
							mSelectedDraw.setSelected(false);
						}
						mSelectedDraw = mActDraws[i];
						mSelectedDraw.setSelected(true);
						break;
					}
				}
			} else if (mChartRect.contains(x, y)) {
				mStockTitleChart.setDrawTarget(this);
			}
*/
			if (mChartRect.contains(x, y)) {
//				mStockTitleChart.setDrawTarget(this);
			}
			mCursorIndex = getCursorIndex(ev.getX());
			
			mTarget.invalidate();

			break;
		case MotionEvent.ACTION_MOVE:
			int ex = (int) ev.getX();
			int ey = (int) ev.getY();
			int sy = Math.abs(ey-by);
			
			if(startTime)
			{
					int sx = Math.abs(ex-bx);
					System.out.println("sx:"+sx+",sy"+sy);
					if(sx <= 1 ) 
					{
						isShowBox = true;
//						WorkSpace.setbProcessBySubView(true);
					}
					else
					{
						isShowBox = false;
//						WorkSpace.setbProcessBySubView(false);
					} 
					
					startTime = false;
			}
			
			isShowBox = true;
			mCursorIndex = getCursorIndex(ev.getX());
			mTarget.invalidate();
			break;
		}

		return true;
	}

	public void draw(Canvas canvas) {
		final Rect f = frame;
//ax		
//		paint.setAntiAlias(false);
		paint.setPathEffect(null);
//ax		
//		paint.setStrokeWidth(1.0f);

//		paint.setStyle(Style.FILL);
//		paint.setColor(0xFF000000);
//		canvas.drawRect(f, paint);

		paint.setStyle(Style.STROKE);
		paint.setColor(Global.frameLineColor);//
		canvas.drawRect(mChartRect, paint);
		canvas.drawRect(mTechRect, paint);
		// canvas.drawRect(mActionRect, paint);
//		paint.setStyle(Style.FILL);
//		canvas.drawRect(mTimeRect, paint);
		

		// 技术指标纵虚线
		float lineHeight = mChartRect.height() / 5.0f;
		float[] dottedLines = DrawTool.getDottedLine(mChartRect, true);
		canvas.save();
		canvas.translate(0, lineHeight);
		canvas.drawLines(dottedLines, paint);
		canvas.translate(0, lineHeight);
		canvas.drawLines(dottedLines, paint);
		canvas.translate(0, lineHeight);
		canvas.drawLines(dottedLines, paint);
		canvas.translate(0, lineHeight);
		canvas.drawLines(dottedLines, paint);
		canvas.restore();
		// 技术指标横虚线
		//lineHeight = mTechRect.height() / 3.0f;
		lineHeight = mTechRect.height() / 2.0f;
		dottedLines = DrawTool.getDottedLine(mTechRect, true);
		canvas.save();
		canvas.translate(0, lineHeight);
		canvas.drawLines(dottedLines, paint);
		canvas.translate(0, lineHeight);
		canvas.drawLines(dottedLines, paint);
//		canvas.translate(0, lineHeight);
//		canvas.drawLines(dottedLines, paint);
		canvas.restore();
		
		if(mMaxPrice == 0) return;

		if (mDataSet != null) {
			drawKPrice(canvas, paint, mStartIndex, mMaxPrice, mMinPrice);
			drawChart(canvas, paint, mStartIndex, mMaxPrice, mMinPrice);
			// chenx add it
//			if (!mStockTitleChart.hasDrawTarget()) {
////				drawMaVolValue(canvas, mDataSet.kCount - 1);
//			}
			if (isShowBox) {
				 drawCharBox(canvas,boxPaint,frame);
			}
		}
		drawActions(canvas);

	}

	private void drawPrice(Canvas c, String value, int color, int x, int y) {
		pricePaint.setTextSize(12);
		pricePaint.setColor(color);
		pricePaint.setTextAlign(Align.CENTER);
		DrawTool.drawText(c, x, y, 0, 20, pricePaint, value);
	}

	/**
	 * 画价格坐标
	 * 
	 * @param g
	 */
	private void drawKPrice(Canvas c, Paint p, int start, float maxPrice,
			float minPrice) {
		final DataSetKLine dsKLine = this.mDataSet;
		if (dsKLine == null || maxPrice == 0)
			return;

		int iX = mChartRect.left - 30;//mChartRect.left + 2;

		// 最高价格
		drawPrice(c, maxPrice + "", 0xfff6f6f6, iX, mChartRect.top);
		// 中间价格 
		drawPrice(c, String.format("%1$.2f", (maxPrice + minPrice)/ 2),
				0xfff6f6f6, iX, mChartRect.top
						+ (mChartRect.bottom - mChartRect.top - 18) / 2);
		// 最低价格
		drawPrice(c, minPrice + "", 0xfff6f6f6, iX,
				mChartRect.bottom - 18);
		// // 指标名称
		// drawPrice(g, techFlags[mKTechChart.getTechID()], 0xdddd00, topHeight
		// + 5 * nHeight
		// / m_grids + fontHeight + 6 + subtitleHeight);
		/*
		 * if (mKTechChart.getTechID() == 0) { // 最高指标 drawPrice(c,
		 * kMaxVol.toString(), 0xffffff, topHeight + 5 * nHeight / m_grids + 2 +
		 * subtitleHeight); }
		 */
	}

	protected void drawMaVolValue(Canvas c, int index) {
		// if(index < 0 || index > m_nMaxDataLength) return;
		if(index < 0 || index >= mDataSet.kCount) return;
		final DataSetKLine dsKLine = mDataSet;
		if (dsKLine == null)
			return;
		if (dsKLine.kMA[0].length <= 0)
			return;

		if (index >= dsKLine.kCount) {
			index = dsKLine.kCount - 1;
		} else if (index < 0) {
			index = 0;
		}
		//int topHeight = this.mMaRect.top;
		int topHeight = this.mMaRect.top + 4;

		String strMa = "";
		int iX = 3;
		//strMa = "MA5:" + dsKLine.kMA[0][index].toString();
		strMa = "MA"+Global.getMacycle1()+":"+ dsKLine.kMA[0][index] + "";
//		drawPrice(c, strMa, 0xffffffff, iX, topHeight);
		iX += pricePaint.measureText(strMa) + 2;

		//strMa = "10:" + dsKLine.kMA[1][index].toString();
		strMa = Global.getMacycle2()+":" + dsKLine.kMA[1][index] + "";
//		drawPrice(c, strMa, 0xffFFFF0B, iX, topHeight);
		iX += pricePaint.measureText(strMa) + 2;

		//strMa = "30:" + dsKLine.kMA[2][index].toString();
		strMa = Global.getMacycle3()+":" + dsKLine.kMA[2][index] + "";
//		drawPrice(c, strMa, 0xff8811FF, iX, topHeight);
		iX += pricePaint.measureText(strMa) + 2;

		// vol
		//topHeight = this.mTechValRect.top;
		topHeight = this.mTechValRect.top + 6;
		if (mKTechChart == null)
			return;
		String strValue = "";

		switch (mKTechChart.m_iTechType) {
		case KTechChart.TECH_VOLUME: {
			iX = 3;
			//strValue = "5:"
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = Global.getMacycle1()+":"
					+ aFloat
							;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			//strValue = "10:"
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = Global.getMacycle2()+":"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			//strValue = "30:"
			aFloat = (mKTechChart.kTech[2][index]);
			strValue = Global.getMacycle3()+":"
					+ aFloat;
			drawPrice(c, strValue, 0xffc800ff, iX, topHeight);
		}
			break;
		case KTechChart.TECH_KDJ: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "K:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "D:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[2][index]);
			strValue = "J:"
					+ aFloat;
			drawPrice(c, strValue, 0xcff800ff, iX, topHeight);
		}
			break;
		case KTechChart.TECH_MACD: {
			iX = 3;
			aFloat = mKTechChart.kTech[0][index];
			strValue = "D:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "D:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[2][index]);
			strValue = "M:"
					+ aFloat;
			drawPrice(c, strValue, 0xcff800ff, iX, topHeight);
		}
			break;
		case KTechChart.TECH_OBV: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "OBV:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			if(mKTechChart.kTech[1][index]!=0){
				strValue = "MAOBV:"
						+ aFloat;
			}else{
				strValue = "MAOBV: ---";
			}
			
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
		}
			break;
		case KTechChart.TECH_DMA: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "DIF:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "AMA:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
		}
			break;
		case KTechChart.TECH_VR: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "VR:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "MAVR:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
		}
			break;
		case KTechChart.TECH_RSI: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "RSI6:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "12:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[2][index]);
			strValue = "24:"
					+ aFloat;
			drawPrice(c, strValue, 0xcff800ff, iX, topHeight);
		}
			break;
		case KTechChart.TECH_DMI: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "PDI:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "MDI:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[2][index]);
			strValue = "ADX:"
					+ aFloat;
			drawPrice(c, strValue, 0xcff800ff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[3][index]);
			strValue = "ADXR:"
					+ aFloat;
			drawPrice(c, strValue, 0xff00ff00, iX, topHeight);
		}
			break;
		case KTechChart.TECH_BOLL: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "BOLL:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "UP:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[2][index]);
			strValue = "LO:"
					+ aFloat;
			drawPrice(c, strValue, 0xcff800ff, iX, topHeight);
		}
			break;
		case KTechChart.TECH_BRAR: {
			iX = 3;
			aFloat = (mKTechChart.kTech[0][index]);
			strValue = "BR:"
					+ aFloat;
			drawPrice(c, strValue, 0xffffffff, iX, topHeight);
			iX += pricePaint.measureText(strValue) + 2;
			aFloat = (mKTechChart.kTech[1][index]);
			strValue = "AR:"
					+ aFloat;
			drawPrice(c, strValue, 0xffFFFF0B, iX, topHeight);
		}
			break;
		default:
			break;
		}

	}

	public void drawCharBox(Canvas canvas, Paint paint, final Rect frame) {
		final DataSetKLine dataset = mDataSet;
		int index = mCursorIndex;
		if (dataset == null)
			return;
		if (dataset.kTime == null)
			return;
		if (index >= dataset.kCount) {
			index = dataset.kCount - 1;
		} else if (index < 0) {
			index = 0;
		}
		int x = frame.left;
		int y = frame.top;
		int itemHeight = frame.height() / 3;
		int itemWidth = frame.width() / 3;
		int color = 0XffEEEEEE;
		//画线
		paint.setStyle(Style.STROKE);
		paint.setColor(0xffa2a2a2);
		float rectX = frame.left + frame.width()/3;
//		
//		//canvas.drawLine(rectX, frame.top, rectX, frame.bottom, paint);
//		//canvas.drawLine(rectX + frame.width()/3, frame.top, rectX + frame.width()/3, frame.bottom, paint);
//		if (mBackgroundVLine == null) {
//			setDrawable(frame);
//		}
//		mBackgroundVLine.setBounds(new Rect((int)rectX - 1,frame.top,(int)rectX,frame.bottom));
//		mBackgroundVLine.draw(canvas);
//		mBackgroundVLine.setBounds(new Rect((int)rectX + frame.width()/3 - 1, frame.top, (int)rectX + frame.width()/3, frame.bottom));
//		mBackgroundVLine.draw(canvas);
//
//		float itemH = frame.height()/3;
//		for (int i=0;i<2;i++) {
//			//canvas.drawLine(frame.left, frame.top + itemH*(i+1), frame.right, frame.top + itemH*(i+1), paint);
//			mBackgroundHLine.setBounds(new Rect(frame.left, (int)(frame.top + itemH*(i+1)), frame.right, (int)(frame.top + itemH*(i+1) + 1)));
//			mBackgroundHLine.draw(canvas);
//		}
//		// 时间
//		if(mDataSet.retCycle >= Business.KX_DAY){
//			MiniChart.drawNVItem(canvas, x + 2, y, itemHeight, itemWidth - 2,
//					Theme.formatDate(dataset.kTime[index]), "", 0XFFFFFFFF, color, paint);
//		}else{
//			MiniChart.drawNVItem(canvas, x + 2, y, itemHeight, itemWidth - 2,
//					Theme.formatDateMMDDHHMM(dataset.kTime[index]), "", 0XFFffffff, color, paint);
//		}
//		
//		// 涨跌		
//		color = Theme.factoryColor(dataset.kZd[index]);
//		MiniChart.drawNVItem(canvas, x + 2, y + itemHeight, itemHeight,
//				itemWidth - 2, "涨跌", dataset.kZd[index].toString(""), color,
//				paint);
//		// 涨幅
//		color = Theme.factoryColor(dataset.kZdf[index]);
//		MiniChart.drawNVItem(canvas, x + 2, y + itemHeight * 2, itemHeight,
//				itemWidth - 2, "涨幅", dataset.kZdf[index].toString("%"), color,
//				paint);
//
//		color = Theme.factoryColor(dataset.kOpen[index], dataset.kYClose[index]);
//		MiniChart.drawNVItem(canvas, x + itemWidth, y, itemHeight, itemWidth,
//				"开盘", dataset.kOpen[index].toString(), color, paint);
//		color = Theme.factoryColor(dataset.kZgcj[index], dataset.kYClose[index]);
//		MiniChart.drawNVItem(canvas, x + itemWidth, y + itemHeight, itemHeight,
//						itemWidth, "最高", dataset.kZgcj[index].toString(),
//						color, paint);
//		color = Theme.factoryColor(dataset.kZdcj[index], dataset.kYClose[index]);
//		MiniChart.drawNVItem(canvas, x + itemWidth, y + itemHeight * 2,
//				itemHeight, itemWidth, "最低", dataset.kZdcj[index].toString(),
//				color, paint);
//
//		color = Theme.factoryColor(dataset.kClose[index], dataset.kYClose[index]);
//		MiniChart.drawNVItem(canvas, x + itemWidth * 2, y, itemHeight,
//				itemWidth, "收盘", dataset.kClose[index].toString(), color,
//				paint);
//		color = 0xFFffff00;//Theme.defaultColor();
//		MiniChart.drawNVItem(canvas, x + itemWidth * 2, y + itemHeight,
//				itemHeight, itemWidth, "量　", dataset.kCjss[index].toString(),
//				color, paint);
//		color = 0xFFffff00;//Theme.defaultColor();
//		MiniChart.drawNVItem(canvas, x + itemWidth * 2, y + itemHeight * 2,
//				itemHeight, itemWidth, "金额", dataset.kCjje[index].toString(),
//				color, paint);
//
		paint.setTextAlign(Align.LEFT);
		int cX = getCursorX(index);
		paint.setColor(0xffffffff);
//
		if (true||isShowBox) {
			// chenxi update it 20130514
			//canvas.drawLine(cX, mChartRect.top, cX, mTechRect.bottom, paint);			
			 canvas.drawLine(cX, mChartRect.top, cX, mChartRect.bottom, paint);
			 canvas.drawLine(cX, mTechRect.top, cX, mTechRect.bottom, paint);
			 
			float cY = getCursorY(index);
			canvas.drawLine(mChartRect.left, cY, mChartRect.right, cY, paint);
				
			//draw figure price
			String strPrice = dataset.kClose[index] + "";
			pricePaint.getTextBounds(strPrice, 0, strPrice.length(), rect); 
			paint.setStyle(Style.FILL);
			paint.setColor(0xaa0000ff);
			int iX = mChartRect.left+2;
			int iY = (int)(cY+rect.height()/2);
			canvas.drawRect(iX+rect.left, iY+rect.top, iX+rect.left+rect.width(), iY+rect.top+rect.height(), paint);
			paint.setColor(0XFFffffff);	
			paint.setTextSize(10);
			DrawTool.drawTextMid(canvas, iX+rect.left, iY+rect.top, rect.width(), rect.height(), paint, strPrice);
				
			//draw figure time
			String strTime;
			if(mDataSet.retCycle >= Business.KX_DAY){
				strTime = "" + dataset.kTime[index];
			}
			else
			{
//				Log.e("formatDateMMDDHHMM", dataset.kTime[index] + "");
				SimpleDateFormat dateformat2=new SimpleDateFormat("yyyy/MM/dd");
				strTime = dateformat2.format(new Date(dataset.kTime[index]));//Theme.formatDateMMDDHHMM(dataset.kTime[index]);
			}
			pricePaint.getTextBounds(strTime, 0, strTime.length(), rect); 
			paint.setStyle(Style.FILL);
			paint.setColor(0xaa0000ff);		
			if(cX-rect.width()/2<mTechRect.left+2)
			{
				iX = mChartRect.left+2;
			}
			else if(cX+rect.width()/2>mTechRect.width())
			{
				iX = mTechRect.width() - rect.width();
			}
			else
			{
				iX = (int)(cX-rect.width()/2);
			}
			iY =  mTechRect.top+5;		
			canvas.drawRect(iX+rect.left, iY, iX+rect.left+rect.width(), iY+rect.height(), paint);
			paint.setColor(0XFFffffff);	
			DrawTool.drawTextMid(canvas, iX+rect.left, iY, rect.width(), rect.height(), paint, strTime);
		}
//
	}

	private int getCursorX(int cursorIndex) {
		final int lineWidth = LINEWIDTHS[chartType];
		final int lineHalfWidth = lineWidth / 2;
		final int itemWidth = LINEWIDTHS[chartType] + LINEGAPS[chartType];
		final int maxcount = (mChartRect.width() - 2) / itemWidth;
		return mChartRect.left + 1 + mChartRect.width()
				* (cursorIndex - mStartIndex) / maxcount + lineHalfWidth;
	}

	private float getCursorY(int cursorIndex){
		if(this.mLinesY != null && cursorIndex>=0 && cursorIndex <= mLinesY.length-1)
		{
			return mLinesY[cursorIndex];	
		}
		else
		{
			return -100;
		}
	}	
	private int getCursorIndex(float x) {
		if (mDataSet == null)
			return -1;
		final DataSetKLine dataset = mDataSet;
		if (x < mChartRect.left + mChartRect.width() / 2) {
			mBoxOffsetX = mChartRect.right - mChartBox.width() - 5;
		} else {
			mBoxOffsetX = 0;
		}
		final int itemWidth = LINEWIDTHS[chartType] + LINEGAPS[chartType];
		final int maxcount = (mChartRect.width() - 2) / itemWidth;
		float xIndex = (x - mChartRect.left - 1) / itemWidth;
		xIndex = xIndex >= maxcount ? maxcount - 1 : xIndex;
		xIndex = xIndex < 0 ? 0 : xIndex;
		xIndex += mStartIndex;
		if (xIndex >= dataset.kCount) {
			xIndex = dataset.kCount - 1;
		}
		return (int) xIndex;
	}

	private void drawChart(Canvas c, Paint p, int start, float maxPrice,
			float minPrice) {
		final Rect chartFrame = mChartRect;
		final Rect techFrame = mTechRect;
		final DataSetKLine dataSet = mDataSet;
		final float maxVaol = dataSet.mMaxVaol;
		final int[] indexColor = { 0xFF66af2a, 0xFFffffff, 0xFFff0000 };//0xFF00ffff
		int oldX = 0;
		float oldY = 0;
		int newX = 0;
		float lowY = 0;
		float highY = 0;
		float openY = 0;
		float closeY = 0;

		final int chartWidth = chartFrame.width();
		final int chartHeight = chartFrame.height();
		final int lineWidth = LINEWIDTHS[chartType];
		final int lineHalfWidth = lineWidth / 2;

		final int bottomY = chartFrame.bottom;

		final float priceMargin = maxPrice - minPrice;
		if (priceMargin == 0)
			return;

		int itemWidth = LINEWIDTHS[chartType] + LINEGAPS[chartType];

		int maxcount = (chartFrame.width() - 2) / itemWidth;

		boolean bHavedrawHigh=false;
		boolean bHavedrawlow=false;
		int color = 0;
		for (int i = start; i < dataSet.kCount; i++) {
			float low = dataSet.kZdcj[i];
			float high = dataSet.kZgcj[i];
			float open = dataSet.kOpen[i];
			float close = dataSet.kClose[i];
			float amount = dataSet.kCjss[i];
			newX = chartFrame.left + 1 + chartWidth * (i - start) / maxcount;
			lowY = bottomY
					- 
							((low - minPrice) * chartHeight)/
							priceMargin;
			highY = bottomY
					- 
							(high - minPrice) * chartHeight/
							priceMargin;
			openY = bottomY
					- (open - minPrice) * chartHeight/
							priceMargin;
			closeY = bottomY
					- (close - minPrice) * chartHeight/
							priceMargin;
			mLinesY[i] = closeY;

			// 画K线主体部分
			int max  = 0;
			if(dataSet.kClose[i] >
					dataSet.kOpen[i])
				max = 1;
			else max = -1;
			color = indexColor[max + 1];
			p.setColor(color);
			//ax add 20121223
			p.setStrokeWidth(1.0f);

			switch (LINETYPES[chartType]) {
			case 0: // K线
			case 1:
				if (close < open) {
					p.setStyle(Paint.Style.FILL);
					c.drawRect(newX, openY, newX + lineWidth, closeY, p);
					if (low < close) {
						c.drawLine(newX + lineHalfWidth, lowY, newX
								+ lineHalfWidth, closeY, p);
					}
					if (high > open) {
						c.drawLine(newX + lineHalfWidth, highY, newX
								+ lineHalfWidth, openY, p);
					}
				} else if (close > open) {
					p.setStyle(Paint.Style.FILL);//Paint.Style.STROKE
					c.drawRect(newX, closeY, newX + lineWidth, openY, p);

					if (low < open) {
						c.drawLine(newX + lineHalfWidth, lowY, newX
								+ lineHalfWidth, openY, p);
					}
					if (high > close) {
						c.drawLine(newX + lineHalfWidth, highY, newX
								+ lineHalfWidth, closeY, p);
					}
				} else {
					c.drawLine(newX, openY, newX + lineWidth, openY, p);
					if (high > low) {
						c.drawLine(newX + lineHalfWidth, highY, newX
								+ lineHalfWidth, lowY, p);
					}
				}
				break;
			case 2: // 美国线
				c.drawLine(newX + lineHalfWidth, closeY, newX + lineWidth,
						closeY, p);
				if (high > low) {
					c.drawLine(newX + lineHalfWidth, highY, newX
							+ lineHalfWidth, lowY, p);
				}
				break;
			default: // 3 普通线
				if (i > 0) {
					c.drawLine(oldX, oldY, newX, closeY, p);
				}
				oldX = newX;
				oldY = closeY;
				break;
			}
			if (color == 0xFFFFFFFF)
				p.setColor(0xFFFF0000);
			if (mKTechChart.getTechID() == 0) { // 只画成交量
				int nBottom_tech = techFrame.bottom;
				final float tHeight = techFrame.height();
				float newY_l = nBottom_tech - (amount* tHeight)
						/ maxVaol + 1;// kCjss
				if (lineWidth > 1) {
					if (close < open) {
						p.setStyle(Paint.Style.FILL);
						c.drawRect(newX, newY_l, newX + lineWidth,
								nBottom_tech, p);
					} else {
						p.setStyle(Paint.Style.FILL);//Paint.Style.STROKE
						c.drawRect(newX, newY_l, newX + lineWidth,
								nBottom_tech, p);
					}
				} else {
					c.drawLine(newX, newY_l, newX + lineWidth, nBottom_tech, p);
				}
			}
			
			//chenxi add it 20111229 
			if(high == mMaxPrice)
			{
				if(!bHavedrawHigh)
				{
					//画最高价
					DrawTool.drawArrowPrice(c, newX+LINEWIDTHS[chartType]/2, highY, chartWidth, chartHeight, ""+mMaxPrice);
					bHavedrawHigh = true;
				}
			}
			if(low == mMinPrice)
			{
				if(!bHavedrawlow)
				{
					//画最低价
					DrawTool.drawArrowPrice(c, newX+LINEWIDTHS[chartType]/2, lowY, chartWidth, chartHeight, ""+mMinPrice);
					bHavedrawlow = true;
				}
			}			
			
		}
		
		if(dataSet.kTime != null)
		{		
			// 画均线
			paint.setStyle(Paint.Style.STROKE);
			// paint.setStrokeWidth(1.5f);
			//ax add 20121223
	//ax		
//			paint.setStrokeWidth(1.0f);
			paint.setAlpha(255);
			paint.setPathEffect(pathEffect);

			for (int i = 0; i < mMaPaths.length; i++) {
				paint.setColor(mMaColors[i]);
				c.drawPath(mMaPaths[i], paint);
			}

			// 画技术指标
			if (mKTechChart.getTechID() == T_MACD) {
				drawMACD(c, paint);
			} else if (mKTechChart.getTechID() == KTechChart.TECH_BOLL) {
				paint.setPathEffect(null);
				drawBOLLStockChart(c, paint, start, maxPrice, minPrice);
				paint.setPathEffect(pathEffect);
			}

			if (mCurvePaths != null && mKTechChart.getTechID() == 0) {
				for (int i = 0; i < mCurvePaths.length; i++) {
					if (mCurvePaths[i] != null) {
						paint.setColor(mCurveColors[i]);
						c.drawPath(mCurvePaths[i], paint);
					}
				}
			} else {
				for (int i = 0; i < mTechPaths.length; i++) {
					if (mTechPaths[i] != null) {
						paint.setColor(mTechColors[i]);
						c.drawPath(mTechPaths[i], paint);
					}
				}
			}
		}		
		// 指标名称
//		txtPaint.setColor(0XFFFFFF00);
//		DrawTool.drawText(c, techFrame.left + 8, techFrame.top, 0, 20,
//				txtPaint, techFlags[mKTechChart.getTechID()]);

		//K线时间
		if(dataSet.kTime != null)
		{
			if(mDataSet.retCycle >= Business.KX_DAY){
				int topHeight = this.mChartRect.bottom + 2;
				String strTime = "";
				int iX = 70;
				strTime = "" + dataSet.kTime[start];
				drawPrice(c, strTime, 0xfff6f6f6, iX, topHeight);
				
				strTime = "" + dataSet.kTime[dataSet.kCount-1];
				iX = mChartRect.width() + 70 - (int)pricePaint.measureText(strTime);
				drawPrice(c, strTime, 0xfff6f6f6, iX, topHeight);
			}else{
				int topHeight = this.mChartRect.bottom + 4;
				String strTime = "";
				int iX = 80;
				SimpleDateFormat dateformat2=new SimpleDateFormat("yyyy-MM-dd");   
		        
				strTime = dateformat2.format(new Date(dataSet.kTime[start]));//Theme.formatDateMMDDHHMM(dataSet.kTime[start]);
				drawPrice(c, strTime, 0xfff6f6f6, iX, topHeight);
				
//				strTime = "" + Theme.formatDateMMDDHHMM(dataSet.kTime[dataSet.kCount-1]);
				strTime = dateformat2.format(new Date(dataSet.kTime[dataSet.kCount-1]));
				iX = mChartRect.width() + 80 - (int)pricePaint.measureText(strTime);
				drawPrice(c, strTime, 0xfff6f6f6, iX, topHeight);
			}
		}
	}

	private void drawActions(Canvas canvas) {
		final DataSetKLine dsk = getDataSet();
		int index = 4;
		if (dsk == null) {
			index = 4;
		}else {
			index = dsk.retCycle >= Business.KX_15MIN?dsk.retCycle - Business.KX_15MIN + 1: 0;
		}
//		for (ActionDraw2 draw : mActDraws) {
//			
//			draw.draw(canvas);
//		}
/*		
		for (int i = 0; i<mActDraws.length; i++) {
			if (index <= 3 && i==0) {
				switch(index){
				case 0:
					mActDraws[i].setText("5分钟");
					break;
				case 1:
					mActDraws[i].setText("15分钟");
					break;
				case 2:
					mActDraws[i].setText("30分钟");
					break;
				case 3:
					mActDraws[i].setText("60分钟");
					break;
				}
				mActDraws[i].setSelect(true);
			}
			else if (index - 3 == i) {
				mActDraws[i].setSelect(true);
				mActDraws[0].setText("分");
			}
			else {
				mActDraws[i].setSelect(false);
			}
			mActDraws[i].draw(canvas);
		}
*/
	}

	/**
	 * 画BOLL美国线
	 * 
	 * @param c
	 * @param p
	 * @param start
	 * @param maxPrice
	 * @param minPrice
	 */
	final void drawBOLLStockChart(Canvas c, Paint p, int start,
			float maxPrice, float minPrice) {
		final Rect chartFrame = mTechRect;
		final DataSetKLine dataSet = mDataSet;
		final int[] indexColor = { 0xFF00ffff, 0xFFffffff, 0xFFff0000 };
		int oldX = 0;
		float oldY = 0;
		int newX = 0;
		float lowY = 0;
		float highY = 0;
		float openY = 0;
		float closeY = 0;

		final int chartWidth = chartFrame.width();
		final int chartHeight = chartFrame.height();
		final int lineWidth = LINEWIDTHS[chartType];
		final int lineHalfWidth = lineWidth / 2;

		final int bottomY = chartFrame.bottom;

		final float priceMargin = maxPrice - minPrice;
		if (priceMargin == 0)
			return;

		int itemWidth = LINEWIDTHS[chartType] + LINEGAPS[chartType];

		int maxcount = (chartFrame.width() - 2) / itemWidth;

		int color = 0;
		for (int i = start; i < dataSet.kCount; i++) {
			float low = dataSet.kZdcj[i];
			float high = dataSet.kZgcj[i];
			float open = dataSet.kOpen[i];
			float close = dataSet.kClose[i];
			float amount = dataSet.kCjss[i];
			newX = chartFrame.left + 1 + chartWidth * (i - start) / maxcount;
			lowY = bottomY
					- (low - minPrice) * chartHeight/
							priceMargin;
			highY = bottomY
					- (high - minPrice) * chartHeight/
							priceMargin;
			openY = bottomY
					- (open - minPrice) * chartHeight/
							priceMargin;
			closeY = bottomY
					- (close - minPrice) * chartHeight/
							priceMargin;

			// 画K线主体部分
			int max = 0;
					if(dataSet.kClose[i] -
					dataSet.kOpen[i] > 0)
						max  = 1;
					else max = -1;
				
			color = indexColor[max + 1];
			p.setColor(color);

			switch (LINETYPES[chartType]) {
			case 0: // K线
			case 1:
				// /
				if (close == open) {
					c.drawLine(newX, openY, newX + lineWidth, openY, paint);
					c.drawLine(newX + lineHalfWidth, highY, newX
							+ lineHalfWidth, lowY, paint);
				} else {
					c.drawLine(newX + lineHalfWidth, highY, newX
							+ lineHalfWidth, lowY, paint);

					c.drawLine(newX, openY, newX + lineHalfWidth, openY, paint);

					c.drawLine(newX + lineHalfWidth, closeY, newX + lineWidth,
							closeY, paint);
				}
				break;
			case 2: // 美国线
				c.drawLine(newX + lineHalfWidth, closeY, newX + lineWidth,
						closeY, p);
				if (high > low) {
					c.drawLine(newX + lineHalfWidth, highY, newX
							+ lineHalfWidth, lowY, p);
				}
				break;
			default: // 3 普通线
				if (i > 0) {
					c.drawLine(oldX, oldY, newX, closeY, p);
				}
				oldX = newX;
				oldY = closeY;
				break;
			}
		}
	}

	private Path buildAVPath(float[] data, float maxTop, float minBottom,
			int start, int colCount, Rect rect) {

		if (data == null)
			return null;
		final int itemWidth = LINEWIDTHS[chartType] + LINEGAPS[chartType];
		final int drawcount = data.length;
		final float maxZf = maxTop - minBottom;
		int perX = 1000 * rect.width() / colCount;// 水平的间隔点
		int newx = 0;
		float newy = 0;
		float zf = 0;
		Path p = new Path();
		boolean hasStart = false;
		if (maxZf == 0)
			return null;
		for (int i = start; i < drawcount; i++) {
			final float floator = data[i] == 0 ? 0 : data[i];

			newx = rect.left + perX * (i - start) / 1000;
			zf = floator - minBottom;
			newy = rect.bottom - zf * rect.height() / maxZf;
			if (hasStart && zf >= 0 && maxZf >= zf) {
				p.lineTo(newx + itemWidth, newy);
			} else if (!hasStart) {
				hasStart = floator > minBottom;
				hasStart &= floator <= maxTop;
				hasStart &= floator != 0;
				p.moveTo(newx, newy);
			}

		}
		return p;
	}

	private int[] buildMACDLines(float[] data, float maxTop,
			float minBottom, int start, int colCount, Rect rect) {
		if (data == null)
			return null;
		int drawcount = data.length;
		final float maxZf = maxTop - minBottom;

		if (maxZf == 0) {
			return new int[] {};
		}
		int perX = 1000 * rect.width() / colCount;// 水平的间隔点
		int newx = 0;
		float newy = 0;
		float zf = 0;
		int bottomH = rect.bottom;
		AFloat zero = new AFloat();
		float bottomY = bottomH - (zero.toFloat() - minBottom)
				* rect.height() / maxZf;
		int[] lines = new int[(drawcount - start) * 5];
		for (int i = start; i < drawcount; i++) {
			final float floator = data[i];
			newx = rect.left + perX * (i - start) / 1000;
			zf = floator - minBottom;
			newy = rect.bottom - zf * rect.height() / maxZf;
			newy = newy > bottomH ? bottomH - 1 : newy;

			lines[(i - start) * 5] = floator > 0 ? 0xffff0000 : 0xff00ffff;
			lines[(i - start) * 5 + 1] = newx;
			lines[(i - start) * 5 + 2] = (int) bottomY;
			lines[(i - start) * 5 + 3] = newx;
			lines[(i - start) * 5 + 4] = (int) newy;

		}
		return lines;
	}

	private void drawMACD(Canvas canvas, Paint paint) {
		if (mMACDLines == null)
			return;
		int linescount = mMACDLines.length / 5;
		int x1, y1, x2, y2;
		for (int i = 0; i < linescount; i++) {
			paint.setStyle(Style.STROKE);
			paint.setColor(mMACDLines[5 * i]);
			x1 = mMACDLines[5 * i + 1];
			y1 = mMACDLines[5 * i + 2];
			x2 = mMACDLines[5 * i + 3];
			y2 = mMACDLines[5 * i + 4];
			// System.out.println("x1:"+x1+" y1:"+y1+" x2:"+x2+" y2:"+y2);
			canvas.drawLine(x1, y1, x2, y2, paint);
		}
	}

	@Override
	public boolean onDown(MotionEvent e) {

		return false;
	}

	@Override
	public void onShowPress(MotionEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean onSingleTapUp(MotionEvent e) {
//		onSingleTapUpAs(e); //换成在别的地方进行控件 不通过点击 k 线图控件
		return false;
	}
	
	public boolean onSingleTapUpAs(MotionEvent e) {
		isKeepLine = false;
		int x = (int) e.getX();
		int y = (int) e.getY();
		if (mTechRect.contains(x, y) && mKTechChart.isEnable()) {
			mKTechChart.onChangedTech();
			initChart();
			mTarget.invalidate();
		}
		return false;
	}

	@Override
	public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX,
			float distanceY) {
		/*
		 * mCursorIndex = getCursorIndex(e2.getX()); isShowBox = true;
		 * mTarget.invalidate();
		 */
		return false;
	}

	@Override
	public void onLongPress(MotionEvent e) {
		// TODO Auto-generated method stub
		isKeepLine = true;
	}

	@Override
	public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
			float velocityY) {
		Log.i("KLine", "KLine Chart onFling");
		float fy = e2.getY() - e1.getY();
		if(fy > 50)//down
		{
			this.zoomOut();
		}
		else if(fy < -50) //up
		{
			this.zoomIn();
		}
		else
		{}
		//mTarget.onPage();
		return false;
	}
	
	public void draw2(Canvas canvas) {
		if (mDataSet == null)
			return;
		drawCharBox(canvas, boxPaint, frame);
	}
	
	public void setTechType(int type){
		mKTechChart.onChangedTech(type);
		initChart();
		mTarget.invalidate();
	}
}
