package com.gf.view.adapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.gf.client.R;
import com.gf.control.QuotationActivity;
import com.gf.view.ItemClickedListener;
import com.gf.view.ItemHeaderClickedListener;
import com.gf.view.adapter.InformationAdapter.ItemViewHolder;
import com.gf.viewmodel.bean.Group;
import com.gf.viewmodel.bean.MessageInfo;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 我的自选股列表
 * @author cola
 *
 */
public class StockDetailInfoAdapter extends CommonAdapter  {

	private List<MessageInfo> mMessageList;
	private List<Group> mMessageListGroup;
	
//	private ItemClickedListener mItemClickedListener;
//	private ItemHeaderClickedListener mItemHeaderClickedListener;

	private Context context;
	
	private boolean mIsOpen;//初始化View时分组是否展开

	public StockDetailInfoAdapter(Context context, List<MessageInfo> message_list, boolean isOpen) {
		this.context = context;
		this.mMessageList = message_list;
		this.mIsOpen = isOpen;
		initMessageList(message_list);
	}

	private void initMessageList(List<MessageInfo> message_list) {
		this.mMessageList = message_list;
		if (message_list != null && message_list.size() > 0) {
			getSectionIndicesAndGroupNames();
		}
	}

	@Override
	public int getCount() {
		return mMessageList == null ? 0 : mMessageList.size();
	}

	public int getRealCount() {
		return mMessageList == null ? 0 : mMessageList.size();
	}

	@Override
	public Object getItem(int position) {
		return mMessageList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		ItemViewHolder holder;

		if (convertView == null) {
			holder = new ItemViewHolder();
			convertView = LayoutInflater.from(context).inflate(R.layout.information_context, null);
			holder.layout = (LinearLayout) convertView.findViewById(R.id.information_line);
			holder.more = (LinearLayout) convertView.findViewById(R.id.more);
			holder.title = (TextView) convertView.findViewById(R.id.information_title);
			holder.icon = (ImageView) convertView.findViewById(R.id.information_icon);
			holder.context = (TextView) convertView.findViewById(R.id.information_context);
			holder.line = (View) convertView.findViewById(R.id.line2);
			convertView.setTag(holder);
			convertView.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					if(mItemClickedListener != null) {
						mItemClickedListener.onItemClick(v, position);
					}
					
				}
			});
			

		} else {
			holder = (ItemViewHolder) convertView.getTag();
		}
		
		/**
		 * 最后的获取更多item按钮
		 */
		if( mMessageList.get(position).order == mMessageListGroup.get(mMessageList.get(position).getGroupId()).getCount()){
			holder.context.setVisibility(View.GONE);
			holder.more.setGravity(Gravity.CENTER); 
			holder.icon.setBackgroundResource(R.drawable.add);
		}else{
			holder.context.setVisibility(View.VISIBLE);
			holder.more.setGravity(Gravity.LEFT); 
			holder.icon.setBackgroundResource(0);
		}
		
		
		holder.title.setText(mMessageList.get(position).mTitle);
		holder.context.setText(mMessageList.get(position).getInfo());
		holder.line.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);
		holder.layout.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);
		//若合起分组，则里面的view不显示
//		holder.textViewInfo.setVisibility(mMessageListGroup.get(mMessageList.get(position).getGroupId()).isShown() ? View.VISIBLE : View.GONE);


		
		return convertView;
	}

	/**
	 * 分组
	 */
	private void getSectionIndicesAndGroupNames() {
		mMessageListGroup = new ArrayList<Group>();
		Group gp;
		int countGp = 0;
		String groupName = "";
		final int len  = mMessageList.size();
		for (int i = 0; i < len; i++) {
//			int order = 1;
			String groupName2 = mMessageList.get(i).getGroupName();
			if (!groupName2.equals(groupName)) {
				
				if(mMessageListGroup.size()>0) {
					mMessageListGroup.get(mMessageListGroup.size()-1).setCount(countGp);
				}
				groupName = groupName2;
				countGp = 1;
				mMessageList.get(i).setGroupId(mMessageListGroup.size());
				gp = new Group();
				gp.setName(groupName);
				gp.setFirstPositionInList(i);
				gp.setShown(mIsOpen);
				mMessageList.get(i).order = countGp;
				mMessageListGroup.add(gp);
			} else {
				countGp ++;
				mMessageList.get(i).order = countGp;
				mMessageList.get(i).setGroupId(mMessageListGroup.size() - 1);
			}

		}
		if(mMessageListGroup.size()>0) {
			mMessageListGroup.get(mMessageListGroup.size()-1).setCount(countGp);
		}

	}

	@Override
	public View getHeaderView(final int position, View convertView, ViewGroup parent) {

		ItemHeaderViewHolder holder = null;
		if (convertView == null) {
			holder = new ItemHeaderViewHolder();
			convertView = LayoutInflater.from(context).inflate(R.layout.stockdetailheader, parent, false);
			holder.mCompany_New = (TextView) convertView.findViewById(R.id.time);
			holder.mCompany_Introduction = (TextView) convertView.findViewById(R.id.price);
			holder.mCompany_Dividend = (TextView) convertView.findViewById(R.id.tvolume);
			holder.mCompany_Data = (TextView) convertView.findViewById(R.id.level);
			convertView.setTag(holder);
		} else {
			holder = (ItemHeaderViewHolder) convertView.getTag();
		}

		convertView.setBackgroundColor(Color.BLACK);
//		Group gp = mMessageListGroup.get(mMessageList.get(position).getGroupId());
		holder.mCompany_New.setText(mMessageList.get(position).mField1);
		
		holder.mCompany_Introduction.setText(mMessageList.get(position).mField2);
		
		holder.mCompany_Dividend.setText(mMessageList.get(position).mField3);
		
		holder.mCompany_Data.setText(mMessageList.get(position).mField4);
		holder.mCompany_Data.setTextColor(context.getResources().getColor(R.color.plate_title));
//		 if(gp.isShown()) {
////			 holder.imgArrow.setImageResource(R.drawable.ic_group_arrow_open);
//			 holder.line.setVisibility(View.VISIBLE);
//		 } else {
////			 holder.imgArrow.setImageResource(R.drawable.ic_group_arrow_close);
//			 holder.line.setVisibility(View.GONE);
//		 }
		
		return convertView;
	}

	@Override
	public long getHeaderId(int position) {
		return mMessageList.get(position).getGroupId();
	}

	/**
	 * 当点击header时，即GroupName，可以展开合起
	 */
	public void onListHeaderClicked(int position) {
		Group gp = mMessageListGroup.get(mMessageList.get(position).getGroupId());
		gp.setShown(!gp.isShown());

		StockDetailInfoAdapter.this.notifyDataSetChanged();
	}
	
	/////////////////////////////////////////
//	public void setOnItemClickedListener(ItemClickedListener listener) {
//		this.mItemClickedListener = listener;
//	}
//	
//	public void setOnItemHeaderClickedListener(ItemHeaderClickedListener listener) {
//		this.mItemHeaderClickedListener = listener;
//	}
//	
//	public ItemHeaderClickedListener getmItemHeaderClickedListener() {
//		return mItemHeaderClickedListener;
//	}


	// /////////////////////////////////////
	public class ItemHeaderViewHolder {

		TextView mCompany_New;
		ImageView imgArrow;
		TextView mCompany_Introduction;
		TextView mCompany_Dividend;
		TextView mCompany_Data;
		
	}

	public class ItemViewHolder {
		LinearLayout layout,more;
		TextView title;
		TextView context;
		ImageView icon;
		View line;
	}

	protected void sort(int sort){
		Collections.sort(mMessageList, new Comparator<MessageInfo>() {

			@Override
			public int compare(MessageInfo lhs, MessageInfo rhs) {
				// TODO Auto-generated method stub
				if (Integer.parseInt(lhs.stockRang) > Integer
						.parseInt(rhs.stockRang))
					return 1;
				else if (Integer.parseInt(lhs.stockRang) == Integer
						.parseInt(rhs.stockRang))
					return 0;
				else if (Integer.parseInt(lhs.stockRang) < Integer
						.parseInt(rhs.stockRang))
					return -1;
				
				return 0;
			}


			
		});
	}
}
