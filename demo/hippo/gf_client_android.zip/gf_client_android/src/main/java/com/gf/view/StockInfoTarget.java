/**
 * 
 */
package com.gf.view;

import com.gf.client.R;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * @author Cola
 *
 */
public class StockInfoTarget extends LinearLayout{
	private RealtimeQuoteItem mRealtimeQuoteItem;
	private TextView mOpen, mVolume, mPclose, mPrice,mAmount,mPe,mEps,mShare,mIn,mOut,mNvaps,mHeight,mLow,mAmplitude,
	mTotal;
	/** 涨跌值 */
	private TextView mChange;
	/** 涨跌幅 */
	public TextView mRise;
	/**
	 * 换手率
	 */
	public TextView mHandover;

	public StockInfoTarget(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;

	public StockInfoTarget(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	public void init() {
		LayoutInflater.from(context).inflate(R.layout.qutotation_stockinfo_target, this);
		this.mOpen = (TextView) findViewById(R.id.target_open);
		this.mHandover = (TextView) findViewById(R.id.target_handover);
		this.mOut = (TextView) findViewById(R.id.target_out);
		this.mIn = (TextView) findViewById(R.id.target_in);
		this.mVolume = (TextView) findViewById(R.id.target_volume);
		this.mShare = (TextView) findViewById(R.id.target_share);
		this.mPclose = (TextView) findViewById(R.id.target_pclose);
		mNvaps = (TextView) findViewById(R.id.target_nvaps);
		mAmount = (TextView) findViewById(R.id.target_amount);
		mPe = (TextView) findViewById(R.id.target_pe);
		mEps = (TextView) findViewById(R.id.target_eps);
		mHeight = (TextView) findViewById(R.id.target_height);
		mLow = (TextView) findViewById(R.id.target_low);
		mTotal = (TextView) findViewById(R.id.target_total);
		mAmplitude = (TextView) findViewById(R.id.target_amplitude);
	}

	public void setData(RealtimeQuoteItem mTimeSeriesQuoteCache) {
		this.mRealtimeQuoteItem = mTimeSeriesQuoteCache;
		draw();
	}

	private void draw() {
		float tmp = mRealtimeQuoteItem.getAmount()/100000000;
		if(tmp > 1)
		this.mAmount.setText(String.format("%1$.2f", tmp) + "亿");
		else
		this.mAmount.setText(String.format("%1$.2f", mRealtimeQuoteItem.getAmount()/10000) + "万");
		this.mEps.setText(mRealtimeQuoteItem.getEps() + "");
		this.mHandover.setText(String.format("%1$.2f", mRealtimeQuoteItem.getHandover()));
		
		this.mHeight.setText(mRealtimeQuoteItem.getHigh() + "");
		this.mLow.setText(mRealtimeQuoteItem.getLow() + "");
		this.mNvaps.setText(String.format("%1$.2f",mRealtimeQuoteItem.getNvaps()));
		
		this.mOpen.setText(mRealtimeQuoteItem.getOpen() + "");
		this.mOut.setText(String.format("%1$.2f", mRealtimeQuoteItem.getOut()/10000) + "万");
		this.mPclose.setText(mRealtimeQuoteItem.getPclose() + "");
		
		this.mPe.setText(mRealtimeQuoteItem.getPe() + "");
		this.mShare.setText(String.format("%1$.2f", mRealtimeQuoteItem.getShare()/100000000) + "亿");
		this.mVolume.setText(String.format("%1$.2f", mRealtimeQuoteItem.getVolume()/10000) + "万");
//		
		this.mIn.setText(String.format("%1$.2f", mRealtimeQuoteItem.getIn()/10000) + "万");
		this.mAmplitude.setText(String.format("%1$.2f", (mRealtimeQuoteItem.getHigh() - mRealtimeQuoteItem.getLow())/mRealtimeQuoteItem.getPclose()));
		this.mTotal.setText(String.format("%1$.2f", mRealtimeQuoteItem.getTotal()/100000000) + "亿");
	}
}
