package com.gf.view;

import com.gf.control.BaseWindow;
import com.gf.view.widget.Events;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.DataSetKLine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

public class KlineView extends View{
	protected BaseWindow application;
	final static String[] sTitleExs = {
		"-5分钟K线",
		"-15分钟K线",
		"-30分钟K线",
		"-60分钟K线",
		"-日K线",
		"-周K线",
		"-月K线"
	};
//	public static StockTitleChart mTitleChart;
	private KLineChart mKLineChart;
	
	private GestureDetector mGestureDetector;
    private OnGestureListener mOnGestureListener;
	private Bundle mExtras = new Bundle();
       
    private int mMatchId;    
    
    private String mStockName;
    private String mStockCode;
    private int    mStockMarket;
    private int    mStockIndex;
    private int    mStockType;
    
//	protected int mKlineCycle = Business.KX_DAY;//当前K线周期
    
	public KlineView(Context context, AttributeSet attrs) {
		super(context, attrs);
		this.application = (BaseWindow) context;
		// TODO Auto-generated constructor stub
		init();
		intGesture();
		
		setFocusable(true);
		setClickable(true);		
	}
	
	public void init(){
		final int w = getWidth();//Global.fullScreenWidth;
		final int h = getHeight();//Global.fullScreenHeight;
		final int r = w - 90;//170
		final int top = 10;
//		final int bottom =h-50;
		int temp_bottom = h - 50;
		if (Global.BottomMenu_H > 35) {
			temp_bottom = temp_bottom - Global.BottomMenu_H + 25;
		}
		final int bottom = temp_bottom;
//		mTitleChart = new StockTitleChart(0,top,r,top+56);		
//		mKLineChart = new KLineChart(0,top+60,r,bottom);
		mKLineChart = new KLineChart(0,0,h,w);
		mKLineChart.setTarget(this);		
//		mKLineChart.setStockTitleChart(mTitleChart);
	}
	
	//设置当前证券，横竖屏切换时恢复，为兼容4.0
	public void setCurStock(String code,String name,int market,int index){
		mStockName = name;
		mStockCode = code;
		mStockMarket = market;
		mStockIndex = index;
//		mTitleChart.setStock(name, code);
	}	
	
	private void initDraw(){
		
		final int w = getWidth();
		final int h = getHeight();
		
		final int top = 0;
		final int bottom =h-1;
		
		final int left = 1;
		
		final int title_height = 70;
		
//		if(mTitleChart.isRequestUpdate()){
//			mTitleChart.update();
//		}
		
		final int r = (int) (w - 1);
				
//		mTitleChart.setFrame(0,top,Global.isLandscape()?r:w,top+title_height);		
		
		if(!Global.isLandscape()){
			if(mKLineChart != null) mKLineChart.setFrame(left,top,w,h);
		}else{
			if(mKLineChart != null) mKLineChart.setFrame(left,top,w,h);
		}
		
		if(mKLineChart!=null && mKLineChart.isRequestUpdate()){
			mKLineChart.update();
		}	
	}
	
	private void intGesture(){
		mOnGestureListener=new OnGestureListener(){
			@Override
			public boolean onDown(MotionEvent e) {				
				invalidate();
				return false;
			}
			@Override
			public void onShowPress(MotionEvent e) {	
				
			}
			@Override
			public boolean onSingleTapUp(MotionEvent e) {
				
				return false;
			}
			@Override
			public boolean onScroll(MotionEvent e1, MotionEvent e2,
					float distanceX, float distanceY) {
				
				return false;
			}
			@Override
			public void onLongPress(MotionEvent e) {		
				
			}
			@Override
			public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
					float velocityY) {			
				return false;
			}};
			
			mGestureDetector = new GestureDetector(mOnGestureListener);
	}
	
//    public void sendKlineRequest(int ktype) {     
//    	mKlineCycle = ktype;
//        request(false);
//		//requestFS(); K线请求不需要去刷新分时
//    }	
	
//	public void request(boolean isRefresh){		
//	
//		boolean bShowDialog;		
//		if(isRefresh)
//		{
//			bShowDialog = false;
//			application.startNetworkUi(bShowDialog);
//		StockRequest.reqKLine(mStockMarket, mStockCode, 0, mKlineCycle, 1,true);
//		}
//		else
//		{
//			bShowDialog = true;
//			application.startNetworkUi(bShowDialog);
//		 StockRequest.reqKLine(mStockMarket, mStockCode, 0, mKlineCycle, 1000,false);
//		}		
//				
//	}
	
//	public void requestFS(int data,boolean ifrefresh) {
//		application.startNetworkUi(true);
//		StockRequest.reqFS(mStockMarket, mStockCode, data,ifrefresh);
//	}
	
	public String getCurStockCode()
	{
		return this.mStockCode;
	}
	
	public String getCurStockName()
	{
		return this.mStockName;
	}
	
	public int getCurStockMarket()
	{
		return this.mStockMarket;
	}
	
	public int getCurStockType()
	{
		return this.mStockType;
	}	
	
	public int getCurStockIndex()
	{
		return this.mStockIndex;
	}
	
	protected void updateTitle(){
//		if(mKLineChart!=null && mKLineChart.getDataSet()!=null){
//			final DataSetKLine dsk = mKLineChart.getDataSet();
//			int i = dsk.retCycle >= Business.KX_15MIN?dsk.retCycle - Business.KX_15MIN + 1: 0;
//			String tex = sTitleExs[i];
//			//ax
//			//mr.initTitle(mModelID==0?"即时分析":"技术分析"+tex);
//		}else{
//			//ax
//			//mr.initTitle(mModelID==0?"即时分析":"技术分析");
//		}
		invalidate();
	}
	
	public void clear(){
//		mTitleChart.clear();
		mKLineChart.clear();
	}

//	public boolean handleData(Rsp rsp){	
//		final byte[] data = (byte[]) rsp.packet.mBodyBuffer;
//		if(data==null)return false;
//		int uuiq=StockTool.buildStockUUIQ(mStockMarket, mStockCode);
//		if(!StockTool.compareDataByUUIQ(rsp.packet.mBodyBuffer, uuiq)){
//			Log.e("证券内码对不上","uuiq:"+uuiq);
//			return false;//如果证券内码对不上，不处理
//		}
//		if (rsp.packet.mSFuncNo == Business.HQ_KX) {
//			DataSetKLine ds = new DataSetKLine();
//			ds.AnalysisKLine(data,Global.getMacycle1(),Global.getMacycle2(),Global.getMacycle3());
//			
//			if(rsp.packet.mReserved == 1&&mKLineChart.getDataSet()!=null){//增量 
//				Log.e("refresh", "refresh...kline");
//				ds = mKLineChart.getDataSet().merge(ds,Global.getMacycle1(),Global.getMacycle2(),Global.getMacycle3());
//			}
//			setDataSet(ds);
//		} else if (rsp.packet.mSFuncNo == Business.HQ_FS) {
//			DataSetTimeSharing dst = new DataSetTimeSharing();	
//			dst.setCmdVersion(rsp.packet.mVersion);
//			
//			if(rsp.packet.mReserved != 1){
//				dst.Analysis(data,null);
//			}					
////			mTitleChart.setDataSet(dst);
//		}
//		
//		Functions.removeCashe(application.bizId+1);		
//		Functions.putCashe(application.bizId+1, mKLineChart.getDataSet());//K线数据进栈
//		Global.stockCode = this.mStockCode;
//		Global.stockName = this.mStockName;
//		Global.mStockMarket = this.mStockMarket;
//		Global.mStockIndex = this.mStockIndex;
//		return true;
//}
//
	public void setDataSet(DataSetKLine dataset) {
		mKLineChart.setDataSet(dataset);
		this.postInvalidate();
	}
//	
//	public boolean matchMessage(XMessage msg) {		
//		mMatchId = 0;
//		if(msg.match(Business.MF_HQ, Business.HQ_FS)){
//			mMatchId = 1;
//		}else if(msg.match(Business.MF_HQ, Business.HQ_KX)){
//			mMatchId = 2;
//		}
//		return mMatchId != 0;
//	}

	public Bundle getExtras() {		
		return mExtras;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		initDraw();
//		canvas.drawColor(0xff333333);		
		canvas.save();
		
		if(Global.isLandscape()){
			mKLineChart.draw(canvas);
		}else{
			mKLineChart.draw(canvas);
		}			
		
//		mTitleChart.draw(canvas);
//		mKLineChart.draw2(canvas);
		canvas.restore();
		
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		mGestureDetector.onTouchEvent(ev);
		mKLineChart.onTouchEvent(ev);
		final int action = ev.getAction();
		//兼容1.6
		//switch(action & MotionEvent.ACTION_MASK){
		switch(action){
		case MotionEvent.ACTION_DOWN:
//			mMiniChart.touch((int)ev.getX(), (int)ev.getY());
			break;
		case MotionEvent.ACTION_UP:		
//			if(mMiniChart.clickChart((int)ev.getX(), (int)ev.getY()) && !Global.isLandscape()){
//				initDraw();
//				mKLineChart.update();
//			}
			invalidate();
			break;
		}
		return true;
	}
	
	public void zoomIn() {
		mKLineChart.zoomIn();
	}

	public void zoomOut() {
		mKLineChart.zoomOut();
	}	
	public KLineChart getKLineChart() {
		return mKLineChart;
	}
	
	public void setTechType(int type){
		mKLineChart.setTechType(type);
	}
}
