package com.gf.viewmodel.bean;
/**
 * 跟业务协议相关的定义
 *
 */
public interface Business {

	//通讯时间参数
	public final static long SOCKET_TIMEOUT = 30000; // 10秒超时
	public final static long SOCKET_REVC_DELAY = 20;     // 接收数据延时500豪秒
	
	//网络状态
	public final static int NOT_CNT = 0; // 尚未连接
	public final static int ON_CNTING = 1; // 正在建立连接中
	public final static int ON_CNT = 2; // 连接中
	public final static int OFF_CNT = 3; // 连接正常断开
	public final static int ERROR_CNT = 4; // 连接异常断开
	public final static int FAILD_CNT = 5; // 连接失败
	
	//网络通讯参数
	public static final int SOCKET_DELAY = 0;
	public static final int SOCKET_LINGER = 5;
	public static final int SOCKET_KEEPALIVE = 0;
	public static final int SOCKET_RCVBUF = 5120;
	public static final int SOCKET_SNDBUF = 128;
	
	//通讯错误代码
	public final static int ERROR_CODE_SENDBUF_NULL      = 20001;     //发送数据不能为空
	public final static int ERROR_CODE_SENDBUF_TOOLENGHT = 20002;     //发送数据超长
	public final static int ERROR_CODE_CONN_IS_FAILED    = 20003;     //通讯失败
	public final static int ERROR_CODE_RRCV_TIMEOUT      = 20004;     //接收数据超时
	public final static int ERROR_CODE_SEND_CANCEL       = 20005;     //请求已经被取消
	public final static int ERROR_CODE_SEND_SENDING      =  20006;

	
	public final static String ERROR_INFO_SENDBUF_NULL      = "发送数据太短";
	public final static String ERROR_INFO_SENDBUF_TOOLENGHT = "发送数据超长";
	public final static String ERROR_INFO_CONN_IS_FAILED    = "通讯失败";
	public final static String ERROR_INFO_RRCV_TIMEOUT    = "接收数据超时";
	public final static String ERROR_INFO_SEND_CANCEL     = "请求已经被取消";
	public final static String ERROR_INFO_SEND_SENDING    = "数据通讯进行中";
	
	//------------------------------------------------------------------------------------------//
	// 下面是压缩类型定义
	public final static boolean CT_NONE = false; // 不压缩
	public final static boolean CT_GZIP = true; // GZIP压缩
	// 下面是加密类型定义
	public final static boolean ET_NONE = false; // 不加密
	public final static boolean ET_3DES = true; // 3DES加密
	// 正确信息标示
	public final static boolean RDT_UNICODE_DATA = true; // UNICODE编码的正确数据
	public final static boolean RDT_UNICODE_ERROR = false; // UNICODE编码的错误信息
	// 协议类型
	public final static boolean PROTOCOL_TYPE1 = false; // 常规协议类型
	public final static boolean PROTOCOL_TYPE2 = true; // XML协议类型
	// 命令版本
	public final static boolean PROTOCOL_VERSION0 = false; // 协议版本号
	public final static boolean PROTOCOL_VERSION1 = false; // 协议版本号
	public final static boolean PROTOCOL_VERSION2 = false; // 协议版本号
	public final static boolean PROTOCOL_VERSION3 = false; // 协议版本号

	//public final static byte HEADERLENGTH = 6; // 包头的长度
	public final static byte HEADERLENGTH = 17; // 包头的长度
	
	//服务器类型
	public final static int SERVER_HQ = 1;   //行情服务器
	public final static int SERVER_ZX = 2;   //资讯服务器
	public final static int SERVER_YJ = 4;   //预警服务器
	public final static int SERVER_RZ = 8;   //认证服务器
	public final static int SERVER_JY = 16;  //交易服务器
	public final static int SERVER_WEB = 32;  //web服务器

	// 下面是请求主命令号的定义
	/**主命令号: 行情*/public final static byte MF_HQ = 0x01; // 行情
	/**主命令号:资讯 12 目前只用于全球指数 */public final static byte MF_ZX = 0x0c; // 资讯 12 

	// 子功能号
	/**子功能号:K线*/public final static byte HQ_KX = 0x01;							//K线
	/**子功能号:分时*/public final static byte HQ_FS = 0x02;							//分时行情
	/**子功能号:自选行情*/public final static byte HQ_ZX = 0x03;							//自选行情
	/**子功能号:排序行情*/public final static byte HQ_PX = 0x04;							//排序行情
	/**子功能号:分笔*/public final static byte HQ_FB = 0x05;							//分笔
	/**子功能号:代码链*/public final static byte HQ_DM = 0x06;                          //代码链
	/**子功能号:代码链(支持场外)*/public final static byte HQ_DM_CW = 0x07;                       //代码链(支持场外)
	
	// 系统子功能号
	public final static byte XT_LOGIN   	= 0x01;			 	//用户认证	
	public final static byte XT_UPDATES 	= 0x02;            	//自动升级
	public final static byte XT_LOGIN_INFO  = 0x03;			    //资讯用户认证	
	public final static byte XT_REG_CODE   	= 0x04;			    //大众用户注册
	public final static byte XT_REG_CONFIRM = 0x05;			    //大众用户验证服务码，完成注册
	public final static byte XT_LOGIN_YD   	= 0x06;			    //大众用户认证	
	public final static int XT_FEEDBACK   	= 1015;			    //意见反馈
	public final static int XT_FEEDBACK_ITEM = 1016;			    //查询默认意见列表

	// 资讯子功能号
	public final static byte ZX_QQ = 0x01;							//资讯请求
	
	public final static byte ZX_MYINFO_CX = 0x03;					//我的资讯栏目查询
	public final static byte ZX_MYINFO_BC = 0x04;					//我的资讯栏目保存
	
	public final static byte ZX_QUESTIONINFO = 0x06;					//互动交流获取基本信息
	public final static byte ZX_INTERSUBMIT = 0x07;					//互动交流--提交问题
	public final static byte ZX_INTERQUERY = 0x08;					//互动交流--查询
	public final static byte ZX_ZXG_SZ = 0x09;                      //(资讯)自选股设置	
	
	//预警子功能号
	public final static byte FIN_WARN_LIST           = 0x04;  /* 获取我的定制列表 */
	public final static byte FIN_WARN_SERVICES       = 0x05;  /* 预警项目列表 */
	public final static byte FIN_WARN_SUBSCRIBE      = 0x06;  /* 定制预警项目 */
	public final static byte FIN_WARN_UNSUBSCRIBE    = 0x07;  /* 退订预警项目 */
	
	

	//排序方式
    public final static byte PX_NONE = 0x00;					//不排序  
    public final static byte PX_CODE = 0x01;                  	//代码
    public final static byte PX_NOW = 0x02;                  	//最新
    public final static byte PX_VOLUME = 0x03;                  //成交数量
    public final static byte PX_AMOUNT = 0x04;                  //成交金额
    public final static byte PX_CHANGE_PCT = 0x05;              //涨跌幅
    public final static byte PX_TURNOVER = 0x06;                //换手
    public final static byte PX_PE = 0x07;                   	//市盈率
    
    //交易所代码
    public final static short MT_SHENZHEN = 1; //深圳交易所
    public final static short MT_SHANGHAI = 2; //上海交易所
    public final static short MT_CHANGWAI = 4; //场外基金
    
    //板块 曾用名 证券类别
    public final static short BK_zixuan		= 0;							//自选
    public final static short BK_a			= 1;							//A股
    public final static short BK_b			= 2;							//B股
	public final static short BK_fund		= 4;							//基金
	public final static short BK_warrant    = 8;							//权证
	public final static short BK_index		= 16;							//指数
	public final static short BK_bond	    = 32;							//债券
	public final static short BK_growth     = 64;							//创业板
	public final static short BK_small      = 128;                          //中小版
	public final static short BK_third      = 256;                          //三板
	
    //K线类型
    public final static byte KX_1MIN  	= 0x01;                   	//01分钟数据
    public final static byte KX_5MIN  	= 0x02;                   	//05分钟数据
    public final static byte KX_10MIN 	= 0x03;                   	//10分钟数据 
    public final static byte KX_15MIN 	= 0x04;                   	//15分钟数据
    public final static byte KX_30MIN 	= 0x05;                   	//30分钟数据
    public final static byte KX_60MIN 	= 0x06;                   	//60分钟数据
    public final static byte KX_DAY   	=  0x07;                   	//日K线数据
    public final static byte KX_WEEK    = 0x08;                   	//周K线数据
    public final static byte KX_MONTH   = 0x09;                     //月K线数据
    public final static byte KX_03MNT 	=  0x0a;                    //季K线数据
    public final static byte KX_06MNT 	= 0x0b;                     //半年K线数据
    public final static byte KX_12MNT 	= 0x0c;                     //年K线数据
	
	//------------------------------------------------------------------------------------------//
    public static short clsZXRefreshTime = 30;        //自选报价刷新时间间隔，值为0表示手动刷新
    public static short clsDPRefreshTime = 30;        //大盘分析刷新间隔时间,值为0表示手动刷新
    public static short clsZHRefreshTime = 30;        //综合排行刷新间隔时间,值为0表示手动刷新
    public static short clsGGRefreshTime = 30;        //个股行情刷新间隔时间,值为0表示手动刷新
	
	//证券业务定义代码
	public final static int MAX_CODE_LENGTH = 9;  //股票代码长度
    public final static int MAX_NAME_LENGTH = 26; //股票名称长度
    
  //------------------------------------------------------------------------------------------//
    
}
