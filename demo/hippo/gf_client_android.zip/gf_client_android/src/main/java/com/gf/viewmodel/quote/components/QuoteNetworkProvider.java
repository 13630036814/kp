package com.gf.viewmodel.quote.components;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;

import com.gf.common.network.Callback;
import com.gf.common.network.Config;
import com.gf.common.network.ConnectionInfo;
import com.gf.common.network.Data;
import com.gf.common.network.NetUtil;
import com.gf.common.network.NetworkImpl;
import com.gf.common.network.Status;
import com.gf.hippo.domain.client.common.DomainObject;
import com.gf.hippo.domain.client.common.Network;
import com.gf.hippo.domain.client.common.NetworkListener;
import com.gf.hippo.domain.client.common.NetworkStatus;
import com.gf.hippo.domain.client.common.Parser;
import com.gf.trade.TradeConstant;
import com.gf.trade.network.TradeNetworkListener;

public class QuoteNetworkProvider extends Network {
    private NetworkImpl mImpl;
    private NetworkListener mListener;
    private HashMap<String,Parser> mMapParser=new HashMap<String,Parser>();
	private TradeNetworkListener mTradeListencer;
    
    public void registeParser(String topic,Parser parser){
    	mMapParser.put(getParseKey(topic), parser);
    }
    public QuoteNetworkProvider(Context context){
        Callback callback = new Callback(){
            @Override
			public void onData(Data serverData) {
				Parser parser = mMapParser.get(getParseKey(serverData.getTopic()));
				DomainObject domainObject = null;
				if (parser != null) {
					domainObject = parser.unserialize(serverData.getData());
				}
//				System.out.println(mTradeListencer.toString());
				if (serverData.getTopic().equals(TradeConstant.TRADE_SERVER_TOPIC) && mTradeListencer != null) {
					mTradeListencer.onData(domainObject);
				} else {
					if (mListener != null && parser != null) {
						if (domainObject != null)
							mListener.onData(serverData.getTopic(), domainObject);
					}
				}
			}

            @Override
            public void onStatus(Status status) {
            	if (mListener != null){
					NetworkStatus nStatus=new NetworkStatus();
					nStatus.setMessage(status.getReason());
					nStatus.setStatus(status.getType());
					mListener.onStatus(nStatus)	;
				}
            }
        };

        mImpl = new NetworkImpl(new NetUtil(context), callback);
        ArrayList<ConnectionInfo> list = new ArrayList<ConnectionInfo>();
        ConnectionInfo info = new ConnectionInfo();
        info.hqUrl = "183.232.32.100:5000";
        info.jyUrl = "10.2.121.186:1521";
        list.add(info);
        Config config = new Config(list);
        config.activeInfo = info;
        config.updateUrl = null;
        mImpl.start(config);
    }

    public void restart(){
        mImpl.restart();
    }

    @Override
    public void setListener(NetworkListener listener) {
        mListener = listener;
    }
    
    @Override
    public void send(String topic, DomainObject data) {
		if (data instanceof DomainObject) {
			Parser parser;					
			parser = mMapParser.get(getParseKey(topic));			
			DomainObject domainObject = (DomainObject) data;
			Object datas = null;
			if (parser != null)
				datas = parser.serialize(domainObject);
			if (datas != null) {
				sendBytes(topic, datas);
			}

		} else {

		}
	}
    
    @Override
	public void sendBytes(String topic, Object data) {
		if (data instanceof byte[]) {
			mImpl.send(topic, (byte[]) data);
		}
	}

	public void setTradeListener(TradeNetworkListener tradeListener) {
		mTradeListencer = tradeListener;
	}

	public TradeNetworkListener getTradeListener() {
		return mTradeListencer;
	}
	   
	private String getParseKey(String topic) {
		if (topic.equals(TradeConstant.TRADE_TOPIC)) {
			return TradeConstant.TRADE_SERVER_TOPIC;
		} else {
			return topic;
		}
	}

}
