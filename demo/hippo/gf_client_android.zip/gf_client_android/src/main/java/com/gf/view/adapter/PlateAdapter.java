/**
 * 
 */
package com.gf.view.adapter;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.gf.client.R;
import com.gf.view.adapter.MailAdapter.ItemHeaderViewHolder;
import com.gf.viewmodel.bean.MessageInfo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * @author cola
 *
 */
public class PlateAdapter extends BaseAdapter{
	private Context context;
	private List<MessageInfo> mMessageList;
	
	public PlateAdapter(Context context, List<MessageInfo> message_list){
		this.context = context;
		this.mMessageList = message_list;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mMessageList.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return mMessageList.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ItemHeaderViewHolder holder = null;
		if (convertView == null) {
			holder = new ItemHeaderViewHolder();
			convertView = LayoutInflater.from(context).inflate(R.layout.stockitem, parent, false);
			holder.stcokName = (TextView) convertView.findViewById(R.id.stockName);
			holder.stockCode = (TextView) convertView.findViewById(R.id.stockCode);
			holder.stockRange2 = (TextView) convertView.findViewById(R.id.risedrop);
			holder.stockPrice = (TextView) convertView.findViewById(R.id.price);
			holder.stockRange = (TextView) convertView.findViewById(R.id.risedroprang);
			holder.shape = (LinearLayout) convertView.findViewById(R.id.shape);
			convertView.setTag(holder);
		} else {
			holder = (ItemHeaderViewHolder) convertView.getTag();
		}

		
//		Group gp = mMessageListGroup.get(mMessageList.get(position).getGroupId());

		holder.stcokName.setText(mMessageList.get(position).getGroupName());
		
		String data = mMessageList.get(position).mField3;
		int p = mMessageList.get(position).mField3.indexOf(".");
		int len = mMessageList.get(position).mField3.length();
		
		if(p == -1 || mMessageList.get(position).mField3.equals("-100.0")){
			data = "--";
		}
		else if(len - p  > 3)
			data = mMessageList.get(position).mField3.substring(0, p + 3) + "%";
		else if(len - p  < 3)
			data = mMessageList.get(position).mField3 + "0" + "%";
		else
			data = mMessageList.get(position).mField3 + "%";
		holder.stockRange2.setText(data);
		
		data = mMessageList.get(position).mField2;
		p = mMessageList.get(position).mField2.indexOf(".");
		len = mMessageList.get(position).mField2.length();
		if(p == -1){
			data = "--";
		}
		else if(len - p  > 3)
			data = mMessageList.get(position).mField2.substring(0, p + 3);
		else if(len - p  < 3)
			data = mMessageList.get(position).mField2 + "0";
		holder.stockRange.setText(data);
		
		data = mMessageList.get(position).mField1;
		p = mMessageList.get(position).mField1.indexOf(".");
		len = mMessageList.get(position).mField1.length();
		if(p == -1){
			data = "--";
		}
		else if(len - p  > 3)
			data = mMessageList.get(position).mField1.substring(0, p + 3);
		else if(len - p  < 3)
			data = mMessageList.get(position).mField1 + "0";
		holder.stockPrice.setText(data);
		
		
		if (mMessageList.get(position).mField3.indexOf("--") < 0 && !mMessageList.get(position).mField3.equals("")) {
			if (mMessageList.get(position).mField3 != ""
					&& Float.parseFloat(mMessageList.get(position).mField3) > 0) {
				holder.shape
						.setBackgroundResource(R.drawable.mystockitemshape_red);
				holder.stockRange.setTextColor(context.getResources().getColor(
						R.color.shallow_red));
			} else {
				holder.shape
						.setBackgroundResource(R.drawable.mystockitemshape_green);
				holder.stockRange.setTextColor(context.getResources().getColor(
						R.color.shallow_green));
			}
		} else {
			holder.shape
			.setBackgroundResource(R.drawable.mystockitemshape_grey);
			holder.stockRange.setTextColor(context.getResources().getColor(
					R.color.shallow_grey));
		}
		
		holder.stockCode.setText(mMessageList.get(position).getInfo());
		return convertView;
	}

	public class ItemHeaderViewHolder {

		TextView stcokName;
		ImageView imgArrow;
		TextView stockCode;
		TextView stockPrice;
		TextView stockRange;
		TextView stockRange2;
		LinearLayout shape;
	}
	
	public void sort(final int sort, final int sortField) {
		Collections.sort(mMessageList, new Comparator<MessageInfo>() {

			@Override
			public int compare(MessageInfo lhs, MessageInfo rhs) {
				// TODO Auto-generated method stub
				// Log.e("sort", lhs.mField2 + " and "+ rhs.mField2);
				switch(sortField){
				case 0:
					if (sort == MailAdapter.SORT_ASCENDING) {
						if (lhs.mField1.equals(rhs.mField1)
								&& rhs.mField1.equals(""))
							return 0;

						if (lhs.mField1.equals("") || lhs.mField1.equals("[]"))
							return -1;

						if (rhs.mField1.equals("") || rhs.mField1.equals("[]"))
							return 1;

						if (Float.valueOf(lhs.mField1) > Float.valueOf(rhs.mField1))
							return 1;
						else if (Float.valueOf(lhs.mField1) == Float
								.valueOf(rhs.mField1))
							return 0;
						else if (Float.valueOf(lhs.mField1) < Float
								.valueOf(rhs.mField1))
							return -1;
					} else {
						if (lhs.mField1.equals(rhs.mField1)
								&& rhs.mField1.equals(""))
							return 0;

						if (lhs.mField1.equals("") || lhs.mField1.equals("[]"))
							return 1;

						if (rhs.mField1.equals("") || rhs.mField1.equals("[]"))
							return -1;

						if (Float.valueOf(rhs.mField1) > Float.valueOf(lhs.mField1))
							return 1;
						else if (Float.valueOf(rhs.mField1) == Float
								.valueOf(lhs.mField1))
							return 0;
						else if (Float.valueOf(rhs.mField1) < Float
								.valueOf(lhs.mField1))
							return -1;
					}
					break;
				case 1:
					if (sort == MailAdapter.SORT_ASCENDING) {
						if (lhs.mField2.equals(rhs.mField2)
								&& rhs.mField2.equals(""))
							return 0;

						if (lhs.mField2.equals("") || lhs.mField2.equals("[]"))
							return -1;

						if (rhs.mField2.equals("") || rhs.mField2.equals("[]"))
							return 1;

						if (Float.valueOf(lhs.mField2) > Float.valueOf(rhs.mField2))
							return 1;
						else if (Float.valueOf(lhs.mField2) == Float
								.valueOf(rhs.mField2))
							return 0;
						else if (Float.valueOf(lhs.mField2) < Float
								.valueOf(rhs.mField2))
							return -1;
					} else {
						if (lhs.mField2.equals(rhs.mField2)
								&& rhs.mField2.equals(""))
							return 0;

						if (lhs.mField2.equals("") || lhs.mField2.equals("[]"))
							return 1;

						if (rhs.mField2.equals("") || rhs.mField2.equals("[]"))
							return -1;

						if (Float.valueOf(rhs.mField2) > Float.valueOf(lhs.mField2))
							return 1;
						else if (Float.valueOf(rhs.mField2) == Float
								.valueOf(lhs.mField2))
							return 0;
						else if (Float.valueOf(rhs.mField2) < Float
								.valueOf(lhs.mField2))
							return -1;
					}
					break;
				case 2:
					if (sort == MailAdapter.SORT_ASCENDING) {
						if (lhs.mField2.equals(rhs.mField2)
								&& rhs.mField2.equals(""))
							return 0;

						if (lhs.mField2.equals("") || lhs.mField2.equals("[]"))
							return -1;

						if (rhs.mField2.equals("") || rhs.mField2.equals("[]"))
							return 1;

						if (Float.valueOf(lhs.mField2) > Float.valueOf(rhs.mField2))
							return 1;
						else if (Float.valueOf(lhs.mField2) == Float
								.valueOf(rhs.mField2))
							return 0;
						else if (Float.valueOf(lhs.mField2) < Float
								.valueOf(rhs.mField2))
							return -1;
					} else {
						if (lhs.mField2.equals(rhs.mField2)
								&& rhs.mField2.equals(""))
							return 0;

						if (lhs.mField2.equals("") || lhs.mField2.equals("[]"))
							return 1;

						if (rhs.mField2.equals("") || rhs.mField2.equals("[]"))
							return -1;

						if (Float.valueOf(rhs.mField2) > Float.valueOf(lhs.mField2))
							return 1;
						else if (Float.valueOf(rhs.mField2) == Float
								.valueOf(lhs.mField2))
							return 0;
						else if (Float.valueOf(rhs.mField2) < Float
								.valueOf(lhs.mField2))
							return -1;
					}
					break;
				}

				return 0;
			}

		});
		this.notifyDataSetChanged();
	}
}
