package com.gf.control.trade;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.view.adapter.trade.NewStockInfoAdapter;
import com.gf.viewmodel.ebiz.trade.NewStockInfo;
import com.gf.viewmodel.util.View_Util;

/**
 * 新股申购
 * 
 */
public class NewStockPurchaseActivity extends Activity {

	private TextView tvTitle;
	private Button btnRight;

	private TextView lbStock; // 股票名称
	private TextView lbLimit; // 申购限额
	private TextView lbPrice; // 定价
	private TextView lbDate; // 申购日

	private ListView listView;
	private List<NewStockInfo> items = new ArrayList<NewStockInfo>();
	private NewStockInfoAdapter adapter;
	
	private EditText txtStockCode; // 股票代码
	private TextView tvStockName; // 股票名称
	private TextView tvPrice; // 定价
	private TextView tvMax; // 可买数量
	private TextView tvLimit; // 申购限额
	
	private NewStockInfo selectedStock;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_stock_purchase);

		initData();
		initViews();

		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				selectedStock = items.get(position);
				txtStockCode.setText(selectedStock.getStockCode());
				tvStockName.setText(selectedStock.getStockName());
				tvPrice.setText(selectedStock.getPrice());
				tvMax.setText(selectedStock.getMaxAmount());
				tvLimit.setText(selectedStock.getLimit());
			}
		});
	}

	private void initData() {
		if (!items.isEmpty()) {
			items.clear();
		}
		items.add(new NewStockInfo("000776", "广发证券", "10000", "3.86", "2014-04-18", "5000"));
		items.add(new NewStockInfo("601998", "中信银行", "30000", "42.15", "2014-04-23", "8000"));
		items.add(new NewStockInfo("600874", "民生银行", "50000", "15.32", "2014-05-09", "23000"));
	}

	private void initViews() {
		tvTitle = (TextView) findViewById(R.id.tv_title);
		tvTitle.setText("新股申购");
		btnRight = (Button) findViewById(R.id.btn_right);
		btnRight.setVisibility(View.GONE);

		lbStock = (TextView) findViewById(R.id.lb_one);
		lbLimit = (TextView) findViewById(R.id.lb_two);
		lbPrice = (TextView) findViewById(R.id.lb_three);
		lbDate = (TextView) findViewById(R.id.lb_four);
		lbStock.setText("股票名称");
		lbLimit.setText("申购限额");
		lbPrice.setText("定价");
		lbDate.setText("申购日");

		listView = (ListView) findViewById(R.id.listView);
		adapter = new NewStockInfoAdapter(this, items);
		listView.setAdapter(adapter);
		View_Util.setListViewHeightBasedOnChildren(listView);
		
		txtStockCode = (EditText) findViewById(R.id.txt_stock_code);
		tvStockName = (TextView) findViewById(R.id.tv_stock_name);
		tvPrice = (TextView) findViewById(R.id.tv_price);
		tvMax = (TextView) findViewById(R.id.tv_max);
		tvLimit = (TextView) findViewById(R.id.tv_limit);
	}
}
