package com.gf.view.widget;


import com.gf.view.Theme;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.util.DrawTool;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/**
 * K线中的按钮
 * @author Mark Ye 2012-4-27
 *
 */
public class ActionDraw {
	private Paint paint = Theme.factroyPaint();
	private GradientDrawable mDrawable;
	private static GradientDrawable mSelDrawable = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
			new int[] { 0xFF151515, 0xff3e3e3e, 0xFF151515});
	static{
		mSelDrawable.setShape(GradientDrawable.RECTANGLE);
		mSelDrawable.setGradientRadius((float) (Math.sqrt(2) * 60));
		setCornerRadii(mSelDrawable,0,0,0,0);
	}
	private String mText;
	private int mEventID;
	private boolean isSelected;
	private boolean hasChanged;
	
	private int mSelTextColor;
	private String mSelText;
	
	private Drawable mUsrDrawable;
	private Drawable mUsrSelDrawable;
	
	private Drawable mArrow, mBig, mSmall;
	
	private boolean isSelect = false;
	
	public ActionDraw() {
		mDrawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
				new int[] { 0xFF151515, 0xFF151515, 0xFF151515});
		mDrawable.setShape(GradientDrawable.RECTANGLE);
		mDrawable.setGradientRadius((float) (Math.sqrt(2) * 60));
		
		setCornerRadii(mDrawable,0,0,0,0);
	}
	
	public ActionDraw(String text){
		this();
		mText = text;
	}
	
	public ActionDraw(String text,int event){
		this();
		mText = text;
		mEventID = event;
	}
	
	public void setSelected(boolean value){
		isSelected = value;
		hasChanged = true;
	}
	
	public void setSelect(boolean b) {
		isSelect = b;
	}
	
	public boolean changed(){
		return hasChanged;
	}
	
	public void reset(){
		hasChanged = false;
	}
	
	public boolean isClick(){
		return isSelected;
	}
	
	public void setText(String text){
		mText = text;
	}
	
	public void setEventID(int id){
		mEventID = id;
	}
	
	public String getText() {
		return mText;
	}
	
	public int getEventID(){
		return mEventID;
	}
	
	public void setBounds(Rect r){
		mDrawable.setBounds(r);		
	}
	
	public Rect getBounds(){
		return mDrawable.getBounds();
	}
	
	public void setBounds(int left,int top,int right,int bottom){
		if(mUsrDrawable!=null){
			mUsrDrawable.setBounds(left, top, right, bottom);
		}
		mDrawable.setBounds(left, top, right, bottom);		
	}
	
	public void setDrawable(Drawable ud){
		mUsrDrawable = ud;
	}
	
	public void setSelDrawable(Drawable usd){
		mUsrSelDrawable = usd;
	}

	public void setArrowDrawable(Drawable usd){
		mArrow = usd;
	}

	public void setBigDrawable(Drawable usd){
		mBig = usd;
	}

	public void setSmallDrawable(Drawable usd){
		mSmall = usd;
	}

	public void setSelTextColor(int color){
		mSelTextColor = color;
	}
	
	public void setSelText(String value){
		mSelText = value;
	}
	
	public float getWidth(){
		final float density = Global.density;
		final Rect r = mDrawable.getBounds();
		if(mText!=null){
			return paint.measureText(mText)+10*density;
		}
		return r.width();
	}
	
	public float getHeight(){
		final Rect r = mDrawable.getBounds();		
		float ret = r.height();		
		if(ret == 0){
			ret = paint.getTextSize()+10;
		}		
		return ret;
	}
	
	
	public boolean contains(int x,int y){
		return mDrawable.getBounds().contains(x, y);
	}

	public void draw(Canvas canvas) {
		final Drawable d = mUsrDrawable!=null?mUsrDrawable:mDrawable;
		final Drawable seld = mUsrSelDrawable!=null?mUsrSelDrawable:mSelDrawable;
		final Rect r = d.getBounds();
		if(isSelected || isSelect){
			seld.setBounds(r);
			seld.draw(canvas);
		}else{
			d.draw(canvas);
		}
		
		paint.setColor(0XFF3f3f3f);
		canvas.drawLine(r.right, r.top, r.right, r.bottom, paint);
		
		if (mArrow != null) {
			//加个向上的箭头
			mArrow.setBounds(new Rect(r.left + 2,r.top + 2,r.left + 2 + mArrow.getMinimumWidth(),r.top + 2 + mArrow.getMinimumHeight()));
			//mArrow.setBounds(r);
			mArrow.draw(canvas);
			
		}
		
		if(mText!=null){
			String txt = mText;
			if(isSelected){	
				if(mSelText!=null){
					txt = mSelText;
				}
				paint.setColor(mSelTextColor!=0?mSelTextColor:0XFFeeeeee);
			}else{
				paint.setColor(0XFFffffff);
			}
			paint.setTextAlign(Align.CENTER);
			
			if (mBig != null) {
				//Bitmap bm = ((BitmapDrawable) mBig).getBitmap();
				//canvas.drawBitmap(bm, r.left+r.width()/2, r.top + r.height()/2, paint);
				mBig.setBounds(r.left+r.width()/2 - mBig.getMinimumWidth()/2, 
							   r.top + r.height()/2 - mBig.getMinimumHeight()/2, 
							   r.left+r.width()/2 + mBig.getMinimumWidth()/2, 
							   r.top + r.height()/2 + mBig.getMinimumHeight()/2);
				mBig.draw(canvas);
			}
			else if (mSmall != null) {
				mSmall.setBounds(r.left+r.width()/2 - mSmall.getMinimumWidth()/2, 
						   r.top + r.height()/2 - mSmall.getMinimumHeight()/2, 
						   r.left+r.width()/2 + mSmall.getMinimumWidth()/2, 
						   r.top + r.height()/2 + mSmall.getMinimumHeight()/2);
				mSmall.draw(canvas);
			}
			else {
				DrawTool.drawText(canvas, r.left+r.width()/2, r.top, r.width(), r.height(), paint, txt);
//				if (isSelect) {
//					paint.setStyle(Style.STROKE);
//					paint.setColor(0xffffff00);
//					canvas.drawRect(r, paint);
//				}
			}
			
		}
	}

	public static void setCornerRadii(GradientDrawable drawable, float r0, float r1,
			float r2, float r3) {
		drawable.setCornerRadii(new float[] { r0, r0, r1, r1, r2, r2, r3, r3 });
	}
}
