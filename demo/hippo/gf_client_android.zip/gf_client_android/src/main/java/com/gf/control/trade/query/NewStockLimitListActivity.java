package com.gf.control.trade.query;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.view.adapter.trade.FourItemInfoAdapter;
import com.gf.viewmodel.ebiz.trade.FourItemInfo;

/**
 * 新股申购额度查询
 * 
 */
public class NewStockLimitListActivity extends Activity {

	private TextView tvTitle;
	private Button btnRight;

	private TextView lbAccount; // 资金账号
	private TextView lbLimit; // 申购额度
	private TextView lbDept; // 交易所
	private TextView lbOwnerCode; // 股东代码

	private ListView listView;
	private List<FourItemInfo> items = new ArrayList<FourItemInfo>();
	private FourItemInfoAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.new_stock_limit_query_list);

		initData();
		initViews();

		btnRight.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
			}
		});

	}

	private void initData() {
		if (!items.isEmpty()) {
			items.clear();
		}
		for (int i = 0; i < 5; i++) {
			items.add(new FourItemInfo("11104207", "2000", "深圳A股", "0522119"));
			items.add(new FourItemInfo("11133257", "1500", "上海A股", "1201419"));
			items.add(new FourItemInfo("11104117", "3000", "深圳A股", "0514198"));
			items.add(new FourItemInfo("11104209", "3500", "上海A股", "1121423"));
		}
	}

	private void initViews() {
		tvTitle = (TextView) findViewById(R.id.tv_title);
		tvTitle.setText("新股申购额度");
		btnRight = (Button) findViewById(R.id.btn_right);
		btnRight.setText("刷新");

		lbAccount = (TextView) findViewById(R.id.lb_one);
		lbLimit = (TextView) findViewById(R.id.lb_two);
		lbDept = (TextView) findViewById(R.id.lb_three);
		lbOwnerCode = (TextView) findViewById(R.id.lb_four);
		lbAccount.setText("资金账号");
		lbLimit.setText("申购额度");
		lbDept.setText("交易所");
		lbOwnerCode.setText("股东代码");

		listView = (ListView) findViewById(R.id.listView_four);
		adapter = new FourItemInfoAdapter(this, items);
		listView.setAdapter(adapter);
	}
}
