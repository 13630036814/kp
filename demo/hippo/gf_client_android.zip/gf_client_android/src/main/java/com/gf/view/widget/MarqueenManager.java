/**
 * 
 */
package com.gf.view.widget;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.View;

/**
 * @author mrcola
 * 
 */
public abstract class MarqueenManager implements Marquee {
	protected List<MarqueeTextView> marqueen = new ArrayList<MarqueeTextView>();
	protected Context context;

	public MarqueenManager(Context context) {
		this.context = context;
	}

	@Override
	public void clean() {
		// TODO Auto-generated method stub
		marqueen.clear();
	}

	@Override
	public void update(MarqueeInfo info, View v) {
		// TODO Auto-generated method stub

	}

	protected View getMarqueeTextView(){
		return new MarqueeTextView(context);
	}
	
	protected void addMarqueeTextView(MarqueeTextView mtv){
		marqueen.add(mtv);
	}
	public abstract View getChildAt(int n);
	public abstract View removeChildAt(int n);
	public abstract View removeChildAt(View n);
}
