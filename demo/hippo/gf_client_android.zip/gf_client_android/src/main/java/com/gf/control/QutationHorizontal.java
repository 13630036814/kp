/**
 * 
 */
package com.gf.control;

import java.util.ArrayList;
import java.util.List;

import com.gf.client.R;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.quote.CandleQuoteStream;
import com.gf.hippo.domain.client.quote.CandleQuoteStreamItem;
import com.gf.hippo.domain.client.quote.PeriodType;
import com.gf.hippo.domain.client.quote.RealtimeQuoteItem;
import com.gf.hippo.domain.client.quote.TickQuoteStream;
import com.gf.hippo.domain.client.quote.TickQuoteStreamItem;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStream;
import com.gf.hippo.domain.client.quote.TimeSeriesQuoteStreamItem;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.view.KTechChart;
import com.gf.view.KlineView;
import com.gf.view.QuotationData;
import com.gf.view.QuotationFiveRange;
import com.gf.view.QuotationLandscapeTop;
import com.gf.view.StockInfoTarget;
import com.gf.view.TimeSharingDetailView;
import com.gf.view.adapter.VolumeAdapter;
import com.gf.view.widget.Navigation;
import com.gf.view.widget.NavigationFragment;
import com.gf.view.widget.NavigationVerticalFragment;
import com.gf.view.widget.NavigationVerticalFragment.onSelectorNavigationListener;
import com.gf.viewmodel.base.Global;
import com.gf.viewmodel.bean.DataSetKLine;
import com.gf.viewmodel.bean.TimeSeriesQuoteCache;
import com.gf.viewmodel.bean.VolumeItem;

import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 黄屏下的分时和 k 线图
 * @author Cola
 *
 */
public class QutationHorizontal extends DomainWindow implements OnClickListener,onSelectorNavigationListener{
	private QuotationData mQuotationDataView;
	private StockInfoTarget mStockInfoTarget;
	private TimeSharingDetailView mTimeSharingDetailView;
	private QuotationFiveRange mTimeSharing_fiverange;
	private QuotationLandscapeTop mQuotationLandscapeTop;
	
	private LinearLayout mTimeSharing_container,line_container;
	private TextView mFiveK,mTimeShare,mFiveTimeshare,mDayk,mWeekk,m5Mink,m30Mink,m60Mink,mMonk,mFiveRang,mVolume;
	
	private List<Navigation> navs = buildNavigation();
	private NavigationVerticalFragment mNavigationFragment;
	private TimeSeriesQuoteCache mTimeSeriesQuoteData;
	private DataSetKLine mDataSetKLineData;
	/**
	 * 记录前一次按钮
	 */
	private int pressBtn = 1;
	
	private ListView listViewVolume;
	private List<TickQuoteStreamItem> volumList;
	private VolumeAdapter volumeAdapter;
	private LinearLayout mTopRefresh,mShareTimeRight;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.quotation_horizontalscreen);
		init();
	}
	
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (mDayk.equals(v)) {
			
			mTimeSharing_container.getChildAt(0).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(1).setVisibility(View.VISIBLE);
			setCandlesTickQuoteListener(stock,PeriodType.KX_DAY);
			mDayk.setBackgroundResource(R.drawable.btn_bg);
//			mTimeShare.setBackgroundResource(0);
			setVisible(pressBtn);
			pressBtn = 3;
			this.showDialog(true);
		} else if (this.mWeekk.equals(v)) {
			
			mTimeSharing_container.getChildAt(0).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(1).setVisibility(View.VISIBLE);
			setCandlesTickQuoteListener(stock,PeriodType.KX_WEEK);
			this.mWeekk.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 4;
			this.showDialog(true);
		}else if (this.mMonk.equals(v)) {
			setCandlesTickQuoteListener(stock,PeriodType.KX_MONTH);
			mTimeSharing_container.getChildAt(0).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(1).setVisibility(View.VISIBLE);
			this.mMonk.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 5;
			this.showDialog(true);
		}else if (this.mTimeShare.equals(v)) {
			this.setTimeSeriesQuote(this.mStockMarket, mStockCode, 241);
			setVisible(pressBtn);
			pressBtn = 1;
			mTimeSharing_container.getChildAt(1).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(0).setVisibility(View.VISIBLE);
			mTimeShare.setBackgroundResource(R.drawable.btn_bg);
			mShareTimeRight.setVisibility(View.VISIBLE);
		}else if (this.mVolume.equals(v)) {
			listViewVolume.setVisibility(View.VISIBLE);
			mTimeSharing_fiverange.setVisibility(View.GONE);
			mVolume.setTextColor(this.getResources().getColor(R.color.navigation_line));
			mFiveRang.setTextColor(this.getResources().getColor(R.color.gray_font));
		}else if (this.mFiveRang.equals(v)) {
			listViewVolume.setVisibility(View.GONE);
			mTimeSharing_fiverange.setVisibility(View.VISIBLE);
			mVolume.setTextColor(this.getResources().getColor(R.color.gray_font));
			mFiveRang.setTextColor(this.getResources().getColor(R.color.navigation_line));
		}else if (this.mTopRefresh.equals(v)) {
			this.endWatchEveryStock();
			
			Log.e("mTopRefresh","mTopRefresh");
			this.setMyStockListener();
			setUserStockListener();
			
			this.setTickQuote(stock);
			this.showDialog(true);
		}else if (this.m5Mink.equals(v)) {
			setCandlesTickQuoteListener(stock,PeriodType.KX_5MIN);
			mTimeSharing_container.getChildAt(0).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(1).setVisibility(View.VISIBLE);
			this.m5Mink.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 6;
			this.dismissDialog();
			this.showDialog(true);
		}else if (this.m30Mink.equals(v)) {
			setCandlesTickQuoteListener(stock,PeriodType.KX_30MIN);
			mTimeSharing_container.getChildAt(0).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(1).setVisibility(View.VISIBLE);
			this.m30Mink.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 7;
			this.showDialog(true);
		}else if (this.m60Mink.equals(v)) {
			setCandlesTickQuoteListener(stock,PeriodType.KX_60MIN);
			mTimeSharing_container.getChildAt(0).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(1).setVisibility(View.VISIBLE);
			this.m60Mink.setBackgroundResource(R.drawable.btn_bg);
			setVisible(pressBtn);
			pressBtn = 8;
			this.showDialog(true);
		}else if (this.mFiveTimeshare.equals(v)) {
			this.setTimeSeriesQuote(this.mStockMarket, mStockCode, 241 * 5);
			setVisible(pressBtn);
			pressBtn = 9;
			mTimeSharing_container.getChildAt(1).setVisibility(View.GONE);
			mTimeSharing_container.getChildAt(0).setVisibility(View.VISIBLE);
			mFiveTimeshare.setBackgroundResource(R.drawable.btn_bg);
			mShareTimeRight.setVisibility(View.GONE);
			this.showDialog(true);
		}
	}

	@Override
	public void onEvent(Event event) {
		// TODO Auto-generated method stub
//		String time = "";
		Log.v(TAG,"onEvent");
		if (event.getObject() instanceof RealtimeQuoteItem) {
			// 某只股票行情有更新
			quote = (RealtimeQuoteItem) event.getObject();
//			Log.e(TAG, "mHandlerRealtimeQuoteItem get time series quote item:"
//					+ quote.getTime());
//			mQuotationDataView.setData(quote);
//			mStockInfoTarget.setData(quote);
			mQuotationLandscapeTop.setData(quote);
			mTimeSharing_fiverange.setData(quote);
		} else if (event.getObject() instanceof Stock) {
			// 某只股票属性有更新
			Stock stock = (Stock) event.getObject();
			
		} else if (event.getObject() instanceof StockList) {
			// 自选股票列表有更新
			// 结束旧自选股的监听
			endWatchEveryStock();
		}else if (event.getObject() instanceof TimeSeriesQuoteStream) {//分词数据

			TimeSeriesQuoteStream quote = (TimeSeriesQuoteStream) event.getObject();
			TimeSeriesQuoteStreamItem[] items = null;
			if(pressBtn == 9)
			// 更新UI数据
			items = quote.getAllItems();
			else if(pressBtn == 1)
				items = quote.getItemsOfLastDate();
			else
				return;
			mTimeSeriesQuoteData = reconsitution(items,mStockMarket,mStockCode);
			mTimeSharingDetailView.setDataSet(mTimeSeriesQuoteData);
			
		}else if (event.getObject() instanceof CandleQuoteStream) {//k 线
			CandleQuoteStream quote = (CandleQuoteStream) event.getObject();
			// 更新UI数据
			CandleQuoteStreamItem[] items = quote.getAllItems();
			KlineView kv = (KlineView)line_container.getChildAt(0);
//			Log.e("k线长度 ", items.length + "");
			mDataSetKLineData = reconsitution(items,mStockMarket,mStockCode);
			kv.setDataSet(mDataSetKLineData);
			
		}else if (event.getObject() instanceof TickQuoteStream) {//成交明细
			TickQuoteStream quote = (TickQuoteStream) event.getObject();
			
//			for (TickQuoteStreamItem item : quote.getAllItems()) {
////				System.out.println(" + );
//				Log.e("get TickQuoteStreamItem, time:", item.getTime()+"");
//			}
			copy(quote.getAllItems());
			volumeAdapter.notifyDataSetChanged();

		}
		this.dismissDialog();
//		Toast.makeText(this, "更新时间：", Toast.LENGTH_LONG);
	}

	private void copy(TickQuoteStreamItem mTickQuoteStreamItem[]){
		volumList.clear();
		int len = mTickQuoteStreamItem.length;
		int i = 0;
		for(int n = len - 1; n > 0; n--){
			if(i >= 20) break;
			volumList.add(mTickQuoteStreamItem[n]);
			i++;
		}
	}
	
	@Override
	public void init() {
		// TODO Auto-generated method stub
		volumList = new ArrayList<TickQuoteStreamItem>();
		volumeAdapter = new VolumeAdapter(this,volumList);
		
		mDayk = (TextView) findViewById(R.id.dayk);
		this.mWeekk = (TextView) findViewById(R.id.weekk);
		this.mMonk = (TextView) findViewById(R.id.monk);
		mFiveRang  = (TextView) findViewById(R.id.quotation_fiver);
		this.mVolume  = (TextView) findViewById(R.id.qutotation_volume);
		mFiveTimeshare =  (TextView) findViewById(R.id.lots_timeshare);
		
		m5Mink  = (TextView) findViewById(R.id.quotation_5mink);
		m30Mink  = (TextView) findViewById(R.id.quotation_30mink);
		m60Mink  = (TextView) findViewById(R.id.quotation_60mink);
		mFiveK  = (TextView) findViewById(R.id.fivek);
		mTimeShare  = (TextView) findViewById(R.id.timeshare);
		mTimeSharing_fiverange = (QuotationFiveRange) findViewById(R.id.quotation_fiverange);
		mStockInfoTarget = (StockInfoTarget) findViewById(R.id.quotation_stocktarget);
		mTimeSharingDetailView = (TimeSharingDetailView) findViewById(R.id.TimeSharing);
		mTimeSharing_container = (LinearLayout) findViewById(R.id.line_container);
		line_container = (LinearLayout) findViewById(R.id.kline_container);
		mShareTimeRight = (LinearLayout) findViewById(R.id.timeshare_right);
//		mQuotationDataView = (QuotationData) findViewById(R.id.qutation_quotationDataView);
		mQuotationLandscapeTop = (QuotationLandscapeTop) findViewById(R.id.qutation_top);
		mTopRefresh = (LinearLayout) findViewById(R.id.top_refresh);
		listViewVolume = (ListView) findViewById(R.id.volume_listview);
		listViewVolume.setAdapter(volumeAdapter);
		setListener();
		
		if(this.getIntent().getExtras() != null){
			this.mStockCode = getIntent().getExtras().getString("stockCode");
			this.mStockMarket = getIntent().getExtras().getString("stockMarket");
			String name = getIntent().getExtras().getString("stockName");

			stock = mStockManager.getStock(mStockMarket, mStockCode);
			Log.e("stock",stock.getStock_code());
			mStockList.putItem(stock);
			this.setMyStockListener();
			setTimeSeriesQuote(mStockMarket,mStockCode,241);
			setUserStockListener();
			this.showDialog(true);
			this.setTickQuote(stock);
			mQuotationLandscapeTop.setStockName(name);
		}
		
		mNavigationFragment = (NavigationVerticalFragment) getSupportFragmentManager()
				.findFragmentById(R.id.fragment_navigation);
		mNavigationFragment.setNavs(navs);
		mNavigationFragment.setOnSelectorNavigationListener(this);
		mTimeSharingDetailView.setRiseShow(true);
	}

	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		((LinearLayout) findViewById(R.id.top_back))
		.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}

		});
		mTimeShare.setOnClickListener(this);
		mDayk.setOnClickListener(this);
		this.mWeekk.setOnClickListener(this);
		this.mMonk.setOnClickListener(this);
		mVolume.setOnClickListener(this);
		this.mFiveRang.setOnClickListener(this);
		mTopRefresh.setOnClickListener(this);
		m60Mink.setOnClickListener(this);
		this.m30Mink.setOnClickListener(this);
		this.m5Mink.setOnClickListener(this);
		mFiveTimeshare.setOnClickListener(this);
	}

	private void setVisible(int p){
		switch(p){
		case 1:
			mTimeShare.setBackgroundResource(0);
			break;
		case 2:
			mFiveK.setBackgroundResource(0);
			break;
		case 3:
			this.mDayk.setBackgroundResource(0);
			break;
		case 4:
			this.mWeekk.setBackgroundResource(0);
			break;
		case 5:
			this.mMonk.setBackgroundResource(0);
			break;
		case 6:
			this.m5Mink.setBackgroundResource(0);
			break;
		case 7:
			this.m30Mink.setBackgroundResource(0);
			break;
		case 8:
			this.m60Mink.setBackgroundResource(0);
			break;
		case 9:
			this.mFiveTimeshare.setBackgroundResource(0);
			break;
		}
	}
	
	private List<Navigation> buildNavigation() {
		List<Navigation> navigations = new ArrayList<Navigation>();
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "成交量"));
		navigations.add(new Navigation(Navigation.TYPE_1, "url", "KDJ"));
		navigations.add(new Navigation(Navigation.TYPE_2, "url", "BOLL"));
		navigations.add(new Navigation(Navigation.TYPE_4, "url", "MACD"));
		navigations.add(new Navigation(Navigation.TYPE_5, "url", "RSI"));
		navigations.add(new Navigation(Navigation.TYPE_0, "url", "OBV"));
//		navigations.add(new Navigation(Navigation.TYPE_3, "url", "DMI"));
		return navigations;
	}

	@Override
	public void selector(Navigation navigation, int position) {
		// TODO Auto-generated method stub
		KlineView kv = (KlineView)line_container.getChildAt(0);
		switch(position){
		case 0:
			kv.setTechType(KTechChart.TECH_VOLUME);
			break;
		case 1:
			kv.setTechType(KTechChart.TECH_KDJ);
			break;
		case 2:
			kv.setTechType(KTechChart.TECH_BOLL);
			break;
		case 3:
			kv.setTechType(KTechChart.TECH_MACD);
			break;
		case 4:
			kv.setTechType(KTechChart.TECH_RSI);
			break;
		case 5:
			kv.setTechType(KTechChart.TECH_OBV);
			break;
//		case 6:
//			kv.setTechType(KTechChart.TECH_DMI);
//			break;
		}
	}

	@Override
	public void netStatus(boolean status) {
		// TODO Auto-generated method stub
		
	}
}
