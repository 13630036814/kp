/**
 * 
 */
package com.gf.control;



import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gf.client.R;
import com.gf.data.sqlite.GfClientSqliteOpenHelper;
import com.gf.hippo.domain.client.common.Event;
import com.gf.hippo.domain.client.common.EventHandler;
import com.gf.hippo.domain.client.common.EventObject;
import com.gf.hippo.domain.client.securities.CodeList;
import com.gf.hippo.domain.client.securities.SimpleStockManager;
import com.gf.hippo.domain.client.securities.SimpleUserStockManager;
import com.gf.hippo.domain.client.securities.Stock;
import com.gf.hippo.domain.client.securities.StockList;
import com.gf.hippo.domain.client.securities.StockManager;
import com.gf.view.MainPopMenu;
import com.gf.view.adapter.CodeLineAdapter;
import com.gf.view.adapter.CodeLineAdapter.StockAction;
import com.gf.view.anim.UgcAnimations;
import com.gf.view.widget.StockInput;
import com.gf.viewmodel.base.GfClientSqliteProvider;
import com.gf.viewmodel.base.GlobalMsg;
import com.gf.viewmodel.bean.MessageInfo;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;

/**
 * 
 * @author cola
 * 
 */
public class CodeLine extends BaseWindow implements StockAction{
	private final String TAG = "CodeLine";
	private LinearLayout mBack;
	private Button mCancel,mBackBtn;
	private ListView mCodeLineListView;
	private TextView mHeaderView;
	private List<MessageInfo> messages,historys;
	private MainPopMenu menu;
	private CodeLineAdapter mCodeLineAdapter,mHistorysCodeLineAdapter;
	private RelativeLayout mPopMenu;
	private StockInput mInput;
	/**
	 */
	private boolean mHistory = true;
	private LinearLayout mFootLine;
	private DoHandler mHandler = new DoHandler(this);
	
	private CodeList mCodeList = null;
	
	EventHandler realtimeHandler;
	private Stock[] mStocks;
	
	StockList mStockList = null;
	
	private CodeList codelist = null;
	
	GlobalMsg mGlobal = GlobalMsg.getInstance();
	
	private boolean mOnKeyDown = false;
	private boolean mLastSearchResultBack = true;
	private String mInputContent;
	
	private long mLastSearchTime;	
	private boolean mMustRun = false;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.v(TAG, "onCreate");
		setContentView(R.layout.codeline);
		init();
		setListener();
	}

	public void init() {
		setUserStockListener();
		Log.v(TAG, "init begin");
		messages = new ArrayList<MessageInfo>();
		((LinearLayout) findViewById(R.id.top_serch)).setVisibility(View.INVISIBLE);
		((TextView) findViewById(R.id.title)).setText("股票查询");
		mBack = (LinearLayout) findViewById(R.id.top_back);
		mBackBtn = (Button) findViewById(R.id.top_back_btn);
		mCancel = (Button) findViewById(R.id.code_line_cancel);
		mCodeLineListView = (ListView) findViewById(R.id.code_line_listview);
		mInput = (StockInput) findViewById(R.id.code_input);
		mInput.updateInputView();
		
		history();
	}

	public void setListener() {
		mBack.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}

		});
		
		mBackBtn.setBackgroundResource(R.drawable.back);
		
//		final int len = messages.size();
		mCodeLineListView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int pos,
					long arg3) {
				// TODO Auto-generated method stub

				if (pos == 0 && mHistory) {

				} else if (pos == 0 && !mHistory) {
					MessageInfo msg = messages.get(pos);
					insert(msg);
					startActivity(new Intent(CodeLine.this,
							QuotationActivity.class));
				} else if (mHistory && pos == historys.size() + 1) {
					
					getContentResolver().delete(Uri.parse(
							GfClientSqliteProvider.URI_CODELINE_SEARCH), null, null);
					historys.clear();
					remove();
					mHistorysCodeLineAdapter.notifyDataSetChanged();
					// mCodeLineListView.setAdapter(null);
				} else {
					MessageInfo msg = null;
					if (!mHistory) {
						msg = messages.get(pos);
						insert(msg);
//						addToMyStock(msg.getGroupName(), msg.getInfo());
					}else{
						msg = historys.get(pos - 1);
					}
					
					Intent it = new Intent(CodeLine.this,QuotationActivity.class);
					Bundle b = new Bundle();
					b.putString("stockCode", msg.getInfo());
					b.putString("stockMarket", msg.mField4);
					b.putString("stockName", msg.getGroupName());
					it.putExtras(b);
					CodeLine.this.startActivityForResult(it,1);
				}
			}

		});
		
		mInput.addTextChangedListener(new TextWatcher(){

			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				
				if(s.toString().length() > 0 && mCancel.getVisibility() == View.INVISIBLE){
					if(mCodeLineListView.getHeaderViewsCount() > 0)
						remove();
					
					mCancel.setAnimation(UgcAnimations.horizontalMove(200, mCancel));
					mCancel.setVisibility(View.VISIBLE);
					mHistory = false;
					mCodeLineAdapter.setStockAction(CodeLine.this);
					mCodeLineListView.setAdapter(mCodeLineAdapter);
				}else if(s.toString().length() == 0){
					mCancel.clearAnimation();
					mCancel.setVisibility(View.INVISIBLE);
					if(mCodeLineListView.getHeaderViewsCount() == 0 && historys.size() > 0){//显示被删除的 头与尾项
						mCodeLineListView.setAdapter(null);
						addHead();
						addFoot();
					}
					mHistorysCodeLineAdapter.setStockAction(CodeLine.this);
					mCodeLineListView.setAdapter(mHistorysCodeLineAdapter);
					mHistory = true;
				}
				
				mOnKeyDown = true;
				mMustRun = false;
				mLastSearchTime = System.currentTimeMillis();
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				if(s.length() > 0){
					mInputContent = s.toString();
					GetCodeListQuote(mInputContent);
					mCodeLineAdapter.setColorString(s.toString());
				}
			}
			
		});
		
		mCancel.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mInput.setText("");
				mCancel.clearAnimation();
				mCancel.setVisibility(View.INVISIBLE);
				if(mCodeLineListView.getHeaderViewsCount() == 0 && historys.size() > 0){//显示被删除的 头与尾项
					mCodeLineListView.setAdapter(null);
					addHead();
					addFoot();
				}
			}
			
		});
		
		mCodeLineListView.setOnScrollListener(new OnScrollListener(){

			@Override
			public void onScroll(AbsListView view, int firstVisibleItem,
					int visibleItemCount, int totalItemCount) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void onScrollStateChanged(AbsListView view, int scrollState) {
				// TODO Auto-generated method stub
				mInput.closeWindow();
			}
		});
	}

	private void remove(){
		mCodeLineListView.removeFooterView(mFootLine);
		mCodeLineListView.removeHeaderView(mHeaderView);
	}
	
	private void addHead() {
		mHeaderView = new TextView(this);
		mHeaderView.setText("以下为历史查询：");
		mHeaderView.setHeight(54);
		mHeaderView.setTextSize(16);
		// mHeaderView.setLayoutParams(params);
		mHeaderView.setGravity(Gravity.CENTER_VERTICAL);
		mCodeLineListView.addHeaderView(mHeaderView);
	}

	private void addFoot() {
		mFootLine = new LinearLayout(this);
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT, 60);
		layoutParams.setMargins(10, 0, 0, 0);
		TextView mFootView = new TextView(this);
		mFootView.setText("清除搜索历史记录");
		mFootView.setHeight(54);
		mFootView.setTextSize(16);
		mFootView.setCompoundDrawablesWithIntrinsicBounds(this.getResources()
				.getDrawable(R.drawable.history), null, null, null);
		mFootView.setCompoundDrawablePadding(5);
		// mHeaderView.setLayoutParams(params);
		mFootView.setGravity(Gravity.CENTER);
		mFootLine.setGravity(Gravity.CENTER);
		mFootLine.addView(mFootView);
		mCodeLineListView.addFooterView(mFootLine);
	}
	
	private void history(){
		historys = (List<MessageInfo>) query(GfClientSqliteOpenHelper.TABLE_WBW_INFO, GfClientSqliteProvider.URI_CODELINE_SEARCH);
		mCodeLineAdapter = new CodeLineAdapter(this, messages);
		mHistorysCodeLineAdapter = new CodeLineAdapter(this, historys);
		if(historys.size() <= 0){
			mHistory = false;
			mCodeLineAdapter.setStockAction(this);
		}else{
			mHistory = true;
			
			addHead();
			addFoot();
			mHistorysCodeLineAdapter.setStockAction(this);
			mCodeLineListView.setAdapter(mHistorysCodeLineAdapter);
		}
	}
	
	public synchronized Object query(String table, String uri) {
		ArrayList<MessageInfo> messages = new ArrayList<MessageInfo>();

		Cursor cursor = getContentResolver().query(Uri.parse(uri),
				new String[] { "Field", "value", "status" ,"name"}, null, null, null);
		int count = cursor.getCount();
		if (count > 0) {

			while (cursor.moveToNext()) {
				MessageInfo msg = new MessageInfo();
				msg.setInfo(cursor.getString(0));
				msg.mField1 = "";
				msg.mField3 = cursor.getString(2);;//cursor.getInt(1) + "";
				msg.mField4 = cursor.getString(1);
				msg.setGroupName(cursor.getString(3));
				messages.add(msg);
			}
		}
		cursor.close();
		return messages;
	}
	
	static class DoHandler extends Handler {
		WeakReference<CodeLine> mSearchstockwindow;

		DoHandler(CodeLine searchstockwindow) {
			mSearchstockwindow = new WeakReference<CodeLine>(searchstockwindow);
		}

		public void handleMessage(Message msg) {
			switch (msg.what) {
			case BaseApplication.MSG_SEARCH_UPDATE:
				CodeLine searchstockwindow = mSearchstockwindow.get();
				mSearchstockwindow.get().copy();
				mSearchstockwindow.get().mCodeLineAdapter.setSelectStatus();
				mSearchstockwindow.get().mCodeLineAdapter.notifyDataSetChanged();
				//setAdapter(mSearchstockwindow.get().mCodeLineAdapter);
				break;
			}
		}
	};	
	
	/**
	 * 将 stockinfo 信息转换成 messageinfo
	 */
	public void copy(){
		messages.clear();
		if(mCodeList == null){
			return;
		}
		
		Stock stock[] = mCodeList.getItems().getAllItems();
		
		for (Stock s : stock) {
			MessageInfo msg = new MessageInfo();
			msg.setGroupName(s.getStock_name()); // 名称
			msg.setInfo(s.getStock_code()); // 股票代码
			msg.mField1 = "";
			msg.mField2 = "";
			msg.mField3 = getAddFlag(s.getStock_code(), s.getMarket()); // 最后位置的显示状态
			msg.mField4 = s.getMarket() + "";// 代表市场
			msg.shortPy = s.getPinyin();
			messages.add(msg);
			
			if(messages.size() == 50) {
				break;
			}
		}
		
	}
	
	/**
	 * 0 已经添加
	 * 1 没有添加
	 * @param code
	 * @param market
	 * @return
	 */
	private String getAddFlag(String code, String market) {
		SimpleUserStockManager mSimpleUserStockManager = mQuoteManagerFactory.getUserStockManager(); 
		StockList stockList = mSimpleUserStockManager.getUserStocks();

		Stock stocks[] = stockList.getAllItems();
		for (int i = 0; i < stocks.length; i++) {
			Stock stock = stocks[i];
			if (stock.getMarket().equals(market) && stock.getStock_code().equals(code)) {
				//Log.v(TAG, "find it in userStockList");
				return "" + 1;
			}
		}
		//Log.v(TAG, "not find it in userStockList");
		return "" + 0;
	}
		
	private void insert(MessageInfo msg) {
		ContentValues value = new ContentValues();
		value.put("Field", msg.getInfo());
		value.put("value", msg.mField4);
		value.put("status", msg.mField3);
		value.put("name", msg.getGroupName());

		if (sqlCompare(msg.getGroupName())) {
			getContentResolver().insert(Uri.parse(GfClientSqliteProvider.URI_CODELINE_SEARCH), value);
			historys.add(msg);// 加入历史
		}
	}
   
	/**
	 * @param word 股票名称
	 * @return
	 */
	private boolean sqlCompare(String word){
		for(MessageInfo m : historys){
			if(m.getGroupName().equals(word))
				return false;
		}
		return true;
	}
	
	public void onConfigurationChanged(Configuration config) {
		super.onConfigurationChanged(config);
		mInput.handleClose();
		mInput.updateInputView();
		mInput.handleClose();
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch (keyCode) {
		case KeyEvent.KEYCODE_BACK:
			if (mInput.isShowWindow()) {
				mInput.closeWindow();
			} else {
				finish();
			}
			break;
		}
		return false;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		setResult(resultCode);
		finish();
	}
	
	/**
	 * @param market
	 * @param code
	 */
//	public void addToMyStock(String market, String code) {
//		Stock stock = mStockManager.getStock(market, code);
//		//mGlobal.mStocksNeedToAdd.add(stock);
//		
//		// 添加到数据库
//		mUserStockManager.addUserStock(stock);
//	}

	/**
	 * @param codeOrPinYin
	 */
	private void GetCodeListQuote(String codeOrPinYin) {
		
		long now = System.currentTimeMillis();
		if (!mLastSearchResultBack || (now - mLastSearchTime < 2000 && !mMustRun)) {
			return;
		}
		
		mLastSearchResultBack = false;
		mOnKeyDown = false;
		StockManager stockManager = mQuoteManagerFactory.getStockManager();
		// 使用
		codelist = stockManager.getCodeList(codeOrPinYin);
		EventHandler handler = new EventHandler() {
			@Override
			public void onEvent(Event event) {
				mCodeList = (CodeList) event.getObject();
				// 更新UI数据
				Stock[] stocks = mCodeList.getItems().getAllItems();
				Log.v(TAG, "new stock len: " + stocks.length);
				
				Message msg = Message.obtain();
				msg.what = BaseApplication.MSG_SEARCH_UPDATE;
				mHandler.sendMessage(msg);
				mLastSearchResultBack = true;
				
				if (mOnKeyDown) {
					mMustRun = true;
					GetCodeListQuote(mInputContent);
				}
			}
		};
		EventObject eventObject = new EventObject();
		eventObject.setEventHandler(handler);
		stockManager.beginWatch(codelist, eventObject);
		Log.v(TAG, "GetCodeListQuote");
	}

	@Override
	public void add(int pos) {
		MessageInfo msg;
		if(mHistory)
			msg = historys.get(pos);
		else
		msg = messages.get(pos);
		
		addToMyStock(msg.mField4, msg.getInfo());
		Toast.makeText(CodeLine.this, msg.getGroupName() + "添加成功", Toast.LENGTH_LONG).show();//这是交互设计的添加后的提示，别删除，请跟ui的要交互的设计图
	}

	@Override
	public void del(int pos) {
		MessageInfo msg;
		if(mHistory)
			msg = historys.get(pos);
		else
		msg = messages.get(pos);
		
		String market = msg.mField4;
		String code = msg.getInfo();
		
		Stock stock = mStockManager.getStock(market, code);
		mUserStockManager.removeUserStock(stock);
		
		/*ArrayList<Stock> stocksNeedToAdd = GlobalMsg.getInstance().mStocksNeedToAdd;
		for(int i = 0; i < stocksNeedToAdd.size(); i++) {
			Stock stock = stocksNeedToAdd.get(i);
			if (stock.getMarket().equals(market) && stock.getStock_code().equals(code)) {
				stocksNeedToAdd.remove(i);
			}
		}*/
		
	}

	@Override
	public void onEvent(Event event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void netStatus(boolean status) {
		// TODO Auto-generated method stub
		
	}
}
