/**
 * 
 */
package com.gf.view;

import com.gf.client.R;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * 列头排序上下图标的头
 * 
 * @author Cola
 * 
 */
public class ListSortHeader extends LinearLayout {
	/**
	 * 涨跌幅
	 */
	public static final int SORTHEADER_RANGE = 0x0;
	/**
	 * 涨跌值
	 */
	public static final int SORTHEADER_RISE = 0x1;
	/**
	 * 现价
	 */
	public static final int SORTHEADER_PRICE = 0x2;
	private ImageView mRang_arrows, mPrice_arrows, mRise_arrows;
	private int prePrice = 1, preRise = 1, preRange = 1;

	public ListSortHeader(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	private Context context;

	public ListSortHeader(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
		setListener();
	}

	public void init() {
		LayoutInflater.from(context).inflate(R.layout.listview_header, this);
		mRang_arrows = ((ImageView) findViewById(R.id.rang_arrows));
		mPrice_arrows = ((ImageView) findViewById(R.id.price_arrows));
		mRise_arrows = ((ImageView) findViewById(R.id.rise_arrows));
	}

	private void setListener() {
		((RelativeLayout) findViewById(R.id.stockRang))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						// mAdapter.sort(preRange,0);
						if (preRange == 1) {
							preRange = 2;

							mRang_arrows
									.setBackgroundResource(R.drawable.arrows_up);
						} else {

							mRang_arrows
									.setBackgroundResource(R.drawable.arrows_down);
							preRange = 1;
						}

						if (mOnSortListener != null)
							mOnSortListener.sort(arg0, preRange,
									ListSortHeader.SORTHEADER_RANGE);

						mRang_arrows.setVisibility(View.VISIBLE);
						mPrice_arrows.setVisibility(View.GONE);
						mRise_arrows.setVisibility(View.GONE);
					}

				});

		((RelativeLayout) findViewById(R.id.stock_price))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						// mAdapter.sort(prePrice,2);
						if (prePrice == 1){
							prePrice = 2;
							mPrice_arrows
							.setBackgroundResource(R.drawable.arrows_up);
						}
						else{
							prePrice = 1;
							mPrice_arrows
							.setBackgroundResource(R.drawable.arrows_down);
						}

						if (mOnSortListener != null)
							mOnSortListener.sort(arg0, prePrice,
									ListSortHeader.SORTHEADER_PRICE);

						mRang_arrows.setVisibility(View.GONE);
						mPrice_arrows.setVisibility(View.VISIBLE);
						mRise_arrows.setVisibility(View.GONE);
					}

				});

		((RelativeLayout) findViewById(R.id.stock_rise))
				.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						// TODO Auto-generated method stub
						// mAdapter.sort(preRise,1);
						if (preRise == 1){
							preRise = 2;
							mRise_arrows
							.setBackgroundResource(R.drawable.arrows_up);
						}
						else{
							preRise = 1;
							mRise_arrows
							.setBackgroundResource(R.drawable.arrows_down);
						}

						if (mOnSortListener != null)
							mOnSortListener.sort(arg0, preRise,
									ListSortHeader.SORTHEADER_RISE);

						mRang_arrows.setVisibility(View.GONE);
						mPrice_arrows.setVisibility(View.GONE);
						mRise_arrows.setVisibility(View.VISIBLE);
					}

				});
	}

	private OnSortListener mOnSortListener;

	public void setOnSortListener(OnSortListener mOnSortListener) {
		this.mOnSortListener = mOnSortListener;
	}

	public interface OnSortListener {
		public void sort(View v, int sort, int sortField);
	}
}
