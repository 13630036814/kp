package com.gf.control.trade.query;

import com.gf.control.BaseWindow;
import com.gf.hippo.domain.client.common.Event;

public class PositionDetailActivity extends BaseWindow {

	@Override
	public void onEvent(Event event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setListener() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void netStatus(boolean status) {
		// TODO Auto-generated method stub
		
	}

}
