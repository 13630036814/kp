/**
 * 
 */
package com.gf.control;

import com.gf.view.widget.Events;
import com.gf.viewmodel.base.LauncherModel;
import com.gf.viewmodel.quote.components.QuoteManagerFactory;
import com.gf.viewmodel.quote.components.QuoteNetworkProvider;

import android.app.Application;
import android.util.Log;

/**
 * @author mrcola
 * 
 */
public class BaseApplication extends Application {
    //MESSAGE
	public static final int MSG = Events.EVENT_MAX + 10;	
	public static final int MSG_SEARCH_UPDATE = MSG + 7;
	private static final String TAG = "BaseApplication";
	private MainActivity mMainActivity = null;
	
	private QuoteNetworkProvider mNetwork = null;
	private QuoteManagerFactory mQuoteManagerFactory = null;
	
	public LauncherModel mClientModel;
	public static final String APP_PACKAGE_NAME = "com.gf.client";
	
	public void onCreate() {
		super.onCreate();
		Log.v(TAG, "onCreate");
		init();
	}
	
	private void init() {
		mClientModel = LauncherModel.getInstance(BaseApplication.this);
	}
	
	public void setMainActivity(MainActivity mainActivity) {
		mMainActivity = mainActivity;
	}
	
	public MainActivity getMainActivity() {
		return mMainActivity;
	}
	
	public LauncherModel getClientModel() {
		return mClientModel;
	}
	
	public QuoteManagerFactory getQuoteManagerFactory() {
		return mQuoteManagerFactory;
	}
	
	public LauncherModel setLauncher(Launcher launcher) {
		mClientModel.setCallback(launcher);
		return mClientModel;
	}
	
	/**
	 * 必须通过Launcher调用
	 */
	public void initDomainModel() {
		mNetwork = new QuoteNetworkProvider(this);
		mQuoteManagerFactory = QuoteManagerFactory.getInstance(mNetwork, this,	mClientModel.getHandler());
	}
	
}
