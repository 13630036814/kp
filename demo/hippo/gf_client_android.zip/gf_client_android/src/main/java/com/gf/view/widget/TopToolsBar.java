/**
 * 
 */
package com.gf.view.widget;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.control.CodeLine;
import com.gf.control.EditMyStock;

/**
 * 顶部工具栏
 * @author cola
 *
 */
public class TopToolsBar extends LinearLayout{
	private TextView tvTitle;
	private LinearLayout mSearchBtn;
	/**
	 * 跳转窗口代码
	 */
	private int mCode;
	
	public TopToolsBar(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	private Context context;
	public TopToolsBar(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.context = context;
		init();
	}

	public void setActivityCode(int code){
		this.mCode = code;
	}
	
	private void init(){
		LayoutInflater.from(context).inflate(R.layout.topmenu, this);
		tvTitle = (TextView) findViewById(R.id.title);
		mSearchBtn = (LinearLayout) findViewById(R.id.top_serch);
		
		mSearchBtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				((Activity) context).startActivityForResult(new Intent(context,
						CodeLine.class), 0);//
			}
			
		});
		
		((LinearLayout) findViewById(R.id.top_edit)).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				((Activity) context).startActivityForResult(new Intent(context,
						EditMyStock.class), 0);
			}

		});
	}
	
	public void setTitle(String title) {
		tvTitle.setText(title);
	}
}
