package com.gf.viewmodel.bean;

import android.util.Log;

/*
 * 证券代码链对象
 * 
 */
public class StockInfo 
{
	private int       m_iMarket=0;               //市场代码 1深圳 2上海 4场外
	private int       m_iType=0;                 //证券类别
	private String    m_strCode="";              //证券代码
	private String    m_strJP="";                //简拼
	private String    m_strName="";              //证券名称
	private boolean   mSelected;
	

	public StockInfo(){};
	
	public StockInfo(
			int    market,
			int    type,
			String code,
			String jp, 
			String name
			)
	{
		m_iMarket = market;
		m_iType = type;
		m_strCode = code;  
		m_strJP = jp; 
		m_strName = name;
	}
	
	public int GetMarket() 
	{
		return m_iMarket;
	}
	
	public int GetType() 
	{
		return m_iType;
	}
	
	public String GetCode()
	{
		if(m_iMarket == 4 && m_strCode.length() == 7)
		{
			return m_strCode.substring(1);
		}
		else
		{
			return m_strCode;
		}
	}
	
	/**
	 * 获取证券代码内码(场外特别处理 共7位 市场+代码,其他6位)
	 * 仅在维护代码链时使用
	 * @return
	 */
	public String GetInCode()
	{
		return m_strCode;
	}	
	
	public String GetJP()
	{
		return m_strJP;
	}
	
	public String GetName()
	{
		return m_strName;
	}
	
	public boolean isSelected(){
		return mSelected;
	}
	
	public void SetMarket(int market) 
	{
		m_iMarket = market;
	}
	
	public void SetType(int type) 
	{
		m_iType = type;
	}
	
	public void SetCode(String code)
	{
		m_strCode = code;
	}
	
	public void SetJP(String jp)
	{
		m_strJP = jp;
	}
	
	public void SetName(String name)
	{
		m_strName = name;
	}
	
	public void setSelected(boolean value){
		mSelected = value;
	}
}
