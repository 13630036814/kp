package com.gf.control;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.gf.client.R;
import com.gf.data.sqlite.GfClientSqliteOpenHelper;
import com.gf.viewmodel.bean.IconItem;
import com.gf.viewmodel.base.Global;

/**
 * 左侧栏
 * 
 * @author jin
 * 
 */
public class CustomPage {
	private static final String TAG = "CustomPage";
	
	private Context mContext;
	private View mCustomPageView;
	private GridView mGridview;
	private ImageButton mbtnAddIcon;
	private Button mbtnLoginOut; // 退出登陆
	
	private Resources mRes = null; 
	private List<Map<String, Object>> data = null;
	private CustomPageAdapter adapter = null;
	private GfClientSqliteOpenHelper mSqliteHelper = null;
	private static final int UPDATE_VIEW_MSG = 1;
	
	public static final String CUSTOM_PAGE_DATA_CHANGED = 
            "android.intent.action.custom_page.data_change"; 

	public CustomPage(Context context) {
		mContext = context;
		mCustomPageView = LayoutInflater.from(context).inflate(R.layout.custom_page, null);
		findViewById();
		init();
		setListener();
	}
	
	private void findViewById() {
		mGridview = (GridView) mCustomPageView.findViewById(R.id.gridview);// 得到GridView对象
		mbtnAddIcon = (ImageButton) mCustomPageView.findViewById(R.id.btn_add_icon);
		mbtnLoginOut = (Button)mCustomPageView.findViewById(R.id.btn_login_out);
	}

	private void init() {
		mSqliteHelper = GfClientSqliteOpenHelper.getInstance(mContext);
		
		mRes = mContext.getResources();
		update();
	    
	    IntentFilter themeFilter = new IntentFilter(CUSTOM_PAGE_DATA_CHANGED);
	    mContext.registerReceiver(mCustomPageDataChangeReceiver, themeFilter);
	    
	}
	
	/**
	 * 转换成adapter需要的信息
	 * @param iconItems
	 * @return
	 */
	private List<Map<String, Object>> getAdapterData(ArrayList<IconItem> iconItems) {
		List<Map<String, Object>> adapterData = new ArrayList<Map<String, Object>>();
		Map<String ,Object> map = null;
		
		for (int i = 0; i < iconItems.size(); i++) {
			IconItem iconItem = iconItems.get(i);
			
			map = new HashMap<String, Object>();
	    	map.put("iconTitle", iconItem.getTitle());
	    	
	    	String iconFileName = iconItem.getFileName();
	    	int id = mRes.getIdentifier(iconFileName, "drawable", BaseApplication.APP_PACKAGE_NAME);
	    	map.put("iconFileId", id);
	    	map.put("className", iconItem.getClassName());
	    	map.put("packageName", iconItem.getPackageName());
	    	adapterData.add(map);
		}
		
		return adapterData;
	}

	private void setListener() {
		OnClickListener onClickListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (v.equals(mbtnAddIcon)) {
					Intent newIntent = new Intent(mContext, CustomPageEdit.class);
					((MainActivity)mContext).startActivityForResult(newIntent, MainActivity.CUSTOM_PAGE_ACTIVITY_RESULT); 
				} else if (v.equals(mbtnLoginOut)) {
					((Activity) mContext).finish();
					saveData();
					Intent newIntent = new Intent(mContext, GfCommonLoginActivity.class);
					((MainActivity)mContext).startActivity(newIntent);
				}
			}
			
		};
		
		mbtnAddIcon.setOnClickListener(onClickListener);
		mbtnLoginOut.setOnClickListener(onClickListener);
	}
	
	public void saveData() {
		SharedPreferences sharePref = mContext.getSharedPreferences(Global.USER_PREF, Context.MODE_PRIVATE);
		Editor editor = sharePref.edit();
		editor.putString(Global.USER_NAME, null);
		editor.commit();
	}

	public View getView() {
		return mCustomPageView;
	}
	
	public void update() {
		Log.v(TAG, "update2");
		
		new Thread() {
			public void run() {
				ArrayList<IconItem> selectData = new ArrayList<IconItem>();
				SQLiteDatabase db = mSqliteHelper.openDatabase();
				
				Cursor cursor;
				String tableName = GfClientSqliteOpenHelper.TABLE_CUSTOM_PAGE;
				String[] columns = new String[] {
						"file_name",
						"title",
						"class_name",
						"package_name",
						"select_flag",
				};
				
				cursor = db.query(tableName, columns, null,	null, null, null, null);
				
				int fileName = cursor.getColumnIndex("file_name");
				int title = cursor.getColumnIndex("title");
				int className = cursor.getColumnIndex("class_name");
				int packageName = cursor.getColumnIndex("package_name");
				int selectFlag = cursor.getColumnIndex("select_flag");
				
				for (cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()) {
					IconItem iconItem = new IconItem();
					if ((cursor.getString(selectFlag).equals("0"))) {
						continue;
					}
					iconItem.setFileName(cursor.getString(fileName));
					iconItem.setTitle(cursor.getString(title));
					iconItem.setClassName(cursor.getString(className));
					iconItem.setPackageName(cursor.getString(packageName));
					iconItem.setSelectFlag(cursor.getString(selectFlag));
					selectData.add(iconItem);
			    }
				mSqliteHelper.closeDatabase();
				
				data = getAdapterData(selectData);
				
			    Message msg = mHandler.obtainMessage();
			    msg.what = UPDATE_VIEW_MSG;
			    mHandler.sendMessage(msg);
			}
		}.start();
	}
	
    BroadcastReceiver mCustomPageDataChangeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (CUSTOM_PAGE_DATA_CHANGED.equals(action)) {
            	update();
            }
        }
        
    };
    
	Handler mHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case UPDATE_VIEW_MSG:
				adapter = new CustomPageAdapter(mContext, data);
			    mGridview.setAdapter(adapter);
				adapter.notifyDataSetChanged();
				break;
			default:
				break;
			}
		}
	};
    
	/**
	 * 适配器
	 * @author Administrator
	 *
	 */
	class CustomPageAdapter extends BaseAdapter {
		private static final String TAG = "CustomPageAdapter";

		private Context mContext;// 上下文
		
		List<Map<String, Object>> mData = null;

		/* 构造函数 */
		public CustomPageAdapter(Context ct, List<Map<String, Object>> data) {
			mContext = ct;
			mData = data;
		}

		@Override
		public int getCount() {
			return mData.size();// 返回数组长度
		}

		@Override
		public Object getItem(int arg0) {
			return mData.get(arg0);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			LayoutInflater layoutInflater = LayoutInflater.from(mContext);// 导入布局
			View view = (View) layoutInflater.inflate(R.layout.custom_page_item, null);// 绑定自定义的layout
			ImageButton imgBtn = (ImageButton) view.findViewById(R.id.icon);
			TextView textView = (TextView) view.findViewById(R.id.text);
			
			Integer iconFileId = (Integer)(mData.get(position).get("iconFileId"));
			final String iconTitle = (String)(mData.get(position).get("iconTitle"));
			final String className = (String)(mData.get(position).get("className"));
			final String packageName = (String)(mData.get(position).get("packageName"));
			
			imgBtn.setImageResource(iconFileId);// 设置图片
			textView.setText(iconTitle);// 设置标题
			
			imgBtn.setOnClickListener(new OnClickListener() {
				public void onClick(View arg0) {
					if (packageName != null && packageName.length() != 0 
							&& className != null && className.length() != 0) {
						itemClickOper(packageName, className);
					}
				}
			});
			return view;
		}
		
		private void itemClickOper(String pkgName, String clsName) {
			Intent newIntent = new Intent();
			ComponentName comp = new ComponentName(pkgName, clsName);
			newIntent.setComponent(comp);
			mContext.startActivity(newIntent); 
		}
	}
}
